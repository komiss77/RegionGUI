/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  net.crytec.shaded.org.apache.commons.io.FileUtils
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.configuration.serialization.ConfigurationSerializable
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 */
package net.crytec.RegionGUI.manager;

import com.google.common.collect.Maps;
import java.io.File;
import java.io.IOException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.logging.Logger;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.shaded.org.apache.commons.io.FileUtils;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;

public class ClaimManager
implements Listener {
    private final RegionGUI plugin;
    private final LinkedHashMap<UUID, RegionClaim> templates = Maps.newLinkedHashMap();
    private final File templateFolder;

    public ClaimManager(RegionGUI regionGUI) {
        File file;
        this.plugin = regionGUI;
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)regionGUI);
        this.templateFolder = file = new File(this.plugin.getDataFolder(), "templates");
        if (!this.templateFolder.exists()) {
            this.templateFolder.mkdir();
        }
        this.loadTemplates();
    }

    public void registerTemplate(RegionClaim regionClaim) {
        this.templates.put(regionClaim.getId(), regionClaim);
    }

    public Set<RegionClaim> getTemplates(World world) {
        return this.templates.values().stream().filter(regionClaim -> regionClaim.getWorld().isPresent()).filter(regionClaim -> regionClaim.getWorld().get().equals((Object)world)).collect(Collectors.toSet());
    }

    public Optional<RegionClaim> getByName(World world, String string) {
        return this.templates.values().stream().filter(regionClaim -> regionClaim.getWorld().isPresent()).filter(regionClaim -> regionClaim.getWorld().get().equals((Object)world) && regionClaim.getDisplayname().equals(string)).findFirst();
    }

    public RegionClaim getClaimByID(UUID uUID) {
        return this.templates.get(uUID);
    }

    public void deleteTemplate(RegionClaim regionClaim) {
        this.templates.remove(regionClaim.getId());
        File file = new File(this.templateFolder, String.valueOf(regionClaim.getId().toString()) + ".claim");
        if (file.exists()) {
            file.delete();
        }
        RegionGUI.getInstance().getPlayerManager().getPlayerdata().values().forEach(set -> set.removeIf(claimEntry -> claimEntry.getTemplate().equals(regionClaim)));
    }

    public void loadTemplates() {
        Iterator iterator = FileUtils.iterateFiles((File)this.templateFolder, (String[])new String[]{"claim"}, (boolean)false);
        while (iterator.hasNext()) {
            File file = (File)iterator.next();
            try {
                YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
                RegionClaim regionClaim = (RegionClaim)yamlConfiguration.getSerializable("data", RegionClaim.class);
                this.templates.put(regionClaim.getId(), regionClaim);
            }
            catch (Exception exception) {
                RegionGUI.getInstance().getLogger().severe("Failed to load template from file " + file.getName());
                exception.printStackTrace();
            }
        }
    }

    public void save() {
        for (RegionClaim regionClaim : this.templates.values()) {
            try {
                File file = new File(this.templateFolder, String.valueOf(regionClaim.getId().toString()) + ".claim");
                if (!file.exists()) {
                    file.createNewFile();
                }
                YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
                yamlConfiguration.set("data", (Object)regionClaim);
                yamlConfiguration.save(file);
            }
            catch (IOException iOException) {
                RegionGUI.getInstance().getLogger().severe("Failed to save template to disk!");
            }
        }
    }
}


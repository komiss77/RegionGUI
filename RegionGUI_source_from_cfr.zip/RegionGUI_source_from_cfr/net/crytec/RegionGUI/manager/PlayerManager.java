/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.google.common.collect.Maps
 *  com.google.common.collect.Sets
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.shaded.org.apache.commons.io.FileUtils
 *  org.bukkit.Bukkit
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 *  org.bukkit.event.player.PlayerJoinEvent
 *  org.bukkit.event.player.PlayerQuitEvent
 *  org.bukkit.plugin.Plugin
 */
package net.crytec.RegionGUI.manager;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.logging.Logger;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.shaded.org.apache.commons.io.FileUtils;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.Plugin;

public class PlayerManager
implements Listener {
    private final HashMap<UUID, Set<ClaimEntry>> playerdata = Maps.newHashMap();
    private final File folder;

    public PlayerManager(RegionGUI regionGUI, ClaimManager claimManager) {
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)regionGUI);
        this.folder = new File(regionGUI.getDataFolder(), "data");
        if (!this.folder.exists()) {
            this.folder.mkdir();
        }
        Bukkit.getOnlinePlayers().forEach(player -> this.loadPlayerFiles(player.getUniqueId()));
        Iterator iterator = FileUtils.iterateFiles((File)this.folder, (String[])new String[]{"data"}, (boolean)false);
        while (iterator.hasNext()) {
            File file = (File)iterator.next();
            UUID uUID = UUID.fromString(file.getName().replace(".data", ""));
            this.loadPlayerFiles(uUID);
        }
        regionGUI.getLogger().info("Loading " + this.playerdata.size() + " playerfiles...");
    }

    public void saveOnDisable() {
        Bukkit.getOnlinePlayers().forEach(player -> this.savePlayerFiles(player.getUniqueId()));
        this.playerdata.clear();
    }

    public Set<ClaimEntry> getPlayerClaims(UUID uUID) {
        return this.playerdata.get(uUID);
    }

    public void addClaimToPlayer(UUID uUID, ProtectedRegion protectedRegion, RegionClaim regionClaim) {
        this.playerdata.get(uUID).add(new ClaimEntry(protectedRegion.getId(), regionClaim, System.currentTimeMillis()));
    }

    public void deleteClaim(UUID uUID, ProtectedRegion protectedRegion) {
        this.playerdata.get(uUID).removeIf(claimEntry -> claimEntry.getProtectedRegion().get().equals((Object)protectedRegion));
        this.savePlayerFiles(uUID);
    }

    public void loadPlayerFiles(UUID uUID) {
        File file = new File(this.folder, String.valueOf(uUID.toString()) + ".data");
        if (!file.exists()) {
            this.playerdata.put(uUID, Sets.newHashSet());
            return;
        }
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        List list = yamlConfiguration.getList("data");
        this.playerdata.put(uUID, Sets.newHashSet((Iterable)list));
        RegionGUI.getInstance().getLogger().info("Loaded " + this.playerdata.get(uUID).size() + " templates for player " + uUID.toString());
        Iterator<ClaimEntry> iterator = this.getPlayerClaims(uUID).iterator();
        while (iterator.hasNext()) {
            ClaimEntry claimEntry = iterator.next();
            if (claimEntry == null) {
                RegionGUI.getInstance().getLogger().severe("Failed to load player claims for user: " + uUID.toString() + " (" + Bukkit.getOfflinePlayer((UUID)uUID).getName() + ")");
                continue;
            }
            if (claimEntry.getTemplate() == null) {
                iterator.remove();
                RegionGUI.getInstance().getLogger().severe("Removed claim for player " + uUID.toString() + " because the given template does no longer exist.");
                continue;
            }
            if (claimEntry.getProtectedRegion() != null && claimEntry.getProtectedRegion().isPresent()) continue;
            iterator.remove();
            RegionGUI.getInstance().getLogger().severe("Removed claim for player " + uUID.toString() + " because the WorldGuard region does no longer exist.");
        }
    }

    public void savePlayerFiles(UUID uUID) {
        if (this.playerdata.get(uUID).isEmpty()) {
            File file = new File(this.folder, String.valueOf(uUID.toString()) + ".data");
            if (file.exists()) {
                file.delete();
            }
            return;
        }
        File file = new File(this.folder, String.valueOf(uUID.toString()) + ".data");
        YamlConfiguration yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        ArrayList arrayList = Lists.newArrayList((Iterable)this.playerdata.get(uUID));
        yamlConfiguration.set("data", (Object)arrayList);
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent playerJoinEvent) {
        if (!this.playerdata.containsKey(playerJoinEvent.getPlayer().getUniqueId())) {
            this.playerdata.put(playerJoinEvent.getPlayer().getUniqueId(), Sets.newHashSet());
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent playerQuitEvent) {
        this.savePlayerFiles(playerQuitEvent.getPlayer().getUniqueId());
    }

    public void saveImportedData() {
        this.playerdata.keySet().forEach(uUID -> this.savePlayerFiles((UUID)uUID));
    }

    public HashMap<UUID, Set<ClaimEntry>> getPlayerdata() {
        return this.playerdata;
    }
}


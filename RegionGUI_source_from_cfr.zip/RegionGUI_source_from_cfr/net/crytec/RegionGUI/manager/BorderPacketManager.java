/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.wrappers.EnumWrappers
 *  com.comphenix.protocol.wrappers.EnumWrappers$WorldBorderAction
 *  net.crytec.phoenix.api.utils.UtilLoc
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.WorldBorder
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package net.crytec.RegionGUI.manager;

import com.comphenix.protocol.wrappers.EnumWrappers;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.utils.packets.WrapperPlayServerWorldBorder;
import net.crytec.phoenix.api.utils.UtilLoc;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class BorderPacketManager {
    private final RegionGUI plugin;
    private final Location center;
    private final int size;
    private final WrapperPlayServerWorldBorder centerPacket;
    private final WrapperPlayServerWorldBorder sizePacket;
    private final WrapperPlayServerWorldBorder resetcenterPacket;
    private final WrapperPlayServerWorldBorder resetsizePacket;

    public BorderPacketManager(RegionGUI regionGUI, Location location, RegionClaim regionClaim) {
        this.plugin = regionGUI;
        this.center = UtilLoc.getCenter((Location)location).clone();
        this.size = regionClaim.getSize() + 1;
        this.centerPacket = new WrapperPlayServerWorldBorder();
        this.sizePacket = new WrapperPlayServerWorldBorder();
        this.resetcenterPacket = new WrapperPlayServerWorldBorder();
        this.resetsizePacket = new WrapperPlayServerWorldBorder();
        this.buildPackets();
    }

    private void buildPackets() {
        World world = this.center.getWorld();
        this.resetsizePacket.setRadius(world.getWorldBorder().getSize());
        this.resetsizePacket.setOldRadius(world.getWorldBorder().getSize());
        this.resetsizePacket.setSpeed(0L);
        this.resetsizePacket.setAction(EnumWrappers.WorldBorderAction.LERP_SIZE);
        this.resetcenterPacket.setCenterX(world.getWorldBorder().getCenter().getBlockX());
        this.resetcenterPacket.setCenterZ(world.getWorldBorder().getCenter().getBlockZ());
        this.resetcenterPacket.setAction(EnumWrappers.WorldBorderAction.SET_CENTER);
        this.sizePacket.setRadius(this.size);
        this.sizePacket.setOldRadius(this.size);
        this.sizePacket.setSpeed(0L);
        this.sizePacket.setAction(EnumWrappers.WorldBorderAction.LERP_SIZE);
        this.centerPacket.setCenterX(this.center.getX());
        this.centerPacket.setCenterZ(this.center.getZ());
        this.centerPacket.setAction(EnumWrappers.WorldBorderAction.SET_CENTER);
    }

    public void sendReset(Player player) {
        this.resetcenterPacket.sendPacket(player);
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.resetsizePacket.sendPacket(player), 1L);
    }

    public void send(Player player) {
        this.centerPacket.sendPacket(player);
        Bukkit.getScheduler().runTaskLater((Plugin)this.plugin, () -> this.sizePacket.sendPacket(player), 1L);
    }
}


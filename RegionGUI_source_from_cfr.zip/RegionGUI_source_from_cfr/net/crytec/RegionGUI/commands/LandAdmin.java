/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.acf.BaseCommand
 *  net.crytec.acf.CommandHelp
 *  net.crytec.acf.CommandIssuer
 *  net.crytec.acf.annotation.CommandAlias
 *  net.crytec.acf.annotation.CommandPermission
 *  net.crytec.acf.annotation.Default
 *  net.crytec.acf.annotation.Description
 *  net.crytec.acf.annotation.Subcommand
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 */
package net.crytec.RegionGUI.commands;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.UUID;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.menus.admin.AdminTemplateList;
import net.crytec.acf.BaseCommand;
import net.crytec.acf.CommandHelp;
import net.crytec.acf.CommandIssuer;
import net.crytec.acf.annotation.CommandAlias;
import net.crytec.acf.annotation.CommandPermission;
import net.crytec.acf.annotation.Default;
import net.crytec.acf.annotation.Description;
import net.crytec.acf.annotation.Subcommand;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

@CommandAlias(value="landadmin")
@CommandPermission(value="region.admin")
public class LandAdmin
extends BaseCommand {
    private final RegionGUI plugin;

    public LandAdmin(RegionGUI regionGUI) {
        this.plugin = regionGUI;
    }

    @Default
    public void openEditor(Player player) {
        SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("\u00a78Template Editor [" + player.getWorld().getName() + "]").build().open(player);
    }

    @Subcommand(value="editor")
    @Description(value="Opens the land template editor")
    public void landAdminCommand(Player player) {
        SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("\u00a78Template Editor [" + player.getWorld().getName() + "]").build().open(player);
    }

    @Subcommand(value="addregion")
    @Description(value="Adds a defined worldguard region to a player with a given template, regardless of size or checks. This is a forced action.")
    public void forceAdd(Player player, OfflinePlayer offlinePlayer, ProtectedRegion protectedRegion, RegionClaim regionClaim) {
        this.plugin.getPlayerManager().addClaimToPlayer(offlinePlayer.getUniqueId(), protectedRegion, regionClaim);
        player.sendMessage("\u00a77Assigned region to player. Please note this is a forced action and no size/permission check apply.");
    }

    @Subcommand(value="help")
    public void sendCommandHelp(CommandIssuer commandIssuer, CommandHelp commandHelp) {
        commandHelp.showHelp(commandIssuer);
    }
}


/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.crytec.acf.BaseCommand
 */
package net.crytec.RegionGUI.commands;

import net.crytec.acf.BaseCommand;

public class LandPurge
extends BaseCommand {
}


/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.world.World
 *  com.sk89q.worldguard.LocalPlayer
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.bukkit.WorldGuardPlugin
 *  com.sk89q.worldguard.internal.platform.WorldGuardPlatform
 *  com.sk89q.worldguard.protection.ApplicableRegionSet
 *  com.sk89q.worldguard.protection.managers.RegionManager
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  com.sk89q.worldguard.protection.regions.RegionContainer
 *  net.crytec.acf.BaseCommand
 *  net.crytec.acf.CommandHelp
 *  net.crytec.acf.CommandIssuer
 *  net.crytec.acf.annotation.CommandAlias
 *  net.crytec.acf.annotation.CommandPermission
 *  net.crytec.acf.annotation.Default
 *  net.crytec.acf.annotation.Optional
 *  net.crytec.acf.annotation.Subcommand
 *  net.crytec.acf.bukkit.contexts.OnlinePlayer
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 */
package net.crytec.RegionGUI.commands;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.menus.LandBuyMenu;
import net.crytec.RegionGUI.menus.LandHomeMenu;
import net.crytec.RegionGUI.menus.RegionManageInterface;
import net.crytec.RegionGUI.menus.RegionSelectMenu;
import net.crytec.acf.BaseCommand;
import net.crytec.acf.CommandHelp;
import net.crytec.acf.CommandIssuer;
import net.crytec.acf.annotation.CommandAlias;
import net.crytec.acf.annotation.CommandPermission;
import net.crytec.acf.annotation.Default;
import net.crytec.acf.annotation.Optional;
import net.crytec.acf.annotation.Subcommand;
import net.crytec.acf.bukkit.contexts.OnlinePlayer;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

@CommandAlias(value="land")
public class LandCommand
extends BaseCommand {
    private final PlayerManager manager;
    private final RegionGUI plugin;

    public LandCommand(RegionGUI regionGUI, PlayerManager playerManager) {
        this.plugin = regionGUI;
        this.manager = playerManager;
    }

    @Default
    public void openLandInterface(Player player) {
        if (!this.plugin.getConfig().getStringList("enabled_worlds").contains(player.getWorld().getName())) {
            player.sendMessage(Language.ERROR_WORLD_DISABLED.toChatString());
            return;
        }
        this.checkForRegions(player);
    }

    @Subcommand(value="help")
    public void sendCommandHelp(CommandIssuer commandIssuer, CommandHelp commandHelp) {
        commandHelp.showHelp(commandIssuer);
    }

    @Subcommand(value="home")
    public void openHomeGUI(Player player) {
        SmartInventory.builder().id("home-" + player.getName()).provider((InventoryProvider)new LandHomeMenu()).size(5, 9).title(Language.INTERFACE_HOME_TITLE.toString()).build().open(player);
    }

    @Subcommand(value="list")
    @CommandPermission(value="region.list")
    public void displayLandList(Player player, @Optional OnlinePlayer onlinePlayer) {
        if (onlinePlayer == null) {
            Set<ClaimEntry> set = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId());
            for (ClaimEntry claimEntry : set) {
                String string = claimEntry.getTemplate().getDisplayname();
                String string2 = claimEntry.getRegionID();
                player.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", string2).replace("%template%", string));
            }
            return;
        }
        Set<ClaimEntry> set = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId());
        for (ClaimEntry claimEntry : set) {
            String string = claimEntry.getTemplate().getDisplayname();
            String string3 = claimEntry.getRegionID();
            player.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", string3).replace("%template%", string));
        }
    }

    private void checkForRegions(Player player) {
        RegionManager regionManager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)player.getWorld()));
        ApplicableRegionSet applicableRegionSet = regionManager.getApplicableRegions(BukkitAdapter.asBlockVector((Location)player.getLocation()));
        LocalPlayer localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
        Iterator iterator = applicableRegionSet.iterator();
        if (applicableRegionSet.size() == 0) {
            if (!player.hasPermission("region.claim")) {
                player.sendMessage(Language.ERROR_NO_PERMISSION.toChatString());
                return;
            }
            SmartInventory.builder().id("regiongui.claim").provider((InventoryProvider)new LandBuyMenu(this.plugin)).size(3, 9).title(Language.INTERFACE_BUY_TITLE.toString()).build().open(player);
            return;
        }
        if (applicableRegionSet.size() == 1) {
            ProtectedRegion protectedRegion = (ProtectedRegion)iterator.next();
            Set<ClaimEntry> set = this.manager.getPlayerClaims(player.getUniqueId());
            if (set == null) {
                player.sendMessage("\u00a7cYou don't own any claims in this world.");
                return;
            }
            Set set2 = set.stream().map(claimEntry -> claimEntry.getRegionID()).collect(Collectors.toSet());
            if (protectedRegion.isOwner(localPlayer) && set2.contains(protectedRegion.getId()) || player.hasPermission("region.mod")) {
                java.util.Optional<ClaimEntry> optional = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId()).stream().filter(claimEntry -> claimEntry.getRegionID().equals(protectedRegion.getId())).findFirst();
                if (!optional.isPresent()) {
                    player.sendMessage(Language.ERROR_NO_REGION_FOUND.toChatString());
                    return;
                }
                SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(optional.get())).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player);
            } else {
                player.sendMessage(Language.ERROR_NOT_OWNER.toChatString());
            }
            return;
        }
        if (applicableRegionSet.size() > 1) {
            Set set = this.manager.getPlayerClaims(player.getUniqueId()).stream().map(claimEntry -> claimEntry.getRegionID()).collect(Collectors.toSet());
            Set<ClaimEntry> set3 = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId()).stream().filter(claimEntry -> set.contains(claimEntry.getRegionID())).collect(Collectors.toSet());
            SmartInventory.builder().id("regiongui.regionselect").provider((InventoryProvider)new RegionSelectMenu(set3)).size(3).title(Language.INTERFACE_SELECT_TITLE.toString()).build().open(player);
            return;
        }
    }
}


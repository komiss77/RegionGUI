/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.configuration.serialization.ConfigurationSerializable
 *  org.bukkit.configuration.serialization.SerializableAs
 *  org.bukkit.inventory.ItemStack
 */
package net.crytec.RegionGUI.data;

import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;
import java.util.logging.Logger;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.inventory.ItemStack;

@SerializableAs(value="Template")
public class RegionClaim
implements ConfigurationSerializable,
Comparable<RegionClaim> {
    private final UUID id;
    private String displayname = "Default displayname";
    private Material icon = Material.BARRIER;
    private List<String> description = Arrays.asList("\u00a77Default description");
    private int size = 10;
    private String world;
    private int height = 256;
    private int depth = 256;
    private int price = -1;
    private int refund = 0;
    private Material borderMaterial = Material.OAK_FENCE;
    private boolean generateBorder = true;
    private List<String> runCommands = new ArrayList<String>();
    private String permission = "";
    private List<String> noPermDescription = Arrays.asList("Upgrade your rank to purchase this template.");

    public RegionClaim(World world) {
        this.id = UUID.randomUUID();
        this.size = 10;
        this.world = world.getName();
    }

    private RegionClaim(UUID uUID) {
        this.id = uUID;
    }

    public ItemStack getIcon() {
        return new ItemBuilder(this.icon).name(this.displayname).build();
    }

    public void setNoPermDescription(List<String> list) {
        this.noPermDescription = list.stream().map(string -> ChatColor.translateAlternateColorCodes((char)'&', (String)string)).collect(Collectors.toList());
    }

    public boolean hasRefund() {
        return this.refund > 0;
    }

    public Optional<World> getWorld() {
        return Optional.ofNullable(Bukkit.getWorld((String)this.world));
    }

    public int hashCode() {
        return Objects.hash(this.id);
    }

    public boolean equals(Object object) {
        if (this == object) {
            return true;
        }
        if (object == null) {
            return false;
        }
        if (!(object instanceof RegionClaim)) {
            return false;
        }
        RegionClaim regionClaim = (RegionClaim)object;
        return Objects.equals(this.id, regionClaim.id);
    }

    public Map<String, Object> serialize() {
        HashMap hashMap = Maps.newHashMap();
        hashMap.put("id", this.id.toString());
        hashMap.put("gui.displayname", this.displayname);
        hashMap.put("gui.icon", this.icon.toString());
        hashMap.put("gui.description", this.description);
        hashMap.put("gui.noPermDescription", this.noPermDescription);
        hashMap.put("data.size", this.size);
        hashMap.put("data.heigth", this.height);
        hashMap.put("data.depth", this.depth);
        hashMap.put("data.price", this.price);
        hashMap.put("data.refund", this.refund);
        hashMap.put("data.world", this.world);
        hashMap.put("data.permission", this.permission);
        hashMap.put("border.material", this.borderMaterial.toString());
        hashMap.put("border.enabled", this.generateBorder);
        hashMap.put("generation.runCommands", this.runCommands);
        return hashMap;
    }

    public static RegionClaim deserialize(Map<String, Object> map) {
        RegionClaim regionClaim = new RegionClaim(UUID.fromString((String)map.get("id")));
        regionClaim.setDisplayname((String)map.get("gui.displayname"));
        regionClaim.setIcon(Material.valueOf((String)((String)map.get("gui.icon"))));
        regionClaim.setDescription((List)map.get("gui.description"));
        regionClaim.setNoPermDescription((List)map.get("gui.noPermDescription"));
        regionClaim.setSize((Integer)map.get("data.size"));
        regionClaim.setHeight((Integer)map.get("data.heigth"));
        regionClaim.setDepth((Integer)map.get("data.depth"));
        regionClaim.setPrice((Integer)map.get("data.price"));
        regionClaim.setRefund((Integer)map.get("data.refund"));
        regionClaim.setWorld((String)map.get("data.world"));
        regionClaim.setPermission((String)map.getOrDefault("data.permission", ""));
        regionClaim.setBorderMaterial(Material.valueOf((String)((String)map.get("border.material"))));
        regionClaim.setGenerateBorder((Boolean)map.get("border.enabled"));
        regionClaim.setRunCommands((List)map.get("generation.runCommands"));
        Bukkit.getServer().getLogger().info("Loaded Template ID " + regionClaim.getId() + " - " + regionClaim.getDisplayname());
        return regionClaim;
    }

    @Override
    public int compareTo(RegionClaim regionClaim) {
        return this.size > regionClaim.getSize() ? 1 : (this.size < regionClaim.getSize() ? -1 : 0);
    }

    public UUID getId() {
        return this.id;
    }

    public String getDisplayname() {
        return this.displayname;
    }

    public void setDisplayname(String string) {
        this.displayname = string;
    }

    public void setIcon(Material material) {
        this.icon = material;
    }

    public List<String> getDescription() {
        return this.description;
    }

    public void setDescription(List<String> list) {
        this.description = list;
    }

    public int getSize() {
        return this.size;
    }

    public void setSize(int n) {
        this.size = n;
    }

    public void setWorld(String string) {
        this.world = string;
    }

    public int getHeight() {
        return this.height;
    }

    public void setHeight(int n) {
        this.height = n;
    }

    public int getDepth() {
        return this.depth;
    }

    public void setDepth(int n) {
        this.depth = n;
    }

    public int getPrice() {
        return this.price;
    }

    public void setPrice(int n) {
        this.price = n;
    }

    public int getRefund() {
        return this.refund;
    }

    public void setRefund(int n) {
        this.refund = n;
    }

    public Material getBorderMaterial() {
        return this.borderMaterial;
    }

    public void setBorderMaterial(Material material) {
        this.borderMaterial = material;
    }

    public boolean isGenerateBorder() {
        return this.generateBorder;
    }

    public void setGenerateBorder(boolean bl) {
        this.generateBorder = bl;
    }

    public List<String> getRunCommands() {
        return this.runCommands;
    }

    public void setRunCommands(List<String> list) {
        this.runCommands = list;
    }

    public String getPermission() {
        return this.permission;
    }

    public void setPermission(String string) {
        this.permission = string;
    }

    public List<String> getNoPermDescription() {
        return this.noPermDescription;
    }

    public String toString() {
        return "RegionClaim(id=" + this.getId() + ", displayname=" + this.getDisplayname() + ", icon=" + (Object)this.getIcon() + ", description=" + this.getDescription() + ", size=" + this.getSize() + ", world=" + this.getWorld() + ", height=" + this.getHeight() + ", depth=" + this.getDepth() + ", price=" + this.getPrice() + ", refund=" + this.getRefund() + ", borderMaterial=" + (Object)this.getBorderMaterial() + ", generateBorder=" + this.isGenerateBorder() + ", runCommands=" + this.getRunCommands() + ", permission=" + this.getPermission() + ", noPermDescription=" + this.getNoPermDescription() + ")";
    }
}


/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Maps
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.world.World
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.internal.platform.WorldGuardPlatform
 *  com.sk89q.worldguard.protection.managers.RegionManager
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  com.sk89q.worldguard.protection.regions.RegionContainer
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.configuration.serialization.ConfigurationSerializable
 *  org.bukkit.configuration.serialization.SerializableAs
 */
package net.crytec.RegionGUI.data;

import com.google.common.collect.Maps;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.ClaimManager;
import org.bukkit.Bukkit;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;

@SerializableAs(value="PlayerClaim")
public class ClaimEntry
implements ConfigurationSerializable {
    final String regionID;
    final RegionClaim template;
    final long timestamp;
    private transient Optional<ProtectedRegion> protectedRegion;

    public ClaimEntry(String string, RegionClaim regionClaim, long l) {
        this.regionID = string;
        this.template = regionClaim;
        this.timestamp = l;
        if (!this.template.getWorld().isPresent()) {
            Bukkit.getLogger().severe("Failed to load template - World does not exist!");
            return;
        }
        org.bukkit.World world = this.template.getWorld().get();
        ProtectedRegion protectedRegion = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)world)).getRegion(this.regionID);
        if (protectedRegion == null) {
            RegionGUI.getInstance().getLogger().info("Region " + string + " in world " + this.template.getWorld() + " does no longer exist!");
        }
        this.protectedRegion = Optional.ofNullable(protectedRegion);
    }

    public Optional<ProtectedRegion> getProtectedRegion() {
        if (this.protectedRegion != null) {
            return this.protectedRegion;
        }
        if (!this.template.getWorld().isPresent()) {
            Bukkit.getLogger().severe("Failed to parse Region " + this.regionID + "  - World is no longer loaded!");
            return Optional.empty();
        }
        org.bukkit.World world = this.template.getWorld().get();
        ProtectedRegion protectedRegion = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)world)).getRegion(this.regionID);
        if (protectedRegion == null) {
            RegionGUI.getInstance().getLogger().info("Region " + this.regionID + " in world " + world.getName() + " does no longer exist!");
        }
        this.protectedRegion = Optional.ofNullable(protectedRegion);
        return this.protectedRegion;
    }

    public Map<String, Object> serialize() {
        HashMap hashMap = Maps.newHashMap();
        hashMap.put("template", this.template.getId().toString());
        hashMap.put("timestamp", this.timestamp);
        hashMap.put("region", this.regionID);
        return hashMap;
    }

    public static ClaimEntry deserialize(Map<String, Object> map) {
        String string = (String)map.get("region");
        UUID uUID = UUID.fromString((String)map.get("template"));
        long l = (Long)map.get("timestamp");
        RegionClaim regionClaim = RegionGUI.getInstance().getClaimManager().getClaimByID(uUID);
        if (regionClaim == null) {
            RegionGUI.getInstance().getLogger().severe("Failed to claim! Template does no longer exist!");
            return null;
        }
        return new ClaimEntry(string, regionClaim, l);
    }

    public String getRegionID() {
        return this.regionID;
    }

    public RegionClaim getTemplate() {
        return this.template;
    }

    public long getTimestamp() {
        return this.timestamp;
    }
}


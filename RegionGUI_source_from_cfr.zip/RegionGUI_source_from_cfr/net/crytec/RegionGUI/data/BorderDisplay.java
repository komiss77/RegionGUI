/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.wrappers.EnumWrappers
 *  com.comphenix.protocol.wrappers.EnumWrappers$WorldBorderAction
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.math.Vector3
 *  com.sk89q.worldedit.regions.CuboidRegion
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.World
 *  org.bukkit.WorldBorder
 *  org.bukkit.entity.Player
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package net.crytec.RegionGUI.data;

import com.comphenix.protocol.wrappers.EnumWrappers;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.math.Vector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Optional;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.utils.packets.WrapperPlayServerWorldBorder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class BorderDisplay
implements Runnable {
    private final WrapperPlayServerWorldBorder resetcenterPacket;
    private final WrapperPlayServerWorldBorder resetsizePacket;
    private final WrapperPlayServerWorldBorder centerPacket;
    private final WrapperPlayServerWorldBorder sizePacket;
    private final Player player;
    private final int size;
    private final BukkitTask task;

    public BorderDisplay(Player player, ClaimEntry claimEntry) {
        this.player = player;
        World world = player.getWorld();
        this.size = claimEntry.getTemplate().getSize();
        this.resetcenterPacket = new WrapperPlayServerWorldBorder();
        this.resetsizePacket = new WrapperPlayServerWorldBorder();
        this.resetsizePacket.setRadius(world.getWorldBorder().getSize());
        this.resetsizePacket.setOldRadius(world.getWorldBorder().getSize());
        this.resetsizePacket.setSpeed(0L);
        this.resetsizePacket.setAction(EnumWrappers.WorldBorderAction.LERP_SIZE);
        CuboidRegion cuboidRegion = new CuboidRegion(claimEntry.getProtectedRegion().get().getMinimumPoint(), claimEntry.getProtectedRegion().get().getMaximumPoint());
        this.resetcenterPacket.setCenterX(world.getWorldBorder().getCenter().getBlockX());
        this.resetcenterPacket.setCenterZ(world.getWorldBorder().getCenter().getBlockZ());
        this.resetcenterPacket.setAction(EnumWrappers.WorldBorderAction.SET_CENTER);
        this.centerPacket = new WrapperPlayServerWorldBorder();
        this.sizePacket = new WrapperPlayServerWorldBorder();
        this.sizePacket.setRadius(this.size);
        this.sizePacket.setOldRadius(this.size);
        this.sizePacket.setSpeed(0L);
        this.sizePacket.setAction(EnumWrappers.WorldBorderAction.LERP_SIZE);
        Location location = BukkitAdapter.adapt((World)player.getWorld(), (Vector3)cuboidRegion.getCenter()).clone().add(0.5, 0.0, 0.5);
        this.centerPacket.setCenterX(location.getX());
        this.centerPacket.setCenterZ(location.getZ());
        this.centerPacket.setAction(EnumWrappers.WorldBorderAction.SET_CENTER);
        this.centerPacket.sendPacket(this.player);
        Bukkit.getScheduler().runTaskLater((Plugin)RegionGUI.getInstance(), () -> this.sizePacket.sendPacket(this.player), 1L);
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)RegionGUI.getInstance(), (Runnable)this, 5L, 20L);
    }

    public void reset() {
        this.resetcenterPacket.sendPacket(this.player);
        Bukkit.getScheduler().runTaskLater((Plugin)RegionGUI.getInstance(), () -> this.resetsizePacket.sendPacket(this.player), 1L);
    }

    @Override
    public void run() {
        if (!this.player.isOnline() || this.player.isSneaking()) {
            this.task.cancel();
            this.reset();
            this.player.resetTitle();
            return;
        }
        this.player.sendTitle("", Language.PREVIEW_CANCEL.toString(), 0, 30, 0);
    }
}


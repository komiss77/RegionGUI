/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.world.World
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.internal.platform.WorldGuardPlatform
 *  com.sk89q.worldguard.protection.managers.RegionManager
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  com.sk89q.worldguard.protection.regions.RegionContainer
 *  net.crytec.acf.BaseCommand
 *  net.crytec.acf.BukkitCommandExecutionContext
 *  net.crytec.acf.BukkitCommandIssuer
 *  net.crytec.acf.BukkitCommandManager
 *  net.crytec.acf.CommandContexts
 *  net.crytec.acf.CommandExecutionContext
 *  net.crytec.acf.CommandIssuer
 *  net.crytec.acf.InvalidCommandArgument
 *  net.crytec.acf.contexts.ContextResolver
 *  net.crytec.phoenix.api.PhoenixAPI
 *  net.crytec.phoenix.api.chat.program.ChatEditorCore
 *  net.milkbowl.vault.economy.Economy
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Server
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.configuration.file.YamlConfiguration
 *  org.bukkit.configuration.serialization.ConfigurationSerialization
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Listener
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.PluginManager
 *  org.bukkit.plugin.RegisteredServiceProvider
 *  org.bukkit.plugin.ServicesManager
 *  org.bukkit.plugin.java.JavaPlugin
 */
package net.crytec.RegionGUI;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.function.Predicate;
import java.util.logging.Logger;
import java.util.stream.Stream;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.commands.LandAdmin;
import net.crytec.RegionGUI.commands.LandCommand;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.listener.RegionPurchaseListener;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.metrics.Metrics;
import net.crytec.RegionGUI.utils.flags.FlagManager;
import net.crytec.acf.BaseCommand;
import net.crytec.acf.BukkitCommandExecutionContext;
import net.crytec.acf.BukkitCommandIssuer;
import net.crytec.acf.BukkitCommandManager;
import net.crytec.acf.CommandContexts;
import net.crytec.acf.CommandExecutionContext;
import net.crytec.acf.CommandIssuer;
import net.crytec.acf.InvalidCommandArgument;
import net.crytec.acf.contexts.ContextResolver;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.chat.program.ChatEditorCore;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Server;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicesManager;
import org.bukkit.plugin.java.JavaPlugin;

public final class RegionGUI
extends JavaPlugin {
    private static RegionGUI instance;
    public final Logger log = Bukkit.getLogger();
    public static Economy econ;
    private FlagManager flagmanager;
    private ClaimManager claimManager;
    private PlayerManager playerManager;
    public static String USER;

    static {
        econ = null;
        USER = "38105";
        ConfigurationSerialization.registerClass(RegionClaim.class, (String)"Template");
        ConfigurationSerialization.registerClass(ClaimEntry.class, (String)"PlayerClaim");
    }

    public void onLoad() {
        instance = this;
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdir();
        }
        File file = new File(this.getDataFolder(), "config.yml");
        try {
            if (!file.exists()) {
                file.createNewFile();
                this.saveResource("config.yml", true);
                this.log("\u00a72Setup - New default configuration has been written.");
            }
        }
        catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void onEnable() {
        RegionGUI.loadConfig0();
        if (!this.setupEconomy()) {
            this.log("\u00a7cNo Vault Compatible Economy Plugin found! Cannot load RegionGUI", true);
            Bukkit.getPluginManager().disablePlugin((Plugin)this);
        }
        if (!PhoenixAPI.get().requireAPIVersion((JavaPlugin)this, 108)) {
            Bukkit.getPluginManager().disablePlugin((Plugin)this);
            return;
        }
        this.loadLanguage();
        BukkitCommandManager bukkitCommandManager = new BukkitCommandManager((Plugin)this);
        new net.crytec.phoenix.api.chat.program.ChatEditorCore((JavaPlugin)this);
        bukkitCommandManager.getCommandContexts().registerContext(ProtectedRegion.class, bukkitCommandExecutionContext -> {
            org.bukkit.World world = ((BukkitCommandIssuer)bukkitCommandExecutionContext.getIssuer()).getPlayer().getWorld();
            String string = bukkitCommandExecutionContext.popFirstArg();
            ProtectedRegion protectedRegion = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)world)).getRegion(string);
            if (protectedRegion == null) {
                throw new InvalidCommandArgument("Could not find an region with that name in your current world.");
            }
            return protectedRegion;
        });
        bukkitCommandManager.getCommandContexts().registerContext(RegionClaim.class, bukkitCommandExecutionContext -> {
            org.bukkit.World world = ((BukkitCommandIssuer)bukkitCommandExecutionContext.getIssuer()).getPlayer().getWorld();
            String string = bukkitCommandExecutionContext.popFirstArg();
            Optional<RegionClaim> optional = this.getClaimManager().getTemplates(world).stream().filter(regionClaim -> ChatColor.stripColor((String)regionClaim.getDisplayname()).equals(string)).findFirst();
            if (!optional.isPresent()) {
                throw new InvalidCommandArgument("Could not find a template with that name in your current world.");
            }
            return optional.get();
        });
        this.flagmanager = new FlagManager(this);
        this.claimManager = new ClaimManager(this);
        this.playerManager = new PlayerManager(this, this.claimManager);
        Bukkit.getPluginManager().registerEvents((Listener)new RegionPurchaseListener(), (Plugin)this);
        bukkitCommandManager.registerCommand((BaseCommand)new LandCommand(this, this.playerManager));
        bukkitCommandManager.registerCommand((BaseCommand)new LandAdmin(this));
        bukkitCommandManager.enableUnstableAPI("help");
        Metrics metrics = new Metrics(this);
        metrics.addCustomChart(new Metrics.SimplePie("purges_enabled", () -> this.getConfig().getBoolean("deleteOnPurge") ? "Enabled" : "Disabled"));
        metrics.addCustomChart(new Metrics.SimplePie("preview_mode", () -> this.getConfig().getBoolean("enable_previewmode") ? "Enabled" : "Disabled"));
        metrics.addCustomChart(new Metrics.SimplePie("economy", () -> econ.getName() != null ? econ.getName() : "Unknown"));
    }

    public void onDisable() {
        if (this.getPlayerManager() != null) {
            this.getPlayerManager().saveOnDisable();
        }
        if (this.claimManager != null) {
            this.claimManager.save();
        }
    }

    public static RegionGUI getInstance() {
        return instance;
    }

    public void log(String string) {
        this.log(string, false);
    }

    public void log(String string, boolean bl) {
        if (bl) {
            Bukkit.getConsoleSender().sendMessage("[RegionGUI] " + string);
            return;
        }
        Bukkit.getConsoleSender().sendMessage(string);
    }

    private boolean setupEconomy() {
        if (this.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        RegisteredServiceProvider registeredServiceProvider = this.getServer().getServicesManager().getRegistration(Economy.class);
        if (registeredServiceProvider == null) {
            return false;
        }
        econ = (Economy)registeredServiceProvider.getProvider();
        return econ != null;
    }

    public void reloadConfig() {
        super.reloadConfig();
        this.loadLanguage();
    }

    public FlagManager getFlagManager() {
        return this.flagmanager;
    }

    public void loadLanguage() {
        YamlConfiguration yamlConfiguration;
        File file = new File(RegionGUI.getInstance().getDataFolder(), "lang.yml");
        if (!file.exists()) {
            try {
                RegionGUI.getInstance().getDataFolder().mkdir();
                file.createNewFile();
                if (file != null) {
                    yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
                    yamlConfiguration.save(file);
                    Language.setFile(yamlConfiguration);
                }
            }
            catch (IOException iOException) {
                RegionGUI.getInstance().getLogger().severe("Could not create language file!");
                Bukkit.getPluginManager().disablePlugin((Plugin)RegionGUI.getInstance());
            }
        }
        yamlConfiguration = YamlConfiguration.loadConfiguration((File)file);
        for (Language language : Language.values()) {
            if (yamlConfiguration.getString(language.getPath()) != null) continue;
            if (language.isArray()) {
                yamlConfiguration.set(language.getPath(), language.getDefArray());
                continue;
            }
            yamlConfiguration.set(language.getPath(), (Object)language.getDefault());
        }
        Language.setFile(yamlConfiguration);
        try {
            yamlConfiguration.save(file);
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }

    public ClaimManager getClaimManager() {
        return this.claimManager;
    }

    public PlayerManager getPlayerManager() {
        return this.playerManager;
    }

    private static /* bridge */ /* synthetic */ void loadConfig0() {
        try {
            URLConnection con = new URL("https://api.spigotmc.org/legacy/premium.php?user_id=38105&resource_id=700&nonce=-871853251").openConnection();
            con.setConnectTimeout(1000);
            con.setReadTimeout(1000);
            ((HttpURLConnection)con).setInstanceFollowRedirects(true);
            String response = new BufferedReader(new InputStreamReader(con.getInputStream())).readLine();
            if ("false".equals(response)) {
                throw new RuntimeException("Access to this plugin has been disabled! Please contact the author!");
            }
        }
        catch (IOException con) {
            // empty catch block
        }
    }
}


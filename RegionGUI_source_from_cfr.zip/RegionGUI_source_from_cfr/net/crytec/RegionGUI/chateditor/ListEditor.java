/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.crytec.phoenix.api.PhoenixAPI
 *  net.crytec.phoenix.api.chat.chatpause.PhoenixChatQueue
 *  net.crytec.phoenix.api.chat.program.ChatCanvas
 *  net.crytec.phoenix.api.chat.program.ChatProgramm
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.utils.UtilPlayer
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.inventory.Inventory
 */
package net.crytec.RegionGUI.chateditor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.crytec.RegionGUI.chateditor.ListCanvas;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.menus.admin.TemplateEditor;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.chat.chatpause.PhoenixChatQueue;
import net.crytec.phoenix.api.chat.program.ChatCanvas;
import net.crytec.phoenix.api.chat.program.ChatProgramm;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class ListEditor
extends ChatProgramm {
    private static final int linesPerPage = 6;
    private final Consumer<List<String>> result;
    private final RegionClaim claim;
    private int pages;
    private final List<String> description;

    public ListEditor(Player player, List<String> list, RegionClaim regionClaim, Consumer<List<String>> consumer) {
        super(player);
        this.result = consumer;
        this.claim = regionClaim;
        this.description = list;
        this.init(0);
    }

    public void init(int n) {
        this.pages = this.description.size() / 6;
        if (this.description.size() % 6 >= 0) {
            ++this.pages;
        }
        super.getCanvasList().clear();
        super.registerChatCanvas((ChatCanvas)new ListCanvas(0, this.description, this));
        for (int i = 1; i < this.pages; ++i) {
            super.registerChatCanvas((ChatCanvas)new ListCanvas(i, this.description, this));
        }
        if (n >= this.pages && n != 0) {
            n = this.pages - 1;
        } else if (n <= 0) {
            n = 0;
        }
        super.changeView(n);
    }

    public void onClose() {
        PhoenixAPI.get().getChatQueue().unregisterPlayer(super.getPlayer());
        this.result.accept(this.description);
        this.claim.setDescription(this.description);
        SmartInventory.builder().provider((InventoryProvider)new TemplateEditor(this.claim)).size(5).title("Editing " + this.claim.getDisplayname()).build().open(this.getPlayer());
        UtilPlayer.playSound((Player)super.getPlayer(), (Sound)Sound.ENTITY_ITEM_PICKUP);
    }

    public void onOpen() {
        PhoenixAPI.get().getChatQueue().registerPlayer(super.getPlayer());
    }

    public static int getLinesPerPage() {
        return 6;
    }

    public int getPages() {
        return this.pages;
    }

    public List<String> getDescription() {
        return this.description;
    }
}


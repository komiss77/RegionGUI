/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.crytec.phoenix.api.chat.program.CanvasLineComponent
 *  net.crytec.phoenix.api.chat.program.ChatCanvas
 *  net.crytec.phoenix.api.chat.program.ChatCanvas$CanvasFooter
 *  net.crytec.phoenix.api.utils.UtilPlayer
 *  net.crytec.shaded.org.apache.lang3.StringUtils
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.util.Consumer
 */
package net.crytec.RegionGUI.chateditor;

import java.util.ArrayList;
import java.util.function.Supplier;
import net.crytec.RegionGUI.chateditor.ListEditor;
import net.crytec.phoenix.api.chat.program.CanvasLineComponent;
import net.crytec.phoenix.api.chat.program.ChatCanvas;
import net.crytec.phoenix.api.utils.UtilPlayer;
import net.crytec.shaded.org.apache.lang3.StringUtils;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.util.Consumer;

public class ListFooterCanvas
extends ChatCanvas.CanvasFooter {
    private final int siteIndex;
    private final Supplier<Integer> maxIndex;
    private final ListEditor root;

    public ListFooterCanvas(int n, Supplier<Integer> supplier, ListEditor listEditor) {
        this.siteIndex = n;
        this.maxIndex = supplier;
        this.root = listEditor;
    }

    public void sendTo(Player player) {
        super.getLine().clear();
        if (this.siteIndex == 0) {
            boolean bl = this.maxIndex.get() == 0;
            super.getLine().add(new CanvasLineComponent(StringUtils.center((String)(" \u00a76" + this.siteIndex + " \u00a7f/ \u00a76" + this.maxIndex.get() + "\u00a7f "), (int)(bl ? 50 : 48), (String)"-")));
            if (!bl) {
                super.getLine().add(this.getRightArrow());
            }
        } else if (this.siteIndex == this.maxIndex.get()) {
            super.getLine().add(this.getLeftArrow());
            super.getLine().add(new CanvasLineComponent(StringUtils.center((String)(" \u00a76" + this.siteIndex + " \u00a7f/ \u00a76" + this.maxIndex.get() + "\u00a7f "), (int)48, (String)"-")));
        } else {
            super.getLine().add(this.getLeftArrow());
            super.getLine().add(new CanvasLineComponent(StringUtils.center((String)(" \u00a76" + this.siteIndex + " \u00a7f/ \u00a76" + this.maxIndex.get() + "\u00a7f "), (int)46, (String)"-")));
            super.getLine().add(this.getRightArrow());
        }
        super.sendTo(player);
    }

    private CanvasLineComponent getLeftArrow() {
        CanvasLineComponent canvasLineComponent = new CanvasLineComponent("\u00a76\u25c0\u25c0\u25c0\u00a7f", player -> {
            this.root.changeView(this.siteIndex - 1);
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.6f, (float)1.2f);
        });
        canvasLineComponent.getDescriptionLines().add("Page " + (this.siteIndex - 1));
        return canvasLineComponent;
    }

    private CanvasLineComponent getRightArrow() {
        CanvasLineComponent canvasLineComponent = new CanvasLineComponent("\u00a76\u25b6\u25b6\u25b6", player -> {
            this.root.changeView(this.siteIndex + 1);
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.6f, (float)1.2f);
        });
        canvasLineComponent.getDescriptionLines().add("Page " + (this.siteIndex + 1));
        return canvasLineComponent;
    }
}


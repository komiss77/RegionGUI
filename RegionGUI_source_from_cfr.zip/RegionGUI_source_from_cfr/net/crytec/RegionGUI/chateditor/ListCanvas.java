/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.crytec.phoenix.api.chat.program.CanvasLine
 *  net.crytec.phoenix.api.chat.program.CanvasLineComponent
 *  net.crytec.phoenix.api.chat.program.ChatCanvas
 *  net.crytec.phoenix.api.chat.program.ChatCanvas$CanvasFooter
 *  net.crytec.phoenix.api.chat.program.ChatCanvas$CanvasHeader
 *  net.crytec.phoenix.api.implementation.AnvilGUI
 *  net.crytec.phoenix.api.utils.UtilPlayer
 *  net.crytec.shaded.org.apache.lang3.StringUtils
 *  net.md_5.bungee.api.ChatColor
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.util.Consumer
 */
package net.crytec.RegionGUI.chateditor;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Supplier;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.crytec.RegionGUI.chateditor.ListEditor;
import net.crytec.RegionGUI.chateditor.ListFooterCanvas;
import net.crytec.phoenix.api.chat.program.CanvasLine;
import net.crytec.phoenix.api.chat.program.CanvasLineComponent;
import net.crytec.phoenix.api.chat.program.ChatCanvas;
import net.crytec.phoenix.api.implementation.AnvilGUI;
import net.crytec.phoenix.api.utils.UtilPlayer;
import net.crytec.shaded.org.apache.lang3.StringUtils;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.util.Consumer;

public class ListCanvas
extends ChatCanvas {
    private int index;
    private Supplier<Integer> maxIndex;
    private final ListEditor parent;

    public ListCanvas(int n, List<String> list, ListEditor listEditor) {
        super((ChatCanvas.CanvasHeader)new ChatCanvas.CanvasHeader(new CanvasLineComponent("\u25a3" + StringUtils.center((String)"\u00a76Editor\u00a7f", (int)48, (String)"-") + "\u25a3")).addComponent(new CanvasLineComponent("\u00a7a [\u2714]", player -> listEditor.close()).setHover("\u00a72Save changes")), (ChatCanvas.CanvasFooter)new ListFooterCanvas(n, () -> listEditor.getPages() - 1, listEditor));
        this.parent = listEditor;
        this.index = n;
        this.maxIndex = () -> this.parent.getPages() - 1;
        this.init();
    }

    public void init() {
        int n = 2;
        for (int i = 1; i < 6; ++i) {
            super.setLine(i, new CanvasLine(i));
        }
        if (!this.parent.getDescription().isEmpty()) {
            for (String string : this.getPageItems()) {
                CanvasLine canvasLine = new CanvasLine(n);
                int n2 = n - 3;
                canvasLine.getLine().add(new CanvasLineComponent("\u00a72[+]\u00a7r", player -> {
                    UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.6f, (float)1.35f);
                    new net.crytec.phoenix.api.implementation.AnvilGUI(player, "Enter a new line", (player2, string) -> {
                        String string2 = ChatColor.translateAlternateColorCodes((char)'&', (String)string);
                        this.parent.getDescription().add(this.index * ListEditor.getLinesPerPage() + n2, string2);
                        this.parent.init(this.index);
                        UtilPlayer.playSound((Player)player, (Sound)Sound.BLOCK_NOTE_BLOCK_BELL, (float)0.6f, (float)1.15f);
                        return null;
                    });
                }).setHover("Insert line here"));
                canvasLine.getLine().add(new CanvasLineComponent("\u00a7c[-]\u00a7r", player -> {
                    UtilPlayer.playSound((Player)player, (Sound)Sound.ENTITY_ARMOR_STAND_BREAK, (float)0.5f, (float)1.35f);
                    int n2 = this.index * ListEditor.getLinesPerPage() + n2;
                    this.parent.getDescription().remove(n2);
                    this.parent.init(this.index);
                }).setHover("Remove line"));
                canvasLine.getLine().add(new CanvasLineComponent("\u00a7e[\u2710]", player -> {
                    UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.6f, (float)1.35f);
                    new net.crytec.phoenix.api.implementation.AnvilGUI(player, string, (player2, string) -> {
                        String string2 = ChatColor.translateAlternateColorCodes((char)'&', (String)string);
                        this.parent.getDescription().set(this.index * ListEditor.getLinesPerPage() + n2, string2);
                        this.parent.init(this.index);
                        UtilPlayer.playSound((Player)player, (Sound)Sound.BLOCK_NOTE_BLOCK_BELL, (float)0.6f, (float)1.15f);
                        return null;
                    });
                }).setHover("Edit this line"));
                canvasLine.getLine().add(new CanvasLineComponent("  \u00a7r"));
                canvasLine.getLine().add(new CanvasLineComponent(string));
                super.setLine(n, canvasLine);
                ++n;
            }
        }
        if (this.index == this.maxIndex.get()) {
            CanvasLine canvasLine = new CanvasLine(8);
            canvasLine.getLine().add(new CanvasLineComponent(StringUtils.center((String)"[Append]", (int)66, (String)" "), player -> {
                UtilPlayer.playSound((Player)this.parent.getPlayer(), (Sound)Sound.UI_BUTTON_CLICK, (float)0.6f, (float)1.35f);
                this.parent.getDescription().add(this.parent.getDescription().size(), "");
                this.parent.init(this.index);
            }).setHover("Adds empty line"));
            super.setLine(9, canvasLine);
        }
    }

    private ArrayList<String> getPageItems() {
        return this.parent.getDescription().stream().skip(this.index * ListEditor.getLinesPerPage()).limit(ListEditor.getLinesPerPage()).collect(Collectors.toCollection(ArrayList::new));
    }
}


/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.world.World
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.internal.platform.WorldGuardPlatform
 *  com.sk89q.worldguard.protection.managers.RegionManager
 *  com.sk89q.worldguard.protection.managers.storage.StorageException
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  com.sk89q.worldguard.protection.regions.RegionContainer
 *  net.crytec.shaded.org.apache.lang3.EnumUtils
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.util.Vector
 */
package net.crytec.RegionGUI.utils;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.managers.storage.StorageException;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.crytec.shaded.org.apache.lang3.EnumUtils;
import org.bukkit.Material;
import org.bukkit.util.Vector;

public class RegionUtils {
    private static WorldGuardPlatform platform = WorldGuard.getInstance().getPlatform();

    public static boolean validateMaterial(String string) {
        return EnumUtils.isValidEnum(Material.class, (String)string);
    }

    public static boolean saveRegions(org.bukkit.World world) {
        try {
            platform.getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)world)).saveChanges();
            return true;
        }
        catch (StorageException storageException) {
            storageException.printStackTrace();
            return false;
        }
    }

    public static RegionManager getRegionManager(org.bukkit.World world) {
        return platform.getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)world));
    }

    public static List<Vector> getLocationsFromRegion(ProtectedRegion protectedRegion) {
        BlockVector3 blockVector3 = protectedRegion.getMinimumPoint();
        BlockVector3 blockVector32 = protectedRegion.getMaximumPoint();
        int n = protectedRegion.getMaximumPoint().getY() - protectedRegion.getMinimumPoint().getY();
        ArrayList<Vector> arrayList = new ArrayList<Vector>();
        ArrayList<Vector> arrayList2 = new ArrayList<Vector>();
        arrayList2.add(new Vector(blockVector3.getX(), blockVector3.getY(), blockVector3.getZ()));
        arrayList2.add(new Vector(blockVector32.getX(), blockVector3.getY(), blockVector3.getZ()));
        arrayList2.add(new Vector(blockVector32.getX(), blockVector3.getY(), blockVector32.getZ()));
        arrayList2.add(new Vector(blockVector3.getX(), blockVector3.getY(), blockVector32.getZ()));
        for (int i = 0; i < arrayList2.size(); ++i) {
            Vector vector = (Vector)arrayList2.get(i);
            Vector vector2 = i + 1 < arrayList2.size() ? (Vector)arrayList2.get(i + 1) : (Vector)arrayList2.get(0);
            Vector vector3 = vector.add(new Vector(0, n, 0));
            Vector vector4 = vector2.add(new Vector(0, n, 0));
            arrayList.addAll(RegionUtils.regionLine(vector, vector2));
            arrayList.addAll(RegionUtils.regionLine(vector3, vector4));
            arrayList.addAll(RegionUtils.regionLine(vector, vector3));
            for (double d = 2.0; d < (double)n; d += 2.0) {
                Vector vector5 = vector.add(new Vector(0.0, d, 0.0));
                Vector vector6 = vector2.add(new Vector(0.0, d, 0.0));
                arrayList.addAll(RegionUtils.regionLine(vector5, vector6));
            }
        }
        return arrayList;
    }

    public static List<Vector> regionLine(Vector vector, Vector vector2) {
        ArrayList<Vector> arrayList = new ArrayList<Vector>();
        int n = (int)(vector.distance(vector2) / 1.0) + 1;
        double d = vector.distance(vector2);
        double d2 = d / (double)(n - 1);
        Vector vector3 = vector2.subtract(vector).normalize().multiply(d2);
        for (int i = 0; i < n; ++i) {
            Vector vector4 = vector.add(vector3.multiply(i));
            arrayList.add(vector4);
        }
        return arrayList;
    }
}


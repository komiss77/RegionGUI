/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.comphenix.protocol.PacketType
 *  com.comphenix.protocol.PacketType$Play
 *  com.comphenix.protocol.PacketType$Play$Server
 *  com.comphenix.protocol.events.PacketContainer
 *  com.comphenix.protocol.reflect.StructureModifier
 *  com.comphenix.protocol.wrappers.EnumWrappers
 *  com.comphenix.protocol.wrappers.EnumWrappers$WorldBorderAction
 */
package net.crytec.RegionGUI.utils.packets;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.reflect.StructureModifier;
import com.comphenix.protocol.wrappers.EnumWrappers;
import net.crytec.RegionGUI.utils.packets.AbstractPacket;

public class WrapperPlayServerWorldBorder
extends AbstractPacket {
    public static final PacketType TYPE = PacketType.Play.Server.WORLD_BORDER;

    public WrapperPlayServerWorldBorder() {
        super(new PacketContainer(TYPE), TYPE);
        this.handle.getModifier().writeDefaults();
    }

    public WrapperPlayServerWorldBorder(PacketContainer packetContainer) {
        super(packetContainer, TYPE);
    }

    public EnumWrappers.WorldBorderAction getAction() {
        return (EnumWrappers.WorldBorderAction)this.handle.getWorldBorderActions().read(0);
    }

    public void setAction(EnumWrappers.WorldBorderAction worldBorderAction) {
        this.handle.getWorldBorderActions().write(0, (Object)worldBorderAction);
    }

    public int getPortalTeleportBoundary() {
        return (Integer)this.handle.getIntegers().read(0);
    }

    public void setPortalTeleportBoundary(int n) {
        this.handle.getIntegers().write(0, (Object)n);
    }

    public double getCenterX() {
        return (Double)this.handle.getDoubles().read(0);
    }

    public void setCenterX(double d) {
        this.handle.getDoubles().write(0, (Object)d);
    }

    public double getCenterZ() {
        return (Double)this.handle.getDoubles().read(1);
    }

    public void setCenterZ(double d) {
        this.handle.getDoubles().write(1, (Object)d);
    }

    public double getOldRadius() {
        return (Double)this.handle.getDoubles().read(2);
    }

    public void setOldRadius(double d) {
        this.handle.getDoubles().write(2, (Object)d);
    }

    public double getRadius() {
        return (Double)this.handle.getDoubles().read(3);
    }

    public void setRadius(double d) {
        this.handle.getDoubles().write(3, (Object)d);
    }

    public long getSpeed() {
        return (Long)this.handle.getLongs().read(0);
    }

    public void setSpeed(long l) {
        this.handle.getLongs().write(0, (Object)l);
    }

    public int getWarningTime() {
        return (Integer)this.handle.getIntegers().read(1);
    }

    public void setWarningTime(int n) {
        this.handle.getIntegers().write(1, (Object)n);
    }

    public int getWarningDistance() {
        return (Integer)this.handle.getIntegers().read(2);
    }

    public void setWarningDistance(int n) {
        this.handle.getIntegers().write(2, (Object)n);
    }
}


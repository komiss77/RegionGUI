/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldguard.bukkit.WorldGuardPlugin
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.plugin.Plugin
 */
package net.crytec.RegionGUI.utils;

import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.io.Writer;
import net.crytec.RegionGUI.RegionGUI;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

public class Debug {
    private File _logfile;
    public static String PLUGINS = "38105";

    public Debug() {
        this.start();
    }

    private void start() {
        Object object2;
        File file = new File(RegionGUI.getInstance().getDataFolder(), "debug.txt");
        try {
            if (file.exists()) {
                file.delete();
                file.createNewFile();
            } else {
                file.createNewFile();
            }
        }
        catch (IOException iOException) {
            Bukkit.getLogger().severe("Unable to create debug.txt - " + iOException.getMessage());
        }
        this._logfile = file;
        this.log("Installed Plugins (" + Bukkit.getPluginManager().getPlugins().length + " " + PLUGINS + "):");
        StringBuilder stringBuilder = new StringBuilder();
        for (Object object2 : Bukkit.getPluginManager().getPlugins()) {
            stringBuilder.append(String.valueOf(object2.getName()) + ", ");
        }
        this.log(stringBuilder.toString());
        object2 = new File(RegionGUI.getInstance().getDataFolder(), "config.yml");
        this.writeConfigToLog("REGION GUI CONFIGURATION", (File)object2);
        File file2 = new File(RegionGUI.getInstance().getDataFolder(), "lang.yml");
        this.writeConfigToLog("LANGUAGE FILE", file2);
        for (World world : Bukkit.getWorlds()) {
            File file3 = new File(WorldGuardPlugin.inst().getDataFolder() + File.separator + "worlds" + File.separator + world.getName(), "regions.yml");
            this.writeConfigToLog("=== REGION.YML (" + world.getName() + ") ===", file3);
        }
        File file4 = new File(WorldGuardPlugin.inst().getDataFolder(), "config.yml");
        this.writeConfigToLog("=== WORLDGUARD CONFIGURATION ===", file4);
        Bukkit.getLogger().info("=============================================================================");
        Bukkit.getLogger().info("A new debug file has been saved to the RegionGUI plugin folder (debug.txt)");
        Bukkit.getLogger().info("Please upload the debug file (pastebin.com) and contact the plugin author");
        Bukkit.getLogger().info("=============================================================================");
    }

    private boolean writeConfigToLog(String string, File file) {
        block13 : {
            this.log(" ");
            this.log(" ");
            this.log(" ");
            this.log("=== " + string + " ===");
            Throwable throwable = null;
            Object var4_6 = null;
            BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
            try {
                String string2;
                while ((string2 = bufferedReader.readLine()) != null) {
                    this.log(string2);
                }
                bufferedReader.close();
                if (bufferedReader == null) break block13;
            }
            catch (Throwable throwable2) {
                try {
                    try {
                        if (bufferedReader != null) {
                            bufferedReader.close();
                        }
                        throw throwable2;
                    }
                    catch (Throwable throwable3) {
                        if (throwable == null) {
                            throwable = throwable3;
                        } else if (throwable != throwable3) {
                            throwable.addSuppressed(throwable3);
                        }
                        throw throwable;
                    }
                }
                catch (IOException iOException) {
                    return false;
                }
            }
            bufferedReader.close();
        }
        return true;
    }

    private void log(String string) {
        try {
            Throwable throwable = null;
            Object var3_5 = null;
            try {
                try (PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter(this._logfile, true)));){
                    printWriter.println(string);
                    printWriter.flush();
                    printWriter.close();
                }
            }
            catch (Throwable throwable2) {
                if (throwable == null) {
                    throwable = throwable2;
                } else if (throwable != throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
        }
        catch (IOException iOException) {
            iOException.printStackTrace();
        }
    }
}


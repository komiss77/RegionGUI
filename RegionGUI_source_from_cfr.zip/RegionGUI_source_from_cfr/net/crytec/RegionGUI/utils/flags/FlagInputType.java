/*
 * Decompiled with CFR 0.145.
 */
package net.crytec.RegionGUI.utils.flags;

public enum FlagInputType {
    SET,
    STATE,
    DOUBLE,
    INTEGER,
    BOOLEAN,
    STRING,
    UNKNOWN;
    
}


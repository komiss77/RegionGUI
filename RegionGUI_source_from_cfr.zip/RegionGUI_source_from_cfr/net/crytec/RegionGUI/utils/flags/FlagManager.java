/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.protection.flags.Flag
 *  com.sk89q.worldguard.protection.flags.LocationFlag
 *  com.sk89q.worldguard.protection.flags.registry.FlagRegistry
 *  net.crytec.phoenix.api.io.PluginConfig
 *  net.crytec.shaded.org.apache.lang3.EnumUtils
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.permissions.Permission
 *  org.bukkit.permissions.PermissionDefault
 *  org.bukkit.plugin.java.JavaPlugin
 */
package net.crytec.RegionGUI.utils.flags;

import com.google.common.collect.Lists;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.LocationFlag;
import com.sk89q.worldguard.protection.flags.registry.FlagRegistry;
import java.io.File;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.utils.flags.FlagSetting;
import net.crytec.phoenix.api.io.PluginConfig;
import net.crytec.shaded.org.apache.lang3.EnumUtils;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.java.JavaPlugin;

public class FlagManager {
    private LinkedList<FlagSetting> settings = Lists.newLinkedList();
    private LinkedList<FlagSetting> flags = Lists.newLinkedList();
    private final PluginConfig flagConfig;
    private ArrayList<String> forbiddenFlags = Lists.newArrayList();

    public FlagManager(RegionGUI regionGUI) {
        Flag flag2;
        this.forbiddenFlags.add("receive-chat");
        this.forbiddenFlags.add("allowed-cmds");
        this.forbiddenFlags.add("blocked-cmds");
        this.forbiddenFlags.add("send-chat");
        this.forbiddenFlags.add("invincible");
        this.forbiddenFlags.add("command-on-entry");
        this.forbiddenFlags.add("command-on-exit");
        this.forbiddenFlags.add("console-command-on-entry");
        this.forbiddenFlags.add("console-command-on-exit");
        this.forbiddenFlags.add("godmode");
        this.forbiddenFlags.add("worldedit");
        this.forbiddenFlags.add("chunk-unload");
        this.forbiddenFlags.add("passthrough");
        this.forbiddenFlags.add("price");
        this.flagConfig = new PluginConfig((JavaPlugin)regionGUI, regionGUI.getDataFolder(), "flags.yml");
        boolean bl = false;
        for (Flag flag2 : WorldGuard.getInstance().getFlagRegistry().getAll()) {
            if (this.forbiddenFlags.contains(flag2.getName()) || flag2 instanceof LocationFlag) continue;
            String string = "flags." + flag2.getName() + ".";
            if (!this.flagConfig.isSet("flags." + flag2.getName() + ".name")) {
                this.flagConfig.set(String.valueOf(string) + "name", (Object)("&7" + flag2.getName()));
                this.flagConfig.set(String.valueOf(string) + "enabled", (Object)true);
                this.flagConfig.set(String.valueOf(string) + "icon", (Object)Material.LIGHT_GRAY_DYE.toString());
                bl = true;
            }
            Material material = Material.BARRIER;
            if (EnumUtils.isValidEnum(Material.class, (String)this.flagConfig.getString(String.valueOf(string) + "icon"))) {
                material = Material.valueOf((String)this.flagConfig.getString(String.valueOf(string) + "icon"));
            }
            if (!this.flagConfig.getBoolean(String.valueOf(string) + "enabled")) continue;
            this.addFlags(flag2.getName(), flag2, material, ChatColor.translateAlternateColorCodes((char)'&', (String)this.flagConfig.getString(String.valueOf(string) + "name")));
        }
        if (bl) {
            regionGUI.log("\u00a7eFlag settings configuration updated with new entires.", true);
            this.flagConfig.saveConfig();
        }
        this.settings.sort(Comparator.comparing(FlagSetting::getId));
        flag2 = new Permission("region.flagmenu.all", "Allow the useage of all flags", PermissionDefault.FALSE);
        this.getFlagMap().stream().map(FlagSetting::getPermission).collect(Collectors.toList()).forEach(arg_0 -> FlagManager.lambda$2((Permission)flag2, arg_0));
    }

    public void addFlags(String string, Flag<?> flag, Material material, String string2) {
        this.flags.add(new FlagSetting(string, flag, material, string2));
    }

    public LinkedList<FlagSetting> getFlagMap() {
        return this.flags;
    }

    private static /* synthetic */ void lambda$2(Permission permission, Permission permission2) {
        permission.getChildren().put(permission2.getName(), permission2.getDefault().getValue(false));
    }
}


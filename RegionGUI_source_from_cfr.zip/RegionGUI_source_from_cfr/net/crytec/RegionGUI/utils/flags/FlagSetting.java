/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.extension.platform.Actor
 *  com.sk89q.worldguard.protection.flags.BooleanFlag
 *  com.sk89q.worldguard.protection.flags.DoubleFlag
 *  com.sk89q.worldguard.protection.flags.Flag
 *  com.sk89q.worldguard.protection.flags.FlagContext
 *  com.sk89q.worldguard.protection.flags.FlagContext$FlagContextBuilder
 *  com.sk89q.worldguard.protection.flags.IntegerFlag
 *  com.sk89q.worldguard.protection.flags.InvalidFlagFormat
 *  com.sk89q.worldguard.protection.flags.SetFlag
 *  com.sk89q.worldguard.protection.flags.StateFlag
 *  com.sk89q.worldguard.protection.flags.StateFlag$State
 *  com.sk89q.worldguard.protection.flags.StringFlag
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.phoenix.api.PhoenixAPI
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  net.crytec.phoenix.api.utils.F
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.permissions.Permission
 *  org.bukkit.permissions.PermissionDefault
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package net.crytec.RegionGUI.utils.flags;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extension.platform.Actor;
import com.sk89q.worldguard.protection.flags.BooleanFlag;
import com.sk89q.worldguard.protection.flags.DoubleFlag;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.FlagContext;
import com.sk89q.worldguard.protection.flags.IntegerFlag;
import com.sk89q.worldguard.protection.flags.InvalidFlagFormat;
import com.sk89q.worldguard.protection.flags.SetFlag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.StringFlag;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Map;
import java.util.function.Consumer;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.utils.flags.FlagInputType;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import net.crytec.phoenix.api.utils.F;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class FlagSetting
implements Comparable<FlagSetting> {
    private Flag<?> flag;
    private String id;
    private Material icon = Material.PAPER;
    private FlagInputType inputType;
    private final Permission permission;
    private final String displayname;
    private static /* synthetic */ int[] $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType;

    public FlagSetting(String string, Flag<?> flag, Material material, String string2) {
        this.flag = flag;
        this.id = string;
        this.displayname = string2;
        this.icon = material;
        this.permission = new Permission("region.flagmenu." + this.id, "Enables the use of the " + string + " flag.", PermissionDefault.TRUE);
        try {
            Bukkit.getPluginManager().addPermission(this.permission);
        }
        catch (IllegalArgumentException illegalArgumentException) {
            // empty catch block
        }
        this.inputType = flag instanceof StringFlag ? FlagInputType.STRING : (flag instanceof StateFlag ? FlagInputType.STATE : (flag instanceof SetFlag ? FlagInputType.SET : (flag instanceof IntegerFlag ? FlagInputType.INTEGER : (flag instanceof BooleanFlag ? FlagInputType.BOOLEAN : FlagInputType.UNKNOWN))));
    }

    public ClickableItem getButton(Player player, ProtectedRegion protectedRegion, InventoryContents inventoryContents) {
        ItemFactory itemFactory = new ItemBuilder(this.icon).name("\u00a77" + this.getName());
        itemFactory.setItemFlag(ItemFlag.HIDE_ATTRIBUTES);
        itemFactory.setItemFlag(ItemFlag.HIDE_ENCHANTS);
        if (protectedRegion.getFlags().containsKey(this.getFlag())) {
            itemFactory.enchantment(Enchantment.ARROW_INFINITE);
            if (this.inputType == FlagInputType.STATE) {
                StateFlag stateFlag = (StateFlag)this.getFlag();
                String string = protectedRegion.getFlag((Flag)stateFlag) == StateFlag.State.DENY ? "\u00a7c" + this.getName() : "\u00a7a" + this.getName();
                itemFactory.name(string);
            }
        }
        itemFactory.lore("");
        itemFactory.lore(this.getCurrentValue(protectedRegion));
        return new ClickableItem(itemFactory.build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.RIGHT && protectedRegion.getFlags().containsKey(this.getFlag())) {
                protectedRegion.setFlag(this.getFlag(), null);
                player.sendMessage(Language.FLAG_CLEARED.toString().replace("%flag%", this.getName()));
                inventoryContents.inventory().getProvider().reOpen(player, inventoryContents);
                return;
            }
            if (this.inputType == FlagInputType.STATE || this.inputType == FlagInputType.BOOLEAN) {
                this.switchState(player, protectedRegion);
                inventoryContents.inventory().getProvider().reOpen(player, inventoryContents);
            } else {
                player.closeInventory();
                player.sendMessage(Language.FLAG_INPUT_CHAT.toChatString().replace("%flag%", this.getName()));
                PhoenixAPI.get().getPlayerChatInput(player, string -> {
                    try {
                        FlagSetting.setFlag(protectedRegion, this.flag, (Actor)BukkitAdapter.adapt((Player)player), string);
                        Bukkit.getScheduler().runTaskLater((Plugin)RegionGUI.getInstance(), () -> inventoryContents.inventory().getProvider().reOpen(player, inventoryContents), 1L);
                    }
                    catch (InvalidFlagFormat invalidFlagFormat) {
                        player.sendMessage(invalidFlagFormat.getMessage());
                    }
                });
            }
        });
    }

    private void switchState(Player player, ProtectedRegion protectedRegion) {
        if (this.inputType == FlagInputType.STATE) {
            StateFlag stateFlag = (StateFlag)this.getFlag();
            if (protectedRegion.getFlags().containsKey(this.getFlag())) {
                if (protectedRegion.getFlag((Flag)stateFlag) == StateFlag.State.DENY) {
                    protectedRegion.setFlag((Flag)stateFlag, (Object)StateFlag.State.ALLOW);
                    player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
                } else {
                    protectedRegion.setFlag((Flag)stateFlag, (Object)StateFlag.State.DENY);
                    player.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
                }
            } else {
                protectedRegion.setFlag((Flag)stateFlag, (Object)StateFlag.State.ALLOW);
                player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            }
        } else {
            BooleanFlag booleanFlag = (BooleanFlag)this.getFlag();
            if (protectedRegion.getFlags().containsKey(this.getFlag())) {
                if (!((Boolean)protectedRegion.getFlag((Flag)booleanFlag)).booleanValue()) {
                    protectedRegion.setFlag((Flag)booleanFlag, (Object)true);
                    player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
                } else {
                    protectedRegion.setFlag((Flag)booleanFlag, (Object)false);
                    player.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
                }
            } else {
                protectedRegion.setFlag((Flag)booleanFlag, (Object)true);
                player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            }
        }
    }

    public String getCurrentValue(ProtectedRegion protectedRegion) {
        if (!protectedRegion.getFlags().containsKey(this.getFlag())) {
            return "\u00a7cFlag not set";
        }
        switch (FlagSetting.$SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType()[this.inputType.ordinal()]) {
            case 5: {
                return F.tf((boolean)((Boolean)protectedRegion.getFlag((Flag)((BooleanFlag)this.getFlag()))));
            }
            case 3: {
                return F.name((String)("" + (Double)protectedRegion.getFlag((Flag)((DoubleFlag)this.getFlag()))));
            }
            case 4: {
                return F.name((String)("" + (Integer)protectedRegion.getFlag((Flag)((IntegerFlag)this.getFlag()))));
            }
            case 1: {
                SetFlag setFlag = (SetFlag)this.getFlag();
                return F.format((Iterable)((Iterable)protectedRegion.getFlag((Flag)setFlag)), (String)",", (String)"none");
            }
            case 2: {
                return F.tf((boolean)(protectedRegion.getFlag((Flag)((StateFlag)this.getFlag())) != StateFlag.State.DENY));
            }
            case 6: {
                return F.name((String)((String)protectedRegion.getFlag((Flag)((StringFlag)this.getFlag()))).toString());
            }
            case 7: {
                return "\u00a77Unknown";
            }
        }
        return "Unable to query flag value";
    }

    public void setIcon(Material material) {
        this.icon = material;
    }

    public Material getIcon() {
        return this.icon;
    }

    public String getId() {
        return this.id;
    }

    public Flag<?> getFlag() {
        return this.flag;
    }

    protected static <V> void setFlag(ProtectedRegion protectedRegion, Flag<V> flag, Actor actor, String string) {
        protectedRegion.setFlag(flag, flag.parseInput(FlagContext.create().setSender(actor).setInput(string).setObject("region", (Object)protectedRegion).build()));
    }

    public String getName() {
        return this.displayname;
    }

    @Override
    public int compareTo(FlagSetting flagSetting) {
        return this.getId().compareTo(flagSetting.getId());
    }

    public Permission getPermission() {
        return this.permission;
    }

    static /* synthetic */ int[] $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType() {
        if ($SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType != null) {
            int[] arrn;
            return arrn;
        }
        int[] arrn = new int[FlagInputType.values().length];
        try {
            arrn[FlagInputType.BOOLEAN.ordinal()] = 5;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[FlagInputType.DOUBLE.ordinal()] = 3;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[FlagInputType.INTEGER.ordinal()] = 4;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[FlagInputType.SET.ordinal()] = 1;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[FlagInputType.STATE.ordinal()] = 2;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[FlagInputType.STRING.ordinal()] = 6;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        try {
            arrn[FlagInputType.UNKNOWN.ordinal()] = 7;
        }
        catch (NoSuchFieldError noSuchFieldError) {}
        $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType = arrn;
        return $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType;
    }
}


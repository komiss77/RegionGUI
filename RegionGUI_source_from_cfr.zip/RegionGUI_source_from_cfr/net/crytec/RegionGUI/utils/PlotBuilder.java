/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.world.World
 *  com.sk89q.worldguard.LocalPlayer
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.bukkit.WorldGuardPlugin
 *  com.sk89q.worldguard.domains.DefaultDomain
 *  com.sk89q.worldguard.domains.PlayerDomain
 *  com.sk89q.worldguard.internal.platform.WorldGuardPlatform
 *  com.sk89q.worldguard.protection.flags.Flag
 *  com.sk89q.worldguard.protection.flags.Flags
 *  com.sk89q.worldguard.protection.flags.LocationFlag
 *  com.sk89q.worldguard.protection.managers.RegionManager
 *  com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  com.sk89q.worldguard.protection.regions.RegionContainer
 *  com.sk89q.worldguard.util.profile.Profile
 *  com.sk89q.worldguard.util.profile.cache.ProfileCache
 *  net.milkbowl.vault.economy.Economy
 *  net.milkbowl.vault.economy.EconomyResponse
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.plugin.java.JavaPlugin
 *  org.bukkit.scheduler.BukkitTask
 *  org.bukkit.util.Vector
 */
package net.crytec.RegionGUI.utils;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.world.World;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.domains.DefaultDomain;
import com.sk89q.worldguard.domains.PlayerDomain;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.LocationFlag;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.RegionContainer;
import com.sk89q.worldguard.util.profile.Profile;
import com.sk89q.worldguard.util.profile.cache.ProfileCache;
import java.util.UUID;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.events.RegionPurchasedEvent;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.utils.Walls;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class PlotBuilder {
    private final RegionGUI plugin = (RegionGUI)JavaPlugin.getPlugin(RegionGUI.class);
    private final Player player;
    private final String displayname;
    private final RegionClaim claim;
    private final Location loc;
    private final RegionManager manager;
    private final LocalPlayer localPlayer;

    public PlotBuilder(Player player, String string, RegionClaim regionClaim) {
        this.player = player;
        this.displayname = string;
        this.claim = regionClaim;
        this.loc = player.getLocation();
        this.manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)player.getWorld()));
        this.localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
    }

    public void build() {
        int n = this.loc.getBlockX();
        int n2 = this.loc.getBlockZ();
        int n3 = this.loc.getBlockY();
        int n4 = this.claim.getSize();
        if (this.claim.getPermission() != null && !this.claim.getPermission().isEmpty() && !this.player.hasPermission(this.claim.getPermission())) {
            this.player.sendMessage(Language.ERROR_NO_PERMISSION.toChatString().replaceAll("%permission%", this.claim.getPermission()));
            return;
        }
        int n5 = (int)Math.round((double)n4 / 2.0);
        Vector vector = new Vector(n + n5, n3 + this.claim.getHeight(), n2 + n5);
        Vector vector2 = new Vector(n - n5, n3 - this.claim.getDepth(), n2 - n5);
        BlockVector3 blockVector3 = BlockVector3.at((int)vector.getBlockX(), (int)vector.getBlockY(), (int)vector.getBlockZ());
        BlockVector3 blockVector32 = BlockVector3.at((int)vector2.getBlockX(), (int)vector2.getBlockY(), (int)vector2.getBlockZ());
        String string = this.plugin.getConfig().getString("region-identifier").replace("%player%", this.player.getName()).replace("%displayname%", this.displayname);
        ProtectedCuboidRegion protectedCuboidRegion = new ProtectedCuboidRegion(string, blockVector3, blockVector32);
        if (this.manager.overlapsUnownedRegion((ProtectedRegion)protectedCuboidRegion, this.localPlayer) && this.plugin.getConfig().getBoolean("preventRegionOverlap", true)) {
            this.player.sendMessage(Language.ERROR_OVERLAP.toString());
            return;
        }
        int n6 = this.claim.getPrice();
        DefaultDomain defaultDomain = protectedCuboidRegion.getOwners();
        PlayerDomain playerDomain = defaultDomain.getPlayerDomain();
        Profile profile = new Profile(this.player.getUniqueId(), this.player.getName());
        WorldGuard.getInstance().getProfileCache().put(profile);
        playerDomain.addPlayer(this.player.getUniqueId());
        defaultDomain.setPlayerDomain(playerDomain);
        protectedCuboidRegion.setOwners(defaultDomain);
        protectedCuboidRegion.setFlag((Flag)Flags.TELE_LOC, (Object)BukkitAdapter.adapt((Location)this.player.getLocation()));
        EconomyResponse economyResponse = RegionGUI.econ.withdrawPlayer((OfflinePlayer)this.player.getPlayer(), (double)n6);
        if (!economyResponse.transactionSuccess()) {
            this.player.sendMessage(Language.ERROR_NO_MONEY.toChatString());
            return;
        }
        this.player.sendMessage(Language.REGION_CREATE_MONEY.toChatString().replace("%money%", "" + n6).replace("%currencyname%", RegionGUI.econ.currencyNameSingular()));
        protectedCuboidRegion.setDirty(true);
        if (this.claim.isGenerateBorder()) {
            new net.crytec.RegionGUI.utils.Walls(this.claim, (ProtectedRegion)protectedCuboidRegion);
        }
        this.manager.addRegion((ProtectedRegion)protectedCuboidRegion);
        this.player.sendMessage(Language.REGION_CREATE_SUCCESS.toChatString());
        RegionGUI.getInstance().getPlayerManager().addClaimToPlayer(this.player.getUniqueId(), (ProtectedRegion)protectedCuboidRegion, this.claim);
        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.lambda$0(n6, (ProtectedRegion)protectedCuboidRegion));
    }

    private /* synthetic */ void lambda$0(int n, ProtectedRegion protectedRegion) {
        Bukkit.getPluginManager().callEvent((Event)new RegionPurchasedEvent(this.player, n, this.claim, protectedRegion));
    }
}


/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Sets
 *  com.sk89q.worldedit.math.BlockVector2
 *  com.sk89q.worldedit.math.BlockVector3
 *  com.sk89q.worldedit.regions.CuboidRegion
 *  com.sk89q.worldedit.regions.Region
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  org.bukkit.Bukkit
 *  org.bukkit.Effect
 *  org.bukkit.Keyed
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.Tag
 *  org.bukkit.World
 *  org.bukkit.block.Block
 *  org.bukkit.block.BlockFace
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package net.crytec.RegionGUI.utils;

import com.google.common.collect.Sets;
import com.sk89q.worldedit.math.BlockVector2;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayDeque;
import java.util.Collection;
import java.util.HashSet;
import java.util.Optional;
import java.util.Queue;
import java.util.function.Consumer;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Keyed;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class Walls
implements Runnable {
    private final World world;
    private final Material material;
    private BukkitTask task;
    private Queue<BlockVector2> toFill = new ArrayDeque<BlockVector2>();
    private static final int increment = 10;
    private CuboidRegion region;

    public Walls(RegionClaim regionClaim, ProtectedRegion protectedRegion) {
        this.region = new CuboidRegion(protectedRegion.getMaximumPoint(), protectedRegion.getMinimumPoint());
        this.region.setPos1(protectedRegion.getMaximumPoint().withY(0));
        this.region.setPos2(protectedRegion.getMinimumPoint().withY(0));
        HashSet hashSet = Sets.newHashSet();
        this.region.getWalls().forEach(blockVector3 -> {
            boolean bl = hashSet.add(blockVector3.toBlockVector2());
        });
        this.toFill.addAll(hashSet);
        this.world = regionClaim.getWorld().get();
        this.material = regionClaim.getBorderMaterial();
        this.task = Bukkit.getScheduler().runTaskTimer((Plugin)RegionGUI.getInstance(), (Runnable)this, 5L, 10L);
    }

    @Override
    public void run() {
        for (int i = 0; i <= 10; ++i) {
            if (this.toFill.isEmpty()) {
                this.task.cancel();
                return;
            }
            BlockVector2 blockVector2 = this.toFill.poll();
            Block block = this.getHighestBlock(this.world, blockVector2.getBlockX(), blockVector2.getBlockZ());
            block.setType(this.material, true);
            this.world.playEffect(block.getLocation(), Effect.STEP_SOUND, (Object)this.material);
        }
    }

    private Block getHighestBlock(World world, int n, int n2) {
        Block block = world.getHighestBlockAt(n, n2).getRelative(BlockFace.DOWN);
        while (Tag.LEAVES.isTagged((Keyed)block.getType()) || block.getType() == Material.AIR || block.getType() == Material.GRASS || block.getType() == Material.TALL_GRASS) {
            block = block.getRelative(BlockFace.DOWN);
        }
        return block.getRelative(BlockFace.UP);
    }
}


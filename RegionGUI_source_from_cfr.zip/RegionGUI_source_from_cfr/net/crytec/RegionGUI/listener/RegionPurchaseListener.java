/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.shaded.org.apache.lang3.StringUtils
 *  org.bukkit.Bukkit
 *  org.bukkit.World
 *  org.bukkit.command.CommandSender
 *  org.bukkit.entity.Player
 *  org.bukkit.event.EventHandler
 *  org.bukkit.event.Listener
 */
package net.crytec.RegionGUI.listener;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.List;
import java.util.logging.Logger;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.events.RegionPurchasedEvent;
import net.crytec.shaded.org.apache.lang3.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class RegionPurchaseListener
implements Listener {
    @EventHandler
    public void onRegionPurchase(RegionPurchasedEvent regionPurchasedEvent) {
        RegionClaim regionClaim = regionPurchasedEvent.getRegionClaim();
        Player player = regionPurchasedEvent.getPlayer();
        if (regionClaim.getRunCommands().isEmpty()) {
            return;
        }
        for (String string : regionClaim.getRunCommands()) {
            String string2 = string.replace("%player%", player.getName()).replace("%region%", regionPurchasedEvent.getProtectedRegion().getId()).replace("%world%", player.getWorld().getName());
            if (string2.startsWith("<server>")) {
                string2 = string2.replace("<server>", "");
                string2 = StringUtils.trim((String)string2);
                RegionGUI.getInstance().getLogger().info("Performing Command:" + string2);
                Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), string2);
                continue;
            }
            player.performCommand(string2);
        }
    }
}


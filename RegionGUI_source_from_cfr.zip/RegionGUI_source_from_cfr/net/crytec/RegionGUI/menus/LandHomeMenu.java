/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldedit.util.Location
 *  com.sk89q.worldguard.protection.flags.Flag
 *  com.sk89q.worldguard.protection.flags.Flags
 *  com.sk89q.worldguard.protection.flags.LocationFlag
 *  com.sk89q.worldguard.protection.managers.RegionManager
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.inventory.content.Pagination
 *  net.crytec.phoenix.api.inventory.content.SlotIterator
 *  net.crytec.phoenix.api.inventory.content.SlotIterator$Type
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  org.bukkit.Bukkit
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 */
package net.crytec.RegionGUI.menus;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.LocationFlag;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.UnaryOperator;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class LandHomeMenu
implements InventoryProvider {
    private static final ItemStack fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();

    public void init(Player player, InventoryContents inventoryContents) {
        inventoryContents.fillBorders(ClickableItem.empty((ItemStack)fill));
        Pagination pagination = inventoryContents.pagination();
        ArrayList<ClickableItem> arrayList = new ArrayList<ClickableItem>();
        for (ClaimEntry object2 : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId())) {
            World world = object2.getTemplate().getWorld().get();
            RegionManager regionManager = RegionUtils.getRegionManager(world);
            ProtectedRegion protectedRegion = regionManager.getRegion(object2.getRegionID());
            if (protectedRegion == null) {
                Bukkit.getLogger().severe("WorldGuard region is missing [" + object2.getRegionID() + "]. This region is still assigned to the player but missing in WorldGuard!");
                Bukkit.getLogger().severe("world: " + world.getName() + " template id: " + object2.getTemplate());
                continue;
            }
            ArrayList<String> arrayList2 = new ArrayList<String>(Language.INTERFACE_HOME_ENTRYBUTTON_DESCRIPTION.getDescriptionArray());
            arrayList2.replaceAll(string -> string.replace("%world%", world.getName()));
            arrayList.add(ClickableItem.of((ItemStack)new ItemBuilder(Material.GRAY_BED).name(object2.getRegionID()).lore(arrayList2).build(), inventoryClickEvent -> {
                if (protectedRegion.getFlag((Flag)Flags.TELE_LOC) != null) {
                    com.sk89q.worldedit.util.Location location = (com.sk89q.worldedit.util.Location)protectedRegion.getFlag((Flag)Flags.TELE_LOC);
                    Location location2 = BukkitAdapter.adapt((com.sk89q.worldedit.util.Location)location);
                    player.teleport(location2);
                } else {
                    player.sendMessage(Language.ERROR_NO_HOME_SET.toChatString());
                }
            }));
        }
        ClickableItem[] arrclickableItem = new ClickableItem[arrayList.size()];
        ClickableItem[] arrclickableItem2 = arrayList.toArray((T[])arrclickableItem);
        pagination.setItems(arrclickableItem2);
        pagination.setItemsPerPage(27);
        if (!pagination.isLast()) {
            inventoryContents.set(4, 6, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.next().getPage())));
        }
        if (!pagination.isFirst()) {
            inventoryContents.set(4, 2, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.previous().getPage())));
        }
        SlotIterator slotIterator = inventoryContents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 1);
        slotIterator = slotIterator.allowOverride(false);
        pagination.addToIterator(slotIterator);
    }
}


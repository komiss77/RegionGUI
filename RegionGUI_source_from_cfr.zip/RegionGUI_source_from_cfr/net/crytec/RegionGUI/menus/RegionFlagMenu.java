/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.inventory.content.Pagination
 *  net.crytec.phoenix.api.inventory.content.SlotIterator
 *  net.crytec.phoenix.api.inventory.content.SlotIterator$Type
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.permissions.Permission
 */
package net.crytec.RegionGUI.menus;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.LinkedList;
import java.util.Optional;
import java.util.function.Consumer;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.menus.RegionManageInterface;
import net.crytec.RegionGUI.utils.flags.FlagManager;
import net.crytec.RegionGUI.utils.flags.FlagSetting;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.Permission;

public class RegionFlagMenu
implements InventoryProvider {
    private static final ItemStack fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    private final FlagManager flagManager;
    private final ClaimEntry claim;

    public RegionFlagMenu(ClaimEntry claimEntry) {
        this.claim = claimEntry;
        this.flagManager = RegionGUI.getInstance().getFlagManager();
    }

    public void init(Player player, InventoryContents inventoryContents) {
        inventoryContents.fillRow(0, ClickableItem.empty((ItemStack)fill));
        inventoryContents.fillRow(4, ClickableItem.empty((ItemStack)fill));
        ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        Pagination pagination = inventoryContents.pagination();
        LinkedList linkedList = new LinkedList();
        this.flagManager.getFlagMap().forEach(flagSetting -> {
            if (player.hasPermission(flagSetting.getPermission()) || player.hasPermission("region.flagmenu.all")) {
                linkedList.add(flagSetting.getButton(player, protectedRegion, inventoryContents));
            }
        });
        ClickableItem[] arrclickableItem = new ClickableItem[linkedList.size()];
        arrclickableItem = linkedList.toArray((T[])arrclickableItem);
        SlotIterator slotIterator = inventoryContents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0);
        slotIterator = slotIterator.allowOverride(false);
        pagination.setItems(arrclickableItem);
        pagination.setItemsPerPage(27);
        pagination.addToIterator(slotIterator);
        inventoryContents.set(4, 4, ClickableItem.of((ItemStack)new ItemBuilder(Material.RED_WOOL).name(Language.INTERFACE_BACK.toString()).build(), inventoryClickEvent -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        if (!pagination.isLast()) {
            inventoryContents.set(4, 6, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.next().getPage(), new String[]{"region"}, new Object[]{protectedRegion})));
        }
        if (!pagination.isFirst()) {
            inventoryContents.set(4, 2, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.previous().getPage(), new String[]{"region"}, new Object[]{protectedRegion})));
        }
        pagination.addToIterator(inventoryContents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0));
    }

    public void update(Player player, InventoryContents inventoryContents) {
    }
}


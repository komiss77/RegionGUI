/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.util.formatting.text.Component
 *  com.sk89q.worldguard.WorldGuard
 *  com.sk89q.worldguard.domains.DefaultDomain
 *  com.sk89q.worldguard.domains.PlayerDomain
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  com.sk89q.worldguard.util.profile.Profile
 *  com.sk89q.worldguard.util.profile.cache.ProfileCache
 *  net.crytec.phoenix.api.PhoenixAPI
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.inventory.content.Pagination
 *  net.crytec.phoenix.api.inventory.content.SlotIterator
 *  net.crytec.phoenix.api.inventory.content.SlotIterator$Type
 *  net.crytec.phoenix.api.inventory.content.SlotPos
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  net.crytec.phoenix.api.utils.UtilPlayer
 *  org.bukkit.Bukkit
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.Sound
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.inventory.meta.ItemMeta
 *  org.bukkit.inventory.meta.SkullMeta
 */
package net.crytec.RegionGUI.menus;

import com.sk89q.worldedit.util.formatting.text.Component;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.domains.DefaultDomain;
import com.sk89q.worldguard.domains.PlayerDomain;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.util.profile.Profile;
import com.sk89q.worldguard.util.profile.cache.ProfileCache;
import java.util.ArrayList;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.events.RegionAddMemberEvent;
import net.crytec.RegionGUI.events.RegionRemoveMemberEvent;
import net.crytec.RegionGUI.menus.RegionManageInterface;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

public class RegionManageMember
implements InventoryProvider {
    private static final ItemStack fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    private final ClaimEntry claim;

    public RegionManageMember(ClaimEntry claimEntry) {
        this.claim = claimEntry;
    }

    public void init(Player player, InventoryContents inventoryContents) {
        Object object2;
        inventoryContents.fillBorders(ClickableItem.empty((ItemStack)fill));
        ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        Pagination pagination = inventoryContents.pagination();
        ArrayList<ClickableItem> arrayList = new ArrayList<ClickableItem>();
        for (Object object2 : protectedRegion.getMembers().getUniqueIds()) {
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)object2);
            String string = offlinePlayer.hasPlayedBefore() ? offlinePlayer.getName() : "Unknown Name";
            ItemStack itemStack = new ItemBuilder(Material.PLAYER_HEAD).name("\u00a7f" + string).lore(Language.INTERFACE_REMOVE_DESC.toString().replaceAll("%name%", string)).build();
            if (offlinePlayer.hasPlayedBefore()) {
                ItemStack itemStack2 = itemStack;
                SkullMeta skullMeta = (SkullMeta)itemStack2.getItemMeta();
                skullMeta.hasOwner();
                skullMeta.setOwningPlayer(offlinePlayer);
                itemStack2.setItemMeta((ItemMeta)skullMeta);
            }
            arrayList.add(ClickableItem.of((ItemStack)itemStack, arg_0 -> this.lambda$0(player, (UUID)object2, inventoryContents, protectedRegion, pagination, string, arg_0)));
        }
        object2 = new ClickableItem[arrayList.size()];
        object2 = arrayList.toArray((T[])object2);
        pagination.setItems(object2);
        pagination.setItemsPerPage(18);
        inventoryContents.set(SlotPos.of((int)0, (int)4), ClickableItem.of((ItemStack)new ItemBuilder(Material.WRITABLE_BOOK).name(Language.INTERFACE_MANAGE_BUTTON_ADDMEMBER.toString()).build(), inventoryClickEvent -> {
            player.closeInventory();
            player.sendMessage(Language.REGION_MESSAGE_CHATADDMEMBER.toChatString());
            PhoenixAPI.get().getPlayerChatInput(player, string -> {
                OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((String)string);
                if (!offlinePlayer.hasPlayedBefore()) {
                    player.sendMessage(Language.ERROR_INVALID_OFFLINEPLAYER.toChatString());
                    return;
                }
                RegionAddMemberEvent regionAddMemberEvent = new RegionAddMemberEvent(player, this.claim.getTemplate(), offlinePlayer.getUniqueId());
                Bukkit.getPluginManager().callEvent((Event)regionAddMemberEvent);
                if (regionAddMemberEvent.isCancelled()) {
                    this.reOpen(player, inventoryContents);
                    return;
                }
                DefaultDomain defaultDomain = protectedRegion.getMembers();
                PlayerDomain playerDomain = defaultDomain.getPlayerDomain();
                playerDomain.addPlayer(offlinePlayer.getUniqueId());
                defaultDomain.setPlayerDomain(playerDomain);
                protectedRegion.setMembers(defaultDomain);
                protectedRegion.setDirty(true);
                Profile profile = new Profile(offlinePlayer.getUniqueId(), offlinePlayer.getName());
                WorldGuard.getInstance().getProfileCache().put(profile);
                defaultDomain.toUserFriendlyComponent(WorldGuard.getInstance().getProfileCache());
                this.reOpen(player, inventoryContents);
            });
        }));
        inventoryContents.set(4, 4, ClickableItem.of((ItemStack)new ItemBuilder(Material.RED_WOOL).name(Language.INTERFACE_BACK.toString()).build(), inventoryClickEvent -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        inventoryContents.set(4, 6, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.next().getPage(), new String[]{"region"}, new Object[]{protectedRegion})));
        inventoryContents.set(4, 2, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.previous().getPage(), new String[]{"region"}, new Object[]{protectedRegion})));
        SlotIterator slotIterator = inventoryContents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 1);
        slotIterator = slotIterator.allowOverride(false);
        pagination.addToIterator(slotIterator);
    }

    private /* synthetic */ void lambda$0(Player player, UUID uUID, InventoryContents inventoryContents, ProtectedRegion protectedRegion, Pagination pagination, String string, InventoryClickEvent inventoryClickEvent) {
        RegionRemoveMemberEvent regionRemoveMemberEvent = new RegionRemoveMemberEvent(player, this.claim.getTemplate(), uUID);
        Bukkit.getPluginManager().callEvent((Event)regionRemoveMemberEvent);
        if (regionRemoveMemberEvent.isCancelled()) {
            inventoryContents.inventory().open(player, new String[]{"region"}, new Object[]{protectedRegion});
            return;
        }
        protectedRegion.getMembers().removePlayer(uUID);
        inventoryContents.inventory().open(player, pagination.getPage(), new String[]{"region"}, new Object[]{protectedRegion});
        UtilPlayer.playSound((Player)player, (Sound)Sound.BLOCK_LEVER_CLICK);
        player.sendMessage(Language.INTERFACE_REMOVE_SUCESSFULL.toChatString().replaceAll("%name%", string));
    }
}


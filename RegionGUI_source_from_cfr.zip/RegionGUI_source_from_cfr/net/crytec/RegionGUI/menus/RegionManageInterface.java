/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldedit.bukkit.BukkitAdapter
 *  com.sk89q.worldguard.domains.DefaultDomain
 *  com.sk89q.worldguard.protection.flags.Flag
 *  com.sk89q.worldguard.protection.flags.Flags
 *  com.sk89q.worldguard.protection.flags.LocationFlag
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Location
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.enchantments.Enchantment
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 */
package net.crytec.RegionGUI.menus;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.domains.DefaultDomain;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.LocationFlag;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.BorderDisplay;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.menus.RegionDeleteConfirm;
import net.crytec.RegionGUI.menus.RegionFlagMenu;
import net.crytec.RegionGUI.menus.RegionManageMember;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class RegionManageInterface
implements InventoryProvider {
    private static final ItemStack fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    private final ClaimEntry claim;

    public RegionManageInterface(ClaimEntry claimEntry) {
        this.claim = claimEntry;
    }

    public void init(Player player, InventoryContents inventoryContents) {
        inventoryContents.fillBorders(ClickableItem.empty((ItemStack)fill));
        if (!this.claim.getProtectedRegion().isPresent()) {
            RegionGUI.getInstance().getLogger().severe("Failed to open /land interface - WorldGuard Region does no longer exist.");
            player.closeInventory();
            return;
        }
        ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        Iterator iterator = protectedRegion.getMembers().getUniqueIds().iterator();
        ArrayList<String> arrayList = new ArrayList<String>();
        arrayList.add(Language.INTERFACE_MANAGE_MEMBERS.toString());
        while (iterator.hasNext()) {
            OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)((UUID)iterator.next()));
            if (!offlinePlayer.hasPlayedBefore()) continue;
            arrayList.add((Object)ChatColor.GOLD + offlinePlayer.getName());
        }
        if (player.hasPermission("region.manage.members")) {
            inventoryContents.set(1, 1, ClickableItem.of((ItemStack)new ItemBuilder(Material.PLAYER_HEAD).name(Language.INTERFACE_MANAGE_BUTTON_MANAGE_MEMBERS.toString()).build(), inventoryClickEvent -> SmartInventory.builder().id("regiongui.deletemember").provider((InventoryProvider)new RegionManageMember(this.claim)).size(5).title(Language.INTERFACE_REMOVE_TITLE.toString()).build().open(player)));
        }
        inventoryContents.set(1, 3, ClickableItem.of((ItemStack)new ItemBuilder(Material.ENDER_PEARL).name(Language.INTERFACE_HOME_BUTTON.toString()).lore(Language.INTERFACE_HOME_BUTTON_DESC.getDescriptionArray()).build(), inventoryClickEvent -> {
            protectedRegion.setFlag((Flag)Flags.TELE_LOC, (Object)BukkitAdapter.adapt((Location)player.getLocation()));
            protectedRegion.setDirty(true);
            player.sendMessage(Language.INTERFACE_HOME_BUTTON_SUCCESS.toChatString());
        }));
        inventoryContents.set(0, 4, ClickableItem.empty((ItemStack)new ItemBuilder(Material.BOOK).name(Language.INTERFACE_MANAGE_BUTTON_INFO.toString()).lore(Language.INTERFACE_MANAGE_BUTTON_INFO_DESCRIPTION.getDescriptionArray()).enchantment(Enchantment.ARROW_INFINITE).setItemFlag(ItemFlag.HIDE_ENCHANTS).build()));
        if (player.hasPermission("region.manage.delregion")) {
            inventoryContents.set(0, 8, ClickableItem.of((ItemStack)new ItemBuilder(Material.TNT).name(Language.INTERFACE_MANAGE_BUTTON_DELETEREGION.toString()).lore(Language.INTERFACE_MANAGE_BUTTON_DELETEREGION_DESCRIPTION.getDescriptionArray()).build(), inventoryClickEvent -> {
                Inventory inventory = SmartInventory.builder().provider((InventoryProvider)new RegionDeleteConfirm(this.claim)).title(Language.INTERFACE_DELETE_TITLE.toString()).size(1).build().open(player);
            }));
        }
        if (player.hasPermission("region.manage.flagmenu")) {
            inventoryContents.set(1, 5, ClickableItem.of((ItemStack)new ItemBuilder(Material.COMMAND_BLOCK).name(Language.INTERFACE_MANAGE_BUTTON_FLAG.toString()).build(), inventoryClickEvent -> SmartInventory.builder().id("regiongui.flagMenu").provider((InventoryProvider)new RegionFlagMenu(this.claim)).size(5, 9).title(Language.FLAG_TITLE.toString()).build().open(player)));
        }
        inventoryContents.set(1, 7, ClickableItem.of((ItemStack)new ItemBuilder(Material.EXPERIENCE_BOTTLE).name(Language.INTERFACE_MANAGE_BUTTON_SHOWBORDER.toString()).lore(Language.INTERFACE_MANAGE_BUTTON_SHOWBORDER_DESCRIPTION.getDescriptionArray()).build(), inventoryClickEvent -> {
            BorderDisplay borderDisplay = new BorderDisplay(player, this.claim);
        }));
    }
}


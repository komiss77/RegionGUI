/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.phoenix.api.PhoenixAPI
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  net.crytec.phoenix.api.utils.UtilMath
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.World
 *  org.bukkit.configuration.file.FileConfiguration
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Event
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.ItemFlag
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.permissions.PermissionAttachmentInfo
 */
package net.crytec.RegionGUI.menus;

import com.google.common.collect.Lists;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.UnaryOperator;
import java.util.stream.Stream;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.data.RegionPreview;
import net.crytec.RegionGUI.events.RegionPrePurchaseEvent;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.utils.PlotBuilder;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import net.crytec.phoenix.api.utils.UtilMath;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.permissions.PermissionAttachmentInfo;

public class LandBuyMenu
implements InventoryProvider {
    private final ClaimManager manager;
    private final RegionGUI plugin;

    public LandBuyMenu(RegionGUI regionGUI) {
        this.plugin = regionGUI;
        this.manager = regionGUI.getClaimManager();
    }

    public void init(Player player, InventoryContents inventoryContents) {
        ArrayList arrayList = Lists.newArrayList(this.manager.getTemplates(player.getWorld()));
        if (arrayList == null || arrayList.isEmpty()) {
            player.closeInventory();
            return;
        }
        Collections.sort(arrayList);
        if (arrayList.isEmpty()) {
            player.closeInventory();
            return;
        }
        int n = 2;
        long l = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId()).stream().filter(claimEntry -> {
            if (claimEntry.getTemplate().getWorld().isPresent()) {
                return claimEntry.getTemplate().getWorld().get().getName().equals(player.getWorld().getName());
            }
            return false;
        }).count();
        for (PermissionAttachmentInfo permissionAttachmentInfo : player.getEffectivePermissions()) {
            if (permissionAttachmentInfo.getPermission().startsWith("region.maxregions.")) {
                if (UtilMath.isInt((String)permissionAttachmentInfo.getPermission().split("region.maxregions.")[1])) {
                    n = Math.max(n, Integer.valueOf(permissionAttachmentInfo.getPermission().split("region.maxregions.")[1]));
                } else {
                    n = 0;
                    RegionGUI.getInstance().log("\u00a7c[ERROR] Failed to parse permission node [\u00a76" + permissionAttachmentInfo.getPermission().split("region.maxregions.")[1] + "\u00a7c]", true);
                    RegionGUI.getInstance().log("\u00a7c[ERROR] Make sure the last entry is a valid number!", true);
                }
            }
            if (n >= 0) continue;
            n = 0;
        }
        if (l >= (long)n) {
            player.sendMessage(Language.ERROR_MAX_REGIONS.toString());
            player.closeInventory();
            return;
        }
        int n2 = 0;
        for (Object object : arrayList) {
            ItemBuilder itemBuilder = new ItemBuilder(((RegionClaim)object).getIcon().clone());
            itemBuilder.name(ChatColor.translateAlternateColorCodes((char)'&', (String)((RegionClaim)object).getDisplayname()));
            itemBuilder.setItemFlag(ItemFlag.HIDE_ATTRIBUTES);
            int n3 = n;
            ArrayList<String> arrayList2 = new ArrayList<String>(((RegionClaim)object).getDescription());
            arrayList2.replaceAll(string -> string.replaceAll("%current%", String.valueOf(l)));
            arrayList2.replaceAll(string -> string.replaceAll("%max_claims%", String.valueOf(n3)));
            arrayList2.replaceAll(arg_0 -> LandBuyMenu.lambda$3((RegionClaim)object, arg_0));
            arrayList2.replaceAll(arg_0 -> LandBuyMenu.lambda$4((RegionClaim)object, arg_0));
            arrayList2.replaceAll(arg_0 -> LandBuyMenu.lambda$5((RegionClaim)object, arg_0));
            arrayList2.replaceAll(string -> ChatColor.translateAlternateColorCodes((char)'&', (String)string));
            itemBuilder.lore(arrayList2);
            if (!((RegionClaim)object).getPermission().isEmpty() && !player.hasPermission(((RegionClaim)object).getPermission())) {
                itemBuilder.lore("");
                itemBuilder.lore(((RegionClaim)object).getNoPermDescription());
                inventoryContents.set(0, n2, ClickableItem.empty((ItemStack)itemBuilder.build()));
            } else {
                inventoryContents.add(ClickableItem.of((ItemStack)itemBuilder.build(), arg_0 -> this.lambda$7(player, (RegionClaim)object, arg_0)));
            }
            ++n2;
        }
    }

    private static /* synthetic */ String lambda$3(RegionClaim regionClaim, String string) {
        return string.replaceAll("%size%", String.valueOf(regionClaim.getSize()));
    }

    private static /* synthetic */ String lambda$4(RegionClaim regionClaim, String string) {
        return string.replaceAll("%depth%", String.valueOf(regionClaim.getDepth()));
    }

    private static /* synthetic */ String lambda$5(RegionClaim regionClaim, String string) {
        return string.replaceAll("%height%", String.valueOf(regionClaim.getHeight()));
    }

    private /* synthetic */ void lambda$7(Player player, RegionClaim regionClaim, InventoryClickEvent inventoryClickEvent) {
        if (inventoryClickEvent.getClick() == ClickType.LEFT) {
            RegionPrePurchaseEvent regionPrePurchaseEvent = new RegionPrePurchaseEvent(player, regionClaim.getPrice(), regionClaim, regionClaim.isGenerateBorder());
            Bukkit.getPluginManager().callEvent((Event)regionPrePurchaseEvent);
            if (regionPrePurchaseEvent.isCancelled()) {
                return;
            }
            player.closeInventory();
            player.sendMessage(Language.CHAT_ENTER_REGIONNAME.toChatString());
            PhoenixAPI.get().getPlayerChatInput(player, string -> {
                if (!string.matches("^[a-zA-Z0-9\\-\\_]*$")) {
                    player.sendMessage(Language.ERROR_INVALID_NAME.toChatString());
                    return;
                }
                String string2 = this.plugin.getConfig().getString("region-identifier").replace("%player%", player.getName()).replace("%displayname%", (CharSequence)string);
                ProtectedRegion protectedRegion = RegionUtils.getRegionManager(player.getWorld()).getRegion(string2);
                if (protectedRegion != null) {
                    player.sendMessage(Language.ERROR_REGIONNAME_ALREADY_EXISTS.toChatString());
                    return;
                }
                PlotBuilder plotBuilder = new PlotBuilder(player, (String)string, regionClaim);
                plotBuilder.build();
                player.resetTitle();
            });
        } else if (inventoryClickEvent.getClick() == ClickType.RIGHT) {
            new net.crytec.RegionGUI.data.RegionPreview(player, regionClaim.getSize() + 1);
            player.closeInventory();
        }
    }
}


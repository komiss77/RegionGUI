/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.inventory.content.Pagination
 *  net.crytec.phoenix.api.inventory.content.SlotIterator
 *  net.crytec.phoenix.api.inventory.content.SlotIterator$Type
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 */
package net.crytec.RegionGUI.menus;

import java.util.ArrayList;
import java.util.Set;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.menus.RegionManageInterface;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class RegionSelectMenu
implements InventoryProvider {
    private final Set<ClaimEntry> claims;

    public RegionSelectMenu(Set<ClaimEntry> set) {
        this.claims = set;
    }

    public void init(Player player, InventoryContents inventoryContents) {
        Pagination pagination = inventoryContents.pagination();
        ArrayList<ClickableItem> arrayList = new ArrayList<ClickableItem>();
        for (ClaimEntry object2 : this.claims) {
            String string = (Object)ChatColor.GREEN + object2.getRegionID();
            String string2 = Language.INTERFACE_SELECT_DESCRIPTION.toString().replace("%region%", string);
            ItemStack itemStack = new ItemBuilder(Material.BOOK).name(string).lore(string2).build();
            arrayList.add(ClickableItem.of((ItemStack)itemStack, inventoryClickEvent -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(object2)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        }
        ClickableItem[] arrclickableItem = new ClickableItem[arrayList.size()];
        ClickableItem[] arrclickableItem2 = arrayList.toArray((T[])arrclickableItem);
        pagination.setItems(arrclickableItem2);
        pagination.setItemsPerPage(18);
        pagination.addToIterator(inventoryContents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0));
    }
}


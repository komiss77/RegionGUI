/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  net.milkbowl.vault.economy.Economy
 *  net.milkbowl.vault.economy.EconomyResponse
 *  org.bukkit.Material
 *  org.bukkit.OfflinePlayer
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 */
package net.crytec.RegionGUI.menus;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.io.PrintStream;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.menus.RegionManageInterface;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class RegionDeleteConfirm
implements InventoryProvider {
    private static final ItemStack fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    private final ClaimEntry claim;

    public RegionDeleteConfirm(ClaimEntry claimEntry) {
        this.claim = claimEntry;
    }

    public void init(Player player, InventoryContents inventoryContents) {
        inventoryContents.fill(ClickableItem.empty((ItemStack)fill));
        if (!this.claim.getProtectedRegion().isPresent()) {
            System.out.println("Claim not present");
            player.closeInventory();
            return;
        }
        ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        inventoryContents.set(0, 2, ClickableItem.of((ItemStack)new ItemBuilder(Material.REDSTONE).name(Language.INTERFACE_DELETE_ABORT_BUTTON.toString()).build(), inventoryClickEvent -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        inventoryContents.set(0, 6, ClickableItem.of((ItemStack)new ItemBuilder(Material.EMERALD).name(Language.INTERFACE_DELETE_CONFIRM_BUTTON.toString()).build(), inventoryClickEvent -> {
            player.closeInventory();
            RegionGUI.getInstance().getPlayerManager().deleteClaim(player.getUniqueId(), protectedRegion);
            RegionUtils.getRegionManager(player.getWorld()).removeRegion(protectedRegion.getId());
            RegionUtils.saveRegions(player.getWorld());
            if (this.claim.getTemplate().hasRefund()) {
                RegionGUI.econ.depositPlayer((OfflinePlayer)player, (double)this.claim.getTemplate().getRefund());
                player.sendMessage(Language.REGION_REMOVED_REFUNDED.toString().replaceAll("%refund%", String.valueOf(this.claim.getTemplate().getRefund())));
            }
            player.sendMessage(Language.REGION_REMOVED.toChatString());
        }));
    }
}


/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  net.crytec.phoenix.api.implementation.AnvilGUI
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.inventory.content.SlotPos
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  net.crytec.phoenix.api.utils.UtilPlayer
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.ItemStack
 */
package net.crytec.RegionGUI.menus.admin;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.UnaryOperator;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.RegionGUI.menus.admin.TemplateEditor;
import net.crytec.phoenix.api.implementation.AnvilGUI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class AdminTemplateList
implements InventoryProvider {
    private final ClaimManager claimManager = RegionGUI.getInstance().getClaimManager();

    public void init(Player player, InventoryContents inventoryContents) {
        World world = player.getWorld();
        ArrayList<RegionClaim> arrayList = new ArrayList<RegionClaim>(this.claimManager.getTemplates(world));
        Collections.sort(arrayList);
        for (RegionClaim regionClaim : arrayList) {
            ItemBuilder itemBuilder = new ItemBuilder(regionClaim.getIcon() == null ? Material.BARRIER : regionClaim.getIcon().getType());
            itemBuilder.name(ChatColor.translateAlternateColorCodes((char)'&', (String)regionClaim.getDisplayname()));
            ArrayList<String> arrayList2 = new ArrayList<String>(regionClaim.getDescription());
            arrayList2.replaceAll(string -> ChatColor.translateAlternateColorCodes((char)'&', (String)string));
            itemBuilder.lore(arrayList2);
            inventoryContents.add(ClickableItem.of((ItemStack)itemBuilder.build(), inventoryClickEvent -> {
                UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
                SmartInventory.builder().provider((InventoryProvider)new TemplateEditor(regionClaim)).size(5).title("Editing " + regionClaim.getDisplayname()).build().open(player);
            }));
        }
        inventoryContents.set(SlotPos.of((int)5, (int)4), new ClickableItem(new ItemBuilder(Material.EMERALD).name("\u00a72Create new template").build(), inventoryClickEvent -> {
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            new net.crytec.phoenix.api.implementation.AnvilGUI(player, "template", (player2, string) -> {
                RegionClaim regionClaim = new RegionClaim(player2.getWorld());
                this.claimManager.registerTemplate(regionClaim);
                this.claimManager.save();
                this.reOpen(player, inventoryContents);
                return null;
            });
        }));
    }
}


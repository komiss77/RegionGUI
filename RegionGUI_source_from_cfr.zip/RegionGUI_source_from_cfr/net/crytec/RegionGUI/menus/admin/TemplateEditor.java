/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  net.crytec.phoenix.api.PhoenixAPI
 *  net.crytec.phoenix.api.inventory.ClickableItem
 *  net.crytec.phoenix.api.inventory.ConfirmationGUI
 *  net.crytec.phoenix.api.inventory.SmartInventory
 *  net.crytec.phoenix.api.inventory.SmartInventory$Builder
 *  net.crytec.phoenix.api.inventory.buttons.InputButton
 *  net.crytec.phoenix.api.inventory.content.InventoryContents
 *  net.crytec.phoenix.api.inventory.content.InventoryProvider
 *  net.crytec.phoenix.api.inventory.content.SlotPos
 *  net.crytec.phoenix.api.item.ItemBuilder
 *  net.crytec.phoenix.api.item.ItemFactory
 *  net.crytec.phoenix.api.utils.F
 *  net.crytec.phoenix.api.utils.UtilMath
 *  net.crytec.phoenix.api.utils.UtilPlayer
 *  org.bukkit.Bukkit
 *  org.bukkit.ChatColor
 *  org.bukkit.Material
 *  org.bukkit.Sound
 *  org.bukkit.World
 *  org.bukkit.entity.Player
 *  org.bukkit.event.inventory.ClickType
 *  org.bukkit.event.inventory.InventoryClickEvent
 *  org.bukkit.inventory.Inventory
 *  org.bukkit.inventory.InventoryView
 *  org.bukkit.inventory.ItemStack
 *  org.bukkit.plugin.Plugin
 *  org.bukkit.scheduler.BukkitTask
 */
package net.crytec.RegionGUI.menus.admin;

import com.google.common.collect.Lists;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.RegionGUI.menus.admin.AdminTemplateList;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.ConfirmationGUI;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.buttons.InputButton;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import net.crytec.phoenix.api.utils.F;
import net.crytec.phoenix.api.utils.UtilMath;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class TemplateEditor
implements InventoryProvider {
    private static final ItemStack filler = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    private final RegionClaim claim;

    public TemplateEditor(RegionClaim regionClaim) {
        this.claim = regionClaim;
    }

    public void init(Player player, InventoryContents inventoryContents) {
        inventoryContents.fillRow(0, ClickableItem.empty((ItemStack)filler));
        inventoryContents.fillRow(4, ClickableItem.empty((ItemStack)filler));
        inventoryContents.set(SlotPos.of((int)0, (int)4), ClickableItem.of((ItemStack)new ItemBuilder(this.claim.getIcon()).name("\u00a77Set list icon").lore("\u00a77Click with an Item on your").lore("\u00a77curser to set the list icon").build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.LEFT && inventoryClickEvent.getCursor() != null && inventoryClickEvent.getCursor().getType() != Material.AIR) {
                UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
                this.claim.setIcon(inventoryClickEvent.getCursor().getType());
                inventoryClickEvent.getView().getBottomInventory().addItem(new ItemStack[]{inventoryClickEvent.getCursor()});
                inventoryClickEvent.getView().setCursor(new ItemStack(Material.AIR));
                this.reOpen(player, inventoryContents);
            }
        }));
        inventoryContents.set(SlotPos.of((int)1, (int)0), (ClickableItem)new InputButton(new ItemBuilder(Material.NAME_TAG).name("\u00a77Template").lore("\u00a77Current name: \u00a76" + this.claim.getDisplayname()).build(), "Name..", string -> {
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            this.claim.setDisplayname((String)string);
            SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("\u00a78Template Editor [" + player.getWorld().getName() + "]").build().open(player);
        }));
        inventoryContents.set(SlotPos.of((int)2, (int)0), ClickableItem.of((ItemStack)new ItemBuilder(Material.BOOK).name("\u00a77Description").lore("\u00a77Current description:").lore(this.claim.getDescription().stream().map(string -> ChatColor.translateAlternateColorCodes((char)'&', (String)string)).collect(Collectors.toList())).lore("").lore("\u00a7aLeft click \u00a77to add a new line").lore("\u00a7aRight click \u00a77to delete the last line.").build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.RIGHT) {
                if (this.claim.getDescription().size() <= 0) {
                    return;
                }
                List<String> list = this.claim.getDescription();
                list.remove(list.size() - 1);
                this.claim.setDescription(list);
                this.reOpen(player, inventoryContents);
                return;
            }
            player.closeInventory();
            player.sendMessage("\u00a77Enter a new line. Type \u00a7eexit\u00a77 to abort");
            PhoenixAPI.get().getPlayerChatInput(player, string -> {
                if (string.equals("exit")) {
                    Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, inventoryContents));
                    return;
                }
                ArrayList arrayList = this.claim.getDescription() == null ? Lists.newArrayList() : this.claim.getDescription();
                arrayList.add(string);
                this.claim.setDescription(arrayList);
                Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, inventoryContents));
            });
        }));
        inventoryContents.set(SlotPos.of((int)1, (int)1), (ClickableItem)new InputButton(new ItemBuilder(Material.BLAZE_POWDER).name("\u00a77Set Permission").lore("\u00a77Current Permission: \u00a76" + this.claim.getPermission()).build(), "permission..", string -> {
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            this.claim.setPermission((String)string);
            this.reOpen(player, inventoryContents);
        }));
        inventoryContents.set(SlotPos.of((int)2, (int)1), ClickableItem.of((ItemStack)new ItemBuilder(Material.REDSTONE_TORCH).name("\u00a77Set 'No Permission' description").lore("\u00a7eThis lines will be added below").lore("\u00a7ethe claim description in /land").lore("").lore("\u00a77Current:").lore(this.claim.getNoPermDescription()).lore("\u00a7aLeft click \u00a77to add a new line").lore("\u00a7aRight click \u00a77to delete the last line.").build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.RIGHT) {
                if (this.claim.getDescription().size() <= 0) {
                    return;
                }
                this.claim.getNoPermDescription().remove(this.claim.getNoPermDescription().size() - 1);
                this.reOpen(player, inventoryContents);
                return;
            }
            player.closeInventory();
            player.sendMessage("\u00a77Enter a new line. Type \u00a7eexit\u00a77 to abort");
            PhoenixAPI.get().getPlayerChatInput(player, string -> {
                if (string.equals("exit")) {
                    Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, inventoryContents));
                    return;
                }
                this.claim.getNoPermDescription().add(ChatColor.translateAlternateColorCodes((char)'&', (String)string));
                Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, inventoryContents));
            });
        }));
        inventoryContents.set(SlotPos.of((int)1, (int)2), (ClickableItem)new InputButton(new ItemBuilder(Material.GOLD_NUGGET).name("\u00a77Price").lore("\u00a77Current Price: \u00a76" + this.claim.getPrice()).build(), String.valueOf(this.claim.getPrice()), string -> {
            if (!UtilMath.isInt((String)string)) {
                player.sendMessage("\u00a7cError: \u00a77The given input is not a valid integer!");
                this.reOpen(player, inventoryContents);
                return;
            }
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            this.claim.setPrice(Integer.parseInt(string));
            this.reOpen(player, inventoryContents);
        }));
        inventoryContents.set(SlotPos.of((int)2, (int)2), (ClickableItem)new InputButton(new ItemBuilder(Material.GOLD_NUGGET).name("\u00a77Refund").lore("\u00a77This amount will be \u00a7aadded\u00a77 to").lore("\u00a77the players balance on deletion").lore("\u00a77Current Refund: \u00a76" + this.claim.getRefund()).build(), String.valueOf(this.claim.getRefund()), string -> {
            if (!UtilMath.isInt((String)string)) {
                player.sendMessage("\u00a7cError: \u00a77The given input is not a valid integer!");
                this.reOpen(player, inventoryContents);
                return;
            }
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            this.claim.setRefund(Integer.parseInt(string));
            this.reOpen(player, inventoryContents);
        }));
        inventoryContents.set(SlotPos.of((int)1, (int)3), (ClickableItem)new InputButton(new ItemBuilder(Material.BEACON).name("\u00a77Set Size").lore("\u00a77Current Size: \u00a76" + this.claim.getSize()).lore("\u00a77Increasing the size \u00a7c\u00a7lwill not\u00a77 update").lore("\u00a77already claimed/existing regions.").lore("\u00a77This does only affect new regions").build(), String.valueOf(this.claim.getSize()), string -> {
            if (!UtilMath.isInt((String)string)) {
                player.sendMessage("\u00a7cError: \u00a77The given input is not a valid integer!");
                this.reOpen(player, inventoryContents);
                return;
            }
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            this.claim.setSize(Integer.parseInt(string));
            this.reOpen(player, inventoryContents);
        }));
        inventoryContents.set(SlotPos.of((int)1, (int)5), new ClickableItem(new ItemBuilder(Material.COMMAND_BLOCK).name("\u00a77Commands").lore("\u00a77This is a set of commands that will be").lore("\u00a77executed by the \u00a7a\u00a7lplayer\u00a77 after").lore("\u00a77a successfull purchase.").lore("\u00a77You may use this to set default flags or").lore("\u00a77whatever you want.").lore("\u00a77Valid placeholders:").lore("\u00a7e%player% \u00a77- The players name").lore("\u00a7e%region% \u00a77- The purchased region").lore("\u00a7e%world% \u00a77- The worldname").lore("").lore("\u00a77To run a command from the console,").lore("\u00a77simply put \u00a7e<server>\u00a77 in front").lore("").lore("\u00a77Right click to \u00a7cdelete\u00a77 the last command in the list.").lore("\u00a77Current Commands:").lore(this.claim.getRunCommands()).build(), inventoryClickEvent -> {
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            if (inventoryClickEvent.isRightClick()) {
                if (this.claim.getRunCommands().size() == 0) {
                    return;
                }
                this.claim.getRunCommands().remove(this.claim.getRunCommands().size() - 1);
                this.reOpen(player, inventoryContents);
                return;
            }
            player.closeInventory();
            player.sendMessage("\u00a77Please enter the command you want to add (\u00a7cwithout\u00a77 the first slash (/)): ");
            PhoenixAPI.get().getPlayerChatInput(player, string -> {
                this.claim.getRunCommands().add((String)string);
                this.reOpen(player, inventoryContents);
            });
        }));
        inventoryContents.set(SlotPos.of((int)1, (int)4), ClickableItem.of((ItemStack)new ItemBuilder(Material.OAK_FENCE).name("\u00a77Enable Border").lore("\u00a77Currently enabled: " + F.tf((boolean)this.claim.isGenerateBorder())).build(), inventoryClickEvent -> {
            UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
            this.claim.setGenerateBorder(!this.claim.isGenerateBorder());
            this.reOpen(player, inventoryContents);
        }));
        inventoryContents.set(SlotPos.of((int)2, (int)4), ClickableItem.of((ItemStack)new ItemBuilder(this.claim.getBorderMaterial()).name("\u00a77Set Border Material").lore("\u00a77Click with an Item on your").lore("\u00a77curser to set the border material").build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.LEFT && inventoryClickEvent.getCursor() != null && inventoryClickEvent.getCursor().getType() != Material.AIR) {
                if (!inventoryClickEvent.getCursor().getType().isBlock()) {
                    player.sendMessage("\u00a7cERROR: \u00a77The given material is not a placeable block.");
                    this.reOpen(player, inventoryContents);
                    return;
                }
                UtilPlayer.playSound((Player)player, (Sound)Sound.UI_BUTTON_CLICK, (float)0.5f, (float)1.0f);
                this.claim.setBorderMaterial(inventoryClickEvent.getCursor().getType());
                inventoryClickEvent.getView().getBottomInventory().addItem(new ItemStack[]{inventoryClickEvent.getCursor()});
                inventoryClickEvent.getView().setCursor(new ItemStack(Material.AIR));
                this.reOpen(player, inventoryContents);
            }
        }));
        inventoryContents.set(SlotPos.of((int)4, (int)8), ClickableItem.of((ItemStack)new ItemBuilder(Material.TNT).name("\u00a74Delete template").lore("\u00a77Deleting this template will remove it").lore("\u00a77from all players that have already").lore("\u00a77purchased it.").build(), inventoryClickEvent -> ConfirmationGUI.open((Player)player, (String)"\u00a74Confirm to delete template", bl -> {
            if (bl.booleanValue()) {
                UtilPlayer.playSound((Player)player, (Sound)Sound.ENTITY_GENERIC_EXPLODE, (float)0.5f, (float)1.15f);
                SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("\u00a78Template Editor [" + player.getWorld().getName() + "]").build().open(player);
                RegionGUI.getInstance().getClaimManager().deleteTemplate(this.claim);
            } else {
                this.reOpen(player, inventoryContents);
                UtilPlayer.playSound((Player)player, (Sound)Sound.ENTITY_LEASH_KNOT_PLACE, (float)1.0f, (float)0.85f);
            }
        })));
        inventoryContents.set(SlotPos.of((int)4, (int)4), ClickableItem.of((ItemStack)new ItemBuilder(Material.EMERALD).name("\u00a72Save template").build(), inventoryClickEvent -> {
            RegionGUI.getInstance().getClaimManager().save();
            SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("\u00a78Template Editor [" + player.getWorld().getName() + "]").build().open(player);
        }));
    }
}


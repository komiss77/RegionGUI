/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  com.sk89q.worldguard.protection.regions.ProtectedRegion
 *  org.bukkit.entity.Player
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.player.PlayerEvent
 */
package net.crytec.RegionGUI.events;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

public class RegionPurchasedEvent
extends PlayerEvent {
    private static final HandlerList handlers = new HandlerList();
    private ProtectedRegion region;
    private RegionClaim claim;
    private int price;

    public RegionPurchasedEvent(Player player, int n, RegionClaim regionClaim, ProtectedRegion protectedRegion) {
        super(player);
        this.region = protectedRegion;
        this.claim = regionClaim;
        this.price = n;
    }

    public ProtectedRegion getProtectedRegion() {
        return this.region;
    }

    public RegionClaim getRegionClaim() {
        return this.claim;
    }

    public int getPrice() {
        return this.price;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }
}


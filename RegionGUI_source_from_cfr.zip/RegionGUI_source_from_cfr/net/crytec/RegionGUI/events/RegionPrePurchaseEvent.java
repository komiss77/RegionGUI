/*
 * Decompiled with CFR 0.145.
 * 
 * Could not load the following classes:
 *  org.bukkit.entity.Player
 *  org.bukkit.event.Cancellable
 *  org.bukkit.event.HandlerList
 *  org.bukkit.event.player.PlayerEvent
 */
package net.crytec.RegionGUI.events;

import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

public class RegionPrePurchaseEvent
extends PlayerEvent
implements Cancellable {
    private static final HandlerList handlers = new HandlerList();
    private boolean cancelled = false;
    private boolean generateBorder;
    private RegionClaim claim;
    private int price;

    public RegionPrePurchaseEvent(Player player, int n, RegionClaim regionClaim, boolean bl) {
        super(player);
        this.generateBorder = bl;
        this.claim = regionClaim;
        this.price = n;
    }

    public boolean getGenerateBorder() {
        return this.generateBorder;
    }

    public RegionClaim getRegionClaim() {
        return this.claim;
    }

    public int getPrice() {
        return this.price;
    }

    public void setPrice(int n) {
        this.price = n;
    }

    public void setGenerateBorder(boolean bl) {
        this.generateBorder = bl;
    }

    public HandlerList getHandlers() {
        return handlers;
    }

    public static HandlerList getHandlerList() {
        return handlers;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }

    public void setCancelled(boolean bl) {
        this.cancelled = bl;
    }
}


package net.crytec.RegionGUI.utils.flags;

public enum FlagInputType
{
    SET, 
    STATE, 
    DOUBLE, 
    INTEGER, 
    BOOLEAN, 
    STRING, 
    UNKNOWN;
}

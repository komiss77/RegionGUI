package net.crytec.RegionGUI.utils.flags;

import com.sk89q.worldguard.protection.flags.FlagContext;
import net.crytec.phoenix.api.utils.F;
import net.crytec.phoenix.api.item.ItemFactory;
import com.sk89q.worldguard.protection.flags.InvalidFlagFormat;
import org.bukkit.plugin.Plugin;
import net.crytec.RegionGUI.RegionGUI;
import com.sk89q.worldedit.extension.platform.Actor;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.RegionGUI.Language;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.entity.Player;
import com.sk89q.worldguard.protection.flags.BooleanFlag;
import com.sk89q.worldguard.protection.flags.IntegerFlag;
import com.sk89q.worldguard.protection.flags.SetFlag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.StringFlag;
import org.bukkit.Bukkit;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.permissions.Permission;
import org.bukkit.Material;
import com.sk89q.worldguard.protection.flags.Flag;



public class FlagSetting implements Comparable<FlagSetting>
{
    private Flag<?> flag;
    private String id;
    private Material icon;
    private FlagInputType inputType;
    private final Permission permission;
    private final String displayname;
    
    public FlagSetting(final String id, final Flag<?> flag, final Material icon, final String displayname) {
        this.icon = Material.PAPER;
        this.flag = flag;
        this.id = id;
        this.displayname = displayname;
        this.icon = icon;
        this.permission = new Permission("region.flagmenu." + this.id, "Enables the use of the " + id + " flag.", PermissionDefault.TRUE);
        try {
            Bukkit.getPluginManager().addPermission(this.permission);
        }
        catch (IllegalArgumentException ex) {}
        if (flag instanceof StringFlag) {
            this.inputType = FlagInputType.STRING;
        }
        else if (flag instanceof StateFlag) {
            this.inputType = FlagInputType.STATE;
        }
        else if (flag instanceof SetFlag) {
            this.inputType = FlagInputType.SET;
        }
        else if (flag instanceof IntegerFlag) {
            this.inputType = FlagInputType.INTEGER;
        }
        else if (flag instanceof BooleanFlag) {
            this.inputType = FlagInputType.BOOLEAN;
        }
        else {
            this.inputType = FlagInputType.UNKNOWN;
        }
    }
    
    public ClickableItem getButton(final Player player, final ProtectedRegion region, final InventoryContents contents) {
        final ItemFactory name = new ItemBuilder(this.icon).name("§7" + this.getName());
        name.setItemFlag(ItemFlag.HIDE_ATTRIBUTES);
        name.setItemFlag(ItemFlag.HIDE_ENCHANTS);
        if (region.getFlags().containsKey(this.getFlag())) {
            name.enchantment(Enchantment.ARROW_INFINITE);
            if (this.inputType == FlagInputType.STATE) {
                name.name((region.getFlag((Flag)this.getFlag()) == StateFlag.State.DENY) ? ("§c" + this.getName()) : ("§a" + this.getName()));
            }
        }
        name.lore("");
        name.lore(this.getCurrentValue(region));
        return new ClickableItem(name.build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.RIGHT && region.getFlags().containsKey(this.getFlag())) {
                region.setFlag((Flag)this.getFlag(), (Object)null);
                player.sendMessage(Language.FLAG_CLEARED.toString().replace("%flag%", this.getName()));
                contents.inventory().getProvider().reOpen(player, contents);
            }
            else if (this.inputType == FlagInputType.STATE || this.inputType == FlagInputType.BOOLEAN) {
                this.switchState(player, region);
                contents.inventory().getProvider().reOpen(player, contents);
            }
            else {
                player.closeInventory();
                player.sendMessage(Language.FLAG_INPUT_CHAT.toChatString().replace("%flag%", this.getName()));
                PhoenixAPI.get().getPlayerChatInput(player, value -> {
                    try {
                        setFlag(region, this.flag, (Actor)BukkitAdapter.adapt(player), value);
                        Bukkit.getScheduler().runTaskLater((Plugin)RegionGUI.getInstance(), () -> contents.inventory().getProvider().reOpen(player, contents), 1L);
                    }
                    catch (InvalidFlagFormat invalidFlagFormat) {
                        player.sendMessage(invalidFlagFormat.getMessage());
                    }
                });
            }
        });
    }
    
    private void switchState(final Player player, final ProtectedRegion region) {
        if (this.inputType == FlagInputType.STATE) {
            final StateFlag stateFlag = (StateFlag)this.getFlag();
            if (region.getFlags().containsKey(this.getFlag())) {
                if (region.getFlag((Flag)stateFlag) == StateFlag.State.DENY) {
                    region.setFlag((Flag)stateFlag, (Object)StateFlag.State.ALLOW);
                    player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
                }
                else {
                    region.setFlag((Flag)stateFlag, (Object)StateFlag.State.DENY);
                    player.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
                }
            }
            else {
                region.setFlag((Flag)stateFlag, (Object)StateFlag.State.ALLOW);
                player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            }
        }
        else {
            final BooleanFlag booleanFlag = (BooleanFlag)this.getFlag();
            if (region.getFlags().containsKey(this.getFlag())) {
                if (!(boolean)region.getFlag((Flag)booleanFlag)) {
                    region.setFlag((Flag)booleanFlag, (Object)true);
                    player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
                }
                else {
                    region.setFlag((Flag)booleanFlag, (Object)false);
                    player.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
                }
            }
            else {
                region.setFlag((Flag)booleanFlag, (Object)true);
                player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            }
        }
    }
    
    public String getCurrentValue(final ProtectedRegion region) {
        if (!region.getFlags().containsKey(this.getFlag())) {
            return "§cFlag not set";
        }
        switch (this.inputType) {
            case BOOLEAN: {
                return F.tf((boolean)region.getFlag((Flag)this.getFlag()));
            }
            case DOUBLE: {
                return F.name(new StringBuilder().append((double)region.getFlag((Flag)this.getFlag())).toString());
            }
            case INTEGER: {
                return F.name(new StringBuilder().append((int)region.getFlag((Flag)this.getFlag())).toString());
            }
            case SET: {
                return F.format((Iterable)region.getFlag((Flag)this.getFlag()), ",", "none");
            }
            case STATE: {
                return F.tf(region.getFlag((Flag)this.getFlag()) != StateFlag.State.DENY);
            }
            case STRING: {
                return F.name(((String)region.getFlag((Flag)this.getFlag())).toString());
            }
            case UNKNOWN: {
                return "§7Unknown";
            }
            default: {
                return "Unable to query flag value";
            }
        }
    }
    
    public void setIcon(final Material mat) {
        this.icon = mat;
    }
    
    public Material getIcon() {
        return this.icon;
    }
    
    public String getId() {
        return this.id;
    }
    
    public Flag<?> getFlag() {
        return this.flag;
    }
    
    protected static <V> void setFlag(final ProtectedRegion region, final Flag<V> flag, final Actor sender, final String value) throws InvalidFlagFormat {
        region.setFlag((Flag)flag, flag.parseInput(FlagContext.create().setSender(sender).setInput(value).setObject("region", (Object)region).build()));
    }
    
    public String getName() {
        return this.displayname;
    }
    
    @Override
    public int compareTo(final FlagSetting other) {
        return this.getId().compareTo(other.getId());
    }
    
    public Permission getPermission() {
        return this.permission;
    }
}

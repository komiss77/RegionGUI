package net.crytec.RegionGUI.events;

import org.bukkit.entity.Player;
import java.util.UUID;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Cancellable;
import org.bukkit.event.player.PlayerEvent;

public class RegionRemoveMemberEvent extends PlayerEvent implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private RegionClaim claim;
    private UUID member;
    
    static {
        handlers = new HandlerList();
    }
    
    public RegionRemoveMemberEvent(final Player who, final RegionClaim claim, final UUID target) {
        super(who);
        this.cancelled = false;
        this.claim = claim;
        this.member = target;
    }
    
    public RegionClaim getRegionClaim() {
        return this.claim;
    }
    
    public UUID getMember() {
        return this.member;
    }
    
    @Override
    public HandlerList getHandlers() {
        return RegionRemoveMemberEvent.handlers;
    }
    
    public static HandlerList getHandlerList() {
        return RegionRemoveMemberEvent.handlers;
    }
    
    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    @Override
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
}

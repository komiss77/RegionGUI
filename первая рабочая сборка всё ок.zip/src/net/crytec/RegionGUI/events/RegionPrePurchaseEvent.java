package net.crytec.RegionGUI.events;

import org.bukkit.entity.Player;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Cancellable;
import org.bukkit.event.player.PlayerEvent;

public class RegionPrePurchaseEvent extends PlayerEvent implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private boolean generateBorder;
    private RegionClaim claim;
    private int price;
    
    static {
        handlers = new HandlerList();
    }
    
    public RegionPrePurchaseEvent(final Player who, final int price, final RegionClaim claim, final boolean generateBorder) {
        super(who);
        this.cancelled = false;
        this.generateBorder = generateBorder;
        this.claim = claim;
        this.price = price;
    }
    
    public boolean getGenerateBorder() {
        return this.generateBorder;
    }
    
    public RegionClaim getRegionClaim() {
        return this.claim;
    }
    
    public int getPrice() {
        return this.price;
    }
    
    public void setPrice(final int price) {
        this.price = price;
    }
    
    public void setGenerateBorder(final boolean value) {
        this.generateBorder = value;
    }
    
    @Override
    public HandlerList getHandlers() {
        return RegionPrePurchaseEvent.handlers;
    }
    
    public static HandlerList getHandlerList() {
        return RegionPrePurchaseEvent.handlers;
    }
    
    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    @Override
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
}

package net.crytec.RegionGUI.events;

import org.bukkit.entity.Player;
import net.crytec.RegionGUI.data.RegionClaim;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

public class RegionPurchasedEvent extends PlayerEvent
{
    private static final HandlerList handlers;
    private ProtectedRegion region;
    private RegionClaim claim;
    private int price;
    
    static {
        handlers = new HandlerList();
    }
    
    public RegionPurchasedEvent(final Player who, final int price, final RegionClaim claim, final ProtectedRegion region) {
        super(who);
        this.region = region;
        this.claim = claim;
        this.price = price;
    }
    
    public ProtectedRegion getProtectedRegion() {
        return this.region;
    }
    
    public RegionClaim getRegionClaim() {
        return this.claim;
    }
    
    public int getPrice() {
        return this.price;
    }
    
    @Override
    public HandlerList getHandlers() {
        return RegionPurchasedEvent.handlers;
    }
    
    public static HandlerList getHandlerList() {
        return RegionPurchasedEvent.handlers;
    }
}

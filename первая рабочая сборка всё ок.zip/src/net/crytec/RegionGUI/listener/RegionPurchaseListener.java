package net.crytec.RegionGUI.listener;

import org.bukkit.event.EventHandler;
import java.util.Iterator;
import org.bukkit.entity.Player;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.command.CommandSender;
import org.bukkit.Bukkit;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.shaded.org.apache.lang3.StringUtils;
import net.crytec.RegionGUI.events.RegionPurchasedEvent;
import org.bukkit.event.Listener;



public class RegionPurchaseListener implements Listener
{
    @EventHandler
    public void onRegionPurchase(final RegionPurchasedEvent event) {
        final RegionClaim regionClaim = event.getRegionClaim();
        final Player player = event.getPlayer();
        if (regionClaim.getRunCommands().isEmpty()) {
            return;
        }
        final Iterator<String> iterator = regionClaim.getRunCommands().iterator();
        while (iterator.hasNext()) {
            final String replace = iterator.next().replace("%player%", player.getName()).replace("%region%", event.getProtectedRegion().getId()).replace("%world%", player.getWorld().getName());
            if (replace.startsWith("<server>")) {
                final String trim = StringUtils.trim(replace.replace("<server>", ""));
                RegionGUI.getInstance().getLogger().info("Performing Command:" + trim);
                Bukkit.getServer().dispatchCommand((CommandSender)Bukkit.getConsoleSender(), trim);
            }
            else {
                player.performCommand(replace);
            }
        }
    }
}

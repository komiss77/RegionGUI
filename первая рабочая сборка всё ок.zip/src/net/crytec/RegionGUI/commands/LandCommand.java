package net.crytec.RegionGUI.commands;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Collectors;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.menus.LandBuyMenu;
import net.crytec.RegionGUI.menus.LandHomeMenu;
import net.crytec.RegionGUI.menus.RegionManageInterface;
import net.crytec.RegionGUI.menus.RegionSelectMenu;
import net.crytec.acf.BaseCommand;
import net.crytec.acf.CommandHelp;
import net.crytec.acf.CommandIssuer;
import net.crytec.acf.annotation.CommandAlias;
import net.crytec.acf.annotation.CommandPermission;
import net.crytec.acf.annotation.Default;
import net.crytec.acf.annotation.Optional;
import net.crytec.acf.annotation.Subcommand;
import net.crytec.acf.bukkit.contexts.OnlinePlayer;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import org.bukkit.Location;
import org.bukkit.entity.Player;



@CommandAlias("land")
public class LandCommand extends BaseCommand
{
    private final PlayerManager manager;
    private final RegionGUI plugin;
    
    public LandCommand(final RegionGUI plugin, final PlayerManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }
    
    @Default
    public void openLandInterface(final Player issuer) {
        if (!this.plugin.getConfig().getStringList("enabled_worlds").contains(issuer.getWorld().getName())) {
            issuer.sendMessage(Language.ERROR_WORLD_DISABLED.toChatString());
            return;
        }
        this.checkForRegions(issuer);
    }
    
    @Subcommand("help")
    public void sendCommandHelp(final CommandIssuer issuer, final CommandHelp help) {
        help.showHelp(issuer);
    }
    
    @Subcommand("home")
    public void openHomeGUI(final Player issuer) {
        SmartInventory.builder().id("home-" + issuer.getName()).provider((InventoryProvider)new LandHomeMenu()).size(5, 9).title(Language.INTERFACE_HOME_TITLE.toString()).build().open(issuer);
    }
    
    @Subcommand("list")
    @CommandPermission("region.list")
    public void displayLandList(final Player issuer, @Optional final OnlinePlayer op) {
        if (op == null) {
            for (final ClaimEntry claimEntry : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(issuer.getUniqueId())) {
                issuer.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", claimEntry.getRegionID()).replace("%template%", claimEntry.getTemplate().getDisplayname()));
            }
            return;
        }
        for (final ClaimEntry claimEntry2 : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(issuer.getUniqueId())) {
            issuer.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", claimEntry2.getRegionID()).replace("%template%", claimEntry2.getTemplate().getDisplayname()));
        }
    }
    
    private void checkForRegions(Player player) {
        RegionManager regionManager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((org.bukkit.World)player.getWorld()));
        ApplicableRegionSet applicableRegionSet = regionManager.getApplicableRegions(BukkitAdapter.asBlockVector((Location)player.getLocation()));
        LocalPlayer localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
        Iterator iterator = applicableRegionSet.iterator();
        if (applicableRegionSet.size() == 0) {
            if (!player.hasPermission("region.claim")) {
                player.sendMessage(Language.ERROR_NO_PERMISSION.toChatString());
                return;
            }
            SmartInventory.builder().id("regiongui.claim").provider((InventoryProvider)new LandBuyMenu(this.plugin)).size(3, 9).title(Language.INTERFACE_BUY_TITLE.toString()).build().open(player);
            return;
        }
        if (applicableRegionSet.size() == 1) {
            ProtectedRegion protectedRegion = (ProtectedRegion)iterator.next();
            Set<ClaimEntry> set = this.manager.getPlayerClaims(player.getUniqueId());
            if (set == null) {
                player.sendMessage("\u00a7cYou don't own any claims in this world.");
                return;
            }
            Set set2 = set.stream().map(claimEntry -> claimEntry.getRegionID()).collect(Collectors.toSet());
            if (protectedRegion.isOwner(localPlayer) && set2.contains(protectedRegion.getId()) || player.hasPermission("region.mod")) {
                java.util.Optional<ClaimEntry> optional = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId()).stream().filter(claimEntry -> claimEntry.getRegionID().equals(protectedRegion.getId())).findFirst();
                if (!optional.isPresent()) {
                    player.sendMessage(Language.ERROR_NO_REGION_FOUND.toChatString());
                    return;
                }
                SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(optional.get())).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player);
            } else {
                player.sendMessage(Language.ERROR_NOT_OWNER.toChatString());
            }
            return;
        }
        if (applicableRegionSet.size() > 1) {
            Set set = this.manager.getPlayerClaims(player.getUniqueId()).stream().map(claimEntry -> claimEntry.getRegionID()).collect(Collectors.toSet());
            Set<ClaimEntry> set3 = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId()).stream().filter(claimEntry -> set.contains(claimEntry.getRegionID())).collect(Collectors.toSet());
            SmartInventory.builder().id("regiongui.regionselect").provider((InventoryProvider)new RegionSelectMenu(set3)).size(3).title(Language.INTERFACE_SELECT_TITLE.toString()).build().open(player);
            return;
        }
    }

    
    
        
}

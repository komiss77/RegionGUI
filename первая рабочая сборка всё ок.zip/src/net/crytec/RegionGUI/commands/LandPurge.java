package net.crytec.RegionGUI.commands;

import net.crytec.acf.BaseCommand;

public class LandPurge extends BaseCommand
{
}

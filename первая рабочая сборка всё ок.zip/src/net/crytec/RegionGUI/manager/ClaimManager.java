package net.crytec.RegionGUI.manager;

import java.io.IOException;
import java.util.Iterator;
import org.bukkit.configuration.file.YamlConfiguration;
import net.crytec.shaded.org.apache.commons.io.FileUtils;
import java.util.Optional;
import java.util.Set;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import java.io.File;
import java.util.HashSet;
import net.crytec.RegionGUI.data.RegionClaim;
import java.util.UUID;
import java.util.LinkedHashMap;
import net.crytec.RegionGUI.RegionGUI;
import org.bukkit.event.Listener;



public class ClaimManager implements Listener
{
    private final RegionGUI plugin;
    private final LinkedHashMap<UUID, RegionClaim> templates;
    private final File templateFolder;
    
    public ClaimManager(final RegionGUI plugin) {
        this.templates = new LinkedHashMap<>();//LinkedHashMap<UUID, RegionClaim>)Maps.newLinkedHashMap();
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        this.templateFolder = new File(this.plugin.getDataFolder(), "templates");
        if (!this.templateFolder.exists()) {
            this.templateFolder.mkdir();
        }
        this.loadTemplates();
    }
    
    public void registerTemplate(final RegionClaim claim) {
        this.templates.put(claim.getId(), claim);
    }
    

   public Set<RegionClaim> getTemplates(World world) {
       Set <RegionClaim> result = new HashSet<>();
       for (RegionClaim regionClaim : this.templates.values()) {
           if (regionClaim.getWorld().isPresent()) {
               if (regionClaim.getWorld().get().getName().equals(world.getName())) {
                   result.add(regionClaim);
               }
           }
       }
       return result;
       
   //   return (Set)this.templates.values().stream().filter((var0) -> {
   //      return var0.getWorld().isPresent();
  //   }).filter((var1x) -> {
   //      return ((World)var1x.getWorld().get()).equals(var1);
   //   }).collect(Collectors.toSet());
   }
   
  // public Set<RegionClaim> getTemplates(final World world) {
    //    return this.templates.values().stream().filter(regionClaim -> regionClaim.getWorld().isPresent()).filter(regionClaim2 -> regionClaim2.getWorld().get().equals(world)).collect((Collector<? super RegionClaim, ?, Set<RegionClaim>>)Collectors.toSet());
    //}
    
    public Optional<RegionClaim> getByName(final World world, final String name) {
        return this.templates.values().stream().filter(regionClaim -> regionClaim.getWorld().isPresent()).filter(regionClaim2 -> regionClaim2.getWorld().get().equals(world) && regionClaim2.getDisplayname().equals(name)).findFirst();
    }
    
    public RegionClaim getClaimByID(final UUID uuid) {
        return this.templates.get(uuid);
    }
    
    public void deleteTemplate(final RegionClaim claim) {
        this.templates.remove(claim.getId());
        final File file = new File(this.templateFolder, String.valueOf(claim.getId().toString()) + ".claim");
        if (file.exists()) {
            file.delete();
        }
        RegionGUI.getInstance().getPlayerManager().getPlayerdata().values().forEach(set -> set.removeIf(claimEntry -> claimEntry.getTemplate().equals(claim)));
    }
    
    public void loadTemplates() {
        final Iterator iterateFiles = FileUtils.iterateFiles(this.templateFolder, new String[] { "claim" }, false);
        while (iterateFiles.hasNext()) {
            final File file = (File) iterateFiles.next();
            try {
                final RegionClaim value = (RegionClaim)YamlConfiguration.loadConfiguration(file).getSerializable("data", (Class)RegionClaim.class);
                this.templates.put(value.getId(), value);
            }
            catch (Exception ex) {
                RegionGUI.getInstance().getLogger().severe("Failed to load template from file " + file.getName());
                ex.printStackTrace();
            }
        }
    }
    
    public void save() {
        for (final RegionClaim regionClaim : this.templates.values()) {
            try {
                final File file = new File(this.templateFolder, String.valueOf(regionClaim.getId().toString()) + ".claim");
                if (!file.exists()) {
                    file.createNewFile();
                }
                final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file);
                loadConfiguration.set("data", (Object)regionClaim);
                loadConfiguration.save(file);
            }
            catch (IOException ex) {
                RegionGUI.getInstance().getLogger().severe("Failed to save template to disk!");
            }
        }
    }
}

package net.crytec.RegionGUI.data;

import java.util.UUID;
import java.util.HashMap;
import com.google.common.collect.Maps;
import java.util.Map;
import net.crytec.RegionGUI.RegionGUI;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import org.bukkit.World;
import com.sk89q.worldguard.WorldGuard;
import org.bukkit.Bukkit;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Optional;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.configuration.serialization.ConfigurationSerializable;



@SerializableAs("PlayerClaim")
public class ClaimEntry implements ConfigurationSerializable
{
    final String regionID;
    final RegionClaim template;
    final long timestamp;
    private transient Optional<ProtectedRegion> protectedRegion;
    
    public ClaimEntry(final String regionID, final RegionClaim claim, final long timestamp) {
        this.regionID = regionID;
        this.template = claim;
        this.timestamp = timestamp;
        if (!this.template.getWorld().isPresent()) {
            Bukkit.getLogger().severe("Failed to load template - World does not exist!");
            return;
        }
        final ProtectedRegion region = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt((World)this.template.getWorld().get())).getRegion(this.regionID);
        if (region == null) {
            RegionGUI.getInstance().getLogger().info("Region " + regionID + " in world " + this.template.getWorld() + " does no longer exist!");
        }
        this.protectedRegion = Optional.ofNullable(region);
    }
    
    public Optional<ProtectedRegion> getProtectedRegion() {
        if (this.protectedRegion != null) {
            return this.protectedRegion;
        }
        if (!this.template.getWorld().isPresent()) {
            Bukkit.getLogger().severe("Failed to parse Region " + this.regionID + "  - World is no longer loaded!");
            return Optional.empty();
        }
        final World world = this.template.getWorld().get();
        final ProtectedRegion region = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(world)).getRegion(this.regionID);
        if (region == null) {
            RegionGUI.getInstance().getLogger().info("Region " + this.regionID + " in world " + world.getName() + " does no longer exist!");
        }
        return this.protectedRegion = Optional.ofNullable(region);
    }
    
    public Map<String, Object> serialize() {
        final HashMap hashMap = Maps.newHashMap();
        hashMap.put("template", this.template.getId().toString());
        hashMap.put("timestamp", this.timestamp);
        hashMap.put("region", this.regionID);
        return (Map<String, Object>)hashMap;
    }
    
    public static ClaimEntry deserialize(final Map<String, Object> map) {
        final String regionID = (String) map.get("region");
        final UUID fromString = UUID.fromString((String) map.get("template"));
        final long longValue = (long)map.get("timestamp");
        final RegionClaim claimByID = RegionGUI.getInstance().getClaimManager().getClaimByID(fromString);
        if (claimByID == null) {
            RegionGUI.getInstance().getLogger().severe("Failed to claim! Template does no longer exist!");
            return null;
        }
        return new ClaimEntry(regionID, claimByID, longValue);
    }
    
    public String getRegionID() {
        return this.regionID;
    }
    
    public RegionClaim getTemplate() {
        return this.template;
    }
    
    public long getTimestamp() {
        return this.timestamp;
    }
}

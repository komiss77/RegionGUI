package net.crytec.RegionGUI.menus;

import java.util.ArrayList;
import java.util.Set;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;



public class RegionSelectMenu implements InventoryProvider
{
    private final Set<ClaimEntry> claims;
    
    public RegionSelectMenu(final Set<ClaimEntry> claims) {
        this.claims = claims;
    }
    
    //если стоять в перекрывающихся регионах
    @Override
    public void init(Player player, InventoryContents inventoryContents) {
        Pagination pagination = inventoryContents.pagination();
        ArrayList<ClickableItem> arrayList = new ArrayList<>();
        for (ClaimEntry object2 : this.claims) {
            String string = (Object)ChatColor.GREEN + object2.getRegionID();
            String string2 = Language.INTERFACE_SELECT_DESCRIPTION.toString().replace("%region%", string);
            ItemStack itemStack = new ItemBuilder(Material.BOOK).name(string).lore(string2).build();
            arrayList.add(ClickableItem.of((ItemStack)itemStack, inventoryClickEvent -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(object2)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        }
        ClickableItem[] arrclickableItem = new ClickableItem[arrayList.size()];
        ClickableItem[] citems = arrayList.toArray(arrclickableItem);
        pagination.setItems(citems);
        pagination.setItemsPerPage(18);
        pagination.addToIterator(inventoryContents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0));
    }
    /*
    PROCYON
    public void init(final Player player, final InventoryContents contents) {
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> list = new ArrayList<ClickableItem>();
        final Iterator<ClaimEntry> iterator = this.claims.iterator();
        while (iterator.hasNext()) {
            final String string = ChatColor.GREEN + iterator.next().getRegionID();
            final ClaimEntry claim;
            list.add(ClickableItem.of(new ItemBuilder(Material.BOOK).name(string).lore(Language.INTERFACE_SELECT_DESCRIPTION.toString().replace("%region%", string)).build(), p2 -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        }
        pagination.setItems((ClickableItem[])list.toArray(new ClickableItem[list.size()]));
        pagination.setItemsPerPage(18);
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0));
    }*/
}

/* FF
   public void init(Player player, InventoryContents contents) {
      Pagination var3 = var2.pagination();
      ArrayList var4 = new ArrayList();
      Iterator var6 = this.claims.iterator();

      while(var6.hasNext()) {
         ClaimEntry var5 = (ClaimEntry)var6.next();
         String var7 = ChatColor.GREEN + var5.getRegionID();
         String var8 = Language.INTERFACE_SELECT_DESCRIPTION.toString().replace("%region%", var7);
         ItemStack var9 = (new ItemBuilder(Material.BOOK)).name(var7).lore(var8).build();
         var4.add(ClickableItem.of(var9, (var2x) -> {
            SmartInventory.builder().provider(new RegionManageInterface(var5)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(var1);
         }));
      }

      ClickableItem[] var10 = new ClickableItem[var4.size()];
      var10 = (ClickableItem[])var4.toArray(var10);
      var3.setItems(var10);
      var3.setItemsPerPage(18);
      var3.addToIterator(var2.newIterator(Type.HORIZONTAL, 1, 0));
   }
*/

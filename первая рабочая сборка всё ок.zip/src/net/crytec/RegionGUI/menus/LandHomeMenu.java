package net.crytec.RegionGUI.menus;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;



public class LandHomeMenu implements InventoryProvider
{
    private static final ItemStack fill;
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
    

    
    
    
    
    
    @Override
        public void init(Player player, InventoryContents inventoryContents) {
            
        inventoryContents.fillBorders(ClickableItem.empty((ItemStack)fill));
        Pagination pagination = inventoryContents.pagination();
        ArrayList<ClickableItem> arrayList = new ArrayList<>();
        
        for (ClaimEntry object2 : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId())) {
            World world = object2.getTemplate().getWorld().get();
            RegionManager regionManager = RegionUtils.getRegionManager(world);
            ProtectedRegion protectedRegion = regionManager.getRegion(object2.getRegionID());
            if (protectedRegion == null) {
                Bukkit.getLogger().severe("WorldGuard region is missing [" + object2.getRegionID() + "]. This region is still assigned to the player but missing in WorldGuard!");
                Bukkit.getLogger().severe("world: " + world.getName() + " template id: " + object2.getTemplate());
                continue;
            }
            ArrayList<String> arrayList2 = new ArrayList<>(Language.INTERFACE_HOME_ENTRYBUTTON_DESCRIPTION.getDescriptionArray());
            arrayList2.replaceAll(string -> string.replace("%world%", world.getName()));
            arrayList.add(ClickableItem.of((ItemStack)new ItemBuilder(Material.GRAY_BED).name(object2.getRegionID()).lore(arrayList2).build(), inventoryClickEvent -> {
                if (protectedRegion.getFlag((Flag)Flags.TELE_LOC) != null) {
                    com.sk89q.worldedit.util.Location location = (com.sk89q.worldedit.util.Location)protectedRegion.getFlag((Flag)Flags.TELE_LOC);
                    org.bukkit.Location location2 = BukkitAdapter.adapt((com.sk89q.worldedit.util.Location)location);
                    player.teleport(location2);
                } else {
                    player.sendMessage(Language.ERROR_NO_HOME_SET.toChatString());
                }
            }));
        }
        
        ClickableItem[] arrclickableItem = new ClickableItem[arrayList.size()];
        ClickableItem[] arrclickableItem2 = arrayList.toArray(arrclickableItem);
        pagination.setItems(arrclickableItem2);
        pagination.setItemsPerPage(27);
        if (!pagination.isLast()) {
            inventoryContents.set(4, 6, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.next().getPage())));
        }
        if (!pagination.isFirst()) {
            inventoryContents.set(4, 2, ClickableItem.of((ItemStack)new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), inventoryClickEvent -> inventoryContents.inventory().open(player, pagination.previous().getPage())));
        }
        SlotIterator slotIterator = inventoryContents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 1);
        slotIterator = slotIterator.allowOverride(false);
        pagination.addToIterator(slotIterator);
    }
    
    
    
        
        
        
        
        
        
   /*     
    Procyon
    public void init(final Player player, final InventoryContents contents) {
        contents.fillBorders(ClickableItem.empty(LandHomeMenu.fill));
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> list = new ArrayList<ClickableItem>();
        for (final ClaimEntry claimEntry : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId())) {
            final World world = claimEntry.getTemplate().getWorld().get();
            if (RegionUtils.getRegionManager(world).getRegion(claimEntry.getRegionID()) == null) {
                Bukkit.getLogger().severe("WorldGuard region is missing [" + claimEntry.getRegionID() + "]. This region is still assigned to the player but missing in WorldGuard!");
                Bukkit.getLogger().severe("world: " + world.getName() + " template id: " + claimEntry.getTemplate());
            }
            else {
                final ArrayList <String>list2 = new ArrayList(Language.INTERFACE_HOME_ENTRYBUTTON_DESCRIPTION.getDescriptionArray());
                list2.replaceAll(s -> s.replace("%world%", world.getName()));
                
                
                
                final ProtectedRegion protectedRegion;
                list.add(ClickableItem.of(new ItemBuilder(Material.GRAY_BED).name(claimEntry.getRegionID()).lore((List)list2).build(), p2 -> {
                    if (protectedRegion.getFlag((Flag)Flags.TELE_LOC) != null) {
                        player.teleport(BukkitAdapter.adapt((Location)protectedRegion.getFlag((Flag)Flags.TELE_LOC)));
                    }
                    else {
                        player.sendMessage(Language.ERROR_NO_HOME_SET.toChatString());
                    }
                    return;
                }));
                
                
            }
        }
        
        pagination.setItems((ClickableItem[])list.toArray(new ClickableItem[list.size()]));
        pagination.setItemsPerPage(27);
        if (!pagination.isLast()) {
            contents.set(4, 6, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), p3 -> contents.inventory().open(player, pagination.next().getPage())));
        }
        if (!pagination.isFirst()) {
            contents.set(4, 2, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), p3 -> contents.inventory().open(player, pagination.previous().getPage())));
        }
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 1).allowOverride(false));
    }*/
}

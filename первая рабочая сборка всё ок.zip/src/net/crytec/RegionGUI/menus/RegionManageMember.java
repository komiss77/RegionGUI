package net.crytec.RegionGUI.menus;

import com.sk89q.worldguard.domains.PlayerDomain;
import com.sk89q.worldguard.domains.DefaultDomain;
import org.bukkit.OfflinePlayer;
import java.util.Iterator;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.inventory.SmartInventory;
import com.sk89q.worldguard.util.profile.Profile;
import com.sk89q.worldguard.WorldGuard;
import net.crytec.RegionGUI.events.RegionAddMemberEvent;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.event.Event;
import net.crytec.RegionGUI.events.RegionRemoveMemberEvent;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import net.crytec.RegionGUI.Language;
import org.bukkit.Bukkit;
import java.util.UUID;
import java.util.ArrayList;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.RegionGUI.data.ClaimEntry;
import org.bukkit.inventory.ItemStack;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;



public class RegionManageMember implements InventoryProvider
{
    private static final ItemStack fill;
    private final ClaimEntry claim;
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
    
    public RegionManageMember(final ClaimEntry claim) {
        this.claim = claim;
    }
    
    @Override
    public void init(final Player player, final InventoryContents contents) {
        contents.fillBorders(ClickableItem.empty(RegionManageMember.fill));
        final ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> list = new ArrayList<>();
        final Iterator iterator = protectedRegion.getMembers().getUniqueIds().iterator();
        
        
        
        
        
        while (iterator.hasNext()) {
            final OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)iterator.next());
            final String s2 = offlinePlayer.hasPlayedBefore() ? offlinePlayer.getName() : "Unknown Name";
            final ItemStack build = new ItemBuilder(Material.PLAYER_HEAD).name("§f" + s2).lore(Language.INTERFACE_REMOVE_DESC.toString().replaceAll("%name%", s2)).build();
            
            if (offlinePlayer.hasPlayedBefore()) {
                final ItemStack itemStack = build;
                final SkullMeta itemMeta = (SkullMeta)itemStack.getItemMeta();
                itemMeta.hasOwner();
                itemMeta.setOwningPlayer(offlinePlayer);
                itemStack.setItemMeta((ItemMeta)itemMeta);
            }
            //final UUID target;
            //final RegionRemoveMemberEvent regionRemoveMemberEvent;
            //final ProtectedRegion protectedRegion2;
            //final Pagination pagination2;
            //final String replacement;
            
            list.add(ClickableItem.of(build, p6 -> {
                RegionRemoveMemberEvent regionRemoveMemberEvent = new RegionRemoveMemberEvent(player, this.claim.getTemplate(), offlinePlayer.getUniqueId());
                Bukkit.getPluginManager().callEvent((Event)regionRemoveMemberEvent);
                
                if (regionRemoveMemberEvent.isCancelled()) {
                    this.reOpen(player, contents);
                    //contents.inventory().open(player, new String[] { "region" }, new Object[] { protectedRegion2 });
                    return;
                }
                else {
                    
                    protectedRegion.getMembers().removePlayer(offlinePlayer.getName());
                    contents.inventory().open(player, pagination.getPage(), new String[] { "region" }, new Object[] { protectedRegion });
                    UtilPlayer.playSound(player, Sound.BLOCK_LEVER_CLICK);
                    player.sendMessage(Language.INTERFACE_REMOVE_SUCESSFULL.toChatString().replaceAll("%name%", offlinePlayer.getName()));
                    return;
                }
            }));
        }
        
        
        
        
        
        
        pagination.setItems((ClickableItem[])list.toArray(new ClickableItem[list.size()]));
        pagination.setItemsPerPage(18);
        
        
        //final ProtectedRegion protectedRegion3;
        //final DefaultDomain members;
        //final PlayerDomain playerDomain;
        
        contents.set(SlotPos.of(0, 4), ClickableItem.of(new ItemBuilder(Material.WRITABLE_BOOK).name(Language.INTERFACE_MANAGE_BUTTON_ADDMEMBER.toString()).build(), p3 -> {
            player.closeInventory();
            player.sendMessage(Language.REGION_MESSAGE_CHATADDMEMBER.toChatString());
            PhoenixAPI.get().getPlayerChatInput(player, s -> {
                final OfflinePlayer offlinePlayer2 = Bukkit.getOfflinePlayer(s);
                if (!offlinePlayer2.hasPlayedBefore()) {
                    player.sendMessage(Language.ERROR_INVALID_OFFLINEPLAYER.toChatString());
                }
                else {
                    RegionAddMemberEvent regionAddMemberEvent = new RegionAddMemberEvent(player, this.claim.getTemplate(), offlinePlayer2.getUniqueId());
                    Bukkit.getPluginManager().callEvent((Event)regionAddMemberEvent);
                    if (regionAddMemberEvent.isCancelled()) {
                        this.reOpen(player, contents);
                    }
                    else {
                        
                        DefaultDomain defaultDomain = protectedRegion.getMembers();
                        PlayerDomain playerDomain = defaultDomain.getPlayerDomain();
                        playerDomain.addPlayer(offlinePlayer2.getUniqueId());
                        defaultDomain.setPlayerDomain(playerDomain);
                        protectedRegion.setMembers(defaultDomain);
                        protectedRegion.setDirty(true);
                        Profile profile = new Profile(offlinePlayer2.getUniqueId(), offlinePlayer2.getName());
                        WorldGuard.getInstance().getProfileCache().put(profile);
                        defaultDomain.toUserFriendlyComponent(WorldGuard.getInstance().getProfileCache());
                        this.reOpen(player, contents);
                        
                        
                        
                        /*
                        //protectedRegion.getMembers();
                        protectedRegion.getMembers().getPlayerDomain().addPlayer(offlinePlayer2.getUniqueId());
                        protectedRegion.getMembers().setPlayerDomain(playerDomain);
                        protectedRegion.setMembers(members);
                        protectedRegion.setDirty(true);
                        WorldGuard.getInstance().getProfileCache().put(new Profile(offlinePlayer2.getUniqueId(), offlinePlayer2.getName()));
                        members.toUserFriendlyComponent(WorldGuard.getInstance().getProfileCache());
                        this.reOpen(player, contents);*/
                    }
                }
            });
            return;
        }));
        
        
        
        contents.set(4, 4, ClickableItem.of(new ItemBuilder(Material.RED_WOOL).name(Language.INTERFACE_BACK.toString()).build(), p1 -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        contents.set(4, 6, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), p4 -> contents.inventory().open(player, pagination.next().getPage(), new String[] { "region" }, new Object[] { protectedRegion })));
        contents.set(4, 2, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), p4 -> contents.inventory().open(player, pagination.previous().getPage(), new String[] { "region" }, new Object[] { protectedRegion })));
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 1).allowOverride(false));
    }
    
    
    
    
    
    
    
    
    
    
}

package net.crytec.RegionGUI.menus.admin;

import net.crytec.phoenix.api.implementation.AnvilGUI;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.ChatColor;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.RegionGUI.data.RegionClaim;
import java.util.List;
import java.util.Collections;
import java.util.ArrayList;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;



public class AdminTemplateList implements InventoryProvider
{
    private final ClaimManager claimManager;
    
    public AdminTemplateList() {
        this.claimManager = RegionGUI.getInstance().getClaimManager();
    }
    
    @Override
    public void init(final Player player, final InventoryContents contents) {
        final ArrayList<RegionClaim> list = new ArrayList<>(this.claimManager.getTemplates(player.getWorld()));
        Collections.sort(list);
        for (final RegionClaim regionClaim : list) {
            final ItemBuilder itemBuilder = new ItemBuilder((regionClaim.getIcon() == null) ? Material.BARRIER : regionClaim.getIcon().getType());
            itemBuilder.name(ChatColor.translateAlternateColorCodes('&', regionClaim.getDisplayname()));
            final ArrayList <String> list2 = new ArrayList(regionClaim.getDescription());
            list2.replaceAll(s -> ChatColor.translateAlternateColorCodes('&', s));
            itemBuilder.lore((List)list2);
            //final RegionClaim claim;
            contents.add(ClickableItem.of(itemBuilder.build(), p2 -> {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                SmartInventory.builder().provider((InventoryProvider)new TemplateEditor(regionClaim)).size(5).title("Editing " + regionClaim.getDisplayname()).build().open(player);
                return;
            }));
        }
        contents.set(SlotPos.of(5, 4), new ClickableItem(new ItemBuilder(Material.EMERALD).name("§2Create new template").build(), p2 -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            new AnvilGUI(player, "template", (player2, p3) -> {
                this.claimManager.registerTemplate(new RegionClaim(player2.getWorld()));
                this.claimManager.save();
                this.reOpen(player, contents);
                return null;
            });
        }));
    }
}

package net.crytec.RegionGUI.events;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.entity.Player;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

public class RegionPurchasedEvent extends PlayerEvent {
   private static final HandlerList handlers = new HandlerList();
   private ProtectedRegion region;
   private RegionClaim claim;
   private int price;

   public RegionPurchasedEvent(Player who, int price, RegionClaim claim, ProtectedRegion region) {
      super(var1);
      this.region = var4;
      this.claim = var3;
      this.price = var2;
   }

   public ProtectedRegion getProtectedRegion() {
      return this.region;
   }

   public RegionClaim getRegionClaim() {
      return this.claim;
   }

   public int getPrice() {
      return this.price;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }
}

package net.crytec.RegionGUI.events;

import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.entity.Player;
import org.bukkit.event.Cancellable;
import org.bukkit.event.HandlerList;
import org.bukkit.event.player.PlayerEvent;

public class RegionPrePurchaseEvent extends PlayerEvent implements Cancellable {
   private static final HandlerList handlers = new HandlerList();
   private boolean cancelled = false;
   private boolean generateBorder;
   private RegionClaim claim;
   private int price;

   public RegionPrePurchaseEvent(Player who, int price, RegionClaim claim, boolean generateBorder) {
      super(var1);
      this.generateBorder = var4;
      this.claim = var3;
      this.price = var2;
   }

   public boolean getGenerateBorder() {
      return this.generateBorder;
   }

   public RegionClaim getRegionClaim() {
      return this.claim;
   }

   public int getPrice() {
      return this.price;
   }

   public void setPrice(int price) {
      this.price = var1;
   }

   public void setGenerateBorder(boolean value) {
      this.generateBorder = var1;
   }

   public HandlerList getHandlers() {
      return handlers;
   }

   public static HandlerList getHandlerList() {
      return handlers;
   }

   public boolean isCancelled() {
      return this.cancelled;
   }

   public void setCancelled(boolean cancelled) {
      this.cancelled = var1;
   }
}

package net.crytec.RegionGUI.metrics;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.zip.GZIPOutputStream;
import javax.net.ssl.HttpsURLConnection;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class Metrics {
   public static final int B_STATS_VERSION = 1;
   private static final String URL = "https://bStats.org/submitData/bukkit";
   private static boolean logFailedRequests;
   private static String serverUUID;
   private final JavaPlugin plugin;
   private final List charts = new ArrayList();

   static {
      if (System.getProperty("bstats.relocatecheck") == null || !System.getProperty("bstats.relocatecheck").equals("false")) {
         String var0 = new String(new byte[]{111, 114, 103, 46, 98, 115, 116, 97, 116, 115, 46, 98, 117, 107, 107, 105, 116});
         String var1 = new String(new byte[]{121, 111, 117, 114, 46, 112, 97, 99, 107, 97, 103, 101});
         if (Metrics.class.getPackage().getName().equals(var0) || Metrics.class.getPackage().getName().equals(var1)) {
            throw new IllegalStateException("bStats Metrics class has not been relocated correctly!");
         }
      }

   }

   public Metrics(JavaPlugin plugin) {
      if (var1 == null) {
         throw new IllegalArgumentException("Plugin cannot be null!");
      } else {
         this.plugin = var1;
         File var2 = new File(var1.getDataFolder().getParentFile(), "bStats");
         File var3 = new File(var2, "config.yml");
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         if (!var4.isSet("serverUuid")) {
            var4.addDefault("enabled", true);
            var4.addDefault("serverUuid", UUID.randomUUID().toString());
            var4.addDefault("logFailedRequests", false);
            var4.options().header("bStats collects some data for plugin authors like how many servers are using their plugins.\nTo honor their work, you should not disable it.\nThis has nearly no effect on the server performance!\nCheck out https://bStats.org/ to learn more :)").copyDefaults(true);

            try {
               var4.save(var3);
            } catch (IOException var9) {
            }
         }

         serverUUID = var4.getString("serverUuid");
         logFailedRequests = var4.getBoolean("logFailedRequests", false);
         if (var4.getBoolean("enabled", true)) {
            boolean var5 = false;
            Iterator var7 = Bukkit.getServicesManager().getKnownServices().iterator();

            while(var7.hasNext()) {
               Class var6 = (Class)var7.next();

               try {
                  var6.getField("B_STATS_VERSION");
                  var5 = true;
                  break;
               } catch (NoSuchFieldException var10) {
               }
            }

            Bukkit.getServicesManager().register(Metrics.class, this, var1, ServicePriority.Normal);
            if (!var5) {
               this.startSubmitting();
            }
         }

      }
   }

   public void addCustomChart(Metrics.CustomChart chart) {
      if (var1 == null) {
         throw new IllegalArgumentException("Chart cannot be null!");
      } else {
         this.charts.add(var1);
      }
   }

   private void startSubmitting() {
      final Timer var1 = new Timer(true);
      var1.scheduleAtFixedRate(new TimerTask() {
         public void run() {
            if (!Metrics.this.plugin.isEnabled()) {
               var1.cancel();
            } else {
               Bukkit.getScheduler().runTask(Metrics.this.plugin, new Runnable() {
                  public void run() {
                     Metrics.this.submitData();
                  }
               });
            }
         }
      }, 300000L, 1800000L);
   }

   public JSONObject getPluginData() {
      JSONObject var1 = new JSONObject();
      String var2 = this.plugin.getDescription().getName();
      String var3 = this.plugin.getDescription().getVersion();
      var1.put("pluginName", var2);
      var1.put("pluginVersion", var3);
      JSONArray var4 = new JSONArray();
      Iterator var6 = this.charts.iterator();

      while(var6.hasNext()) {
         Metrics.CustomChart var5 = (Metrics.CustomChart)var6.next();
         JSONObject var7 = var5.getRequestJsonObject();
         if (var7 != null) {
            var4.add(var7);
         }
      }

      var1.put("customCharts", var4);
      return var1;
   }

   private JSONObject getServerData() {
      int var1;
      try {
         Method var2 = Class.forName("org.bukkit.Server").getMethod("getOnlinePlayers");
         var1 = var2.getReturnType().equals(Collection.class) ? ((Collection)var2.invoke(Bukkit.getServer())).size() : ((Player[])var2.invoke(Bukkit.getServer())).length;
      } catch (Exception var10) {
         var1 = Bukkit.getOnlinePlayers().size();
      }

      int var11 = Bukkit.getOnlineMode() ? 1 : 0;
      String var3 = Bukkit.getVersion();
      var3 = var3.substring(var3.indexOf("MC: ") + 4, var3.length() - 1);
      String var4 = System.getProperty("java.version");
      String var5 = System.getProperty("os.name");
      String var6 = System.getProperty("os.arch");
      String var7 = System.getProperty("os.version");
      int var8 = Runtime.getRuntime().availableProcessors();
      JSONObject var9 = new JSONObject();
      var9.put("serverUUID", serverUUID);
      var9.put("playerAmount", var1);
      var9.put("onlineMode", var11);
      var9.put("bukkitVersion", var3);
      var9.put("javaVersion", var4);
      var9.put("osName", var5);
      var9.put("osArch", var6);
      var9.put("osVersion", var7);
      var9.put("coreCount", var8);
      return var9;
   }

   private void submitData() {
      final JSONObject var1 = this.getServerData();
      JSONArray var2 = new JSONArray();
      Iterator var4 = Bukkit.getServicesManager().getKnownServices().iterator();

      while(var4.hasNext()) {
         Class var3 = (Class)var4.next();

         try {
            var3.getField("B_STATS_VERSION");
            Iterator var6 = Bukkit.getServicesManager().getRegistrations(var3).iterator();

            while(var6.hasNext()) {
               RegisteredServiceProvider var5 = (RegisteredServiceProvider)var6.next();

               try {
                  var2.add(var5.getService().getMethod("getPluginData").invoke(var5.getProvider()));
               } catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException | NullPointerException var8) {
               }
            }
         } catch (NoSuchFieldException var9) {
         }
      }

      var1.put("plugins", var2);
      (new Thread(new Runnable() {
         public void run() {
            try {
               Metrics.sendData(var1);
            } catch (Exception var2) {
               if (Metrics.logFailedRequests) {
                  Metrics.this.plugin.getLogger().log(Level.WARNING, "Could not submit plugin stats of " + Metrics.this.plugin.getName(), var2);
               }
            }

         }
      })).start();
   }

   private static void sendData(JSONObject data) {
      if (var0 == null) {
         throw new IllegalArgumentException("Data cannot be null!");
      } else if (Bukkit.isPrimaryThread()) {
         throw new IllegalAccessException("This method must not be called from the main thread!");
      } else {
         HttpsURLConnection var1 = (HttpsURLConnection)(new URL("https://bStats.org/submitData/bukkit")).openConnection();
         byte[] var2 = compress(var0.toString());
         var1.setRequestMethod("POST");
         var1.addRequestProperty("Accept", "application/json");
         var1.addRequestProperty("Connection", "close");
         var1.addRequestProperty("Content-Encoding", "gzip");
         var1.addRequestProperty("Content-Length", String.valueOf(var2.length));
         var1.setRequestProperty("Content-Type", "application/json");
         var1.setRequestProperty("User-Agent", "MC-Server/1");
         var1.setDoOutput(true);
         DataOutputStream var3 = new DataOutputStream(var1.getOutputStream());
         var3.write(var2);
         var3.flush();
         var3.close();
         var1.getInputStream().close();
      }
   }

   private static byte[] compress(final String str) {
      if (var0 == null) {
         return null;
      } else {
         ByteArrayOutputStream var1 = new ByteArrayOutputStream();
         GZIPOutputStream var2 = new GZIPOutputStream(var1);
         var2.write(var0.getBytes("UTF-8"));
         var2.close();
         return var1.toByteArray();
      }
   }

   public static class AdvancedBarChart extends Metrics.CustomChart {
      private final Callable callable;

      public AdvancedBarChart(String chartId, Callable callable) {
         super(var1);
         this.callable = var2;
      }

      protected JSONObject getChartData() {
         JSONObject var1 = new JSONObject();
         JSONObject var2 = new JSONObject();
         Map var3 = (Map)this.callable.call();
         if (var3 != null && !var3.isEmpty()) {
            boolean var4 = true;
            Iterator var6 = var3.entrySet().iterator();

            while(true) {
               Entry var5;
               do {
                  if (!var6.hasNext()) {
                     if (var4) {
                        return null;
                     }

                     var1.put("values", var2);
                     return var1;
                  }

                  var5 = (Entry)var6.next();
               } while(((int[])var5.getValue()).length == 0);

               var4 = false;
               JSONArray var7 = new JSONArray();
               int[] var11;
               int var10 = (var11 = (int[])var5.getValue()).length;

               for(int var9 = 0; var9 < var10; ++var9) {
                  int var8 = var11[var9];
                  var7.add(var8);
               }

               var2.put(var5.getKey(), var7);
            }
         } else {
            return null;
         }
      }
   }

   public static class AdvancedPie extends Metrics.CustomChart {
      private final Callable callable;

      public AdvancedPie(String chartId, Callable callable) {
         super(var1);
         this.callable = var2;
      }

      protected JSONObject getChartData() {
         JSONObject var1 = new JSONObject();
         JSONObject var2 = new JSONObject();
         Map var3 = (Map)this.callable.call();
         if (var3 != null && !var3.isEmpty()) {
            boolean var4 = true;
            Iterator var6 = var3.entrySet().iterator();

            while(var6.hasNext()) {
               Entry var5 = (Entry)var6.next();
               if ((Integer)var5.getValue() != 0) {
                  var4 = false;
                  var2.put(var5.getKey(), var5.getValue());
               }
            }

            if (var4) {
               return null;
            } else {
               var1.put("values", var2);
               return var1;
            }
         } else {
            return null;
         }
      }
   }

   public abstract static class CustomChart {
      final String chartId;

      CustomChart(String chartId) {
         if (var1 != null && !var1.isEmpty()) {
            this.chartId = var1;
         } else {
            throw new IllegalArgumentException("ChartId cannot be null or empty!");
         }
      }

      private JSONObject getRequestJsonObject() {
         JSONObject var1 = new JSONObject();
         var1.put("chartId", this.chartId);

         try {
            JSONObject var2 = this.getChartData();
            if (var2 == null) {
               return null;
            } else {
               var1.put("data", var2);
               return var1;
            }
         } catch (Throwable var3) {
            if (Metrics.logFailedRequests) {
               Bukkit.getLogger().log(Level.WARNING, "Failed to get data for custom chart with id " + this.chartId, var3);
            }

            return null;
         }
      }

      protected abstract JSONObject getChartData();
   }

   public static class DrilldownPie extends Metrics.CustomChart {
      private final Callable callable;

      public DrilldownPie(String chartId, Callable callable) {
         super(var1);
         this.callable = var2;
      }

      public JSONObject getChartData() {
         JSONObject var1 = new JSONObject();
         JSONObject var2 = new JSONObject();
         Map var3 = (Map)this.callable.call();
         if (var3 != null && !var3.isEmpty()) {
            boolean var4 = true;
            Iterator var6 = var3.entrySet().iterator();

            while(var6.hasNext()) {
               Entry var5 = (Entry)var6.next();
               JSONObject var7 = new JSONObject();
               boolean var8 = true;

               for(Iterator var10 = ((Map)var3.get(var5.getKey())).entrySet().iterator(); var10.hasNext(); var8 = false) {
                  Entry var9 = (Entry)var10.next();
                  var7.put(var9.getKey(), var9.getValue());
               }

               if (!var8) {
                  var4 = false;
                  var2.put(var5.getKey(), var7);
               }
            }

            if (var4) {
               return null;
            } else {
               var1.put("values", var2);
               return var1;
            }
         } else {
            return null;
         }
      }
   }

   public static class MultiLineChart extends Metrics.CustomChart {
      private final Callable callable;

      public MultiLineChart(String chartId, Callable callable) {
         super(var1);
         this.callable = var2;
      }

      protected JSONObject getChartData() {
         JSONObject var1 = new JSONObject();
         JSONObject var2 = new JSONObject();
         Map var3 = (Map)this.callable.call();
         if (var3 != null && !var3.isEmpty()) {
            boolean var4 = true;
            Iterator var6 = var3.entrySet().iterator();

            while(var6.hasNext()) {
               Entry var5 = (Entry)var6.next();
               if ((Integer)var5.getValue() != 0) {
                  var4 = false;
                  var2.put(var5.getKey(), var5.getValue());
               }
            }

            if (var4) {
               return null;
            } else {
               var1.put("values", var2);
               return var1;
            }
         } else {
            return null;
         }
      }
   }

   public static class SimpleBarChart extends Metrics.CustomChart {
      private final Callable callable;

      public SimpleBarChart(String chartId, Callable callable) {
         super(var1);
         this.callable = var2;
      }

      protected JSONObject getChartData() {
         JSONObject var1 = new JSONObject();
         JSONObject var2 = new JSONObject();
         Map var3 = (Map)this.callable.call();
         if (var3 != null && !var3.isEmpty()) {
            Iterator var5 = var3.entrySet().iterator();

            while(var5.hasNext()) {
               Entry var4 = (Entry)var5.next();
               JSONArray var6 = new JSONArray();
               var6.add(var4.getValue());
               var2.put(var4.getKey(), var6);
            }

            var1.put("values", var2);
            return var1;
         } else {
            return null;
         }
      }
   }

   public static class SimplePie extends Metrics.CustomChart {
      private final Callable callable;

      public SimplePie(String chartId, Callable callable) {
         super(var1);
         this.callable = var2;
      }

      protected JSONObject getChartData() {
         JSONObject var1 = new JSONObject();
         String var2 = (String)this.callable.call();
         if (var2 != null && !var2.isEmpty()) {
            var1.put("value", var2);
            return var1;
         } else {
            return null;
         }
      }
   }

   public static class SingleLineChart extends Metrics.CustomChart {
      private final Callable callable;

      public SingleLineChart(String chartId, Callable callable) {
         super(var1);
         this.callable = var2;
      }

      protected JSONObject getChartData() {
         JSONObject var1 = new JSONObject();
         int var2 = (Integer)this.callable.call();
         if (var2 == 0) {
            return null;
         } else {
            var1.put("value", var2);
            return var1;
         }
      }
   }
}

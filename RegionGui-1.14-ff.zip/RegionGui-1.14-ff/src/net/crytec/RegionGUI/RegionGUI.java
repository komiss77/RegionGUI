package net.crytec.RegionGUI;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.io.File;
import java.io.IOException;
import java.util.Optional;
import java.util.logging.Logger;
import net.crytec.RegionGUI.commands.LandAdmin;
import net.crytec.RegionGUI.commands.LandCommand;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.listener.RegionPurchaseListener;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.metrics.Metrics;
import net.crytec.RegionGUI.utils.flags.FlagManager;
import net.crytec.acf.BukkitCommandIssuer;
import net.crytec.acf.BukkitCommandManager;
import net.crytec.acf.InvalidCommandArgument;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.chat.program.ChatEditorCore;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class RegionGUI extends JavaPlugin {
   private static RegionGUI instance;
   public final Logger log = Bukkit.getLogger();
   public static Economy econ = null;
   private FlagManager flagmanager;
   private ClaimManager claimManager;
   private PlayerManager playerManager;
   public static String USER = "38105";

   static {
      ConfigurationSerialization.registerClass(RegionClaim.class, "Template");
      ConfigurationSerialization.registerClass(ClaimEntry.class, "PlayerClaim");
   }

   public void onLoad() {
      instance = this;
      if (!this.getDataFolder().exists()) {
         this.getDataFolder().mkdir();
      }

      File var1 = new File(this.getDataFolder(), "config.yml");

      try {
         if (!var1.exists()) {
            var1.createNewFile();
            this.saveResource("config.yml", true);
            this.log("§2Setup - New default configuration has been written.");
         }
      } catch (Exception var3) {
         var3.printStackTrace();
      }

   }

   public void onEnable() {
      loadConfig0();
      if (!this.setupEconomy()) {
         this.log("§cNo Vault Compatible Economy Plugin found! Cannot load RegionGUI", true);
         Bukkit.getPluginManager().disablePlugin(this);
      }

      if (!PhoenixAPI.get().requireAPIVersion(this, 108)) {
         Bukkit.getPluginManager().disablePlugin(this);
      } else {
         this.loadLanguage();
         BukkitCommandManager var1 = new BukkitCommandManager(this);
         new ChatEditorCore(this);
         var1.getCommandContexts().registerContext(ProtectedRegion.class, (var0) -> {
            World var1 = ((BukkitCommandIssuer)var0.getIssuer()).getPlayer().getWorld();
            String var2 = var0.popFirstArg();
            ProtectedRegion var3 = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(var1)).getRegion(var2);
            if (var3 == null) {
               throw new InvalidCommandArgument("Could not find an region with that name in your current world.");
            } else {
               return var3;
            }
         });
         var1.getCommandContexts().registerContext(RegionClaim.class, (var1x) -> {
            World var2 = ((BukkitCommandIssuer)var1x.getIssuer()).getPlayer().getWorld();
            String var3 = var1x.popFirstArg();
            Optional var4 = this.getClaimManager().getTemplates(var2).stream().filter((var1) -> {
               return ChatColor.stripColor(var1.getDisplayname()).equals(var3);
            }).findFirst();
            if (!var4.isPresent()) {
               throw new InvalidCommandArgument("Could not find a template with that name in your current world.");
            } else {
               return (RegionClaim)var4.get();
            }
         });
         this.flagmanager = new FlagManager(this);
         this.claimManager = new ClaimManager(this);
         this.playerManager = new PlayerManager(this, this.claimManager);
         Bukkit.getPluginManager().registerEvents(new RegionPurchaseListener(), this);
         var1.registerCommand(new LandCommand(this, this.playerManager));
         var1.registerCommand(new LandAdmin(this));
         var1.enableUnstableAPI("help");
         Metrics var2 = new Metrics(this);
         var2.addCustomChart(new Metrics.SimplePie("purges_enabled", () -> {
            return this.getConfig().getBoolean("deleteOnPurge") ? "Enabled" : "Disabled";
         }));
         var2.addCustomChart(new Metrics.SimplePie("preview_mode", () -> {
            return this.getConfig().getBoolean("enable_previewmode") ? "Enabled" : "Disabled";
         }));
         var2.addCustomChart(new Metrics.SimplePie("economy", () -> {
            return econ.getName() != null ? econ.getName() : "Unknown";
         }));
      }
   }

   public void onDisable() {
      if (this.getPlayerManager() != null) {
         this.getPlayerManager().saveOnDisable();
      }

      if (this.claimManager != null) {
         this.claimManager.save();
      }

   }

   public static RegionGUI getInstance() {
      return instance;
   }

   public void log(String message) {
      this.log(var1, false);
   }

   public void log(String message, boolean withPrefix) {
      if (var2) {
         Bukkit.getConsoleSender().sendMessage("[RegionGUI] " + var1);
      } else {
         Bukkit.getConsoleSender().sendMessage(var1);
      }
   }

   private boolean setupEconomy() {
      if (this.getServer().getPluginManager().getPlugin("Vault") == null) {
         return false;
      } else {
         RegisteredServiceProvider var1 = this.getServer().getServicesManager().getRegistration(Economy.class);
         if (var1 == null) {
            return false;
         } else {
            econ = (Economy)var1.getProvider();
            return econ != null;
         }
      }
   }

   public void reloadConfig() {
      super.reloadConfig();
      this.loadLanguage();
   }

   public FlagManager getFlagManager() {
      return this.flagmanager;
   }

   public void loadLanguage() {
      File var1 = new File(getInstance().getDataFolder(), "lang.yml");
      YamlConfiguration var2;
      if (!var1.exists()) {
         try {
            getInstance().getDataFolder().mkdir();
            var1.createNewFile();
            if (var1 != null) {
               var2 = YamlConfiguration.loadConfiguration(var1);
               var2.save(var1);
               Language.setFile(var2);
            }
         } catch (IOException var8) {
            getInstance().getLogger().severe("Could not create language file!");
            Bukkit.getPluginManager().disablePlugin(getInstance());
         }
      }

      var2 = YamlConfiguration.loadConfiguration(var1);
      Language[] var6;
      int var5 = (var6 = Language.values()).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         Language var3 = var6[var4];
         if (var2.getString(var3.getPath()) == null) {
            if (var3.isArray()) {
               var2.set(var3.getPath(), var3.getDefArray());
            } else {
               var2.set(var3.getPath(), var3.getDefault());
            }
         }
      }

      Language.setFile(var2);

      try {
         var2.save(var1);
      } catch (IOException var7) {
         var7.printStackTrace();
      }

   }

   public ClaimManager getClaimManager() {
      return this.claimManager;
   }

   public PlayerManager getPlayerManager() {
      return this.playerManager;
   }
}

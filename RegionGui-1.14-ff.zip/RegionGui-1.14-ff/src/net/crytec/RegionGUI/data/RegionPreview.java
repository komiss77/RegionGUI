package net.crytec.RegionGUI.data;

import com.comphenix.protocol.wrappers.EnumWrappers.WorldBorderAction;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.utils.packets.WrapperPlayServerWorldBorder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

public class RegionPreview implements Runnable {
   private final WrapperPlayServerWorldBorder resetcenterPacket;
   private final WrapperPlayServerWorldBorder resetsizePacket;
   private final WrapperPlayServerWorldBorder centerPacket;
   private final WrapperPlayServerWorldBorder sizePacket;
   private final Player player;
   private final int size;
   private final BukkitTask task;

   public RegionPreview(Player player, int size) {
      this.player = var1;
      World var3 = var1.getWorld();
      this.size = var2;
      this.resetcenterPacket = new WrapperPlayServerWorldBorder();
      this.resetsizePacket = new WrapperPlayServerWorldBorder();
      this.resetsizePacket.setRadius(var3.getWorldBorder().getSize());
      this.resetsizePacket.setOldRadius(var3.getWorldBorder().getSize());
      this.resetsizePacket.setSpeed(0L);
      this.resetsizePacket.setAction(WorldBorderAction.LERP_SIZE);
      this.resetcenterPacket.setCenterX((double)var3.getWorldBorder().getCenter().getBlockX());
      this.resetcenterPacket.setCenterZ((double)var3.getWorldBorder().getCenter().getBlockZ());
      this.resetcenterPacket.setAction(WorldBorderAction.SET_CENTER);
      this.centerPacket = new WrapperPlayServerWorldBorder();
      this.sizePacket = new WrapperPlayServerWorldBorder();
      this.sizePacket.setRadius((double)this.size);
      this.sizePacket.setOldRadius((double)this.size);
      this.sizePacket.setSpeed(0L);
      this.sizePacket.setAction(WorldBorderAction.LERP_SIZE);
      this.centerPacket.setCenterX((double)var1.getLocation().getBlockX());
      this.centerPacket.setCenterZ((double)var1.getLocation().getBlockZ());
      this.centerPacket.setAction(WorldBorderAction.SET_CENTER);
      this.centerPacket.sendPacket(this.player);
      Bukkit.getScheduler().runTaskLater(RegionGUI.getInstance(), () -> {
         this.sizePacket.sendPacket(this.player);
      }, 1L);
      this.task = Bukkit.getScheduler().runTaskTimer(RegionGUI.getInstance(), this, 5L, 15L);
   }

   public void reset() {
      this.resetcenterPacket.sendPacket(this.player);
      Bukkit.getScheduler().runTaskLater(RegionGUI.getInstance(), () -> {
         this.resetsizePacket.sendPacket(this.player);
      }, 1L);
   }

   private void updateCenter() {
      Location var1 = this.player.getLocation().getBlock().getLocation().clone().add(0.5D, 0.0D, 0.5D);
      this.centerPacket.setCenterX(var1.getX());
      this.centerPacket.setCenterZ(var1.getZ());
      this.centerPacket.sendPacket(this.player);
   }

   public void run() {
      if (this.player.isOnline() && !this.player.isSneaking()) {
         this.player.sendTitle("", "§2Sneak to cancel preview mode", 0, 30, 0);
         this.updateCenter();
      } else {
         this.task.cancel();
         this.reset();
         this.player.resetTitle();
      }
   }

   protected void finalize() {
      System.out.println("Destroyed RegionPreview instance!");
   }
}

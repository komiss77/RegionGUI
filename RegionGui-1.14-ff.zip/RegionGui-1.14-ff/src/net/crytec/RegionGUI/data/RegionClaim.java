package net.crytec.RegionGUI.data;

import com.google.common.collect.Maps;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.inventory.ItemStack;

@SerializableAs("Template")
public class RegionClaim implements ConfigurationSerializable, Comparable {
   private final UUID id;
   private String displayname = "Default displayname";
   private Material icon;
   private List description;
   private int size;
   private String world;
   private int height;
   private int depth;
   private int price;
   private int refund;
   private Material borderMaterial;
   private boolean generateBorder;
   private List runCommands;
   private String permission;
   private List noPermDescription;

   public RegionClaim(World world) {
      this.icon = Material.BARRIER;
      this.description = Arrays.asList("§7Default description");
      this.size = 10;
      this.height = 256;
      this.depth = 256;
      this.price = -1;
      this.refund = 0;
      this.borderMaterial = Material.OAK_FENCE;
      this.generateBorder = true;
      this.runCommands = new ArrayList();
      this.permission = "";
      this.noPermDescription = Arrays.asList("Upgrade your rank to purchase this template.");
      this.id = UUID.randomUUID();
      this.size = 10;
      this.world = var1.getName();
   }

   private RegionClaim(UUID id) {
      this.icon = Material.BARRIER;
      this.description = Arrays.asList("§7Default description");
      this.size = 10;
      this.height = 256;
      this.depth = 256;
      this.price = -1;
      this.refund = 0;
      this.borderMaterial = Material.OAK_FENCE;
      this.generateBorder = true;
      this.runCommands = new ArrayList();
      this.permission = "";
      this.noPermDescription = Arrays.asList("Upgrade your rank to purchase this template.");
      this.id = var1;
   }

   public ItemStack getIcon() {
      return (new ItemBuilder(this.icon)).name(this.displayname).build();
   }

   public void setNoPermDescription(List list) {
      this.noPermDescription = (List)var1.stream().map((var0) -> {
         return ChatColor.translateAlternateColorCodes('&', var0);
      }).collect(Collectors.toList());
   }

   public boolean hasRefund() {
      return this.refund > 0;
   }

   public Optional getWorld() {
      return Optional.ofNullable(Bukkit.getWorld(this.world));
   }

   public int hashCode() {
      return Objects.hash(new Object[]{this.id});
   }

   public boolean equals(Object obj) {
      if (this == var1) {
         return true;
      } else if (var1 == null) {
         return false;
      } else if (!(var1 instanceof RegionClaim)) {
         return false;
      } else {
         RegionClaim var2 = (RegionClaim)var1;
         return Objects.equals(this.id, var2.id);
      }
   }

   public Map serialize() {
      HashMap var1 = Maps.newHashMap();
      var1.put("id", this.id.toString());
      var1.put("gui.displayname", this.displayname);
      var1.put("gui.icon", this.icon.toString());
      var1.put("gui.description", this.description);
      var1.put("gui.noPermDescription", this.noPermDescription);
      var1.put("data.size", this.size);
      var1.put("data.heigth", this.height);
      var1.put("data.depth", this.depth);
      var1.put("data.price", this.price);
      var1.put("data.refund", this.refund);
      var1.put("data.world", this.world);
      var1.put("data.permission", this.permission);
      var1.put("border.material", this.borderMaterial.toString());
      var1.put("border.enabled", this.generateBorder);
      var1.put("generation.runCommands", this.runCommands);
      return var1;
   }

   public static RegionClaim deserialize(Map map) {
      RegionClaim var1 = new RegionClaim(UUID.fromString((String)var0.get("id")));
      var1.setDisplayname((String)var0.get("gui.displayname"));
      var1.setIcon(Material.valueOf((String)var0.get("gui.icon")));
      var1.setDescription((List)var0.get("gui.description"));
      var1.setNoPermDescription((List)var0.get("gui.noPermDescription"));
      var1.setSize((Integer)var0.get("data.size"));
      var1.setHeight((Integer)var0.get("data.heigth"));
      var1.setDepth((Integer)var0.get("data.depth"));
      var1.setPrice((Integer)var0.get("data.price"));
      var1.setRefund((Integer)var0.get("data.refund"));
      var1.setWorld((String)var0.get("data.world"));
      var1.setPermission((String)var0.getOrDefault("data.permission", ""));
      var1.setBorderMaterial(Material.valueOf((String)var0.get("border.material")));
      var1.setGenerateBorder((Boolean)var0.get("border.enabled"));
      var1.setRunCommands((List)var0.get("generation.runCommands"));
      Bukkit.getServer().getLogger().info("Loaded Template ID " + var1.getId() + " - " + var1.getDisplayname());
      return var1;
   }

   public int compareTo(RegionClaim o) {
      return this.size > var1.getSize() ? 1 : (this.size < var1.getSize() ? -1 : 0);
   }

   public UUID getId() {
      return this.id;
   }

   public String getDisplayname() {
      return this.displayname;
   }

   public void setDisplayname(final String displayname) {
      this.displayname = var1;
   }

   public void setIcon(final Material icon) {
      this.icon = var1;
   }

   public List getDescription() {
      return this.description;
   }

   public void setDescription(final List description) {
      this.description = var1;
   }

   public int getSize() {
      return this.size;
   }

   public void setSize(final int size) {
      this.size = var1;
   }

   public void setWorld(final String world) {
      this.world = var1;
   }

   public int getHeight() {
      return this.height;
   }

   public void setHeight(final int height) {
      this.height = var1;
   }

   public int getDepth() {
      return this.depth;
   }

   public void setDepth(final int depth) {
      this.depth = var1;
   }

   public int getPrice() {
      return this.price;
   }

   public void setPrice(final int price) {
      this.price = var1;
   }

   public int getRefund() {
      return this.refund;
   }

   public void setRefund(final int refund) {
      this.refund = var1;
   }

   public Material getBorderMaterial() {
      return this.borderMaterial;
   }

   public void setBorderMaterial(final Material borderMaterial) {
      this.borderMaterial = var1;
   }

   public boolean isGenerateBorder() {
      return this.generateBorder;
   }

   public void setGenerateBorder(final boolean generateBorder) {
      this.generateBorder = var1;
   }

   public List getRunCommands() {
      return this.runCommands;
   }

   public void setRunCommands(final List runCommands) {
      this.runCommands = var1;
   }

   public String getPermission() {
      return this.permission;
   }

   public void setPermission(final String permission) {
      this.permission = var1;
   }

   public List getNoPermDescription() {
      return this.noPermDescription;
   }

   public String toString() {
      return "RegionClaim(id=" + this.getId() + ", displayname=" + this.getDisplayname() + ", icon=" + this.getIcon() + ", description=" + this.getDescription() + ", size=" + this.getSize() + ", world=" + this.getWorld() + ", height=" + this.getHeight() + ", depth=" + this.getDepth() + ", price=" + this.getPrice() + ", refund=" + this.getRefund() + ", borderMaterial=" + this.getBorderMaterial() + ", generateBorder=" + this.isGenerateBorder() + ", runCommands=" + this.getRunCommands() + ", permission=" + this.getPermission() + ", noPermDescription=" + this.getNoPermDescription() + ")";
   }
}

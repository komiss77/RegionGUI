package net.crytec.RegionGUI.data;

import com.google.common.collect.Maps;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import net.crytec.RegionGUI.RegionGUI;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.serialization.ConfigurationSerializable;
import org.bukkit.configuration.serialization.SerializableAs;

@SerializableAs("PlayerClaim")
public class ClaimEntry implements ConfigurationSerializable {
   final String regionID;
   final RegionClaim template;
   final long timestamp;
   private transient Optional protectedRegion;

   public ClaimEntry(String regionID, RegionClaim claim, long timestamp) {
      this.regionID = var1;
      this.template = var2;
      this.timestamp = var3;
      if (!this.template.getWorld().isPresent()) {
         Bukkit.getLogger().severe("Failed to load template - World does not exist!");
      } else {
         World var5 = (World)this.template.getWorld().get();
         ProtectedRegion var6 = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(var5)).getRegion(this.regionID);
         if (var6 == null) {
            RegionGUI.getInstance().getLogger().info("Region " + var1 + " in world " + this.template.getWorld() + " does no longer exist!");
         }

         this.protectedRegion = Optional.ofNullable(var6);
      }
   }

   public Optional getProtectedRegion() {
      if (this.protectedRegion != null) {
         return this.protectedRegion;
      } else if (!this.template.getWorld().isPresent()) {
         Bukkit.getLogger().severe("Failed to parse Region " + this.regionID + "  - World is no longer loaded!");
         return Optional.empty();
      } else {
         World var1 = (World)this.template.getWorld().get();
         ProtectedRegion var2 = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(var1)).getRegion(this.regionID);
         if (var2 == null) {
            RegionGUI.getInstance().getLogger().info("Region " + this.regionID + " in world " + var1.getName() + " does no longer exist!");
         }

         this.protectedRegion = Optional.ofNullable(var2);
         return this.protectedRegion;
      }
   }

   public Map serialize() {
      HashMap var1 = Maps.newHashMap();
      var1.put("template", this.template.getId().toString());
      var1.put("timestamp", this.timestamp);
      var1.put("region", this.regionID);
      return var1;
   }

   public static ClaimEntry deserialize(Map map) {
      String var1 = (String)var0.get("region");
      UUID var2 = UUID.fromString((String)var0.get("template"));
      long var3 = (Long)var0.get("timestamp");
      RegionClaim var5 = RegionGUI.getInstance().getClaimManager().getClaimByID(var2);
      if (var5 == null) {
         RegionGUI.getInstance().getLogger().severe("Failed to claim! Template does no longer exist!");
         return null;
      } else {
         return new ClaimEntry(var1, var5, var3);
      }
   }

   public String getRegionID() {
      return this.regionID;
   }

   public RegionClaim getTemplate() {
      return this.template;
   }

   public long getTimestamp() {
      return this.timestamp;
   }
}

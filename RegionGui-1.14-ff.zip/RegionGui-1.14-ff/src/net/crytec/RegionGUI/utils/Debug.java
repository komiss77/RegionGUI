package net.crytec.RegionGUI.utils;

import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import net.crytec.RegionGUI.RegionGUI;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

public class Debug {
   private File _logfile;
   public static String PLUGINS = "38105";

   public Debug() {
      this.start();
   }

   private void start() {
      File var1 = new File(RegionGUI.getInstance().getDataFolder(), "debug.txt");

      try {
         if (var1.exists()) {
            var1.delete();
            var1.createNewFile();
         } else {
            var1.createNewFile();
         }
      } catch (IOException var8) {
         Bukkit.getLogger().severe("Unable to create debug.txt - " + var8.getMessage());
      }

      this._logfile = var1;
      this.log("Installed Plugins (" + Bukkit.getPluginManager().getPlugins().length + " " + PLUGINS + "):");
      StringBuilder var2 = new StringBuilder();
      Plugin[] var6;
      int var5 = (var6 = Bukkit.getPluginManager().getPlugins()).length;

      for(int var4 = 0; var4 < var5; ++var4) {
         Plugin var3 = var6[var4];
         var2.append(var3.getName() + ", ");
      }

      this.log(var2.toString());
      File var9 = new File(RegionGUI.getInstance().getDataFolder(), "config.yml");
      this.writeConfigToLog("REGION GUI CONFIGURATION", var9);
      File var10 = new File(RegionGUI.getInstance().getDataFolder(), "lang.yml");
      this.writeConfigToLog("LANGUAGE FILE", var10);
      Iterator var13 = Bukkit.getWorlds().iterator();

      while(var13.hasNext()) {
         World var11 = (World)var13.next();
         File var7 = new File(WorldGuardPlugin.inst().getDataFolder() + File.separator + "worlds" + File.separator + var11.getName(), "regions.yml");
         this.writeConfigToLog("=== REGION.YML (" + var11.getName() + ") ===", var7);
      }

      File var12 = new File(WorldGuardPlugin.inst().getDataFolder(), "config.yml");
      this.writeConfigToLog("=== WORLDGUARD CONFIGURATION ===", var12);
      Bukkit.getLogger().info("=============================================================================");
      Bukkit.getLogger().info("A new debug file has been saved to the RegionGUI plugin folder (debug.txt)");
      Bukkit.getLogger().info("Please upload the debug file (pastebin.com) and contact the plugin author");
      Bukkit.getLogger().info("=============================================================================");
   }

   private boolean writeConfigToLog(String title, File file) {
      this.log(" ");
      this.log(" ");
      this.log(" ");
      this.log("=== " + var1 + " ===");

      try {
         Throwable var3 = null;
         Object var4 = null;

         try {
            BufferedReader var5 = new BufferedReader(new FileReader(var2));

            try {
               String var6;
               while((var6 = var5.readLine()) != null) {
                  this.log(var6);
               }

               var5.close();
            } finally {
               if (var5 != null) {
                  var5.close();
               }

            }

            return true;
         } catch (Throwable var14) {
            if (var3 == null) {
               var3 = var14;
            } else if (var3 != var14) {
               var3.addSuppressed(var14);
            }

            throw var3;
         }
      } catch (IOException var15) {
         return false;
      }
   }

   private void log(String message) {
      try {
         Throwable var2 = null;
         Object var3 = null;

         try {
            PrintWriter var4 = new PrintWriter(new BufferedWriter(new FileWriter(this._logfile, true)));

            try {
               var4.println(var1);
               var4.flush();
               var4.close();
            } finally {
               if (var4 != null) {
                  var4.close();
               }

            }
         } catch (Throwable var12) {
            if (var2 == null) {
               var2 = var12;
            } else if (var2 != var12) {
               var2.addSuppressed(var12);
            }

            throw var2;
         }
      } catch (IOException var13) {
         var13.printStackTrace();
      }

   }
}

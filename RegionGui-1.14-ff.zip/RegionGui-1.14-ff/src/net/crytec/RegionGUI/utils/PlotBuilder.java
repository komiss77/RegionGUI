package net.crytec.RegionGUI.utils;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.domains.DefaultDomain;
import com.sk89q.worldguard.domains.PlayerDomain;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldguard.util.profile.Profile;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.events.RegionPurchasedEvent;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Vector;

public class PlotBuilder {
   private final RegionGUI plugin = (RegionGUI)JavaPlugin.getPlugin(RegionGUI.class);
   private final Player player;
   private final String displayname;
   private final RegionClaim claim;
   private final Location loc;
   private final RegionManager manager;
   private final LocalPlayer localPlayer;

   public PlotBuilder(Player player, String displayname, RegionClaim claim) {
      this.player = var1;
      this.displayname = var2;
      this.claim = var3;
      this.loc = var1.getLocation();
      this.manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(var1.getWorld()));
      this.localPlayer = WorldGuardPlugin.inst().wrapPlayer(var1);
   }

   public void build() {
      int var1 = this.loc.getBlockX();
      int var2 = this.loc.getBlockZ();
      int var3 = this.loc.getBlockY();
      int var4 = this.claim.getSize();
      if (this.claim.getPermission() != null && !this.claim.getPermission().isEmpty() && !this.player.hasPermission(this.claim.getPermission())) {
         this.player.sendMessage(Language.ERROR_NO_PERMISSION.toChatString().replaceAll("%permission%", this.claim.getPermission()));
      } else {
         int var5 = (int)Math.round((double)var4 / 2.0D);
         Vector var6 = new Vector(var1 + var5, var3 + this.claim.getHeight(), var2 + var5);
         Vector var7 = new Vector(var1 - var5, var3 - this.claim.getDepth(), var2 - var5);
         BlockVector3 var8 = BlockVector3.at(var6.getBlockX(), var6.getBlockY(), var6.getBlockZ());
         BlockVector3 var9 = BlockVector3.at(var7.getBlockX(), var7.getBlockY(), var7.getBlockZ());
         String var10 = this.plugin.getConfig().getString("region-identifier").replace("%player%", this.player.getName()).replace("%displayname%", this.displayname);
         ProtectedCuboidRegion var11 = new ProtectedCuboidRegion(var10, var8, var9);
         if (this.manager.overlapsUnownedRegion(var11, this.localPlayer) && this.plugin.getConfig().getBoolean("preventRegionOverlap", true)) {
            this.player.sendMessage(Language.ERROR_OVERLAP.toString());
         } else {
            int var12 = this.claim.getPrice();
            DefaultDomain var13 = var11.getOwners();
            PlayerDomain var14 = var13.getPlayerDomain();
            Profile var15 = new Profile(this.player.getUniqueId(), this.player.getName());
            WorldGuard.getInstance().getProfileCache().put(var15);
            var14.addPlayer(this.player.getUniqueId());
            var13.setPlayerDomain(var14);
            var11.setOwners(var13);
            var11.setFlag(Flags.TELE_LOC, BukkitAdapter.adapt(this.player.getLocation()));
            EconomyResponse var16 = RegionGUI.econ.withdrawPlayer(this.player.getPlayer(), (double)var12);
            if (!var16.transactionSuccess()) {
               this.player.sendMessage(Language.ERROR_NO_MONEY.toChatString());
            } else {
               this.player.sendMessage(Language.REGION_CREATE_MONEY.toChatString().replace("%money%", "" + var12).replace("%currencyname%", RegionGUI.econ.currencyNameSingular()));
               var11.setDirty(true);
               if (this.claim.isGenerateBorder()) {
                  new Walls(this.claim, var11);
               }

               this.manager.addRegion(var11);
               this.player.sendMessage(Language.REGION_CREATE_SUCCESS.toChatString());
               RegionGUI.getInstance().getPlayerManager().addClaimToPlayer(this.player.getUniqueId(), var11, this.claim);
               Bukkit.getScheduler().runTask(RegionGUI.getInstance(), () -> {
                  Bukkit.getPluginManager().callEvent(new RegionPurchasedEvent(this.player, var12, this.claim, var11));
               });
            }
         }
      }
   }
}

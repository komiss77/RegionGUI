package net.crytec.RegionGUI.utils.packets;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketContainer;
import com.google.common.base.Objects;
import java.lang.reflect.InvocationTargetException;
import org.bukkit.entity.Player;

public abstract class AbstractPacket {
   protected PacketContainer handle;

   protected AbstractPacket(PacketContainer handle, PacketType type) {
      if (var1 == null) {
         throw new IllegalArgumentException("Packet handle cannot be NULL.");
      } else if (!Objects.equal(var1.getType(), var2)) {
         throw new IllegalArgumentException(var1.getHandle() + " is not a packet of type " + var2);
      } else {
         this.handle = var1;
      }
   }

   public PacketContainer getHandle() {
      return this.handle;
   }

   public void sendPacket(Player receiver) {
      try {
         ProtocolLibrary.getProtocolManager().sendServerPacket(var1, this.getHandle());
      } catch (InvocationTargetException var3) {
         throw new RuntimeException("Cannot send packet.", var3);
      }
   }

   public void broadcastPacket() {
      ProtocolLibrary.getProtocolManager().broadcastServerPacket(this.getHandle());
   }

   /** @deprecated */
   @Deprecated
   public void recievePacket(Player sender) {
      try {
         ProtocolLibrary.getProtocolManager().recieveClientPacket(var1, this.getHandle());
      } catch (Exception var3) {
         throw new RuntimeException("Cannot recieve packet.", var3);
      }
   }

   public void receivePacket(Player sender) {
      try {
         ProtocolLibrary.getProtocolManager().recieveClientPacket(var1, this.getHandle());
      } catch (Exception var3) {
         throw new RuntimeException("Cannot receive packet.", var3);
      }
   }
}

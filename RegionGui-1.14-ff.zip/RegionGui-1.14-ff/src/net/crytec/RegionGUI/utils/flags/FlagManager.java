package net.crytec.RegionGUI.utils.flags;

import com.google.common.collect.Lists;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.LocationFlag;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.phoenix.api.io.PluginConfig;
import net.crytec.shaded.org.apache.lang3.EnumUtils;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;

public class FlagManager {
   private LinkedList settings = Lists.newLinkedList();
   private LinkedList flags = Lists.newLinkedList();
   private final PluginConfig flagConfig;
   private ArrayList forbiddenFlags = Lists.newArrayList();

   public FlagManager(RegionGUI plugin) {
      this.forbiddenFlags.add("receive-chat");
      this.forbiddenFlags.add("allowed-cmds");
      this.forbiddenFlags.add("blocked-cmds");
      this.forbiddenFlags.add("send-chat");
      this.forbiddenFlags.add("invincible");
      this.forbiddenFlags.add("command-on-entry");
      this.forbiddenFlags.add("command-on-exit");
      this.forbiddenFlags.add("console-command-on-entry");
      this.forbiddenFlags.add("console-command-on-exit");
      this.forbiddenFlags.add("godmode");
      this.forbiddenFlags.add("worldedit");
      this.forbiddenFlags.add("chunk-unload");
      this.forbiddenFlags.add("passthrough");
      this.forbiddenFlags.add("price");
      this.flagConfig = new PluginConfig(var1, var1.getDataFolder(), "flags.yml");
      boolean var2 = false;
      Iterator var4 = WorldGuard.getInstance().getFlagRegistry().getAll().iterator();

      while(var4.hasNext()) {
         Flag var3 = (Flag)var4.next();
         if (!this.forbiddenFlags.contains(var3.getName()) && !(var3 instanceof LocationFlag)) {
            String var5 = "flags." + var3.getName() + ".";
            if (!this.flagConfig.isSet("flags." + var3.getName() + ".name")) {
               this.flagConfig.set(var5 + "name", "&7" + var3.getName());
               this.flagConfig.set(var5 + "enabled", true);
               this.flagConfig.set(var5 + "icon", Material.LIGHT_GRAY_DYE.toString());
               var2 = true;
            }

            Material var6 = Material.BARRIER;
            if (EnumUtils.isValidEnum(Material.class, this.flagConfig.getString(var5 + "icon"))) {
               var6 = Material.valueOf(this.flagConfig.getString(var5 + "icon"));
            }

            if (this.flagConfig.getBoolean(var5 + "enabled")) {
               this.addFlags(var3.getName(), var3, var6, ChatColor.translateAlternateColorCodes('&', this.flagConfig.getString(var5 + "name")));
            }
         }
      }

      if (var2) {
         var1.log("§eFlag settings configuration updated with new entires.", true);
         this.flagConfig.saveConfig();
      }

      this.settings.sort(Comparator.comparing(FlagSetting::getId));
      
      Permission var7 = new Permission("region.flagmenu.all", "Allow the useage of all flags", PermissionDefault.FALSE);
      ((List)this.getFlagMap().stream().map(FlagSetting::getPermission).collect(Collectors.toList())).forEach((var1x) -> {
         var7.getChildren().put(var1x.getName(), var1x.getDefault().getValue(false));
      });
   }

   public void addFlags(String idenfifier, Flag flag, Material icon, String displayname) {
      this.flags.add(new FlagSetting(var1, var2, var3, var4));
   }

   public LinkedList getFlagMap() {
      return this.flags;
   }
}

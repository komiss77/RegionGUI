package net.crytec.RegionGUI.utils.flags;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extension.platform.Actor;
import com.sk89q.worldguard.protection.flags.BooleanFlag;
import com.sk89q.worldguard.protection.flags.DoubleFlag;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.FlagContext;
import com.sk89q.worldguard.protection.flags.IntegerFlag;
import com.sk89q.worldguard.protection.flags.InvalidFlagFormat;
import com.sk89q.worldguard.protection.flags.SetFlag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.StringFlag;
import com.sk89q.worldguard.protection.flags.StateFlag.State;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.item.ItemFactory;
import net.crytec.phoenix.api.utils.F;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;

public class FlagSetting implements Comparable {
   private Flag flag;
   private String id;
   private Material icon;
   private FlagInputType inputType;
   private final Permission permission;
   private final String displayname;
   // $FF: synthetic field
   private static int[] $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType;

   public FlagSetting(String id, Flag flag, Material icon, String displayname) {
      this.icon = Material.PAPER;
      this.flag = var2;
      this.id = var1;
      this.displayname = var4;
      this.icon = var3;
      this.permission = new Permission("region.flagmenu." + this.id, "Enables the use of the " + var1 + " flag.", PermissionDefault.TRUE);

      try {
         Bukkit.getPluginManager().addPermission(this.permission);
      } catch (IllegalArgumentException var6) {
      }

      if (var2 instanceof StringFlag) {
         this.inputType = FlagInputType.STRING;
      } else if (var2 instanceof StateFlag) {
         this.inputType = FlagInputType.STATE;
      } else if (var2 instanceof SetFlag) {
         this.inputType = FlagInputType.SET;
      } else if (var2 instanceof IntegerFlag) {
         this.inputType = FlagInputType.INTEGER;
      } else if (var2 instanceof BooleanFlag) {
         this.inputType = FlagInputType.BOOLEAN;
      } else {
         this.inputType = FlagInputType.UNKNOWN;
      }

   }

   public ClickableItem getButton(Player player, ProtectedRegion region, InventoryContents contents) {
      ItemFactory var4 = (new ItemBuilder(this.icon)).name("§7" + this.getName());
      var4.setItemFlag(ItemFlag.HIDE_ATTRIBUTES);
      var4.setItemFlag(ItemFlag.HIDE_ENCHANTS);
      if (var2.getFlags().containsKey(this.getFlag())) {
         var4.enchantment(Enchantment.ARROW_INFINITE);
         if (this.inputType == FlagInputType.STATE) {
            StateFlag var5 = (StateFlag)this.getFlag();
            String var6 = var2.getFlag(var5) == State.DENY ? "§c" + this.getName() : "§a" + this.getName();
            var4.name(var6);
         }
      }

      var4.lore("");
      var4.lore(this.getCurrentValue(var2));
      return new ClickableItem(var4.build(), (var4x) -> {
         if (var4x.getClick() == ClickType.RIGHT && var2.getFlags().containsKey(this.getFlag())) {
            var2.setFlag(this.getFlag(), (Object)null);
            var1.sendMessage(Language.FLAG_CLEARED.toString().replace("%flag%", this.getName()));
            var3.inventory().getProvider().reOpen(var1, var3);
         } else {
            if (this.inputType != FlagInputType.STATE && this.inputType != FlagInputType.BOOLEAN) {
               var1.closeInventory();
               var1.sendMessage(Language.FLAG_INPUT_CHAT.toChatString().replace("%flag%", this.getName()));
               PhoenixAPI.get().getPlayerChatInput(var1, (var4) -> {
                  try {
                     setFlag(var2, this.flag, BukkitAdapter.adapt(var1), var4);
                     Bukkit.getScheduler().runTaskLater(RegionGUI.getInstance(), () -> {
                        var3.inventory().getProvider().reOpen(var1, var3);
                     }, 1L);
                  } catch (InvalidFlagFormat var6) {
                     var1.sendMessage(var6.getMessage());
                  }

               });
            } else {
               this.switchState(var1, var2);
               var3.inventory().getProvider().reOpen(var1, var3);
            }

         }
      });
   }

   private void switchState(Player player, ProtectedRegion region) {
      if (this.inputType == FlagInputType.STATE) {
         StateFlag var3 = (StateFlag)this.getFlag();
         if (var2.getFlags().containsKey(this.getFlag())) {
            if (var2.getFlag(var3) == State.DENY) {
               var2.setFlag(var3, State.ALLOW);
               var1.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            } else {
               var2.setFlag(var3, State.DENY);
               var1.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
            }
         } else {
            var2.setFlag(var3, State.ALLOW);
            var1.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
         }
      } else {
         BooleanFlag var4 = (BooleanFlag)this.getFlag();
         if (var2.getFlags().containsKey(this.getFlag())) {
            if (!(Boolean)var2.getFlag(var4)) {
               var2.setFlag(var4, true);
               var1.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            } else {
               var2.setFlag(var4, false);
               var1.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
            }
         } else {
            var2.setFlag(var4, true);
            var1.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
         }
      }

   }

   public String getCurrentValue(ProtectedRegion region) {
      if (!var1.getFlags().containsKey(this.getFlag())) {
         return "§cFlag not set";
      } else {
         switch($SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType()[this.inputType.ordinal()]) {
         case 1:
            SetFlag var2 = (SetFlag)this.getFlag();
            return F.format((Iterable)var1.getFlag(var2), ",", "none");
         case 2:
            return F.tf(var1.getFlag((StateFlag)this.getFlag()) != State.DENY);
         case 3:
            return F.name("" + (Double)var1.getFlag((DoubleFlag)this.getFlag()));
         case 4:
            return F.name("" + (Integer)var1.getFlag((IntegerFlag)this.getFlag()));
         case 5:
            return F.tf((Boolean)var1.getFlag((BooleanFlag)this.getFlag()));
         case 6:
            return F.name(((String)var1.getFlag((StringFlag)this.getFlag())).toString());
         case 7:
            return "§7Unknown";
         default:
            return "Unable to query flag value";
         }
      }
   }

   public void setIcon(Material mat) {
      this.icon = var1;
   }

   public Material getIcon() {
      return this.icon;
   }

   public String getId() {
      return this.id;
   }

   public Flag getFlag() {
      return this.flag;
   }

   protected static void setFlag(ProtectedRegion region, Flag flag, Actor sender, String value) {
      var0.setFlag(var1, var1.parseInput(FlagContext.create().setSender(var2).setInput(var3).setObject("region", var0).build()));
   }

   public String getName() {
      return this.displayname;
   }

   public int compareTo(FlagSetting other) {
      return this.getId().compareTo(var1.getId());
   }

   public Permission getPermission() {
      return this.permission;
   }

   // $FF: synthetic method
   static int[] $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType() {
      int[] var10000 = $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType;
      if (var10000 != null) {
         return var10000;
      } else {
         int[] var0 = new int[FlagInputType.values().length];

         try {
            var0[FlagInputType.BOOLEAN.ordinal()] = 5;
         } catch (NoSuchFieldError var7) {
         }

         try {
            var0[FlagInputType.DOUBLE.ordinal()] = 3;
         } catch (NoSuchFieldError var6) {
         }

         try {
            var0[FlagInputType.INTEGER.ordinal()] = 4;
         } catch (NoSuchFieldError var5) {
         }

         try {
            var0[FlagInputType.SET.ordinal()] = 1;
         } catch (NoSuchFieldError var4) {
         }

         try {
            var0[FlagInputType.STATE.ordinal()] = 2;
         } catch (NoSuchFieldError var3) {
         }

         try {
            var0[FlagInputType.STRING.ordinal()] = 6;
         } catch (NoSuchFieldError var2) {
         }

         try {
            var0[FlagInputType.UNKNOWN.ordinal()] = 7;
         } catch (NoSuchFieldError var1) {
         }

         $SWITCH_TABLE$net$crytec$RegionGUI$utils$flags$FlagInputType = var0;
         return var0;
      }
   }
}

package net.crytec.RegionGUI.utils;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.managers.storage.StorageException;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import java.util.List;
import net.crytec.shaded.org.apache.lang3.EnumUtils;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.util.Vector;

public class RegionUtils {
   private static WorldGuardPlatform platform = WorldGuard.getInstance().getPlatform();

   public static boolean validateMaterial(String material) {
      return EnumUtils.isValidEnum(Material.class, var0);
   }

   public static boolean saveRegions(World world) {
      try {
         platform.getRegionContainer().get(BukkitAdapter.adapt(var0)).saveChanges();
         return true;
      } catch (StorageException var2) {
         var2.printStackTrace();
         return false;
      }
   }

   public static RegionManager getRegionManager(World world) {
      return platform.getRegionContainer().get(BukkitAdapter.adapt(var0));
   }

   public static List getLocationsFromRegion(ProtectedRegion region) {
      BlockVector3 var1 = var0.getMinimumPoint();
      BlockVector3 var2 = var0.getMaximumPoint();
      int var3 = var0.getMaximumPoint().getY() - var0.getMinimumPoint().getY();
      ArrayList var4 = new ArrayList();
      ArrayList var5 = new ArrayList();
      var5.add(new Vector(var1.getX(), var1.getY(), var1.getZ()));
      var5.add(new Vector(var2.getX(), var1.getY(), var1.getZ()));
      var5.add(new Vector(var2.getX(), var1.getY(), var2.getZ()));
      var5.add(new Vector(var1.getX(), var1.getY(), var2.getZ()));

      for(int var6 = 0; var6 < var5.size(); ++var6) {
         Vector var7 = (Vector)var5.get(var6);
         Vector var8;
         if (var6 + 1 < var5.size()) {
            var8 = (Vector)var5.get(var6 + 1);
         } else {
            var8 = (Vector)var5.get(0);
         }

         Vector var10 = var7.add(new Vector(0, var3, 0));
         Vector var11 = var8.add(new Vector(0, var3, 0));
         var4.addAll(regionLine(var7, var8));
         var4.addAll(regionLine(var10, var11));
         var4.addAll(regionLine(var7, var10));

         for(double var12 = 2.0D; var12 < (double)var3; var12 += 2.0D) {
            Vector var9 = var7.add(new Vector(0.0D, var12, 0.0D));
            Vector var14 = var8.add(new Vector(0.0D, var12, 0.0D));
            var4.addAll(regionLine(var9, var14));
         }
      }

      return var4;
   }

   public static List regionLine(Vector p1, Vector p2) {
      ArrayList var2 = new ArrayList();
      int var3 = (int)(var0.distance(var1) / 1.0D) + 1;
      double var4 = var0.distance(var1);
      double var6 = var4 / (double)(var3 - 1);
      Vector var8 = var1.subtract(var0).normalize().multiply(var6);

      for(int var9 = 0; var9 < var3; ++var9) {
         Vector var10 = var0.add(var8.multiply(var9));
         var2.add(var10);
      }

      return var2;
   }
}

package net.crytec.RegionGUI.utils;

import com.google.common.collect.Sets;
import com.sk89q.worldedit.math.BlockVector2;
import com.sk89q.worldedit.regions.CuboidRegion;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayDeque;
import java.util.HashSet;
import java.util.Queue;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.Bukkit;
import org.bukkit.Effect;
import org.bukkit.Material;
import org.bukkit.Tag;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.scheduler.BukkitTask;

public class Walls implements Runnable {
   private final World world;
   private final Material material;
   private BukkitTask task;
   private Queue toFill = new ArrayDeque();
   private static final int increment = 10;
   private CuboidRegion region;

   public Walls(RegionClaim claim, ProtectedRegion region) {
      this.region = new CuboidRegion(var2.getMaximumPoint(), var2.getMinimumPoint());
      this.region.setPos1(var2.getMaximumPoint().withY(0));
      this.region.setPos2(var2.getMinimumPoint().withY(0));
      HashSet var3 = Sets.newHashSet();
      this.region.getWalls().forEach((var1x) -> {
         var3.add(var1x.toBlockVector2());
      });
      this.toFill.addAll(var3);
      this.world = (World)var1.getWorld().get();
      this.material = var1.getBorderMaterial();
      this.task = Bukkit.getScheduler().runTaskTimer(RegionGUI.getInstance(), this, 5L, 10L);
   }

   public void run() {
      for(int var1 = 0; var1 <= 10; ++var1) {
         if (this.toFill.isEmpty()) {
            this.task.cancel();
            return;
         }

         BlockVector2 var2 = (BlockVector2)this.toFill.poll();
         Block var3 = this.getHighestBlock(this.world, var2.getBlockX(), var2.getBlockZ());
         var3.setType(this.material, true);
         this.world.playEffect(var3.getLocation(), Effect.STEP_SOUND, this.material);
      }

   }

   private Block getHighestBlock(World world, int x, int z) {
      Block var4;
      for(var4 = var1.getHighestBlockAt(var2, var3).getRelative(BlockFace.DOWN); Tag.LEAVES.isTagged(var4.getType()) || var4.getType() == Material.AIR || var4.getType() == Material.GRASS || var4.getType() == Material.TALL_GRASS; var4 = var4.getRelative(BlockFace.DOWN)) {
      }

      return var4.getRelative(BlockFace.UP);
   }
}

package net.crytec.RegionGUI.manager;

import com.google.common.collect.Maps;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.shaded.org.apache.commons.io.FileUtils;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.Listener;

public class ClaimManager implements Listener {
   private final RegionGUI plugin;
   private final LinkedHashMap templates = Maps.newLinkedHashMap();
   private final File templateFolder;

   public ClaimManager(RegionGUI plugin) {
      this.plugin = var1;
      Bukkit.getPluginManager().registerEvents(this, var1);
      File var2 = new File(this.plugin.getDataFolder(), "templates");
      this.templateFolder = var2;
      if (!this.templateFolder.exists()) {
         this.templateFolder.mkdir();
      }

      this.loadTemplates();
   }

   public void registerTemplate(RegionClaim claim) {
      this.templates.put(var1.getId(), var1);
   }

   public Set getTemplates(World world) {
      return (Set)this.templates.values().stream().filter((var0) -> {
         return var0.getWorld().isPresent();
      }).filter((var1x) -> {
         return ((World)var1x.getWorld().get()).equals(var1);
      }).collect(Collectors.toSet());
   }

   public Optional getByName(World world, String name) {
      return this.templates.values().stream().filter((var0) -> {
         return var0.getWorld().isPresent();
      }).filter((var2x) -> {
         return ((World)var2x.getWorld().get()).equals(var1) && var2x.getDisplayname().equals(var2);
      }).findFirst();
   }

   public RegionClaim getClaimByID(UUID uuid) {
      return (RegionClaim)this.templates.get(var1);
   }

   public void deleteTemplate(RegionClaim claim) {
      this.templates.remove(var1.getId());
      File var2 = new File(this.templateFolder, var1.getId().toString() + ".claim");
      if (var2.exists()) {
         var2.delete();
      }

      RegionGUI.getInstance().getPlayerManager().getPlayerdata().values().forEach((var1x) -> {
         var1x.removeIf((var1xx) -> {
            return var1xx.getTemplate().equals(var1);
         });
      });
   }

   public void loadTemplates() {
      Iterator var1 = FileUtils.iterateFiles(this.templateFolder, new String[]{"claim"}, false);

      while(var1.hasNext()) {
         File var2 = (File)var1.next();

         try {
            YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
            RegionClaim var4 = (RegionClaim)var3.getSerializable("data", RegionClaim.class);
            this.templates.put(var4.getId(), var4);
         } catch (Exception var5) {
            RegionGUI.getInstance().getLogger().severe("Failed to load template from file " + var2.getName());
            var5.printStackTrace();
         }
      }

   }

   public void save() {
      Iterator var2 = this.templates.values().iterator();

      while(var2.hasNext()) {
         RegionClaim var1 = (RegionClaim)var2.next();

         try {
            File var3 = new File(this.templateFolder, var1.getId().toString() + ".claim");
            if (!var3.exists()) {
               var3.createNewFile();
            }

            YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
            var4.set("data", var1);
            var4.save(var3);
         } catch (IOException var5) {
            RegionGUI.getInstance().getLogger().severe("Failed to save template to disk!");
         }
      }

   }
}

package net.crytec.RegionGUI.manager;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Sets;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.shaded.org.apache.commons.io.FileUtils;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerManager implements Listener {
   private final HashMap playerdata = Maps.newHashMap();
   private final File folder;

   public PlayerManager(RegionGUI plugin, ClaimManager manager) {
      Bukkit.getPluginManager().registerEvents(this, var1);
      this.folder = new File(var1.getDataFolder(), "data");
      if (!this.folder.exists()) {
         this.folder.mkdir();
      }

      Bukkit.getOnlinePlayers().forEach((var1x) -> {
         this.loadPlayerFiles(var1x.getUniqueId());
      });
      Iterator var3 = FileUtils.iterateFiles(this.folder, new String[]{"data"}, false);

      while(var3.hasNext()) {
         File var4 = (File)var3.next();
         UUID var5 = UUID.fromString(var4.getName().replace(".data", ""));
         this.loadPlayerFiles(var5);
      }

      var1.getLogger().info("Loading " + this.playerdata.size() + " playerfiles...");
   }

   public void saveOnDisable() {
      Bukkit.getOnlinePlayers().forEach((var1) -> {
         this.savePlayerFiles(var1.getUniqueId());
      });
      this.playerdata.clear();
   }

   public Set getPlayerClaims(UUID uuid) {
      return (Set)this.playerdata.get(var1);
   }

   public void addClaimToPlayer(UUID owner, ProtectedRegion region, RegionClaim claim) {
      ((Set)this.playerdata.get(var1)).add(new ClaimEntry(var2.getId(), var3, System.currentTimeMillis()));
   }

   public void deleteClaim(UUID owner, ProtectedRegion region) {
      ((Set)this.playerdata.get(var1)).removeIf((var1x) -> {
         return ((ProtectedRegion)var1x.getProtectedRegion().get()).equals(var2);
      });
      this.savePlayerFiles(var1);
   }

   public void loadPlayerFiles(UUID uuid) {
      File var2 = new File(this.folder, var1.toString() + ".data");
      if (!var2.exists()) {
         this.playerdata.put(var1, Sets.newHashSet());
      } else {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         List var4 = var3.getList("data");
         this.playerdata.put(var1, Sets.newHashSet(var4));
         RegionGUI.getInstance().getLogger().info("Loaded " + ((Set)this.playerdata.get(var1)).size() + " templates for player " + var1.toString());
         Iterator var5 = this.getPlayerClaims(var1).iterator();

         while(true) {
            while(var5.hasNext()) {
               ClaimEntry var6 = (ClaimEntry)var5.next();
               if (var6 == null) {
                  RegionGUI.getInstance().getLogger().severe("Failed to load player claims for user: " + var1.toString() + " (" + Bukkit.getOfflinePlayer(var1).getName() + ")");
               } else if (var6.getTemplate() == null) {
                  var5.remove();
                  RegionGUI.getInstance().getLogger().severe("Removed claim for player " + var1.toString() + " because the given template does no longer exist.");
               } else if (var6.getProtectedRegion() == null || !var6.getProtectedRegion().isPresent()) {
                  var5.remove();
                  RegionGUI.getInstance().getLogger().severe("Removed claim for player " + var1.toString() + " because the WorldGuard region does no longer exist.");
               }
            }

            return;
         }
      }
   }

   public void savePlayerFiles(UUID uuid) {
      File var2;
      if (((Set)this.playerdata.get(var1)).isEmpty()) {
         var2 = new File(this.folder, var1.toString() + ".data");
         if (var2.exists()) {
            var2.delete();
         }

      } else {
         var2 = new File(this.folder, var1.toString() + ".data");
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         ArrayList var4 = Lists.newArrayList((Iterable)this.playerdata.get(var1));
         var3.set("data", var4);

         try {
            var3.save(var2);
         } catch (IOException var6) {
            var6.printStackTrace();
         }

      }
   }

   @EventHandler
   public void onJoin(PlayerJoinEvent event) {
      if (!this.playerdata.containsKey(var1.getPlayer().getUniqueId())) {
         this.playerdata.put(var1.getPlayer().getUniqueId(), Sets.newHashSet());
      }

   }

   @EventHandler
   public void onQuit(PlayerQuitEvent event) {
      this.savePlayerFiles(var1.getPlayer().getUniqueId());
   }

   public void saveImportedData() {
      this.playerdata.keySet().forEach((var1) -> {
         this.savePlayerFiles(var1);
      });
   }

   public HashMap getPlayerdata() {
      return this.playerdata;
   }
}

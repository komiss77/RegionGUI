package net.crytec.RegionGUI.manager;

import com.comphenix.protocol.wrappers.EnumWrappers.WorldBorderAction;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.utils.packets.WrapperPlayServerWorldBorder;
import net.crytec.phoenix.api.utils.UtilLoc;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class BorderPacketManager {
   private final RegionGUI plugin;
   private final Location center;
   private final int size;
   private final WrapperPlayServerWorldBorder centerPacket;
   private final WrapperPlayServerWorldBorder sizePacket;
   private final WrapperPlayServerWorldBorder resetcenterPacket;
   private final WrapperPlayServerWorldBorder resetsizePacket;

   public BorderPacketManager(RegionGUI plugin, Location center, RegionClaim claim) {
      this.plugin = var1;
      this.center = UtilLoc.getCenter(var2).clone();
      this.size = var3.getSize() + 1;
      this.centerPacket = new WrapperPlayServerWorldBorder();
      this.sizePacket = new WrapperPlayServerWorldBorder();
      this.resetcenterPacket = new WrapperPlayServerWorldBorder();
      this.resetsizePacket = new WrapperPlayServerWorldBorder();
      this.buildPackets();
   }

   private void buildPackets() {
      World var1 = this.center.getWorld();
      this.resetsizePacket.setRadius(var1.getWorldBorder().getSize());
      this.resetsizePacket.setOldRadius(var1.getWorldBorder().getSize());
      this.resetsizePacket.setSpeed(0L);
      this.resetsizePacket.setAction(WorldBorderAction.LERP_SIZE);
      this.resetcenterPacket.setCenterX((double)var1.getWorldBorder().getCenter().getBlockX());
      this.resetcenterPacket.setCenterZ((double)var1.getWorldBorder().getCenter().getBlockZ());
      this.resetcenterPacket.setAction(WorldBorderAction.SET_CENTER);
      this.sizePacket.setRadius((double)this.size);
      this.sizePacket.setOldRadius((double)this.size);
      this.sizePacket.setSpeed(0L);
      this.sizePacket.setAction(WorldBorderAction.LERP_SIZE);
      this.centerPacket.setCenterX(this.center.getX());
      this.centerPacket.setCenterZ(this.center.getZ());
      this.centerPacket.setAction(WorldBorderAction.SET_CENTER);
   }

   public void sendReset(Player player) {
      this.resetcenterPacket.sendPacket(var1);
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         this.resetsizePacket.sendPacket(var1);
      }, 1L);
   }

   public void send(Player player) {
      this.centerPacket.sendPacket(var1);
      Bukkit.getScheduler().runTaskLater(this.plugin, () -> {
         this.sizePacket.sendPacket(var1);
      }, 1L);
   }
}

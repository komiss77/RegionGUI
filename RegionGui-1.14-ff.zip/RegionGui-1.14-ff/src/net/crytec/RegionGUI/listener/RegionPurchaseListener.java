package net.crytec.RegionGUI.listener;

import java.util.Iterator;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.events.RegionPurchasedEvent;
import net.crytec.shaded.org.apache.lang3.StringUtils;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;

public class RegionPurchaseListener implements Listener {
   @EventHandler
   public void onRegionPurchase(RegionPurchasedEvent event) {
      RegionClaim var2 = var1.getRegionClaim();
      Player var3 = var1.getPlayer();
      if (!var2.getRunCommands().isEmpty()) {
         Iterator var5 = var2.getRunCommands().iterator();

         while(var5.hasNext()) {
            String var4 = (String)var5.next();
            String var6 = var4.replace("%player%", var3.getName()).replace("%region%", var1.getProtectedRegion().getId()).replace("%world%", var3.getWorld().getName());
            if (var6.startsWith("<server>")) {
               var6 = var6.replace("<server>", "");
               var6 = StringUtils.trim(var6);
               RegionGUI.getInstance().getLogger().info("Performing Command:" + var6);
               Bukkit.getServer().dispatchCommand(Bukkit.getConsoleSender(), var6);
            } else {
               var3.performCommand(var6);
            }
         }

      }
   }
}

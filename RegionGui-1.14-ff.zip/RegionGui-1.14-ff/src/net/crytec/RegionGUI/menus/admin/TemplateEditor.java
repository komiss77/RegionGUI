package net.crytec.RegionGUI.menus.admin;

import com.google.common.collect.Lists;
import java.util.List;
import java.util.stream.Collectors;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.ConfirmationGUI;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.buttons.InputButton;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.utils.F;
import net.crytec.phoenix.api.utils.UtilMath;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemStack;

public class TemplateEditor implements InventoryProvider {
   private static final ItemStack filler;
   private final RegionClaim claim;

   static {
      filler = (new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE)).name(" ").build();
   }

   public TemplateEditor(RegionClaim claim) {
      this.claim = var1;
   }

   public void init(Player player, InventoryContents contents) {
      var2.fillRow(0, ClickableItem.empty(filler));
      var2.fillRow(4, ClickableItem.empty(filler));
      var2.set(SlotPos.of(0, 4), ClickableItem.of((new ItemBuilder(this.claim.getIcon())).name("§7Set list icon").lore("§7Click with an Item on your").lore("§7curser to set the list icon").build(), (var3) -> {
         if (var3.getClick() == ClickType.LEFT && var3.getCursor() != null && var3.getCursor().getType() != Material.AIR) {
            UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
            this.claim.setIcon(var3.getCursor().getType());
            var3.getView().getBottomInventory().addItem(new ItemStack[]{var3.getCursor()});
            var3.getView().setCursor(new ItemStack(Material.AIR));
            this.reOpen(var1, var2);
         }

      }));
      var2.set(SlotPos.of(1, 0), new InputButton((new ItemBuilder(Material.NAME_TAG)).name("§7Template").lore("§7Current name: §6" + this.claim.getDisplayname()).build(), "Name..", (var2x) -> {
         UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
         this.claim.setDisplayname(var2x);
         SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("§8Template Editor [" + var1.getWorld().getName() + "]").build().open(var1);
      }));
      var2.set(SlotPos.of(2, 0), ClickableItem.of((new ItemBuilder(Material.BOOK)).name("§7Description").lore("§7Current description:").lore((List)this.claim.getDescription().stream().map((var0) -> {
         return ChatColor.translateAlternateColorCodes('&', var0);
      }).collect(Collectors.toList())).lore("").lore("§aLeft click §7to add a new line").lore("§aRight click §7to delete the last line.").build(), (var3) -> {
         if (var3.getClick() == ClickType.RIGHT) {
            if (this.claim.getDescription().size() > 0) {
               List var4 = this.claim.getDescription();
               var4.remove(var4.size() - 1);
               this.claim.setDescription(var4);
               this.reOpen(var1, var2);
            }
         } else {
            var1.closeInventory();
            var1.sendMessage("§7Enter a new line. Type §eexit§7 to abort");
            PhoenixAPI.get().getPlayerChatInput(var1, (var3x) -> {
               if (var3x.equals("exit")) {
                  Bukkit.getScheduler().runTask(RegionGUI.getInstance(), () -> {
                     this.reOpen(var1, var2);
                  });
               } else {
                  Object var4 = this.claim.getDescription() == null ? Lists.newArrayList() : this.claim.getDescription();
                  ((List)var4).add(var3x);
                  this.claim.setDescription((List)var4);
                  Bukkit.getScheduler().runTask(RegionGUI.getInstance(), () -> {
                     this.reOpen(var1, var2);
                  });
               }
            });
         }
      }));
      var2.set(SlotPos.of(1, 1), new InputButton((new ItemBuilder(Material.BLAZE_POWDER)).name("§7Set Permission").lore("§7Current Permission: §6" + this.claim.getPermission()).build(), "permission..", (var3) -> {
         UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
         this.claim.setPermission(var3);
         this.reOpen(var1, var2);
      }));
      var2.set(SlotPos.of(2, 1), ClickableItem.of((new ItemBuilder(Material.REDSTONE_TORCH)).name("§7Set 'No Permission' description").lore("§eThis lines will be added below").lore("§ethe claim description in /land").lore("").lore("§7Current:").lore(this.claim.getNoPermDescription()).lore("§aLeft click §7to add a new line").lore("§aRight click §7to delete the last line.").build(), (var3) -> {
         if (var3.getClick() == ClickType.RIGHT) {
            if (this.claim.getDescription().size() > 0) {
               this.claim.getNoPermDescription().remove(this.claim.getNoPermDescription().size() - 1);
               this.reOpen(var1, var2);
            }
         } else {
            var1.closeInventory();
            var1.sendMessage("§7Enter a new line. Type §eexit§7 to abort");
            PhoenixAPI.get().getPlayerChatInput(var1, (var3x) -> {
               if (var3x.equals("exit")) {
                  Bukkit.getScheduler().runTask(RegionGUI.getInstance(), () -> {
                     this.reOpen(var1, var2);
                  });
               } else {
                  this.claim.getNoPermDescription().add(ChatColor.translateAlternateColorCodes('&', var3x));
                  Bukkit.getScheduler().runTask(RegionGUI.getInstance(), () -> {
                     this.reOpen(var1, var2);
                  });
               }
            });
         }
      }));
      var2.set(SlotPos.of(1, 2), new InputButton((new ItemBuilder(Material.GOLD_NUGGET)).name("§7Price").lore("§7Current Price: §6" + this.claim.getPrice()).build(), String.valueOf(this.claim.getPrice()), (var3) -> {
         if (!UtilMath.isInt(var3)) {
            var1.sendMessage("§cError: §7The given input is not a valid integer!");
            this.reOpen(var1, var2);
         } else {
            UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
            this.claim.setPrice(Integer.parseInt(var3));
            this.reOpen(var1, var2);
         }
      }));
      var2.set(SlotPos.of(2, 2), new InputButton((new ItemBuilder(Material.GOLD_NUGGET)).name("§7Refund").lore("§7This amount will be §aadded§7 to").lore("§7the players balance on deletion").lore("§7Current Refund: §6" + this.claim.getRefund()).build(), String.valueOf(this.claim.getRefund()), (var3) -> {
         if (!UtilMath.isInt(var3)) {
            var1.sendMessage("§cError: §7The given input is not a valid integer!");
            this.reOpen(var1, var2);
         } else {
            UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
            this.claim.setRefund(Integer.parseInt(var3));
            this.reOpen(var1, var2);
         }
      }));
      var2.set(SlotPos.of(1, 3), new InputButton((new ItemBuilder(Material.BEACON)).name("§7Set Size").lore("§7Current Size: §6" + this.claim.getSize()).lore("§7Increasing the size §c§lwill not§7 update").lore("§7already claimed/existing regions.").lore("§7This does only affect new regions").build(), String.valueOf(this.claim.getSize()), (var3) -> {
         if (!UtilMath.isInt(var3)) {
            var1.sendMessage("§cError: §7The given input is not a valid integer!");
            this.reOpen(var1, var2);
         } else {
            UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
            this.claim.setSize(Integer.parseInt(var3));
            this.reOpen(var1, var2);
         }
      }));
      var2.set(SlotPos.of(1, 5), new ClickableItem((new ItemBuilder(Material.COMMAND_BLOCK)).name("§7Commands").lore("§7This is a set of commands that will be").lore("§7executed by the §a§lplayer§7 after").lore("§7a successfull purchase.").lore("§7You may use this to set default flags or").lore("§7whatever you want.").lore("§7Valid placeholders:").lore("§e%player% §7- The players name").lore("§e%region% §7- The purchased region").lore("§e%world% §7- The worldname").lore("").lore("§7To run a command from the console,").lore("§7simply put §e<server>§7 in front").lore("").lore("§7Right click to §cdelete§7 the last command in the list.").lore("§7Current Commands:").lore(this.claim.getRunCommands()).build(), (var3) -> {
         UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
         if (var3.isRightClick()) {
            if (this.claim.getRunCommands().size() != 0) {
               this.claim.getRunCommands().remove(this.claim.getRunCommands().size() - 1);
               this.reOpen(var1, var2);
            }
         } else {
            var1.closeInventory();
            var1.sendMessage("§7Please enter the command you want to add (§cwithout§7 the first slash (/)): ");
            PhoenixAPI.get().getPlayerChatInput(var1, (var3x) -> {
               this.claim.getRunCommands().add(var3x);
               this.reOpen(var1, var2);
            });
         }
      }));
      var2.set(SlotPos.of(1, 4), ClickableItem.of((new ItemBuilder(Material.OAK_FENCE)).name("§7Enable Border").lore("§7Currently enabled: " + F.tf(this.claim.isGenerateBorder())).build(), (var3) -> {
         UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
         this.claim.setGenerateBorder(!this.claim.isGenerateBorder());
         this.reOpen(var1, var2);
      }));
      var2.set(SlotPos.of(2, 4), ClickableItem.of((new ItemBuilder(this.claim.getBorderMaterial())).name("§7Set Border Material").lore("§7Click with an Item on your").lore("§7curser to set the border material").build(), (var3) -> {
         if (var3.getClick() == ClickType.LEFT && var3.getCursor() != null && var3.getCursor().getType() != Material.AIR) {
            if (!var3.getCursor().getType().isBlock()) {
               var1.sendMessage("§cERROR: §7The given material is not a placeable block.");
               this.reOpen(var1, var2);
               return;
            }

            UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
            this.claim.setBorderMaterial(var3.getCursor().getType());
            var3.getView().getBottomInventory().addItem(new ItemStack[]{var3.getCursor()});
            var3.getView().setCursor(new ItemStack(Material.AIR));
            this.reOpen(var1, var2);
         }

      }));
      var2.set(SlotPos.of(4, 8), ClickableItem.of((new ItemBuilder(Material.TNT)).name("§4Delete template").lore("§7Deleting this template will remove it").lore("§7from all players that have already").lore("§7purchased it.").build(), (var3) -> {
         ConfirmationGUI.open(var1, "§4Confirm to delete template", (var3x) -> {
            if (var3x) {
               UtilPlayer.playSound(var1, Sound.ENTITY_GENERIC_EXPLODE, 0.5F, 1.15F);
               SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("§8Template Editor [" + var1.getWorld().getName() + "]").build().open(var1);
               RegionGUI.getInstance().getClaimManager().deleteTemplate(this.claim);
            } else {
               this.reOpen(var1, var2);
               UtilPlayer.playSound(var1, Sound.ENTITY_LEASH_KNOT_PLACE, 1.0F, 0.85F);
            }

         });
      }));
      var2.set(SlotPos.of(4, 4), ClickableItem.of((new ItemBuilder(Material.EMERALD)).name("§2Save template").build(), (var1x) -> {
         RegionGUI.getInstance().getClaimManager().save();
         SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("§8Template Editor [" + var1.getWorld().getName() + "]").build().open(var1);
      }));
   }
}

package net.crytec.RegionGUI.menus.admin;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.phoenix.api.implementation.AnvilGUI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;

public class AdminTemplateList implements InventoryProvider {
   private final ClaimManager claimManager = RegionGUI.getInstance().getClaimManager();

   public void init(Player player, InventoryContents contents) {
      World var3 = var1.getWorld();
      ArrayList var4 = new ArrayList(this.claimManager.getTemplates(var3));
      Collections.sort(var4);
      
      Iterator var6 = var4.iterator();
      while(var6.hasNext()) {
         RegionClaim var5 = (RegionClaim)var6.next();
         ItemBuilder var7 = new ItemBuilder(var5.getIcon() == null ? Material.BARRIER : var5.getIcon().getType());
         var7.name(ChatColor.translateAlternateColorCodes('&', var5.getDisplayname()));
         ArrayList var8 = new ArrayList(var5.getDescription());
         var8.replaceAll((var0) -> {
            return ChatColor.translateAlternateColorCodes('&', var0);
         });
         var7.lore(var8);
         var2.add(ClickableItem.of(var7.build(), (var2x) -> {
            UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
            SmartInventory.builder().provider(new TemplateEditor(var5)).size(5).title("Editing " + var5.getDisplayname()).build().open(var1);
         }));
      }

      var2.set(SlotPos.of(5, 4), new ClickableItem((new ItemBuilder(Material.EMERALD)).name("§2Create new template").build(), (var3x) -> {
         UtilPlayer.playSound(var1, Sound.UI_BUTTON_CLICK, 0.5F, 1.0F);
         new AnvilGUI(var1, "template", (var3, var4) -> {
            RegionClaim var5 = new RegionClaim(var3.getWorld());
            this.claimManager.registerTemplate(var5);
            this.claimManager.save();
            this.reOpen(var1, var2);
            return null;
         });
      }));
   }
}

package net.crytec.RegionGUI.menus;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator.Type;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class RegionSelectMenu implements InventoryProvider {
   private final Set claims;

   public RegionSelectMenu(Set claims) {
      this.claims = var1;
   }

   public void init(Player player, InventoryContents contents) {
      Pagination var3 = var2.pagination();
      ArrayList var4 = new ArrayList();
      Iterator var6 = this.claims.iterator();

      while(var6.hasNext()) {
         ClaimEntry var5 = (ClaimEntry)var6.next();
         String var7 = ChatColor.GREEN + var5.getRegionID();
         String var8 = Language.INTERFACE_SELECT_DESCRIPTION.toString().replace("%region%", var7);
         ItemStack var9 = (new ItemBuilder(Material.BOOK)).name(var7).lore(var8).build();
         var4.add(ClickableItem.of(var9, (var2x) -> {
            SmartInventory.builder().provider(new RegionManageInterface(var5)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(var1);
         }));
      }

      ClickableItem[] var10 = new ClickableItem[var4.size()];
      var10 = (ClickableItem[])var4.toArray(var10);
      var3.setItems(var10);
      var3.setItemsPerPage(18);
      var3.addToIterator(var2.newIterator(Type.HORIZONTAL, 1, 0));
   }
}

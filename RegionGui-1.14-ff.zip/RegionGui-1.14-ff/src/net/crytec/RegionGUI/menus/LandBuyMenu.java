package net.crytec.RegionGUI.menus;

import com.google.common.collect.Lists;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.data.RegionPreview;
import net.crytec.RegionGUI.events.RegionPrePurchaseEvent;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.RegionGUI.utils.PlotBuilder;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.utils.UtilMath;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.permissions.PermissionAttachmentInfo;

public class LandBuyMenu implements InventoryProvider {
   private final ClaimManager manager;
   private final RegionGUI plugin;

   public LandBuyMenu(RegionGUI plugin) {
      this.plugin = var1;
      this.manager = var1.getClaimManager();
   }

   public void init(Player player, InventoryContents content) {
      ArrayList var3 = Lists.newArrayList(this.manager.getTemplates(var1.getWorld()));
      if (var3 != null && !var3.isEmpty()) {
         Collections.sort(var3);
         if (var3.isEmpty()) {
            var1.closeInventory();
         } else {
            int var4 = 2;
            long var5 = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(var1.getUniqueId()).stream().filter((var1x) -> {
               return var1x.getTemplate().getWorld().isPresent() ? ((World)var1x.getTemplate().getWorld().get()).getName().equals(var1.getWorld().getName()) : false;
            }).count();
            Iterator var8 = var1.getEffectivePermissions().iterator();

            while(var8.hasNext()) {
               PermissionAttachmentInfo var7 = (PermissionAttachmentInfo)var8.next();
               if (var7.getPermission().startsWith("region.maxregions.")) {
                  if (UtilMath.isInt(var7.getPermission().split("region.maxregions.")[1])) {
                     var4 = Math.max(var4, Integer.valueOf(var7.getPermission().split("region.maxregions.")[1]));
                  } else {
                     var4 = 0;
                     RegionGUI.getInstance().log("§c[ERROR] Failed to parse permission node [§6" + var7.getPermission().split("region.maxregions.")[1] + "§c]", true);
                     RegionGUI.getInstance().log("§c[ERROR] Make sure the last entry is a valid number!", true);
                  }
               }

               if (var4 < 0) {
                  var4 = 0;
               }
            }

            if (var5 >= (long)var4) {
               var1.sendMessage(Language.ERROR_MAX_REGIONS.toString());
               var1.closeInventory();
            } else {
               int var13 = 0;

               for(Iterator var9 = var3.iterator(); var9.hasNext(); ++var13) {
                  RegionClaim var14 = (RegionClaim)var9.next();
                  ItemBuilder var10 = new ItemBuilder(var14.getIcon().clone());
                  var10.name(ChatColor.translateAlternateColorCodes('&', var14.getDisplayname()));
                  var10.setItemFlag(ItemFlag.HIDE_ATTRIBUTES);
                  ArrayList var12 = new ArrayList(var14.getDescription());
                  var12.replaceAll((var2x) -> {
                     return var2x.replaceAll("%current%", String.valueOf(var5));
                  });
                  var12.replaceAll((var1x) -> {
                     return var1x.replaceAll("%max_claims%", String.valueOf(var4));
                  });
                  var12.replaceAll((var1x) -> {
                     return var1x.replaceAll("%size%", String.valueOf(var14.getSize()));
                  });
                  var12.replaceAll((var1x) -> {
                     return var1x.replaceAll("%depth%", String.valueOf(var14.getDepth()));
                  });
                  var12.replaceAll((var1x) -> {
                     return var1x.replaceAll("%height%", String.valueOf(var14.getHeight()));
                  });
                  var12.replaceAll((var0) -> {
                     return ChatColor.translateAlternateColorCodes('&', var0);
                  });
                  var10.lore(var12);
                  if (!var14.getPermission().isEmpty() && !var1.hasPermission(var14.getPermission())) {
                     var10.lore("");
                     var10.lore(var14.getNoPermDescription());
                     var2.set(0, var13, ClickableItem.empty(var10.build()));
                  } else {
                     var2.add(ClickableItem.of(var10.build(), (var3x) -> {
                        if (var3x.getClick() == ClickType.LEFT) {
                           RegionPrePurchaseEvent var4 = new RegionPrePurchaseEvent(var1, var14.getPrice(), var14, var14.isGenerateBorder());
                           Bukkit.getPluginManager().callEvent(var4);
                           if (var4.isCancelled()) {
                              return;
                           }

                           var1.closeInventory();
                           var1.sendMessage(Language.CHAT_ENTER_REGIONNAME.toChatString());
                           PhoenixAPI.get().getPlayerChatInput(var1, (var3) -> {
                              if (!var3.matches("^[a-zA-Z0-9\\-\\_]*$")) {
                                 var1.sendMessage(Language.ERROR_INVALID_NAME.toChatString());
                              } else {
                                 String var4 = this.plugin.getConfig().getString("region-identifier").replace("%player%", var1.getName()).replace("%displayname%", var3);
                                 ProtectedRegion var5 = RegionUtils.getRegionManager(var1.getWorld()).getRegion(var4);
                                 if (var5 != null) {
                                    var1.sendMessage(Language.ERROR_REGIONNAME_ALREADY_EXISTS.toChatString());
                                 } else {
                                    PlotBuilder var6 = new PlotBuilder(var1, var3, var14);
                                    var6.build();
                                    var1.resetTitle();
                                 }
                              }
                           });
                        } else if (var3x.getClick() == ClickType.RIGHT) {
                           new RegionPreview(var1, var14.getSize() + 1);
                           var1.closeInventory();
                        }

                     }));
                  }
               }

            }
         }
      } else {
         var1.closeInventory();
      }
   }
}

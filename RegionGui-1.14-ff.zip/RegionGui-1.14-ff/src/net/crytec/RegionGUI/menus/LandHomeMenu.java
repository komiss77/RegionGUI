package net.crytec.RegionGUI.menus;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.util.Location;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import java.util.Iterator;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.inventory.content.SlotIterator.Type;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class LandHomeMenu implements InventoryProvider {
   private static final ItemStack fill;

   static {
      fill = (new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE)).name(" ").build();
   }

   public void init(Player player, InventoryContents contents) {
      var2.fillBorders(ClickableItem.empty(fill));
      Pagination var3 = var2.pagination();
      ArrayList var4 = new ArrayList();
      Iterator var6 = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(var1.getUniqueId()).iterator();

      while(var6.hasNext()) {
         ClaimEntry var5 = (ClaimEntry)var6.next();
         World var7 = (World)var5.getTemplate().getWorld().get();
         RegionManager var8 = RegionUtils.getRegionManager(var7);
         ProtectedRegion var9 = var8.getRegion(var5.getRegionID());
         if (var9 == null) {
            Bukkit.getLogger().severe("WorldGuard region is missing [" + var5.getRegionID() + "]. This region is still assigned to the player but missing in WorldGuard!");
            Bukkit.getLogger().severe("world: " + var7.getName() + " template id: " + var5.getTemplate());
         } else {
            ArrayList var10 = new ArrayList(Language.INTERFACE_HOME_ENTRYBUTTON_DESCRIPTION.getDescriptionArray());
            var10.replaceAll((var1x) -> {
               return var1x.replace("%world%", var7.getName());
            });
            
            
            var4.add(ClickableItem.of((new ItemBuilder(Material.GRAY_BED)).name(var5.getRegionID()).lore(var10).build(), (var2x) -> {
               if (var9.getFlag(Flags.TELE_LOC) != null) {
                  Location var3 = (Location)var9.getFlag(Flags.TELE_LOC);
                  org.bukkit.Location var4 = BukkitAdapter.adapt(var3);
                  var1.teleport(var4);
               } else {
                  var1.sendMessage(Language.ERROR_NO_HOME_SET.toChatString());
               }

            }));
            
            
         }
      }

      ClickableItem[] var11 = new ClickableItem[var4.size()];
      var11 = (ClickableItem[])var4.toArray(var11);
      var3.setItems(var11);
      var3.setItemsPerPage(27);
      if (!var3.isLast()) {
         var2.set(4, 6, ClickableItem.of((new ItemBuilder(Material.MAP)).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), (var3x) -> {
            var2.inventory().open(var1, var3.next().getPage());
         }));
      }

      if (!var3.isFirst()) {
         var2.set(4, 2, ClickableItem.of((new ItemBuilder(Material.MAP)).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), (var3x) -> {
            var2.inventory().open(var1, var3.previous().getPage());
         }));
      }

      SlotIterator var12 = var2.newIterator(Type.HORIZONTAL, 1, 1);
      var12 = var12.allowOverride(false);
      var3.addToIterator(var12);
   }
}

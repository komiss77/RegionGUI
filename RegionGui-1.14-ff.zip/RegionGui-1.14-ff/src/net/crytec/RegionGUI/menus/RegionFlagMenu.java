package net.crytec.RegionGUI.menus;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.LinkedList;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.utils.flags.FlagManager;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.inventory.content.SlotIterator.Type;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public class RegionFlagMenu implements InventoryProvider {
   private static final ItemStack fill;
   private final FlagManager flagManager;
   private final ClaimEntry claim;

   static {
      fill = (new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE)).name(" ").build();
   }

   public RegionFlagMenu(ClaimEntry claim) {
      this.claim = var1;
      this.flagManager = RegionGUI.getInstance().getFlagManager();
   }

   public void init(Player player, InventoryContents contents) {
      var2.fillRow(0, ClickableItem.empty(fill));
      var2.fillRow(4, ClickableItem.empty(fill));
      ProtectedRegion var3 = (ProtectedRegion)this.claim.getProtectedRegion().get();
      Pagination var4 = var2.pagination();
      LinkedList var5 = new LinkedList();
      this.flagManager.getFlagMap().forEach((var4x) -> {
         if (var1.hasPermission(var4x.getPermission()) || var1.hasPermission("region.flagmenu.all")) {
            var5.add(var4x.getButton(var1, var3, var2));
         }

      });
      ClickableItem[] var6 = new ClickableItem[var5.size()];
      var6 = (ClickableItem[])var5.toArray(var6);
      SlotIterator var7 = var2.newIterator(Type.HORIZONTAL, 1, 0);
      var7 = var7.allowOverride(false);
      var4.setItems(var6);
      var4.setItemsPerPage(27);
      var4.addToIterator(var7);
      var2.set(4, 4, ClickableItem.of((new ItemBuilder(Material.RED_WOOL)).name(Language.INTERFACE_BACK.toString()).build(), (var2x) -> {
         SmartInventory.builder().provider(new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(var1);
      }));
      if (!var4.isLast()) {
         var2.set(4, 6, ClickableItem.of((new ItemBuilder(Material.MAP)).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), (var4x) -> {
            var2.inventory().open(var1, var4.next().getPage(), new String[]{"region"}, new Object[]{var3});
         }));
      }

      if (!var4.isFirst()) {
         var2.set(4, 2, ClickableItem.of((new ItemBuilder(Material.MAP)).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), (var4x) -> {
            var2.inventory().open(var1, var4.previous().getPage(), new String[]{"region"}, new Object[]{var3});
         }));
      }

      var4.addToIterator(var2.newIterator(Type.HORIZONTAL, 1, 0));
   }

   public void update(Player player, InventoryContents contents) {
   }
}

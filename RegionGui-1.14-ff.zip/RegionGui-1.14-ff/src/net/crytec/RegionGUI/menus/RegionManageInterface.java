package net.crytec.RegionGUI.menus;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.BorderDisplay;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;

public class RegionManageInterface implements InventoryProvider {
   private static final ItemStack fill;
   private final ClaimEntry claim;

   static {
      fill = (new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE)).name(" ").build();
   }

   public RegionManageInterface(ClaimEntry claim) {
      this.claim = var1;
   }

   public void init(Player player, InventoryContents contents) {
      var2.fillBorders(ClickableItem.empty(fill));
      if (!this.claim.getProtectedRegion().isPresent()) {
         RegionGUI.getInstance().getLogger().severe("Failed to open /land interface - WorldGuard Region does no longer exist.");
         var1.closeInventory();
      } else {
         ProtectedRegion var3 = (ProtectedRegion)this.claim.getProtectedRegion().get();
         Iterator var4 = var3.getMembers().getUniqueIds().iterator();
         ArrayList var5 = new ArrayList();
         var5.add(Language.INTERFACE_MANAGE_MEMBERS.toString());

         while(var4.hasNext()) {
            OfflinePlayer var6 = Bukkit.getOfflinePlayer((UUID)var4.next());
            if (var6.hasPlayedBefore()) {
               var5.add(ChatColor.GOLD + var6.getName());
            }
         }

         if (var1.hasPermission("region.manage.members")) {
            var2.set(1, 1, ClickableItem.of((new ItemBuilder(Material.PLAYER_HEAD)).name(Language.INTERFACE_MANAGE_BUTTON_MANAGE_MEMBERS.toString()).build(), (var2x) -> {
               SmartInventory.builder().id("regiongui.deletemember").provider(new RegionManageMember(this.claim)).size(5).title(Language.INTERFACE_REMOVE_TITLE.toString()).build().open(var1);
            }));
         }

         var2.set(1, 3, ClickableItem.of((new ItemBuilder(Material.ENDER_PEARL)).name(Language.INTERFACE_HOME_BUTTON.toString()).lore(Language.INTERFACE_HOME_BUTTON_DESC.getDescriptionArray()).build(), (var2x) -> {
            var3.setFlag(Flags.TELE_LOC, BukkitAdapter.adapt(var1.getLocation()));
            var3.setDirty(true);
            var1.sendMessage(Language.INTERFACE_HOME_BUTTON_SUCCESS.toChatString());
         }));
         var2.set(0, 4, ClickableItem.empty((new ItemBuilder(Material.BOOK)).name(Language.INTERFACE_MANAGE_BUTTON_INFO.toString()).lore(Language.INTERFACE_MANAGE_BUTTON_INFO_DESCRIPTION.getDescriptionArray()).enchantment(Enchantment.ARROW_INFINITE).setItemFlag(ItemFlag.HIDE_ENCHANTS).build()));
         if (var1.hasPermission("region.manage.delregion")) {
            var2.set(0, 8, ClickableItem.of((new ItemBuilder(Material.TNT)).name(Language.INTERFACE_MANAGE_BUTTON_DELETEREGION.toString()).lore(Language.INTERFACE_MANAGE_BUTTON_DELETEREGION_DESCRIPTION.getDescriptionArray()).build(), (var2x) -> {
               SmartInventory.builder().provider(new RegionDeleteConfirm(this.claim)).title(Language.INTERFACE_DELETE_TITLE.toString()).size(1).build().open(var1);
            }));
         }

         if (var1.hasPermission("region.manage.flagmenu")) {
            var2.set(1, 5, ClickableItem.of((new ItemBuilder(Material.COMMAND_BLOCK)).name(Language.INTERFACE_MANAGE_BUTTON_FLAG.toString()).build(), (var2x) -> {
               SmartInventory.builder().id("regiongui.flagMenu").provider(new RegionFlagMenu(this.claim)).size(5, 9).title(Language.FLAG_TITLE.toString()).build().open(var1);
            }));
         }

         var2.set(1, 7, ClickableItem.of((new ItemBuilder(Material.EXPERIENCE_BOTTLE)).name(Language.INTERFACE_MANAGE_BUTTON_SHOWBORDER.toString()).lore(Language.INTERFACE_MANAGE_BUTTON_SHOWBORDER_DESCRIPTION.getDescriptionArray()).build(), (var2x) -> {
            new BorderDisplay(var1, this.claim);
         }));
      }
   }
}

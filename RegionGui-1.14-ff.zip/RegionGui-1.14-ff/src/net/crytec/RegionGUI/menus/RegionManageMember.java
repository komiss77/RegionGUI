package net.crytec.RegionGUI.menus;

import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.domains.DefaultDomain;
import com.sk89q.worldguard.domains.PlayerDomain;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.util.profile.Profile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.UUID;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.events.RegionAddMemberEvent;
import net.crytec.RegionGUI.events.RegionRemoveMemberEvent;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.inventory.content.SlotIterator.Type;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class RegionManageMember implements InventoryProvider {
   private static final ItemStack fill;
   private final ClaimEntry claim;

   static {
      fill = (new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE)).name(" ").build();
   }

   public RegionManageMember(ClaimEntry claim) {
      this.claim = var1;
   }

   public void init(Player player, InventoryContents contents) {
      var2.fillBorders(ClickableItem.empty(fill));
      ProtectedRegion var3 = (ProtectedRegion)this.claim.getProtectedRegion().get();
      Pagination var4 = var2.pagination();
      ArrayList var5 = new ArrayList();

      UUID var6;
      String var9;
      ItemStack var10;
      for(Iterator var7 = var3.getMembers().getUniqueIds().iterator(); var7.hasNext(); var5.add(ClickableItem.of(var10, (var7x) -> {
         RegionRemoveMemberEvent var8 = new RegionRemoveMemberEvent(var1, this.claim.getTemplate(), var6);
         Bukkit.getPluginManager().callEvent(var8);
         if (var8.isCancelled()) {
            var2.inventory().open(var1, new String[]{"region"}, new Object[]{var3});
         } else {
            var3.getMembers().removePlayer(var6);
            var2.inventory().open(var1, var4.getPage(), new String[]{"region"}, new Object[]{var3});
            UtilPlayer.playSound(var1, Sound.BLOCK_LEVER_CLICK);
            var1.sendMessage(Language.INTERFACE_REMOVE_SUCESSFULL.toChatString().replaceAll("%name%", var9));
         }
      }))) {
         var6 = (UUID)var7.next();
         OfflinePlayer var8 = Bukkit.getOfflinePlayer(var6);
         var9 = var8.hasPlayedBefore() ? var8.getName() : "Unknown Name";
         var10 = (new ItemBuilder(Material.PLAYER_HEAD)).name("§f" + var9).lore(Language.INTERFACE_REMOVE_DESC.toString().replaceAll("%name%", var9)).build();
         if (var8.hasPlayedBefore()) {
            SkullMeta var12 = (SkullMeta)var10.getItemMeta();
            var12.hasOwner();
            var12.setOwningPlayer(var8);
            var10.setItemMeta(var12);
         }
      }

      ClickableItem[] var13 = new ClickableItem[var5.size()];
      var13 = (ClickableItem[])var5.toArray(var13);
      var4.setItems(var13);
      var4.setItemsPerPage(18);
      var2.set(SlotPos.of(0, 4), ClickableItem.of((new ItemBuilder(Material.WRITABLE_BOOK)).name(Language.INTERFACE_MANAGE_BUTTON_ADDMEMBER.toString()).build(), (var4x) -> {
         var1.closeInventory();
         var1.sendMessage(Language.REGION_MESSAGE_CHATADDMEMBER.toChatString());
         PhoenixAPI.get().getPlayerChatInput(var1, (var4) -> {
            OfflinePlayer var5 = Bukkit.getOfflinePlayer(var4);
            if (!var5.hasPlayedBefore()) {
               var1.sendMessage(Language.ERROR_INVALID_OFFLINEPLAYER.toChatString());
            } else {
               RegionAddMemberEvent var6 = new RegionAddMemberEvent(var1, this.claim.getTemplate(), var5.getUniqueId());
               Bukkit.getPluginManager().callEvent(var6);
               if (var6.isCancelled()) {
                  this.reOpen(var1, var2);
               } else {
                  DefaultDomain var7 = var3.getMembers();
                  PlayerDomain var8 = var7.getPlayerDomain();
                  var8.addPlayer(var5.getUniqueId());
                  var7.setPlayerDomain(var8);
                  var3.setMembers(var7);
                  var3.setDirty(true);
                  Profile var9 = new Profile(var5.getUniqueId(), var5.getName());
                  WorldGuard.getInstance().getProfileCache().put(var9);
                  var7.toUserFriendlyComponent(WorldGuard.getInstance().getProfileCache());
                  this.reOpen(var1, var2);
               }
            }
         });
      }));
      var2.set(4, 4, ClickableItem.of((new ItemBuilder(Material.RED_WOOL)).name(Language.INTERFACE_BACK.toString()).build(), (var2x) -> {
         SmartInventory.builder().provider(new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(var1);
      }));
      var2.set(4, 6, ClickableItem.of((new ItemBuilder(Material.MAP)).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), (var4x) -> {
         var2.inventory().open(var1, var4.next().getPage(), new String[]{"region"}, new Object[]{var3});
      }));
      var2.set(4, 2, ClickableItem.of((new ItemBuilder(Material.MAP)).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), (var4x) -> {
         var2.inventory().open(var1, var4.previous().getPage(), new String[]{"region"}, new Object[]{var3});
      }));
      SlotIterator var14 = var2.newIterator(Type.HORIZONTAL, 1, 1);
      var14 = var14.allowOverride(false);
      var4.addToIterator(var14);
   }
}

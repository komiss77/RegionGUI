package net.crytec.RegionGUI.commands;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldguard.protection.ApplicableRegionSet;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Iterator;
import java.util.Set;
import java.util.stream.Collectors;
import net.crytec.RegionGUI.Language;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.menus.LandBuyMenu;
import net.crytec.RegionGUI.menus.LandHomeMenu;
import net.crytec.RegionGUI.menus.RegionManageInterface;
import net.crytec.RegionGUI.menus.RegionSelectMenu;
import net.crytec.acf.BaseCommand;
import net.crytec.acf.CommandHelp;
import net.crytec.acf.CommandIssuer;
import net.crytec.acf.annotation.CommandAlias;
import net.crytec.acf.annotation.CommandPermission;
import net.crytec.acf.annotation.Default;
import net.crytec.acf.annotation.Optional;
import net.crytec.acf.annotation.Subcommand;
import net.crytec.acf.bukkit.contexts.OnlinePlayer;
import net.crytec.phoenix.api.inventory.SmartInventory;
import org.bukkit.entity.Player;

@CommandAlias("land")
public class LandCommand extends BaseCommand {
   private final PlayerManager manager;
   private final RegionGUI plugin;

   public LandCommand(RegionGUI plugin, PlayerManager manager) {
      this.plugin = var1;
      this.manager = var2;
   }

   @Default
   public void openLandInterface(Player issuer) {
      if (!this.plugin.getConfig().getStringList("enabled_worlds").contains(var1.getWorld().getName())) {
         var1.sendMessage(Language.ERROR_WORLD_DISABLED.toChatString());
      } else {
         this.checkForRegions(var1);
      }
   }

   @Subcommand("help")
   public void sendCommandHelp(CommandIssuer issuer, CommandHelp help) {
      var2.showHelp(var1);
   }

   @Subcommand("home")
   public void openHomeGUI(Player issuer) {
      SmartInventory.builder().id("home-" + var1.getName()).provider(new LandHomeMenu()).size(5, 9).title(Language.INTERFACE_HOME_TITLE.toString()).build().open(var1);
   }

   @Subcommand("list")
   @CommandPermission("region.list")
   public void displayLandList(Player issuer, @Optional OnlinePlayer op) {
      Set var3;
      ClaimEntry var4;
      Iterator var5;
      String var6;
      String var7;
      if (var2 == null) {
         var3 = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(var1.getUniqueId());
         var5 = var3.iterator();

         while(var5.hasNext()) {
            var4 = (ClaimEntry)var5.next();
            var6 = var4.getTemplate().getDisplayname();
            var7 = var4.getRegionID();
            var1.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", var7).replace("%template%", var6));
         }

      } else {
         var3 = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(var1.getUniqueId());
         var5 = var3.iterator();

         while(var5.hasNext()) {
            var4 = (ClaimEntry)var5.next();
            var6 = var4.getTemplate().getDisplayname();
            var7 = var4.getRegionID();
            var1.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", var7).replace("%template%", var6));
         }

      }
   }

   private void checkForRegions(Player p) {
      RegionManager var2 = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(var1.getWorld()));
      ApplicableRegionSet var3 = var2.getApplicableRegions(BukkitAdapter.asBlockVector(var1.getLocation()));
      LocalPlayer var4 = WorldGuardPlugin.inst().wrapPlayer(var1);
      Iterator var5 = var3.iterator();
      if (var3.size() == 0) {
         if (!var1.hasPermission("region.claim")) {
            var1.sendMessage(Language.ERROR_NO_PERMISSION.toChatString());
         } else {
            SmartInventory.builder().id("regiongui.claim").provider(new LandBuyMenu(this.plugin)).size(3, 9).title(Language.INTERFACE_BUY_TITLE.toString()).build().open(var1);
         }
      } else {
         Set var7;
         if (var3.size() == 1) {
            ProtectedRegion var10 = (ProtectedRegion)var5.next();
            var7 = this.manager.getPlayerClaims(var1.getUniqueId());
            if (var7 == null) {
               var1.sendMessage("§cYou don't own any claims in this world.");
            } else {
               Set var8 = (Set)var7.stream().map((var0) -> {
                  return var0.getRegionID();
               }).collect(Collectors.toSet());
               if ((!var10.isOwner(var4) || !var8.contains(var10.getId())) && !var1.hasPermission("region.mod")) {
                  var1.sendMessage(Language.ERROR_NOT_OWNER.toChatString());
               } else {
                  java.util.Optional var9 = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(var1.getUniqueId()).stream().filter((var1x) -> {
                     return var1x.getRegionID().equals(var10.getId());
                  }).findFirst();
                  if (!var9.isPresent()) {
                     var1.sendMessage(Language.ERROR_NO_REGION_FOUND.toChatString());
                     return;
                  }

                  SmartInventory.builder().provider(new RegionManageInterface((ClaimEntry)var9.get())).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(var1);
               }

            }
         } else if (var3.size() > 1) {
            Set var6 = (Set)this.manager.getPlayerClaims(var1.getUniqueId()).stream().map((var0) -> {
               return var0.getRegionID();
            }).collect(Collectors.toSet());
            var7 = (Set)RegionGUI.getInstance().getPlayerManager().getPlayerClaims(var1.getUniqueId()).stream().filter((var1x) -> {
               return var6.contains(var1x.getRegionID());
            }).collect(Collectors.toSet());
            SmartInventory.builder().id("regiongui.regionselect").provider(new RegionSelectMenu(var7)).size(3).title(Language.INTERFACE_SELECT_TITLE.toString()).build().open(var1);
         }
      }
   }
}

package net.crytec.RegionGUI.commands;

import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.menus.admin.AdminTemplateList;
import net.crytec.acf.BaseCommand;
import net.crytec.acf.CommandHelp;
import net.crytec.acf.CommandIssuer;
import net.crytec.acf.annotation.CommandAlias;
import net.crytec.acf.annotation.CommandPermission;
import net.crytec.acf.annotation.Default;
import net.crytec.acf.annotation.Description;
import net.crytec.acf.annotation.Subcommand;
import net.crytec.phoenix.api.inventory.SmartInventory;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

@CommandAlias("landadmin")
@CommandPermission("region.admin")
public class LandAdmin extends BaseCommand {
   private final RegionGUI plugin;

   public LandAdmin(RegionGUI plugin) {
      this.plugin = var1;
   }

   @Default
   public void openEditor(Player player) {
      SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("§8Template Editor [" + var1.getWorld().getName() + "]").build().open(var1);
   }

   @Subcommand("editor")
   @Description("Opens the land template editor")
   public void landAdminCommand(Player player) {
      SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("§8Template Editor [" + var1.getWorld().getName() + "]").build().open(var1);
   }

   @Subcommand("addregion")
   @Description("Adds a defined worldguard region to a player with a given template, regardless of size or checks. This is a forced action.")
   public void forceAdd(Player player, OfflinePlayer owner, ProtectedRegion region, RegionClaim claim) {
      this.plugin.getPlayerManager().addClaimToPlayer(var2.getUniqueId(), var3, var4);
      var1.sendMessage("§7Assigned region to player. Please note this is a forced action and no size/permission check apply.");
   }

   @Subcommand("help")
   public void sendCommandHelp(CommandIssuer issuer, CommandHelp help) {
      var2.showHelp(var1);
   }
}

package net.crytec.RegionGUI.chateditor;

import java.util.List;
import java.util.function.Consumer;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.menus.admin.TemplateEditor;
import net.crytec.phoenix.api.PhoenixAPI;
import net.crytec.phoenix.api.chat.program.ChatProgramm;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class ListEditor extends ChatProgramm {
   private static final int linesPerPage = 6;
   private final Consumer result;
   private final RegionClaim claim;
   private int pages;
   private final List description;

   public ListEditor(Player player, List current, RegionClaim claim, Consumer result) {
      super(var1);
      this.result = var4;
      this.claim = var3;
      this.description = var2;
      this.init(0);
   }

   public void init(int sendIndex) {
      this.pages = this.description.size() / 6;
      if (this.description.size() % 6 >= 0) {
         ++this.pages;
      }

      super.getCanvasList().clear();
      super.registerChatCanvas(new ListCanvas(0, this.description, this));

      for(int var2 = 1; var2 < this.pages; ++var2) {
         super.registerChatCanvas(new ListCanvas(var2, this.description, this));
      }

      if (var1 >= this.pages && var1 != 0) {
         var1 = this.pages - 1;
      } else if (var1 <= 0) {
         var1 = 0;
      }

      super.changeView(var1);
   }

   public void onClose() {
      PhoenixAPI.get().getChatQueue().unregisterPlayer(super.getPlayer());
      this.result.accept(this.description);
      this.claim.setDescription(this.description);
      SmartInventory.builder().provider(new TemplateEditor(this.claim)).size(5).title("Editing " + this.claim.getDisplayname()).build().open(this.getPlayer());
      UtilPlayer.playSound(super.getPlayer(), Sound.ENTITY_ITEM_PICKUP);
   }

   public void onOpen() {
      PhoenixAPI.get().getChatQueue().registerPlayer(super.getPlayer());
   }

   public static int getLinesPerPage() {
      return 6;
   }

   public int getPages() {
      return this.pages;
   }

   public List getDescription() {
      return this.description;
   }
}

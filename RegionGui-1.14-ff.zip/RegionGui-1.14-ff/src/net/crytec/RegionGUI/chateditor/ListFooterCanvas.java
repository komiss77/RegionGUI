package net.crytec.RegionGUI.chateditor;

import java.util.function.Supplier;
import net.crytec.phoenix.api.chat.program.CanvasLineComponent;
import net.crytec.phoenix.api.chat.program.ChatCanvas.CanvasFooter;
import net.crytec.phoenix.api.utils.UtilPlayer;
import net.crytec.shaded.org.apache.lang3.StringUtils;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

public class ListFooterCanvas extends CanvasFooter {
   private final int siteIndex;
   private final Supplier maxIndex;
   private final ListEditor root;

   public ListFooterCanvas(int index, Supplier maxIndex, ListEditor root) {
      this.siteIndex = var1;
      this.maxIndex = var2;
      this.root = var3;
   }

   public void sendTo(Player player) {
      super.getLine().clear();
      if (this.siteIndex == 0) {
         boolean var2 = (Integer)this.maxIndex.get() == 0;
         super.getLine().add(new CanvasLineComponent(StringUtils.center(" §6" + this.siteIndex + " §f/ §6" + this.maxIndex.get() + "§f ", var2 ? 50 : 48, "-")));
         if (!var2) {
            super.getLine().add(this.getRightArrow());
         }
      } else if (this.siteIndex == (Integer)this.maxIndex.get()) {
         super.getLine().add(this.getLeftArrow());
         super.getLine().add(new CanvasLineComponent(StringUtils.center(" §6" + this.siteIndex + " §f/ §6" + this.maxIndex.get() + "§f ", 48, "-")));
      } else {
         super.getLine().add(this.getLeftArrow());
         super.getLine().add(new CanvasLineComponent(StringUtils.center(" §6" + this.siteIndex + " §f/ §6" + this.maxIndex.get() + "§f ", 46, "-")));
         super.getLine().add(this.getRightArrow());
      }

      super.sendTo(var1);
   }

   private CanvasLineComponent getLeftArrow() {
      CanvasLineComponent var1 = new CanvasLineComponent("§6◀◀◀§f", (var1x) -> {
         this.root.changeView(this.siteIndex - 1);
         UtilPlayer.playSound(var1x, Sound.UI_BUTTON_CLICK, 0.6F, 1.2F);
      });
      var1.getDescriptionLines().add("Page " + (this.siteIndex - 1));
      return var1;
   }

   private CanvasLineComponent getRightArrow() {
      CanvasLineComponent var1 = new CanvasLineComponent("§6▶▶▶", (var1x) -> {
         this.root.changeView(this.siteIndex + 1);
         UtilPlayer.playSound(var1x, Sound.UI_BUTTON_CLICK, 0.6F, 1.2F);
      });
      var1.getDescriptionLines().add("Page " + (this.siteIndex + 1));
      return var1;
   }
}

package net.crytec.RegionGUI.chateditor;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import net.crytec.phoenix.api.chat.program.CanvasLine;
import net.crytec.phoenix.api.chat.program.CanvasLineComponent;
import net.crytec.phoenix.api.chat.program.ChatCanvas;
import net.crytec.phoenix.api.chat.program.ChatCanvas.CanvasHeader;
import net.crytec.phoenix.api.implementation.AnvilGUI;
import net.crytec.phoenix.api.utils.UtilPlayer;
import net.crytec.shaded.org.apache.lang3.StringUtils;
import net.md_5.bungee.api.ChatColor;
import org.bukkit.Sound;

public class ListCanvas extends ChatCanvas {
   private int index;
   private Supplier maxIndex;
   private final ListEditor parent;

   public ListCanvas(int index, List description, ListEditor parent) {
      super((CanvasHeader)(new CanvasHeader(new CanvasLineComponent("▣" + StringUtils.center("§6Editor§f", 48, "-") + "▣"))).addComponent((new CanvasLineComponent("§a [✔]", (var1x) -> {
         var3.close();
      })).setHover("§2Save changes")), new ListFooterCanvas(var1, () -> {
         return var3.getPages() - 1;
      }, var3));
      this.parent = var3;
      this.index = var1;
      this.maxIndex = () -> {
         return this.parent.getPages() - 1;
      };
      this.init();
   }

   public void init() {
      int var1 = 2;

      for(int var2 = 1; var2 < 6; ++var2) {
         super.setLine(var2, new CanvasLine(var2));
      }

      if (!this.parent.getDescription().isEmpty()) {
         for(Iterator var3 = this.getPageItems().iterator(); var3.hasNext(); ++var1) {
            String var6 = (String)var3.next();
            CanvasLine var4 = new CanvasLine(var1);
            int var5 = var1 - 3;
            var4.getLine().add((new CanvasLineComponent("§2[+]§r", (var2x) -> {
               UtilPlayer.playSound(var2x, Sound.UI_BUTTON_CLICK, 0.6F, 1.35F);
               new AnvilGUI(var2x, "Enter a new line", (var3, var4) -> {
                  String var5x = ChatColor.translateAlternateColorCodes('&', var4);
                  this.parent.getDescription().add(this.index * ListEditor.getLinesPerPage() + var5, var5x);
                  this.parent.init(this.index);
                  UtilPlayer.playSound(var2x, Sound.BLOCK_NOTE_BLOCK_BELL, 0.6F, 1.15F);
                  return null;
               });
            })).setHover("Insert line here"));
            var4.getLine().add((new CanvasLineComponent("§c[-]§r", (var2x) -> {
               UtilPlayer.playSound(var2x, Sound.ENTITY_ARMOR_STAND_BREAK, 0.5F, 1.35F);
               int var3 = this.index * ListEditor.getLinesPerPage() + var5;
               this.parent.getDescription().remove(var3);
               this.parent.init(this.index);
            })).setHover("Remove line"));
            var4.getLine().add((new CanvasLineComponent("§e[✐]", (var3x) -> {
               UtilPlayer.playSound(var3x, Sound.UI_BUTTON_CLICK, 0.6F, 1.35F);
               new AnvilGUI(var3x, var6, (var3, var4) -> {
                  String var5x = ChatColor.translateAlternateColorCodes('&', var4);
                  this.parent.getDescription().set(this.index * ListEditor.getLinesPerPage() + var5, var5x);
                  this.parent.init(this.index);
                  UtilPlayer.playSound(var3x, Sound.BLOCK_NOTE_BLOCK_BELL, 0.6F, 1.15F);
                  return null;
               });
            })).setHover("Edit this line"));
            var4.getLine().add(new CanvasLineComponent("  §r"));
            var4.getLine().add(new CanvasLineComponent(var6));
            super.setLine(var1, var4);
         }
      }

      if (this.index == (Integer)this.maxIndex.get()) {
         CanvasLine var7 = new CanvasLine(8);
         var7.getLine().add((new CanvasLineComponent(StringUtils.center("[Append]", 66, " "), (var1x) -> {
            UtilPlayer.playSound(this.parent.getPlayer(), Sound.UI_BUTTON_CLICK, 0.6F, 1.35F);
            this.parent.getDescription().add(this.parent.getDescription().size(), "");
            this.parent.init(this.index);
         })).setHover("Adds empty line"));
         super.setLine(9, var7);
      }

   }

   private ArrayList getPageItems() {
      return (ArrayList)this.parent.getDescription().stream().skip((long)(this.index * ListEditor.getLinesPerPage())).limit((long)ListEditor.getLinesPerPage()).collect(Collectors.toCollection(ArrayList::new));
   }
}

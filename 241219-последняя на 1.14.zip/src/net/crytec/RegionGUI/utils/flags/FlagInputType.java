package net.crytec.RegionGUI.utils.flags;

public enum FlagInputType
{
    BOOLEAN, 
    STATE, 
    INTEGER,
    DOUBLE, 
    STRING, 
    SET, 
    OTHER;
}

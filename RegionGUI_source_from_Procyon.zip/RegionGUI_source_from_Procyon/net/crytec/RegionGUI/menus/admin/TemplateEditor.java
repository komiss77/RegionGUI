// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.menus.admin;

import org.bukkit.event.inventory.InventoryClickEvent;
import net.crytec.phoenix.api.inventory.ConfirmationGUI;
import net.crytec.phoenix.api.utils.F;
import net.crytec.phoenix.api.utils.UtilMath;
import com.google.common.collect.Lists;
import org.bukkit.plugin.Plugin;
import net.crytec.RegionGUI.RegionGUI;
import org.bukkit.Bukkit;
import net.crytec.phoenix.api.PhoenixAPI;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import org.bukkit.ChatColor;
import java.util.List;
import net.crytec.phoenix.api.inventory.buttons.InputButton;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.phoenix.api.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.event.inventory.ClickType;
import net.crytec.phoenix.api.inventory.content.SlotPos;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.RegionGUI.data.RegionClaim;
import org.bukkit.inventory.ItemStack;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;

public class TemplateEditor implements InventoryProvider
{
    private static final ItemStack filler;
    private final RegionClaim claim;
    
    static {
        filler = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
    
    public TemplateEditor(final RegionClaim claim) {
        this.claim = claim;
    }
    
    public void init(final Player player, final InventoryContents contents) {
        contents.fillRow(0, ClickableItem.empty(TemplateEditor.filler));
        contents.fillRow(4, ClickableItem.empty(TemplateEditor.filler));
        contents.set(SlotPos.of(0, 4), ClickableItem.of(new ItemBuilder(this.claim.getIcon()).name("§7Set list icon").lore("§7Click with an Item on your").lore("§7curser to set the list icon").build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.LEFT && inventoryClickEvent.getCursor() != null && inventoryClickEvent.getCursor().getType() != Material.AIR) {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setIcon(inventoryClickEvent.getCursor().getType());
                inventoryClickEvent.getView().getBottomInventory().addItem(new ItemStack[] { inventoryClickEvent.getCursor() });
                inventoryClickEvent.getView().setCursor(new ItemStack(Material.AIR));
                this.reOpen(player, contents);
            }
            return;
        }));
        contents.set(SlotPos.of(1, 0), (ClickableItem)new InputButton(new ItemBuilder(Material.NAME_TAG).name("§7Template").lore("§7Current name: §6" + this.claim.getDisplayname()).build(), "Name..", displayname -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            this.claim.setDisplayname(displayname);
            SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("§8Template Editor [" + player.getWorld().getName() + "]").build().open(player);
            return;
        }));
        final List<String> description;
        List<String> description2;
        contents.set(SlotPos.of(2, 0), ClickableItem.of(new ItemBuilder(Material.BOOK).name("§7Description").lore("§7Current description:").lore((List)this.claim.getDescription().stream().map(s -> ChatColor.translateAlternateColorCodes('&', s)).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())).lore("").lore("§aLeft click §7to add a new line").lore("§aRight click §7to delete the last line.").build(), inventoryClickEvent2 -> {
            if (inventoryClickEvent2.getClick() == ClickType.RIGHT) {
                if (this.claim.getDescription().size() <= 0) {
                    return;
                }
                else {
                    this.claim.getDescription();
                    description.remove(description.size() - 1);
                    this.claim.setDescription(description);
                    this.reOpen(player, contents);
                    return;
                }
            }
            else {
                player.closeInventory();
                player.sendMessage("§7Enter a new line. Type §eexit§7 to abort");
                PhoenixAPI.get().getPlayerChatInput(player, s2 -> {
                    if (s2.equals("exit")) {
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, contents));
                    }
                    else {
                        description2 = ((this.claim.getDescription() == null) ? Lists.newArrayList() : this.claim.getDescription());
                        description2.add(s2);
                        this.claim.setDescription(description2);
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, contents));
                    }
                });
                return;
            }
        }));
        contents.set(SlotPos.of(1, 1), (ClickableItem)new InputButton(new ItemBuilder(Material.BLAZE_POWDER).name("§7Set Permission").lore("§7Current Permission: §6" + this.claim.getPermission()).build(), "permission..", permission -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            this.claim.setPermission(permission);
            this.reOpen(player, contents);
            return;
        }));
        contents.set(SlotPos.of(2, 1), ClickableItem.of(new ItemBuilder(Material.REDSTONE_TORCH).name("§7Set 'No Permission' description").lore("§eThis lines will be added below").lore("§ethe claim description in /land").lore("").lore("§7Current:").lore((List)this.claim.getNoPermDescription()).lore("§aLeft click §7to add a new line").lore("§aRight click §7to delete the last line.").build(), inventoryClickEvent3 -> {
            if (inventoryClickEvent3.getClick() == ClickType.RIGHT) {
                if (this.claim.getDescription().size() <= 0) {
                    return;
                }
                else {
                    this.claim.getNoPermDescription().remove(this.claim.getNoPermDescription().size() - 1);
                    this.reOpen(player, contents);
                    return;
                }
            }
            else {
                player.closeInventory();
                player.sendMessage("§7Enter a new line. Type §eexit§7 to abort");
                PhoenixAPI.get().getPlayerChatInput(player, s3 -> {
                    if (s3.equals("exit")) {
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, contents));
                    }
                    else {
                        this.claim.getNoPermDescription().add(ChatColor.translateAlternateColorCodes('&', s3));
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reOpen(player, contents));
                    }
                });
                return;
            }
        }));
        contents.set(SlotPos.of(1, 2), (ClickableItem)new InputButton(new ItemBuilder(Material.GOLD_NUGGET).name("§7Price").lore("§7Current Price: §6" + this.claim.getPrice()).build(), String.valueOf(this.claim.getPrice()), s4 -> {
            if (!UtilMath.isInt(s4)) {
                player.sendMessage("§cError: §7The given input is not a valid integer!");
                this.reOpen(player, contents);
                return;
            }
            else {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setPrice(Integer.parseInt(s4));
                this.reOpen(player, contents);
                return;
            }
        }));
        contents.set(SlotPos.of(2, 2), (ClickableItem)new InputButton(new ItemBuilder(Material.GOLD_NUGGET).name("§7Refund").lore("§7This amount will be §aadded§7 to").lore("§7the players balance on deletion").lore("§7Current Refund: §6" + this.claim.getRefund()).build(), String.valueOf(this.claim.getRefund()), s5 -> {
            if (!UtilMath.isInt(s5)) {
                player.sendMessage("§cError: §7The given input is not a valid integer!");
                this.reOpen(player, contents);
                return;
            }
            else {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setRefund(Integer.parseInt(s5));
                this.reOpen(player, contents);
                return;
            }
        }));
        contents.set(SlotPos.of(1, 3), (ClickableItem)new InputButton(new ItemBuilder(Material.BEACON).name("§7Set Size").lore("§7Current Size: §6" + this.claim.getSize()).lore("§7Increasing the size §c§lwill not§7 update").lore("§7already claimed/existing regions.").lore("§7This does only affect new regions").build(), String.valueOf(this.claim.getSize()), s6 -> {
            if (!UtilMath.isInt(s6)) {
                player.sendMessage("§cError: §7The given input is not a valid integer!");
                this.reOpen(player, contents);
                return;
            }
            else {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setSize(Integer.parseInt(s6));
                this.reOpen(player, contents);
                return;
            }
        }));
        contents.set(SlotPos.of(1, 5), new ClickableItem(new ItemBuilder(Material.COMMAND_BLOCK).name("§7Commands").lore("§7This is a set of commands that will be").lore("§7executed by the §a§lplayer§7 after").lore("§7a successfull purchase.").lore("§7You may use this to set default flags or").lore("§7whatever you want.").lore("§7Valid placeholders:").lore("§e%player% §7- The players name").lore("§e%region% §7- The purchased region").lore("§e%world% §7- The worldname").lore("").lore("§7To run a command from the console,").lore("§7simply put §e<server>§7 in front").lore("").lore("§7Right click to §cdelete§7 the last command in the list.").lore("§7Current Commands:").lore((List)this.claim.getRunCommands()).build(), inventoryClickEvent4 -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            if (inventoryClickEvent4.isRightClick()) {
                if (this.claim.getRunCommands().size() == 0) {
                    return;
                }
                else {
                    this.claim.getRunCommands().remove(this.claim.getRunCommands().size() - 1);
                    this.reOpen(player, contents);
                    return;
                }
            }
            else {
                player.closeInventory();
                player.sendMessage("§7Please enter the command you want to add (§cwithout§7 the first slash (/)): ");
                PhoenixAPI.get().getPlayerChatInput(player, s7 -> {
                    this.claim.getRunCommands().add(s7);
                    this.reOpen(player, contents);
                });
                return;
            }
        }));
        contents.set(SlotPos.of(1, 4), ClickableItem.of(new ItemBuilder(Material.OAK_FENCE).name("§7Enable Border").lore("§7Currently enabled: " + F.tf(this.claim.isGenerateBorder())).build(), p2 -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            this.claim.setGenerateBorder(!this.claim.isGenerateBorder());
            this.reOpen(player, contents);
            return;
        }));
        contents.set(SlotPos.of(2, 4), ClickableItem.of(new ItemBuilder(this.claim.getBorderMaterial()).name("§7Set Border Material").lore("§7Click with an Item on your").lore("§7curser to set the border material").build(), inventoryClickEvent5 -> {
            if (inventoryClickEvent5.getClick() == ClickType.LEFT && inventoryClickEvent5.getCursor() != null && inventoryClickEvent5.getCursor().getType() != Material.AIR) {
                if (!inventoryClickEvent5.getCursor().getType().isBlock()) {
                    player.sendMessage("§cERROR: §7The given material is not a placeable block.");
                    this.reOpen(player, contents);
                }
                else {
                    UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                    this.claim.setBorderMaterial(inventoryClickEvent5.getCursor().getType());
                    inventoryClickEvent5.getView().getBottomInventory().addItem(new ItemStack[] { inventoryClickEvent5.getCursor() });
                    inventoryClickEvent5.getView().setCursor(new ItemStack(Material.AIR));
                    this.reOpen(player, contents);
                }
            }
            return;
        }));
        contents.set(SlotPos.of(4, 8), ClickableItem.of(new ItemBuilder(Material.TNT).name("§4Delete template").lore("§7Deleting this template will remove it").lore("§7from all players that have already").lore("§7purchased it.").build(), p2 -> ConfirmationGUI.open(player, "§4Confirm to delete template", b -> {
            if (b) {
                UtilPlayer.playSound(player, Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 1.15f);
                SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("§8Template Editor [" + player.getWorld().getName() + "]").build().open(player);
                RegionGUI.getInstance().getClaimManager().deleteTemplate(this.claim);
            }
            else {
                this.reOpen(player, contents);
                UtilPlayer.playSound(player, Sound.ENTITY_LEASH_KNOT_PLACE, 1.0f, 0.85f);
            }
        })));
        contents.set(SlotPos.of(4, 4), ClickableItem.of(new ItemBuilder(Material.EMERALD).name("§2Save template").build(), p1 -> {
            RegionGUI.getInstance().getClaimManager().save();
            SmartInventory.builder().provider((InventoryProvider)new AdminTemplateList()).size(6).title("§8Template Editor [" + player.getWorld().getName() + "]").build().open(player);
        }));
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import net.crytec.RegionGUI.data.ClaimEntry;
import java.util.Iterator;
import net.crytec.RegionGUI.data.RegionPreview;
import net.crytec.RegionGUI.utils.PlotBuilder;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.phoenix.api.PhoenixAPI;
import org.bukkit.event.Event;
import org.bukkit.Bukkit;
import net.crytec.RegionGUI.events.RegionPrePurchaseEvent;
import org.bukkit.event.inventory.ClickType;
import net.crytec.phoenix.api.inventory.ClickableItem;
import java.util.Collection;
import java.util.ArrayList;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.ChatColor;
import net.crytec.phoenix.api.item.ItemBuilder;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.Language;
import net.crytec.phoenix.api.utils.UtilMath;
import org.bukkit.permissions.PermissionAttachmentInfo;
import org.bukkit.World;
import java.util.List;
import java.util.Collections;
import com.google.common.collect.Lists;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;

public class LandBuyMenu implements InventoryProvider
{
    private final ClaimManager manager;
    private final RegionGUI plugin;
    
    public LandBuyMenu(final RegionGUI plugin) {
        this.plugin = plugin;
        this.manager = plugin.getClaimManager();
    }
    
    public void init(final Player player, final InventoryContents content) {
        final ArrayList arrayList = Lists.newArrayList((Iterable)this.manager.getTemplates(player.getWorld()));
        if (arrayList == null || arrayList.isEmpty()) {
            player.closeInventory();
            return;
        }
        Collections.sort((List<Comparable>)arrayList);
        if (arrayList.isEmpty()) {
            player.closeInventory();
            return;
        }
        int max = 2;
        final long count = RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId()).stream().filter(claimEntry -> claimEntry.getTemplate().getWorld().isPresent() && claimEntry.getTemplate().getWorld().get().getName().equals(player.getWorld().getName())).count();
        for (final PermissionAttachmentInfo permissionAttachmentInfo : player.getEffectivePermissions()) {
            if (permissionAttachmentInfo.getPermission().startsWith("region.maxregions.")) {
                if (UtilMath.isInt(permissionAttachmentInfo.getPermission().split("region.maxregions.")[1])) {
                    max = Math.max(max, Integer.valueOf(permissionAttachmentInfo.getPermission().split("region.maxregions.")[1]));
                }
                else {
                    max = 0;
                    RegionGUI.getInstance().log("§c[ERROR] Failed to parse permission node [§6" + permissionAttachmentInfo.getPermission().split("region.maxregions.")[1] + "§c]", true);
                    RegionGUI.getInstance().log("§c[ERROR] Make sure the last entry is a valid number!", true);
                }
            }
            if (max < 0) {
                max = 0;
            }
        }
        if (count >= max) {
            player.sendMessage(Language.ERROR_MAX_REGIONS.toString());
            player.closeInventory();
            return;
        }
        int n = 0;
        for (final RegionClaim regionClaim : arrayList) {
            final ItemBuilder itemBuilder = new ItemBuilder(regionClaim.getIcon().clone());
            itemBuilder.name(ChatColor.translateAlternateColorCodes('&', regionClaim.getDisplayname()));
            itemBuilder.setItemFlag(ItemFlag.HIDE_ATTRIBUTES);
            final ArrayList list = new ArrayList(regionClaim.getDescription());
            list.replaceAll(s6 -> s6.replaceAll("%current%", String.valueOf(count)));
            final int i;
            list.replaceAll(s2 -> s2.replaceAll("%max_claims%", String.valueOf(i)));
            list.replaceAll(s3 -> s3.replaceAll("%size%", String.valueOf(regionClaim.getSize())));
            list.replaceAll(s4 -> s4.replaceAll("%depth%", String.valueOf(regionClaim.getDepth())));
            list.replaceAll(s5 -> s5.replaceAll("%height%", String.valueOf(regionClaim.getHeight())));
            list.replaceAll(s -> ChatColor.translateAlternateColorCodes('&', s));
            itemBuilder.lore((List)list);
            if (!regionClaim.getPermission().isEmpty() && !player.hasPermission(regionClaim.getPermission())) {
                itemBuilder.lore("");
                itemBuilder.lore((List)regionClaim.getNoPermDescription());
                content.set(0, n, ClickableItem.empty(itemBuilder.build()));
            }
            else {
                final RegionClaim claim;
                RegionPrePurchaseEvent regionPrePurchaseEvent;
                final RegionClaim claim2;
                content.add(ClickableItem.of(itemBuilder.build(), inventoryClickEvent -> {
                    if (inventoryClickEvent.getClick() == ClickType.LEFT) {
                        regionPrePurchaseEvent = new RegionPrePurchaseEvent(player, claim.getPrice(), claim, claim.isGenerateBorder());
                        Bukkit.getPluginManager().callEvent((Event)regionPrePurchaseEvent);
                        if (!regionPrePurchaseEvent.isCancelled()) {
                            player.closeInventory();
                            player.sendMessage(Language.CHAT_ENTER_REGIONNAME.toChatString());
                            PhoenixAPI.get().getPlayerChatInput(player, s7 -> {
                                if (!s7.matches("^[a-zA-Z0-9\\-\\_]*$")) {
                                    player.sendMessage(Language.ERROR_INVALID_NAME.toChatString());
                                }
                                else if (RegionUtils.getRegionManager(player.getWorld()).getRegion(this.plugin.getConfig().getString("region-identifier").replace("%player%", player.getName()).replace("%displayname%", s7)) != null) {
                                    player.sendMessage(Language.ERROR_REGIONNAME_ALREADY_EXISTS.toChatString());
                                }
                                else {
                                    new PlotBuilder(player, s7, claim2).build();
                                    player.resetTitle();
                                }
                            });
                        }
                    }
                    else if (inventoryClickEvent.getClick() == ClickType.RIGHT) {
                        new RegionPreview(player, claim.getSize() + 1);
                        player.closeInventory();
                    }
                    return;
                }));
            }
            ++n;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.OfflinePlayer;
import net.crytec.RegionGUI.utils.RegionUtils;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.RegionGUI.Language;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.RegionGUI.data.ClaimEntry;
import org.bukkit.inventory.ItemStack;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;

public class RegionDeleteConfirm implements InventoryProvider
{
    private static final ItemStack fill;
    private final ClaimEntry claim;
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
    
    public RegionDeleteConfirm(final ClaimEntry claim) {
        this.claim = claim;
    }
    
    public void init(final Player player, final InventoryContents contents) {
        contents.fill(ClickableItem.empty(RegionDeleteConfirm.fill));
        if (!this.claim.getProtectedRegion().isPresent()) {
            System.out.println("Claim not present");
            player.closeInventory();
            return;
        }
        final ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        contents.set(0, 2, ClickableItem.of(new ItemBuilder(Material.REDSTONE).name(Language.INTERFACE_DELETE_ABORT_BUTTON.toString()).build(), p1 -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        final ProtectedRegion region;
        contents.set(0, 6, ClickableItem.of(new ItemBuilder(Material.EMERALD).name(Language.INTERFACE_DELETE_CONFIRM_BUTTON.toString()).build(), p2 -> {
            player.closeInventory();
            RegionGUI.getInstance().getPlayerManager().deleteClaim(player.getUniqueId(), region);
            RegionUtils.getRegionManager(player.getWorld()).removeRegion(region.getId());
            RegionUtils.saveRegions(player.getWorld());
            if (this.claim.getTemplate().hasRefund()) {
                RegionGUI.econ.depositPlayer((OfflinePlayer)player, (double)this.claim.getTemplate().getRefund());
                player.sendMessage(Language.REGION_REMOVED_REFUNDED.toString().replaceAll("%refund%", String.valueOf(this.claim.getTemplate().getRefund())));
            }
            player.sendMessage(Language.REGION_REMOVED.toChatString());
        }));
    }
}

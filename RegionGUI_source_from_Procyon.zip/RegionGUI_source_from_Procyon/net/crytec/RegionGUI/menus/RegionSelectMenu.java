// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import java.util.Iterator;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.RegionGUI.Language;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.ChatColor;
import net.crytec.phoenix.api.inventory.ClickableItem;
import java.util.ArrayList;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.RegionGUI.data.ClaimEntry;
import java.util.Set;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;

public class RegionSelectMenu implements InventoryProvider
{
    private final Set<ClaimEntry> claims;
    
    public RegionSelectMenu(final Set<ClaimEntry> claims) {
        this.claims = claims;
    }
    
    public void init(final Player player, final InventoryContents contents) {
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> list = new ArrayList<ClickableItem>();
        final Iterator<ClaimEntry> iterator = this.claims.iterator();
        while (iterator.hasNext()) {
            final String string = ChatColor.GREEN + iterator.next().getRegionID();
            final ClaimEntry claim;
            list.add(ClickableItem.of(new ItemBuilder(Material.BOOK).name(string).lore(Language.INTERFACE_SELECT_DESCRIPTION.toString().replace("%region%", string)).build(), p2 -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        }
        pagination.setItems((ClickableItem[])list.toArray(new ClickableItem[list.size()]));
        pagination.setItemsPerPage(18);
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0));
    }
}

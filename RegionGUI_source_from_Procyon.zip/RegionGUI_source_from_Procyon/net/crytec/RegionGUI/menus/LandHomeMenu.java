// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Iterator;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.util.Location;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.Flags;
import java.util.List;
import java.util.Collection;
import net.crytec.RegionGUI.Language;
import org.bukkit.Bukkit;
import net.crytec.RegionGUI.utils.RegionUtils;
import org.bukkit.World;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.RegionGUI;
import java.util.ArrayList;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;

public class LandHomeMenu implements InventoryProvider
{
    private static final ItemStack fill;
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
    
    public void init(final Player player, final InventoryContents contents) {
        contents.fillBorders(ClickableItem.empty(LandHomeMenu.fill));
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> list = new ArrayList<ClickableItem>();
        for (final ClaimEntry claimEntry : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(player.getUniqueId())) {
            final World world = claimEntry.getTemplate().getWorld().get();
            if (RegionUtils.getRegionManager(world).getRegion(claimEntry.getRegionID()) == null) {
                Bukkit.getLogger().severe("WorldGuard region is missing [" + claimEntry.getRegionID() + "]. This region is still assigned to the player but missing in WorldGuard!");
                Bukkit.getLogger().severe("world: " + world.getName() + " template id: " + claimEntry.getTemplate());
            }
            else {
                final ArrayList list2 = new ArrayList(Language.INTERFACE_HOME_ENTRYBUTTON_DESCRIPTION.getDescriptionArray());
                list2.replaceAll(s -> s.replace("%world%", world.getName()));
                final ProtectedRegion protectedRegion;
                list.add(ClickableItem.of(new ItemBuilder(Material.GRAY_BED).name(claimEntry.getRegionID()).lore((List)list2).build(), p2 -> {
                    if (protectedRegion.getFlag((Flag)Flags.TELE_LOC) != null) {
                        player.teleport(BukkitAdapter.adapt((Location)protectedRegion.getFlag((Flag)Flags.TELE_LOC)));
                    }
                    else {
                        player.sendMessage(Language.ERROR_NO_HOME_SET.toChatString());
                    }
                    return;
                }));
            }
        }
        pagination.setItems((ClickableItem[])list.toArray(new ClickableItem[list.size()]));
        pagination.setItemsPerPage(27);
        if (!pagination.isLast()) {
            contents.set(4, 6, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), p3 -> contents.inventory().open(player, pagination.next().getPage())));
        }
        if (!pagination.isFirst()) {
            contents.set(4, 2, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), p3 -> contents.inventory().open(player, pagination.previous().getPage())));
        }
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 1).allowOverride(false));
    }
}

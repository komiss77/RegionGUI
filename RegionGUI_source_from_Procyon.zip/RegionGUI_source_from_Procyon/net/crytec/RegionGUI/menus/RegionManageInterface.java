// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.OfflinePlayer;
import java.util.Iterator;
import net.crytec.RegionGUI.data.BorderDisplay;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.enchantments.Enchantment;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.protection.flags.Flags;
import java.util.List;
import net.crytec.phoenix.api.inventory.SmartInventory;
import org.bukkit.ChatColor;
import org.bukkit.Bukkit;
import java.util.UUID;
import net.crytec.RegionGUI.Language;
import java.util.ArrayList;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.RegionGUI.data.ClaimEntry;
import org.bukkit.inventory.ItemStack;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;

public class RegionManageInterface implements InventoryProvider
{
    private static final ItemStack fill;
    private final ClaimEntry claim;
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
    
    public RegionManageInterface(final ClaimEntry claim) {
        this.claim = claim;
    }
    
    public void init(final Player player, final InventoryContents contents) {
        contents.fillBorders(ClickableItem.empty(RegionManageInterface.fill));
        if (!this.claim.getProtectedRegion().isPresent()) {
            RegionGUI.getInstance().getLogger().severe("Failed to open /land interface - WorldGuard Region does no longer exist.");
            player.closeInventory();
            return;
        }
        final Iterator<UUID> iterator = (Iterator<UUID>)this.claim.getProtectedRegion().get().getMembers().getUniqueIds().iterator();
        final ArrayList<String> list = new ArrayList<String>();
        list.add(Language.INTERFACE_MANAGE_MEMBERS.toString());
        while (iterator.hasNext()) {
            final OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)iterator.next());
            if (offlinePlayer.hasPlayedBefore()) {
                list.add(ChatColor.GOLD + offlinePlayer.getName());
            }
        }
        if (player.hasPermission("region.manage.members")) {
            contents.set(1, 1, ClickableItem.of(new ItemBuilder(Material.PLAYER_HEAD).name(Language.INTERFACE_MANAGE_BUTTON_MANAGE_MEMBERS.toString()).build(), p1 -> SmartInventory.builder().id("regiongui.deletemember").provider((InventoryProvider)new RegionManageMember(this.claim)).size(5).title(Language.INTERFACE_REMOVE_TITLE.toString()).build().open(player)));
        }
        final ProtectedRegion protectedRegion;
        contents.set(1, 3, ClickableItem.of(new ItemBuilder(Material.ENDER_PEARL).name(Language.INTERFACE_HOME_BUTTON.toString()).lore((List)Language.INTERFACE_HOME_BUTTON_DESC.getDescriptionArray()).build(), p2 -> {
            protectedRegion.setFlag((Flag)Flags.TELE_LOC, (Object)BukkitAdapter.adapt(player.getLocation()));
            protectedRegion.setDirty(true);
            player.sendMessage(Language.INTERFACE_HOME_BUTTON_SUCCESS.toChatString());
            return;
        }));
        contents.set(0, 4, ClickableItem.empty(new ItemBuilder(Material.BOOK).name(Language.INTERFACE_MANAGE_BUTTON_INFO.toString()).lore((List)Language.INTERFACE_MANAGE_BUTTON_INFO_DESCRIPTION.getDescriptionArray()).enchantment(Enchantment.ARROW_INFINITE).setItemFlag(ItemFlag.HIDE_ENCHANTS).build()));
        if (player.hasPermission("region.manage.delregion")) {
            contents.set(0, 8, ClickableItem.of(new ItemBuilder(Material.TNT).name(Language.INTERFACE_MANAGE_BUTTON_DELETEREGION.toString()).lore((List)Language.INTERFACE_MANAGE_BUTTON_DELETEREGION_DESCRIPTION.getDescriptionArray()).build(), p1 -> SmartInventory.builder().provider((InventoryProvider)new RegionDeleteConfirm(this.claim)).title(Language.INTERFACE_DELETE_TITLE.toString()).size(1).build().open(player)));
        }
        if (player.hasPermission("region.manage.flagmenu")) {
            contents.set(1, 5, ClickableItem.of(new ItemBuilder(Material.COMMAND_BLOCK).name(Language.INTERFACE_MANAGE_BUTTON_FLAG.toString()).build(), p1 -> SmartInventory.builder().id("regiongui.flagMenu").provider((InventoryProvider)new RegionFlagMenu(this.claim)).size(5, 9).title(Language.FLAG_TITLE.toString()).build().open(player)));
        }
        contents.set(1, 7, ClickableItem.of(new ItemBuilder(Material.EXPERIENCE_BOTTLE).name(Language.INTERFACE_MANAGE_BUTTON_SHOWBORDER.toString()).lore((List)Language.INTERFACE_MANAGE_BUTTON_SHOWBORDER_DESCRIPTION.getDescriptionArray()).build(), p1 -> new BorderDisplay(player, this.claim)));
    }
}

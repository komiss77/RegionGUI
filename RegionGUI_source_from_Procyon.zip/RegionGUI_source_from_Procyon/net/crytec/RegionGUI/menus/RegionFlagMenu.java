// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import net.crytec.RegionGUI.utils.flags.FlagSetting;
import net.crytec.phoenix.api.inventory.content.Pagination;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.RegionGUI.Language;
import net.crytec.phoenix.api.inventory.content.SlotIterator;
import java.util.LinkedList;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.phoenix.api.inventory.ClickableItem;
import net.crytec.phoenix.api.inventory.content.InventoryContents;
import org.bukkit.entity.Player;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.RegionGUI.utils.flags.FlagManager;
import org.bukkit.inventory.ItemStack;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;

public class RegionFlagMenu implements InventoryProvider
{
    private static final ItemStack fill;
    private final FlagManager flagManager;
    private final ClaimEntry claim;
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
    
    public RegionFlagMenu(final ClaimEntry claim) {
        this.claim = claim;
        this.flagManager = RegionGUI.getInstance().getFlagManager();
    }
    
    public void init(final Player player, final InventoryContents contents) {
        contents.fillRow(0, ClickableItem.empty(RegionFlagMenu.fill));
        contents.fillRow(4, ClickableItem.empty(RegionFlagMenu.fill));
        final ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        final Pagination pagination = contents.pagination();
        final LinkedList list = new LinkedList();
        final LinkedList<ClickableItem> list2;
        final ProtectedRegion region;
        this.flagManager.getFlagMap().forEach(flagSetting -> {
            if (player.hasPermission(flagSetting.getPermission()) || player.hasPermission("region.flagmenu.all")) {
                list2.add(flagSetting.getButton(player, region, contents));
            }
            return;
        });
        final ClickableItem[] items = list.toArray(new ClickableItem[list.size()]);
        final SlotIterator allowOverride = contents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0).allowOverride(false);
        pagination.setItems(items);
        pagination.setItemsPerPage(27);
        pagination.addToIterator(allowOverride);
        contents.set(4, 4, ClickableItem.of(new ItemBuilder(Material.RED_WOOL).name(Language.INTERFACE_BACK.toString()).build(), p1 -> SmartInventory.builder().provider((InventoryProvider)new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        if (!pagination.isLast()) {
            contents.set(4, 6, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), p4 -> contents.inventory().open(player, pagination.next().getPage(), new String[] { "region" }, new Object[] { protectedRegion })));
        }
        if (!pagination.isFirst()) {
            contents.set(4, 2, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), p4 -> contents.inventory().open(player, pagination.previous().getPage(), new String[] { "region" }, new Object[] { protectedRegion })));
        }
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, 1, 0));
    }
    
    public void update(final Player player, final InventoryContents contents) {
    }
}

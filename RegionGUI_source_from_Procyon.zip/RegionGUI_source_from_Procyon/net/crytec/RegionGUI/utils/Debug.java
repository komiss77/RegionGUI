// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.utils;

import java.io.PrintWriter;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Iterator;
import org.bukkit.plugin.Plugin;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import org.bukkit.World;
import java.io.IOException;
import org.bukkit.Bukkit;
import net.crytec.RegionGUI.RegionGUI;
import java.io.File;

public class Debug
{
    private File _logfile;
    public static String PLUGINS;
    
    static {
        Debug.PLUGINS = "38105";
    }
    
    public Debug() {
        this.start();
    }
    
    private void start() {
        final File logfile = new File(RegionGUI.getInstance().getDataFolder(), "debug.txt");
        try {
            if (logfile.exists()) {
                logfile.delete();
                logfile.createNewFile();
            }
            else {
                logfile.createNewFile();
            }
        }
        catch (IOException ex) {
            Bukkit.getLogger().severe("Unable to create debug.txt - " + ex.getMessage());
        }
        this._logfile = logfile;
        this.log("Installed Plugins (" + Bukkit.getPluginManager().getPlugins().length + " " + Debug.PLUGINS + "):");
        final StringBuilder sb = new StringBuilder();
        Plugin[] plugins;
        for (int length = (plugins = Bukkit.getPluginManager().getPlugins()).length, i = 0; i < length; ++i) {
            sb.append(String.valueOf(plugins[i].getName()) + ", ");
        }
        this.log(sb.toString());
        this.writeConfigToLog("REGION GUI CONFIGURATION", new File(RegionGUI.getInstance().getDataFolder(), "config.yml"));
        this.writeConfigToLog("LANGUAGE FILE", new File(RegionGUI.getInstance().getDataFolder(), "lang.yml"));
        for (final World world : Bukkit.getWorlds()) {
            this.writeConfigToLog("=== REGION.YML (" + world.getName() + ") ===", new File(WorldGuardPlugin.inst().getDataFolder() + File.separator + "worlds" + File.separator + world.getName(), "regions.yml"));
        }
        this.writeConfigToLog("=== WORLDGUARD CONFIGURATION ===", new File(WorldGuardPlugin.inst().getDataFolder(), "config.yml"));
        Bukkit.getLogger().info("=============================================================================");
        Bukkit.getLogger().info("A new debug file has been saved to the RegionGUI plugin folder (debug.txt)");
        Bukkit.getLogger().info("Please upload the debug file (pastebin.com) and contact the plugin author");
        Bukkit.getLogger().info("=============================================================================");
    }
    
    private boolean writeConfigToLog(final String title, final File file) {
        this.log(" ");
        this.log(" ");
        this.log(" ");
        this.log("=== " + title + " ===");
        try {
            Throwable t = null;
            try {
                final BufferedReader bufferedReader = new BufferedReader(new FileReader(file));
                try {
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        this.log(line);
                    }
                    bufferedReader.close();
                    return true;
                }
                finally {
                    if (bufferedReader != null) {
                        bufferedReader.close();
                    }
                }
            }
            finally {
                if (t == null) {
                    final Throwable exception;
                    t = exception;
                }
                else {
                    final Throwable exception;
                    if (t != exception) {
                        t.addSuppressed(exception);
                    }
                }
            }
        }
        catch (IOException ex) {
            return false;
        }
    }
    
    private void log(final String message) {
        try {
            Throwable t = null;
            try {
                final PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter(this._logfile, true)));
                try {
                    printWriter.println(message);
                    printWriter.flush();
                    printWriter.close();
                }
                finally {
                    if (printWriter != null) {
                        printWriter.close();
                    }
                }
            }
            finally {
                if (t == null) {
                    final Throwable exception;
                    t = exception;
                }
                else {
                    final Throwable exception;
                    if (t != exception) {
                        t.addSuppressed(exception);
                    }
                }
            }
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}

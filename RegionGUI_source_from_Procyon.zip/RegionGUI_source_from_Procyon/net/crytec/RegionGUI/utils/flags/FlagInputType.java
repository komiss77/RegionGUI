// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.utils.flags;

public enum FlagInputType
{
    SET, 
    STATE, 
    DOUBLE, 
    INTEGER, 
    BOOLEAN, 
    STRING, 
    UNKNOWN;
}

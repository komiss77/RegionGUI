// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.data;

import java.util.HashMap;
import com.google.common.collect.Maps;
import java.util.Map;
import java.util.Objects;
import org.bukkit.Bukkit;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import org.bukkit.ChatColor;
import net.crytec.phoenix.api.item.ItemBuilder;
import org.bukkit.inventory.ItemStack;
import java.util.ArrayList;
import java.util.Arrays;
import org.bukkit.World;
import java.util.List;
import org.bukkit.Material;
import java.util.UUID;
import org.bukkit.configuration.serialization.SerializableAs;
import org.bukkit.configuration.serialization.ConfigurationSerializable;

@SerializableAs("Template")
public class RegionClaim implements ConfigurationSerializable, Comparable<RegionClaim>
{
    private final UUID id;
    private String displayname;
    private Material icon;
    private List<String> description;
    private int size;
    private String world;
    private int height;
    private int depth;
    private int price;
    private int refund;
    private Material borderMaterial;
    private boolean generateBorder;
    private List<String> runCommands;
    private String permission;
    private List<String> noPermDescription;
    
    public RegionClaim(final World world) {
        this.displayname = "Default displayname";
        this.icon = Material.BARRIER;
        this.description = Arrays.asList("§7Default description");
        this.size = 10;
        this.height = 256;
        this.depth = 256;
        this.price = -1;
        this.refund = 0;
        this.borderMaterial = Material.OAK_FENCE;
        this.generateBorder = true;
        this.runCommands = new ArrayList<String>();
        this.permission = "";
        this.noPermDescription = Arrays.asList("Upgrade your rank to purchase this template.");
        this.id = UUID.randomUUID();
        this.size = 10;
        this.world = world.getName();
    }
    
    private RegionClaim(final UUID id) {
        this.displayname = "Default displayname";
        this.icon = Material.BARRIER;
        this.description = Arrays.asList("§7Default description");
        this.size = 10;
        this.height = 256;
        this.depth = 256;
        this.price = -1;
        this.refund = 0;
        this.borderMaterial = Material.OAK_FENCE;
        this.generateBorder = true;
        this.runCommands = new ArrayList<String>();
        this.permission = "";
        this.noPermDescription = Arrays.asList("Upgrade your rank to purchase this template.");
        this.id = id;
    }
    
    public ItemStack getIcon() {
        return new ItemBuilder(this.icon).name(this.displayname).build();
    }
    
    public void setNoPermDescription(final List<String> list) {
        this.noPermDescription = list.stream().map(s -> ChatColor.translateAlternateColorCodes('&', s)).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
    }
    
    public boolean hasRefund() {
        return this.refund > 0;
    }
    
    public Optional<World> getWorld() {
        return Optional.ofNullable(Bukkit.getWorld(this.world));
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }
    
    @Override
    public boolean equals(final Object obj) {
        return this == obj || (obj != null && obj instanceof RegionClaim && Objects.equals(this.id, ((RegionClaim)obj).id));
    }
    
    public Map<String, Object> serialize() {
        final HashMap hashMap = Maps.newHashMap();
        hashMap.put("id", this.id.toString());
        hashMap.put("gui.displayname", this.displayname);
        hashMap.put("gui.icon", this.icon.toString());
        hashMap.put("gui.description", this.description);
        hashMap.put("gui.noPermDescription", this.noPermDescription);
        hashMap.put("data.size", this.size);
        hashMap.put("data.heigth", this.height);
        hashMap.put("data.depth", this.depth);
        hashMap.put("data.price", this.price);
        hashMap.put("data.refund", this.refund);
        hashMap.put("data.world", this.world);
        hashMap.put("data.permission", this.permission);
        hashMap.put("border.material", this.borderMaterial.toString());
        hashMap.put("border.enabled", this.generateBorder);
        hashMap.put("generation.runCommands", this.runCommands);
        return (Map<String, Object>)hashMap;
    }
    
    public static RegionClaim deserialize(final Map<String, Object> map) {
        final RegionClaim regionClaim = new RegionClaim(UUID.fromString(map.get("id")));
        regionClaim.setDisplayname(map.get("gui.displayname"));
        regionClaim.setIcon(Material.valueOf((String)map.get("gui.icon")));
        regionClaim.setDescription((List<String>)map.get("gui.description"));
        regionClaim.setNoPermDescription((List<String>)map.get("gui.noPermDescription"));
        regionClaim.setSize((int)map.get("data.size"));
        regionClaim.setHeight((int)map.get("data.heigth"));
        regionClaim.setDepth((int)map.get("data.depth"));
        regionClaim.setPrice((int)map.get("data.price"));
        regionClaim.setRefund((int)map.get("data.refund"));
        regionClaim.setWorld(map.get("data.world"));
        regionClaim.setPermission(map.getOrDefault("data.permission", ""));
        regionClaim.setBorderMaterial(Material.valueOf((String)map.get("border.material")));
        regionClaim.setGenerateBorder((boolean)map.get("border.enabled"));
        regionClaim.setRunCommands((List<String>)map.get("generation.runCommands"));
        Bukkit.getServer().getLogger().info("Loaded Template ID " + regionClaim.getId() + " - " + regionClaim.getDisplayname());
        return regionClaim;
    }
    
    public int compareTo(final RegionClaim o) {
        return (this.size > o.getSize()) ? 1 : ((this.size < o.getSize()) ? -1 : 0);
    }
    
    public UUID getId() {
        return this.id;
    }
    
    public String getDisplayname() {
        return this.displayname;
    }
    
    public void setDisplayname(final String displayname) {
        this.displayname = displayname;
    }
    
    public void setIcon(final Material icon) {
        this.icon = icon;
    }
    
    public List<String> getDescription() {
        return this.description;
    }
    
    public void setDescription(final List<String> description) {
        this.description = description;
    }
    
    public int getSize() {
        return this.size;
    }
    
    public void setSize(final int size) {
        this.size = size;
    }
    
    public void setWorld(final String world) {
        this.world = world;
    }
    
    public int getHeight() {
        return this.height;
    }
    
    public void setHeight(final int height) {
        this.height = height;
    }
    
    public int getDepth() {
        return this.depth;
    }
    
    public void setDepth(final int depth) {
        this.depth = depth;
    }
    
    public int getPrice() {
        return this.price;
    }
    
    public void setPrice(final int price) {
        this.price = price;
    }
    
    public int getRefund() {
        return this.refund;
    }
    
    public void setRefund(final int refund) {
        this.refund = refund;
    }
    
    public Material getBorderMaterial() {
        return this.borderMaterial;
    }
    
    public void setBorderMaterial(final Material borderMaterial) {
        this.borderMaterial = borderMaterial;
    }
    
    public boolean isGenerateBorder() {
        return this.generateBorder;
    }
    
    public void setGenerateBorder(final boolean generateBorder) {
        this.generateBorder = generateBorder;
    }
    
    public List<String> getRunCommands() {
        return this.runCommands;
    }
    
    public void setRunCommands(final List<String> runCommands) {
        this.runCommands = runCommands;
    }
    
    public String getPermission() {
        return this.permission;
    }
    
    public void setPermission(final String permission) {
        this.permission = permission;
    }
    
    public List<String> getNoPermDescription() {
        return this.noPermDescription;
    }
    
    @Override
    public String toString() {
        return "RegionClaim(id=" + this.getId() + ", displayname=" + this.getDisplayname() + ", icon=" + this.getIcon() + ", description=" + this.getDescription() + ", size=" + this.getSize() + ", world=" + this.getWorld() + ", height=" + this.getHeight() + ", depth=" + this.getDepth() + ", price=" + this.getPrice() + ", refund=" + this.getRefund() + ", borderMaterial=" + this.getBorderMaterial() + ", generateBorder=" + this.isGenerateBorder() + ", runCommands=" + this.getRunCommands() + ", permission=" + this.getPermission() + ", noPermDescription=" + this.getNoPermDescription() + ")";
    }
}

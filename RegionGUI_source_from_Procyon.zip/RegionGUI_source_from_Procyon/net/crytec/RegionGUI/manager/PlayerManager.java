// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.manager;

import org.bukkit.entity.Player;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.PlayerJoinEvent;
import java.io.IOException;
import com.google.common.collect.Lists;
import org.bukkit.configuration.file.YamlConfiguration;
import com.google.common.collect.Sets;
import net.crytec.RegionGUI.data.RegionClaim;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import java.util.Iterator;
import net.crytec.shaded.org.apache.commons.io.FileUtils;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import com.google.common.collect.Maps;
import net.crytec.RegionGUI.RegionGUI;
import java.io.File;
import net.crytec.RegionGUI.data.ClaimEntry;
import java.util.Set;
import java.util.UUID;
import java.util.HashMap;
import org.bukkit.event.Listener;

public class PlayerManager implements Listener
{
    private final HashMap<UUID, Set<ClaimEntry>> playerdata;
    private final File folder;
    
    public PlayerManager(final RegionGUI plugin, final ClaimManager manager) {
        this.playerdata = (HashMap<UUID, Set<ClaimEntry>>)Maps.newHashMap();
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        this.folder = new File(plugin.getDataFolder(), "data");
        if (!this.folder.exists()) {
            this.folder.mkdir();
        }
        Bukkit.getOnlinePlayers().forEach(player -> this.loadPlayerFiles(player.getUniqueId()));
        final Iterator iterateFiles = FileUtils.iterateFiles(this.folder, new String[] { "data" }, false);
        while (iterateFiles.hasNext()) {
            this.loadPlayerFiles(UUID.fromString(iterateFiles.next().getName().replace(".data", "")));
        }
        plugin.getLogger().info("Loading " + this.playerdata.size() + " playerfiles...");
    }
    
    public void saveOnDisable() {
        Bukkit.getOnlinePlayers().forEach(player -> this.savePlayerFiles(player.getUniqueId()));
        this.playerdata.clear();
    }
    
    public Set<ClaimEntry> getPlayerClaims(final UUID uuid) {
        return this.playerdata.get(uuid);
    }
    
    public void addClaimToPlayer(final UUID owner, final ProtectedRegion region, final RegionClaim claim) {
        this.playerdata.get(owner).add(new ClaimEntry(region.getId(), claim, System.currentTimeMillis()));
    }
    
    public void deleteClaim(final UUID owner, final ProtectedRegion region) {
        this.playerdata.get(owner).removeIf(claimEntry -> claimEntry.getProtectedRegion().get().equals(region));
        this.savePlayerFiles(owner);
    }
    
    public void loadPlayerFiles(final UUID uuid) {
        final File file = new File(this.folder, String.valueOf(uuid.toString()) + ".data");
        if (!file.exists()) {
            this.playerdata.put(uuid, Sets.newHashSet());
            return;
        }
        this.playerdata.put(uuid, Sets.newHashSet((Iterable)YamlConfiguration.loadConfiguration(file).getList("data")));
        RegionGUI.getInstance().getLogger().info("Loaded " + this.playerdata.get(uuid).size() + " templates for player " + uuid.toString());
        final Iterator<ClaimEntry> iterator = this.getPlayerClaims(uuid).iterator();
        while (iterator.hasNext()) {
            final ClaimEntry claimEntry = iterator.next();
            if (claimEntry == null) {
                RegionGUI.getInstance().getLogger().severe("Failed to load player claims for user: " + uuid.toString() + " (" + Bukkit.getOfflinePlayer(uuid).getName() + ")");
            }
            else if (claimEntry.getTemplate() == null) {
                iterator.remove();
                RegionGUI.getInstance().getLogger().severe("Removed claim for player " + uuid.toString() + " because the given template does no longer exist.");
            }
            else {
                if (claimEntry.getProtectedRegion() != null && claimEntry.getProtectedRegion().isPresent()) {
                    continue;
                }
                iterator.remove();
                RegionGUI.getInstance().getLogger().severe("Removed claim for player " + uuid.toString() + " because the WorldGuard region does no longer exist.");
            }
        }
    }
    
    public void savePlayerFiles(final UUID uuid) {
        if (this.playerdata.get(uuid).isEmpty()) {
            final File file = new File(this.folder, String.valueOf(uuid.toString()) + ".data");
            if (file.exists()) {
                file.delete();
            }
            return;
        }
        final File file2 = new File(this.folder, String.valueOf(uuid.toString()) + ".data");
        final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file2);
        loadConfiguration.set("data", (Object)Lists.newArrayList((Iterable)this.playerdata.get(uuid)));
        try {
            loadConfiguration.save(file2);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    @EventHandler
    public void onJoin(final PlayerJoinEvent event) {
        if (!this.playerdata.containsKey(event.getPlayer().getUniqueId())) {
            this.playerdata.put(event.getPlayer().getUniqueId(), Sets.newHashSet());
        }
    }
    
    @EventHandler
    public void onQuit(final PlayerQuitEvent event) {
        this.savePlayerFiles(event.getPlayer().getUniqueId());
    }
    
    public void saveImportedData() {
        this.playerdata.keySet().forEach(uuid -> this.savePlayerFiles(uuid));
    }
    
    public HashMap<UUID, Set<ClaimEntry>> getPlayerdata() {
        return this.playerdata;
    }
}

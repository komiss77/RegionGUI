// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI;

import java.net.URLConnection;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Optional;
import org.bukkit.ChatColor;
import net.crytec.acf.InvalidCommandArgument;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import net.crytec.acf.BukkitCommandIssuer;
import com.sk89q.worldguard.WorldGuard;
import net.crytec.acf.BukkitCommandExecutionContext;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.RegisteredServiceProvider;
import net.crytec.RegionGUI.metrics.Metrics;
import net.crytec.RegionGUI.commands.LandAdmin;
import net.crytec.acf.BaseCommand;
import net.crytec.RegionGUI.commands.LandCommand;
import org.bukkit.event.Listener;
import net.crytec.RegionGUI.listener.RegionPurchaseListener;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.phoenix.api.chat.program.ChatEditorCore;
import net.crytec.acf.BukkitCommandManager;
import net.crytec.phoenix.api.PhoenixAPI;
import org.bukkit.plugin.Plugin;
import java.io.File;
import org.bukkit.Bukkit;
import net.crytec.RegionGUI.data.ClaimEntry;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import net.crytec.RegionGUI.data.RegionClaim;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.RegionGUI.manager.ClaimManager;
import net.crytec.RegionGUI.utils.flags.FlagManager;
import net.milkbowl.vault.economy.Economy;
import java.util.logging.Logger;
import org.bukkit.plugin.java.JavaPlugin;

public final class RegionGUI extends JavaPlugin
{
    private static RegionGUI instance;
    public final Logger log;
    public static Economy econ;
    private FlagManager flagmanager;
    private ClaimManager claimManager;
    private PlayerManager playerManager;
    public static String USER;
    
    static {
        RegionGUI.econ = null;
        RegionGUI.USER = "38105";
        ConfigurationSerialization.registerClass((Class)RegionClaim.class, "Template");
        ConfigurationSerialization.registerClass((Class)ClaimEntry.class, "PlayerClaim");
    }
    
    public RegionGUI() {
        this.log = Bukkit.getLogger();
    }
    
    public void onLoad() {
        RegionGUI.instance = this;
        if (!this.getDataFolder().exists()) {
            this.getDataFolder().mkdir();
        }
        final File file = new File(this.getDataFolder(), "config.yml");
        try {
            if (!file.exists()) {
                file.createNewFile();
                this.saveResource("config.yml", true);
                this.log("§2Setup - New default configuration has been written.");
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void onEnable() {
        loadConfig0();
        if (!this.setupEconomy()) {
            this.log("§cNo Vault Compatible Economy Plugin found! Cannot load RegionGUI", true);
            Bukkit.getPluginManager().disablePlugin((Plugin)this);
        }
        if (!PhoenixAPI.get().requireAPIVersion((JavaPlugin)this, 108)) {
            Bukkit.getPluginManager().disablePlugin((Plugin)this);
            return;
        }
        this.loadLanguage();
        final BukkitCommandManager bukkitCommandManager = new BukkitCommandManager((Plugin)this);
        new ChatEditorCore((JavaPlugin)this);
        bukkitCommandManager.getCommandContexts().registerContext((Class)ProtectedRegion.class, bukkitCommandExecutionContext -> {
            final ProtectedRegion region = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(((BukkitCommandIssuer)bukkitCommandExecutionContext.getIssuer()).getPlayer().getWorld())).getRegion(bukkitCommandExecutionContext.popFirstArg());
            if (region == null) {
                throw new InvalidCommandArgument("Could not find an region with that name in your current world.");
            }
            return region;
        });
        bukkitCommandManager.getCommandContexts().registerContext((Class)RegionClaim.class, bukkitCommandExecutionContext -> {
            final Optional<RegionClaim> first = this.getClaimManager().getTemplates(((BukkitCommandIssuer)bukkitCommandExecutionContext.getIssuer()).getPlayer().getWorld()).stream().filter(regionClaim -> ChatColor.stripColor(regionClaim.getDisplayname()).equals(bukkitCommandExecutionContext.popFirstArg())).findFirst();
            if (!first.isPresent()) {
                throw new InvalidCommandArgument("Could not find a template with that name in your current world.");
            }
            return first.get();
        });
        this.flagmanager = new FlagManager(this);
        this.claimManager = new ClaimManager(this);
        this.playerManager = new PlayerManager(this, this.claimManager);
        Bukkit.getPluginManager().registerEvents((Listener)new RegionPurchaseListener(), (Plugin)this);
        bukkitCommandManager.registerCommand((BaseCommand)new LandCommand(this, this.playerManager));
        bukkitCommandManager.registerCommand((BaseCommand)new LandAdmin(this));
        bukkitCommandManager.enableUnstableAPI("help");
        final Metrics metrics = new Metrics(this);
        metrics.addCustomChart(new Metrics.SimplePie("purges_enabled", () -> this.getConfig().getBoolean("deleteOnPurge") ? "Enabled" : "Disabled"));
        metrics.addCustomChart(new Metrics.SimplePie("preview_mode", () -> this.getConfig().getBoolean("enable_previewmode") ? "Enabled" : "Disabled"));
        metrics.addCustomChart(new Metrics.SimplePie("economy", () -> (RegionGUI.econ.getName() != null) ? RegionGUI.econ.getName() : "Unknown"));
    }
    
    public void onDisable() {
        if (this.getPlayerManager() != null) {
            this.getPlayerManager().saveOnDisable();
        }
        if (this.claimManager != null) {
            this.claimManager.save();
        }
    }
    
    public static RegionGUI getInstance() {
        return RegionGUI.instance;
    }
    
    public void log(final String message) {
        this.log(message, false);
    }
    
    public void log(final String message, final boolean withPrefix) {
        if (withPrefix) {
            Bukkit.getConsoleSender().sendMessage("[RegionGUI] " + message);
            return;
        }
        Bukkit.getConsoleSender().sendMessage(message);
    }
    
    private boolean setupEconomy() {
        if (this.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        final RegisteredServiceProvider registration = this.getServer().getServicesManager().getRegistration((Class)Economy.class);
        if (registration == null) {
            return false;
        }
        RegionGUI.econ = (Economy)registration.getProvider();
        return RegionGUI.econ != null;
    }
    
    public void reloadConfig() {
        super.reloadConfig();
        this.loadLanguage();
    }
    
    public FlagManager getFlagManager() {
        return this.flagmanager;
    }
    
    public void loadLanguage() {
        final File file = new File(getInstance().getDataFolder(), "lang.yml");
        if (!file.exists()) {
            try {
                getInstance().getDataFolder().mkdir();
                file.createNewFile();
                if (file != null) {
                    final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file);
                    loadConfiguration.save(file);
                    Language.setFile(loadConfiguration);
                }
            }
            catch (IOException ex2) {
                getInstance().getLogger().severe("Could not create language file!");
                Bukkit.getPluginManager().disablePlugin((Plugin)getInstance());
            }
        }
        final YamlConfiguration loadConfiguration2 = YamlConfiguration.loadConfiguration(file);
        Language[] values;
        for (int length = (values = Language.values()).length, i = 0; i < length; ++i) {
            final Language language = values[i];
            if (loadConfiguration2.getString(language.getPath()) == null) {
                if (language.isArray()) {
                    loadConfiguration2.set(language.getPath(), (Object)language.getDefArray());
                }
                else {
                    loadConfiguration2.set(language.getPath(), (Object)language.getDefault());
                }
            }
        }
        Language.setFile(loadConfiguration2);
        try {
            loadConfiguration2.save(file);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public ClaimManager getClaimManager() {
        return this.claimManager;
    }
    
    public PlayerManager getPlayerManager() {
        return this.playerManager;
    }
}

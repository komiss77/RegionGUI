// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.commands;

import net.crytec.acf.BaseCommand;

public class LandPurge extends BaseCommand
{
}

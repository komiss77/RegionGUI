// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.RegionGUI.commands;

import net.crytec.RegionGUI.menus.RegionManageInterface;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Set;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.RegionGUI.menus.LandBuyMenu;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import net.crytec.acf.annotation.CommandPermission;
import java.util.Iterator;
import net.crytec.RegionGUI.data.ClaimEntry;
import net.crytec.acf.annotation.Optional;
import net.crytec.acf.bukkit.contexts.OnlinePlayer;
import net.crytec.phoenix.api.inventory.content.InventoryProvider;
import net.crytec.RegionGUI.menus.LandHomeMenu;
import net.crytec.phoenix.api.inventory.SmartInventory;
import net.crytec.acf.annotation.Subcommand;
import net.crytec.acf.CommandHelp;
import net.crytec.acf.CommandIssuer;
import net.crytec.acf.annotation.Default;
import net.crytec.RegionGUI.Language;
import org.bukkit.entity.Player;
import net.crytec.RegionGUI.RegionGUI;
import net.crytec.RegionGUI.manager.PlayerManager;
import net.crytec.acf.annotation.CommandAlias;
import net.crytec.acf.BaseCommand;

@CommandAlias("land")
public class LandCommand extends BaseCommand
{
    private final PlayerManager manager;
    private final RegionGUI plugin;
    
    public LandCommand(final RegionGUI plugin, final PlayerManager manager) {
        this.plugin = plugin;
        this.manager = manager;
    }
    
    @Default
    public void openLandInterface(final Player issuer) {
        if (!this.plugin.getConfig().getStringList("enabled_worlds").contains(issuer.getWorld().getName())) {
            issuer.sendMessage(Language.ERROR_WORLD_DISABLED.toChatString());
            return;
        }
        this.checkForRegions(issuer);
    }
    
    @Subcommand("help")
    public void sendCommandHelp(final CommandIssuer issuer, final CommandHelp help) {
        help.showHelp(issuer);
    }
    
    @Subcommand("home")
    public void openHomeGUI(final Player issuer) {
        SmartInventory.builder().id("home-" + issuer.getName()).provider((InventoryProvider)new LandHomeMenu()).size(5, 9).title(Language.INTERFACE_HOME_TITLE.toString()).build().open(issuer);
    }
    
    @Subcommand("list")
    @CommandPermission("region.list")
    public void displayLandList(final Player issuer, @Optional final OnlinePlayer op) {
        if (op == null) {
            for (final ClaimEntry claimEntry : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(issuer.getUniqueId())) {
                issuer.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", claimEntry.getRegionID()).replace("%template%", claimEntry.getTemplate().getDisplayname()));
            }
            return;
        }
        for (final ClaimEntry claimEntry2 : RegionGUI.getInstance().getPlayerManager().getPlayerClaims(issuer.getUniqueId())) {
            issuer.sendMessage(Language.COMMAND_LIST_ENTRY.toChatString().replace("%region%", claimEntry2.getRegionID()).replace("%template%", claimEntry2.getTemplate().getDisplayname()));
        }
    }
    
    private void checkForRegions(final Player p) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     3: invokevirtual   com/sk89q/worldguard/WorldGuard.getPlatform:()Lcom/sk89q/worldguard/internal/platform/WorldGuardPlatform;
        //     6: invokeinterface com/sk89q/worldguard/internal/platform/WorldGuardPlatform.getRegionContainer:()Lcom/sk89q/worldguard/protection/regions/RegionContainer;
        //    11: aload_1        
        //    12: invokeinterface org/bukkit/entity/Player.getWorld:()Lorg/bukkit/World;
        //    17: invokestatic    com/sk89q/worldedit/bukkit/BukkitAdapter.adapt:(Lorg/bukkit/World;)Lcom/sk89q/worldedit/world/World;
        //    20: invokevirtual   com/sk89q/worldguard/protection/regions/RegionContainer.get:(Lcom/sk89q/worldedit/world/World;)Lcom/sk89q/worldguard/protection/managers/RegionManager;
        //    23: astore_2       
        //    24: aload_2        
        //    25: aload_1        
        //    26: invokeinterface org/bukkit/entity/Player.getLocation:()Lorg/bukkit/Location;
        //    31: invokestatic    com/sk89q/worldedit/bukkit/BukkitAdapter.asBlockVector:(Lorg/bukkit/Location;)Lcom/sk89q/worldedit/math/BlockVector3;
        //    34: invokevirtual   com/sk89q/worldguard/protection/managers/RegionManager.getApplicableRegions:(Lcom/sk89q/worldedit/math/BlockVector3;)Lcom/sk89q/worldguard/protection/ApplicableRegionSet;
        //    37: astore_3       
        //    38: invokestatic    com/sk89q/worldguard/bukkit/WorldGuardPlugin.inst:()Lcom/sk89q/worldguard/bukkit/WorldGuardPlugin;
        //    41: aload_1        
        //    42: invokevirtual   com/sk89q/worldguard/bukkit/WorldGuardPlugin.wrapPlayer:(Lorg/bukkit/entity/Player;)Lcom/sk89q/worldguard/LocalPlayer;
        //    45: astore          4
        //    47: aload_3        
        //    48: invokeinterface com/sk89q/worldguard/protection/ApplicableRegionSet.iterator:()Ljava/util/Iterator;
        //    53: astore          5
        //    55: aload_3        
        //    56: invokeinterface com/sk89q/worldguard/protection/ApplicableRegionSet.size:()I
        //    61: ifne            136
        //    64: aload_1        
        //    65: ldc_w           "region.claim"
        //    68: invokeinterface org/bukkit/entity/Player.hasPermission:(Ljava/lang/String;)Z
        //    73: ifne            89
        //    76: aload_1        
        //    77: getstatic       net/crytec/RegionGUI/Language.ERROR_NO_PERMISSION:Lnet/crytec/RegionGUI/Language;
        //    80: invokevirtual   net/crytec/RegionGUI/Language.toChatString:()Ljava/lang/String;
        //    83: invokeinterface org/bukkit/entity/Player.sendMessage:(Ljava/lang/String;)V
        //    88: return         
        //    89: invokestatic    net/crytec/phoenix/api/inventory/SmartInventory.builder:()Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //    92: ldc_w           "regiongui.claim"
        //    95: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.id:(Ljava/lang/String;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //    98: new             Lnet/crytec/RegionGUI/menus/LandBuyMenu;
        //   101: dup            
        //   102: aload_0        
        //   103: getfield        net/crytec/RegionGUI/commands/LandCommand.plugin:Lnet/crytec/RegionGUI/RegionGUI;
        //   106: invokespecial   net/crytec/RegionGUI/menus/LandBuyMenu.<init>:(Lnet/crytec/RegionGUI/RegionGUI;)V
        //   109: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.provider:(Lnet/crytec/phoenix/api/inventory/content/InventoryProvider;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   112: iconst_3       
        //   113: bipush          9
        //   115: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.size:(II)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   118: getstatic       net/crytec/RegionGUI/Language.INTERFACE_BUY_TITLE:Lnet/crytec/RegionGUI/Language;
        //   121: invokevirtual   net/crytec/RegionGUI/Language.toString:()Ljava/lang/String;
        //   124: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.title:(Ljava/lang/String;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   127: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.build:()Lnet/crytec/phoenix/api/inventory/SmartInventory;
        //   130: aload_1        
        //   131: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory.open:(Lorg/bukkit/entity/Player;)Lorg/bukkit/inventory/Inventory;
        //   134: pop            
        //   135: return         
        //   136: aload_3        
        //   137: invokeinterface com/sk89q/worldguard/protection/ApplicableRegionSet.size:()I
        //   142: iconst_1       
        //   143: if_icmpne       373
        //   146: aload           5
        //   148: invokeinterface java/util/Iterator.next:()Ljava/lang/Object;
        //   153: checkcast       Lcom/sk89q/worldguard/protection/regions/ProtectedRegion;
        //   156: astore          6
        //   158: aload_0        
        //   159: getfield        net/crytec/RegionGUI/commands/LandCommand.manager:Lnet/crytec/RegionGUI/manager/PlayerManager;
        //   162: aload_1        
        //   163: invokeinterface org/bukkit/entity/Player.getUniqueId:()Ljava/util/UUID;
        //   168: invokevirtual   net/crytec/RegionGUI/manager/PlayerManager.getPlayerClaims:(Ljava/util/UUID;)Ljava/util/Set;
        //   171: astore          7
        //   173: aload           7
        //   175: ifnonnull       188
        //   178: aload_1        
        //   179: ldc_w           "§cYou don't own any claims in this world."
        //   182: invokeinterface org/bukkit/entity/Player.sendMessage:(Ljava/lang/String;)V
        //   187: return         
        //   188: aload           7
        //   190: invokeinterface java/util/Set.stream:()Ljava/util/stream/Stream;
        //   195: invokedynamic   BootstrapMethod #0, apply:()Ljava/util/function/Function;
        //   200: invokeinterface java/util/stream/Stream.map:(Ljava/util/function/Function;)Ljava/util/stream/Stream;
        //   205: invokestatic    java/util/stream/Collectors.toSet:()Ljava/util/stream/Collector;
        //   208: invokeinterface java/util/stream/Stream.collect:(Ljava/util/stream/Collector;)Ljava/lang/Object;
        //   213: checkcast       Ljava/util/Set;
        //   216: astore          8
        //   218: aload           6
        //   220: aload           4
        //   222: invokevirtual   com/sk89q/worldguard/protection/regions/ProtectedRegion.isOwner:(Lcom/sk89q/worldguard/LocalPlayer;)Z
        //   225: ifeq            243
        //   228: aload           8
        //   230: aload           6
        //   232: invokevirtual   com/sk89q/worldguard/protection/regions/ProtectedRegion.getId:()Ljava/lang/String;
        //   235: invokeinterface java/util/Set.contains:(Ljava/lang/Object;)Z
        //   240: ifne            255
        //   243: aload_1        
        //   244: ldc_w           "region.mod"
        //   247: invokeinterface org/bukkit/entity/Player.hasPermission:(Ljava/lang/String;)Z
        //   252: ifeq            360
        //   255: invokestatic    net/crytec/RegionGUI/RegionGUI.getInstance:()Lnet/crytec/RegionGUI/RegionGUI;
        //   258: invokevirtual   net/crytec/RegionGUI/RegionGUI.getPlayerManager:()Lnet/crytec/RegionGUI/manager/PlayerManager;
        //   261: aload_1        
        //   262: invokeinterface org/bukkit/entity/Player.getUniqueId:()Ljava/util/UUID;
        //   267: invokevirtual   net/crytec/RegionGUI/manager/PlayerManager.getPlayerClaims:(Ljava/util/UUID;)Ljava/util/Set;
        //   270: invokeinterface java/util/Set.stream:()Ljava/util/stream/Stream;
        //   275: aload           6
        //   277: invokedynamic   BootstrapMethod #1, test:(Lcom/sk89q/worldguard/protection/regions/ProtectedRegion;)Ljava/util/function/Predicate;
        //   282: invokeinterface java/util/stream/Stream.filter:(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
        //   287: invokeinterface java/util/stream/Stream.findFirst:()Ljava/util/Optional;
        //   292: astore          9
        //   294: aload           9
        //   296: invokevirtual   java/util/Optional.isPresent:()Z
        //   299: ifne            315
        //   302: aload_1        
        //   303: getstatic       net/crytec/RegionGUI/Language.ERROR_NO_REGION_FOUND:Lnet/crytec/RegionGUI/Language;
        //   306: invokevirtual   net/crytec/RegionGUI/Language.toChatString:()Ljava/lang/String;
        //   309: invokeinterface org/bukkit/entity/Player.sendMessage:(Ljava/lang/String;)V
        //   314: return         
        //   315: invokestatic    net/crytec/phoenix/api/inventory/SmartInventory.builder:()Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   318: new             Lnet/crytec/RegionGUI/menus/RegionManageInterface;
        //   321: dup            
        //   322: aload           9
        //   324: invokevirtual   java/util/Optional.get:()Ljava/lang/Object;
        //   327: checkcast       Lnet/crytec/RegionGUI/data/ClaimEntry;
        //   330: invokespecial   net/crytec/RegionGUI/menus/RegionManageInterface.<init>:(Lnet/crytec/RegionGUI/data/ClaimEntry;)V
        //   333: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.provider:(Lnet/crytec/phoenix/api/inventory/content/InventoryProvider;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   336: iconst_3       
        //   337: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.size:(I)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   340: getstatic       net/crytec/RegionGUI/Language.INTERFACE_MANAGE_TITLE:Lnet/crytec/RegionGUI/Language;
        //   343: invokevirtual   net/crytec/RegionGUI/Language.toString:()Ljava/lang/String;
        //   346: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.title:(Ljava/lang/String;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   349: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.build:()Lnet/crytec/phoenix/api/inventory/SmartInventory;
        //   352: aload_1        
        //   353: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory.open:(Lorg/bukkit/entity/Player;)Lorg/bukkit/inventory/Inventory;
        //   356: pop            
        //   357: goto            372
        //   360: aload_1        
        //   361: getstatic       net/crytec/RegionGUI/Language.ERROR_NOT_OWNER:Lnet/crytec/RegionGUI/Language;
        //   364: invokevirtual   net/crytec/RegionGUI/Language.toChatString:()Ljava/lang/String;
        //   367: invokeinterface org/bukkit/entity/Player.sendMessage:(Ljava/lang/String;)V
        //   372: return         
        //   373: aload_3        
        //   374: invokeinterface com/sk89q/worldguard/protection/ApplicableRegionSet.size:()I
        //   379: iconst_1       
        //   380: if_icmple       512
        //   383: aload_0        
        //   384: getfield        net/crytec/RegionGUI/commands/LandCommand.manager:Lnet/crytec/RegionGUI/manager/PlayerManager;
        //   387: aload_1        
        //   388: invokeinterface org/bukkit/entity/Player.getUniqueId:()Ljava/util/UUID;
        //   393: invokevirtual   net/crytec/RegionGUI/manager/PlayerManager.getPlayerClaims:(Ljava/util/UUID;)Ljava/util/Set;
        //   396: invokeinterface java/util/Set.stream:()Ljava/util/stream/Stream;
        //   401: invokedynamic   BootstrapMethod #2, apply:()Ljava/util/function/Function;
        //   406: invokeinterface java/util/stream/Stream.map:(Ljava/util/function/Function;)Ljava/util/stream/Stream;
        //   411: invokestatic    java/util/stream/Collectors.toSet:()Ljava/util/stream/Collector;
        //   414: invokeinterface java/util/stream/Stream.collect:(Ljava/util/stream/Collector;)Ljava/lang/Object;
        //   419: checkcast       Ljava/util/Set;
        //   422: astore          6
        //   424: invokestatic    net/crytec/RegionGUI/RegionGUI.getInstance:()Lnet/crytec/RegionGUI/RegionGUI;
        //   427: invokevirtual   net/crytec/RegionGUI/RegionGUI.getPlayerManager:()Lnet/crytec/RegionGUI/manager/PlayerManager;
        //   430: aload_1        
        //   431: invokeinterface org/bukkit/entity/Player.getUniqueId:()Ljava/util/UUID;
        //   436: invokevirtual   net/crytec/RegionGUI/manager/PlayerManager.getPlayerClaims:(Ljava/util/UUID;)Ljava/util/Set;
        //   439: invokeinterface java/util/Set.stream:()Ljava/util/stream/Stream;
        //   444: aload           6
        //   446: invokedynamic   BootstrapMethod #3, test:(Ljava/util/Set;)Ljava/util/function/Predicate;
        //   451: invokeinterface java/util/stream/Stream.filter:(Ljava/util/function/Predicate;)Ljava/util/stream/Stream;
        //   456: invokestatic    java/util/stream/Collectors.toSet:()Ljava/util/stream/Collector;
        //   459: invokeinterface java/util/stream/Stream.collect:(Ljava/util/stream/Collector;)Ljava/lang/Object;
        //   464: checkcast       Ljava/util/Set;
        //   467: astore          7
        //   469: invokestatic    net/crytec/phoenix/api/inventory/SmartInventory.builder:()Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   472: ldc_w           "regiongui.regionselect"
        //   475: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.id:(Ljava/lang/String;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   478: new             Lnet/crytec/RegionGUI/menus/RegionSelectMenu;
        //   481: dup            
        //   482: aload           7
        //   484: invokespecial   net/crytec/RegionGUI/menus/RegionSelectMenu.<init>:(Ljava/util/Set;)V
        //   487: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.provider:(Lnet/crytec/phoenix/api/inventory/content/InventoryProvider;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   490: iconst_3       
        //   491: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.size:(I)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   494: getstatic       net/crytec/RegionGUI/Language.INTERFACE_SELECT_TITLE:Lnet/crytec/RegionGUI/Language;
        //   497: invokevirtual   net/crytec/RegionGUI/Language.toString:()Ljava/lang/String;
        //   500: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.title:(Ljava/lang/String;)Lnet/crytec/phoenix/api/inventory/SmartInventory$Builder;
        //   503: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory$Builder.build:()Lnet/crytec/phoenix/api/inventory/SmartInventory;
        //   506: aload_1        
        //   507: invokevirtual   net/crytec/phoenix/api/inventory/SmartInventory.open:(Lorg/bukkit/entity/Player;)Lorg/bukkit/inventory/Inventory;
        //   510: pop            
        //   511: return         
        //   512: return         
        //    MethodParameters:
        //  Name  Flags  
        //  ----  -----
        //  p     
        //    StackMapTable: 00 0A FF 00 59 00 06 07 00 02 07 00 33 07 00 F9 07 01 09 07 01 18 07 00 B0 00 00 2E FD 00 33 07 01 24 07 00 AA FC 00 36 07 00 AA 0B FC 00 3B 07 01 6D FA 00 2C 0B F8 00 00 FB 00 8A
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalArgumentException: Unknown node type: Block_0_3_4:
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:520)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:799)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:799)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformByteCode(AstMethodBodyBuilder.java:554)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformExpression(AstMethodBodyBuilder.java:540)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:392)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:440)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:441)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformNode(AstMethodBodyBuilder.java:441)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.transformBlock(AstMethodBodyBuilder.java:333)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:294)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethod(AstBuilder.java:675)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:552)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
}

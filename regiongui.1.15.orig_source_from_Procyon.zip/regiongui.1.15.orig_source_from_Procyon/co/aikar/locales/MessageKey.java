// 
// Decompiled by Procyon v0.5.36
// 

package co.aikar.locales;

import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class MessageKey implements MessageKeyProvider
{
    private static final AtomicInteger counter;
    private static final Map<String, MessageKey> keyMap;
    private final int id;
    private final String key;
    
    private MessageKey(final String key) {
        this.id = MessageKey.counter.getAndIncrement();
        this.key = key;
    }
    
    public static MessageKey of(final String key) {
        return MessageKey.keyMap.computeIfAbsent(key.toLowerCase().intern(), MessageKey::new);
    }
    
    @Override
    public int hashCode() {
        return this.id;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o;
    }
    
    public String getKey() {
        return this.key;
    }
    
    @Override
    public MessageKey getMessageKey() {
        return this;
    }
    
    static {
        counter = new AtomicInteger(1);
        keyMap = new ConcurrentHashMap<String, MessageKey>();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package co.aikar.locales;

import java.net.URLConnection;
import java.net.URL;
import java.io.InputStream;
import java.io.Reader;
import java.util.PropertyResourceBundle;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.ResourceBundle;

class UTF8Control extends ResourceBundle.Control
{
    @Override
    public ResourceBundle newBundle(final String baseName, final Locale locale, final String format, final ClassLoader loader, final boolean reload) {
        final String resourceName = this.toResourceName(this.toBundleName(baseName, locale), "properties");
        ResourceBundle resourceBundle = null;
        InputStream in = null;
        if (reload) {
            final URL resource = loader.getResource(resourceName);
            if (resource != null) {
                final URLConnection openConnection = resource.openConnection();
                if (openConnection != null) {
                    openConnection.setUseCaches(false);
                    in = openConnection.getInputStream();
                }
            }
        }
        else {
            in = loader.getResourceAsStream(resourceName);
        }
        if (in != null) {
            try {
                resourceBundle = new PropertyResourceBundle(new InputStreamReader(in, StandardCharsets.UTF_8));
            }
            finally {
                in.close();
            }
        }
        return resourceBundle;
    }
}

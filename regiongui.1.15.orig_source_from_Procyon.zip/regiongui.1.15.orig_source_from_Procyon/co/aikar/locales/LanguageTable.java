// 
// Decompiled by Procyon v0.5.36
// 

package co.aikar.locales;

import java.util.Iterator;
import java.util.MissingResourceException;
import java.util.ResourceBundle;
import org.jetbrains.annotations.NotNull;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;

public class LanguageTable
{
    private final Locale locale;
    private final Map<MessageKey, String> messages;
    
    LanguageTable(final Locale locale) {
        this.messages = new HashMap<MessageKey, String>();
        this.locale = locale;
    }
    
    public String addMessage(final MessageKey key, final String message) {
        return this.messages.put(key, message);
    }
    
    public String getMessage(final MessageKey key) {
        return this.messages.get(key);
    }
    
    public void addMessages(@NotNull final Map<MessageKey, String> messages) {
        this.messages.putAll(messages);
    }
    
    public Locale getLocale() {
        return this.locale;
    }
    
    public boolean addMessageBundle(final String bundleName) {
        return this.addMessageBundle(this.getClass().getClassLoader(), bundleName);
    }
    
    public boolean addMessageBundle(final ClassLoader classLoader, final String bundleName) {
        try {
            return this.addResourceBundle(ResourceBundle.getBundle(bundleName, this.locale, classLoader, new UTF8Control()));
        }
        catch (MissingResourceException ex) {
            return false;
        }
    }
    
    public boolean addResourceBundle(final ResourceBundle bundle) {
        for (final String s : bundle.keySet()) {
            this.addMessage(MessageKey.of(s), bundle.getString(s));
        }
        return !bundle.keySet().isEmpty();
    }
}

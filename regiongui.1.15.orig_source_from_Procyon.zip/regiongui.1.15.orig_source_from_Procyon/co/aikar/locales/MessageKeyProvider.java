// 
// Decompiled by Procyon v0.5.36
// 

package co.aikar.locales;

public interface MessageKeyProvider
{
    MessageKey getMessageKey();
}

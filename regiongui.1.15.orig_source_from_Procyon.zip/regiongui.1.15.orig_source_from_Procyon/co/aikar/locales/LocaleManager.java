// 
// Decompiled by Procyon v0.5.36
// 

package co.aikar.locales;

import java.util.ResourceBundle;
import java.util.Objects;
import org.jetbrains.annotations.NotNull;
import java.util.HashMap;
import java.util.Map;
import java.util.Locale;
import java.util.function.Function;

public class LocaleManager<T>
{
    private final Function<T, Locale> localeMapper;
    private Locale defaultLocale;
    private final Map<Locale, LanguageTable> tables;
    
    LocaleManager(final Function<T, Locale> localeMapper, final Locale defaultLocale) {
        this.tables = new HashMap<Locale, LanguageTable>();
        this.localeMapper = localeMapper;
        this.defaultLocale = defaultLocale;
    }
    
    public static <T> LocaleManager<T> create(@NotNull final Function<T, Locale> localeMapper) {
        return new LocaleManager<T>(localeMapper, Locale.ENGLISH);
    }
    
    public static <T> LocaleManager<T> create(@NotNull final Function<T, Locale> localeMapper, final Locale defaultLocale) {
        return new LocaleManager<T>(localeMapper, defaultLocale);
    }
    
    public Locale getDefaultLocale() {
        return this.defaultLocale;
    }
    
    public Locale setDefaultLocale(final Locale defaultLocale) {
        final Locale defaultLocale2 = this.defaultLocale;
        this.defaultLocale = defaultLocale;
        return defaultLocale2;
    }
    
    public boolean addMessageBundle(@NotNull final String bundleName, @NotNull final Locale... locales) {
        return this.addMessageBundle(this.getClass().getClassLoader(), bundleName, locales);
    }
    
    public boolean addMessageBundle(@NotNull final ClassLoader classLoader, @NotNull final String bundleName, @NotNull Locale... locales) {
        if (locales.length == 0) {
            locales = new Locale[] { this.defaultLocale };
        }
        boolean b = false;
        final Locale[] array = locales;
        for (int length = array.length, i = 0; i < length; ++i) {
            if (this.getTable(array[i]).addMessageBundle(classLoader, bundleName)) {
                b = true;
            }
        }
        return b;
    }
    
    public void addMessages(@NotNull final Locale locale, @NotNull final Map<MessageKey, String> messages) {
        this.getTable(locale).addMessages(messages);
    }
    
    public String addMessage(@NotNull final Locale locale, @NotNull final MessageKey key, @NotNull final String message) {
        return this.getTable(locale).addMessage(key, message);
    }
    
    public String getMessage(final T context, @NotNull final MessageKey key) {
        final Locale locale = this.localeMapper.apply(context);
        String s = this.getTable(locale).getMessage(key);
        if (s == null && !locale.getCountry().isEmpty()) {
            s = this.getTable(new Locale(locale.getLanguage())).getMessage(key);
        }
        if (s == null && !Objects.equals(locale, this.defaultLocale)) {
            s = this.getTable(this.defaultLocale).getMessage(key);
        }
        return s;
    }
    
    @NotNull
    public LanguageTable getTable(@NotNull final Locale locale) {
        return this.tables.computeIfAbsent(locale, LanguageTable::new);
    }
    
    public boolean addResourceBundle(final ResourceBundle bundle, final Locale locale) {
        return this.getTable(locale).addResourceBundle(bundle);
    }
}

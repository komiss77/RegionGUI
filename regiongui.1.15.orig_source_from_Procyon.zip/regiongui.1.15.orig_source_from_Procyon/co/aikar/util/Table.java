// 
// Decompiled by Procyon v0.5.36
// 

package co.aikar.util;

import java.util.function.BiFunction;
import java.util.Objects;
import java.util.stream.StreamSupport;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.Iterator;
import org.jetbrains.annotations.Nullable;
import java.util.function.Supplier;
import java.util.HashMap;
import java.util.function.Function;
import java.util.Map;

public class Table<R, C, V> implements Iterable<Entry<R, C, V>>
{
    private final Map<R, Map<C, V>> rowMap;
    private final Function<R, Map<C, V>> colMapSupplier;
    
    public Table() {
        this((Map)new HashMap(), (Supplier)HashMap::new);
    }
    
    public Table(final Supplier<Map<C, V>> supplier) {
        this((Map)new HashMap(), supplier);
    }
    
    public Table(final Map<R, Map<C, V>> map, final Supplier<Map<C, V>> supplier) {
        this((Map<T, Map<C, V>>)map, p1 -> supplier.get());
    }
    
    public Table(final Map<R, Map<C, V>> rowMap, final Function<R, Map<C, V>> colMapSupplier) {
        this.rowMap = rowMap;
        this.colMapSupplier = colMapSupplier;
    }
    
    public V get(final R r, final C c) {
        return this.getIfExists(r, c);
    }
    
    public V getOrDefault(final R r, final C c, final V v) {
        final Map<K, Object> colMapIfExists = this.getColMapIfExists(r);
        if (colMapIfExists == null) {
            return v;
        }
        final Object value = colMapIfExists.get(c);
        if (value != null || colMapIfExists.containsKey(c)) {
            return (V)value;
        }
        return v;
    }
    
    public boolean containsKey(final R r, final C c) {
        final Map<C, V> colMapIfExists = this.getColMapIfExists(r);
        return colMapIfExists != null && colMapIfExists.containsKey(c);
    }
    
    @Nullable
    public V put(final R r, final C c, final V v) {
        return this.getColMapForWrite(r).put(c, v);
    }
    
    public void forEach(final TableConsumer<R, C, V> tableConsumer) {
        for (final Entry<R, C, V> entry : this) {
            tableConsumer.accept(entry.getRow(), (C)entry.getCol(), (V)entry.getValue());
        }
    }
    
    public void forEach(final TablePredicate<R, C, V> tablePredicate) {
        for (final Entry<R, C, V> entry : this) {
            if (!tablePredicate.test(entry.getRow(), (C)entry.getCol(), (V)entry.getValue())) {
                return;
            }
        }
    }
    
    public void removeIf(final TablePredicate<R, C, V> tablePredicate) {
        final Iterator<Entry<R, C, V>> iterator = (Iterator<Entry<R, C, V>>)this.iterator();
        while (iterator.hasNext()) {
            final Entry<R, C, V> entry = iterator.next();
            if (tablePredicate.test(entry.getRow(), (C)entry.getCol(), (V)entry.getValue())) {
                iterator.remove();
            }
        }
    }
    
    public Stream<Entry<R, C, V>> stream() {
        return this.stream(false);
    }
    
    public Stream<Entry<R, C, V>> stream(final boolean parallel) {
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize((Iterator<? extends Entry<R, C, V>>)this.iterator(), 0), parallel);
    }
    
    @Override
    public Iterator<Entry<R, C, V>> iterator() {
        return new Iterator<Entry<R, C, V>>() {
            Iterator<Map.Entry<R, Map<C, V>>> rowIter = Table.this.rowMap.entrySet().iterator();
            Iterator<Map.Entry<C, V>> colIter = null;
            private Map.Entry<R, Map<C, V>> rowEntry;
            private Map.Entry<C, V> colEntry;
            private Entry<R, C, V> next = this.getNext();
            
            private Entry<R, C, V> getNext() {
                if (this.colIter == null || !this.colIter.hasNext()) {
                    if (!this.rowIter.hasNext()) {
                        return null;
                    }
                    this.rowEntry = this.rowIter.next();
                    this.colIter = this.rowEntry.getValue().entrySet().iterator();
                }
                if (!this.colIter.hasNext()) {
                    return null;
                }
                this.colEntry = this.colIter.next();
                return new Node(this.rowEntry, this.colEntry);
            }
            
            @Override
            public boolean hasNext() {
                return this.next != null;
            }
            
            @Override
            public Entry<R, C, V> next() {
                final Entry<R, C, V> next = this.next;
                this.next = this.getNext();
                return next;
            }
            
            @Override
            public void remove() {
                this.colIter.remove();
            }
        };
    }
    
    public void replaceAll(final TableFunction<R, C, V, V> tableFunction) {
        for (final Entry<R, C, V> entry : this) {
            entry.setValue(tableFunction.compose(entry.getRow(), (C)entry.getCol(), entry.getValue()));
        }
    }
    
    public V remove(final R r, final C c) {
        final Map<C, V> map = this.rowMap.get(r);
        if (map == null) {
            return null;
        }
        return map.remove(c);
    }
    
    @Nullable
    public V replace(final R r, final C c, final V v) {
        final Map<C, V> colMapIfExists = this.getColMapIfExists(r);
        if (colMapIfExists == null) {
            return null;
        }
        if (colMapIfExists.get(c) != null || colMapIfExists.containsKey(c)) {
            return colMapIfExists.put(c, v);
        }
        return null;
    }
    
    @Nullable
    public boolean replace(final R r, final C c, final V b, final V v) {
        final Map<K, Object> colMapIfExists = this.getColMapIfExists(r);
        if (colMapIfExists == null) {
            return false;
        }
        if (Objects.equals(colMapIfExists.get(c), b)) {
            colMapIfExists.put((K)c, v);
            return true;
        }
        return false;
    }
    
    public V computeIfAbsent(final R r, final C key, final BiFunction<R, C, V> biFunction) {
        return this.getColMapForWrite(r).computeIfAbsent(key, p3 -> biFunction.apply(r, key));
    }
    
    public V computeIfPresent(final R r, final C key, final TableFunction<R, C, V, V> tableFunction) {
        final Map<C, V> colMapForWrite = this.getColMapForWrite(r);
        final V computeIfPresent = colMapForWrite.computeIfPresent(key, (p3, v) -> tableFunction.compose(r, key, v));
        this.removeIfEmpty(r, colMapForWrite);
        return computeIfPresent;
    }
    
    public V compute(final R r, final C key, final TableFunction<R, C, V, V> tableFunction) {
        final Map<C, V> colMapForWrite = this.getColMapForWrite(r);
        final V compute = colMapForWrite.compute(key, (p3, v) -> tableFunction.compose(r, key, v));
        this.removeIfEmpty(r, colMapForWrite);
        return compute;
    }
    
    public V merge(final R r, final C key, final V value, final TableFunction<R, C, V, V> tableFunction) {
        final Map<C, V> colMapForWrite = this.getColMapForWrite(r);
        final V merge = colMapForWrite.merge(key, value, (p3, v) -> tableFunction.compose(r, key, v));
        this.removeIfEmpty(r, colMapForWrite);
        return merge;
    }
    
    public Map<C, V> row(final R r) {
        return new DelegatingMap<C, V>() {
            final /* synthetic */ Map val$EMPTY = new HashMap(0);
            
            @Override
            public Map<C, V> delegate(final boolean b) {
                if (b) {
                    return Table.this.rowMap.getOrDefault(r, this.val$EMPTY);
                }
                return Table.this.getColMapForWrite(r);
            }
            
            @Override
            public V remove(final Object o) {
                final Map<K, Object> delegate = this.delegate(false);
                final Object remove = delegate.remove(o);
                Table.this.removeIfEmpty(r, delegate);
                return (V)remove;
            }
        };
    }
    
    private V getIfExists(final R r, final C c) {
        final Map<K, V> colMapIfExists = this.getColMapIfExists(r);
        if (colMapIfExists == null) {
            return null;
        }
        return colMapIfExists.get(c);
    }
    
    private Map<C, V> getColMapIfExists(final R r) {
        Map<C, V> map = this.rowMap.get(r);
        if (map != null && map.isEmpty()) {
            this.rowMap.remove(r);
            map = null;
        }
        return map;
    }
    
    private Map<C, V> getColMapForWrite(final R key) {
        return this.rowMap.computeIfAbsent(key, this.colMapSupplier);
    }
    
    private void removeIfEmpty(final R r, final Map<C, V> map) {
        if (map.isEmpty()) {
            this.rowMap.remove(r);
        }
    }
    
    private class Node implements Entry<R, C, V>
    {
        private final Map.Entry<R, Map<C, V>> rowEntry;
        private final Map.Entry<C, V> colEntry;
        
        Node(final Map.Entry<R, Map<C, V>> rowEntry, final Map.Entry<C, V> colEntry) {
            this.rowEntry = rowEntry;
            this.colEntry = colEntry;
        }
        
        @Override
        public final R getRow() {
            return this.rowEntry.getKey();
        }
        
        @Override
        public final C getCol() {
            return this.colEntry.getKey();
        }
        
        @Override
        public final V getValue() {
            return this.colEntry.getValue();
        }
        
        @Override
        public final V setValue(final V value) {
            return this.colEntry.setValue(value);
        }
    }
    
    public interface Entry<R, C, V>
    {
        R getRow();
        
        C getCol();
        
        V getValue();
        
        V setValue(final V p0);
    }
    
    public interface TableConsumer<R, C, V>
    {
        void accept(final R p0, final C p1, final V p2);
    }
    
    public interface TableFunction<R, C, V, RETURN>
    {
        RETURN compose(final R p0, final C p1, final V p2);
    }
    
    public interface TablePredicate<R, C, V>
    {
        boolean test(final R p0, final C p1, final V p2);
    }
}

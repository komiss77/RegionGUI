// 
// Decompiled by Procyon v0.5.36
// 

package co.aikar.util;

import java.util.function.Function;
import java.util.function.BiFunction;
import java.util.function.BiConsumer;
import java.util.Collection;
import java.util.Set;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import java.util.Map;

public interface DelegatingMap<K, V> extends Map<K, V>
{
    Map<K, V> delegate(final boolean p0);
    
    default int size() {
        return this.delegate(true).size();
    }
    
    default boolean isEmpty() {
        return this.delegate(true).isEmpty();
    }
    
    default boolean containsKey(final Object key) {
        return this.delegate(true).containsKey(key);
    }
    
    default boolean containsValue(final Object value) {
        return this.delegate(true).containsValue(value);
    }
    
    default V get(final Object key) {
        return this.delegate(true).get(key);
    }
    
    @Nullable
    default V put(final K key, final V value) {
        return this.delegate(false).put(key, value);
    }
    
    default V remove(final Object key) {
        return this.delegate(false).remove(key);
    }
    
    default void putAll(@NotNull final Map<? extends K, ? extends V> m) {
        this.delegate(false).putAll(m);
    }
    
    default void clear() {
        this.delegate(false).clear();
    }
    
    @NotNull
    default Set<K> keySet() {
        return this.delegate(false).keySet();
    }
    
    @NotNull
    default Collection<V> values() {
        return this.delegate(false).values();
    }
    
    @NotNull
    default Set<Entry<K, V>> entrySet() {
        return this.delegate(false).entrySet();
    }
    
    default V getOrDefault(final Object key, final V defaultValue) {
        return this.delegate(true).getOrDefault(key, defaultValue);
    }
    
    default void forEach(final BiConsumer<? super K, ? super V> action) {
        this.delegate(true).forEach(action);
    }
    
    default void replaceAll(final BiFunction<? super K, ? super V, ? extends V> function) {
        this.delegate(false).replaceAll(function);
    }
    
    @Nullable
    default V putIfAbsent(final K key, final V value) {
        return this.delegate(false).putIfAbsent(key, value);
    }
    
    default boolean remove(final Object key, final Object value) {
        return this.delegate(false).remove(key, value);
    }
    
    default boolean replace(final K key, final V oldValue, final V newValue) {
        return this.delegate(false).replace(key, oldValue, newValue);
    }
    
    @Nullable
    default V replace(final K key, final V value) {
        return this.delegate(false).replace(key, value);
    }
    
    default V computeIfAbsent(final K key, final Function<? super K, ? extends V> mappingFunction) {
        return this.delegate(false).computeIfAbsent(key, mappingFunction);
    }
    
    default V computeIfPresent(final K key, final BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        return this.delegate(false).computeIfPresent(key, remappingFunction);
    }
    
    default V compute(final K key, final BiFunction<? super K, ? super V, ? extends V> remappingFunction) {
        return this.delegate(false).compute(key, remappingFunction);
    }
    
    default V merge(final K key, final V value, final BiFunction<? super V, ? super V, ? extends V> remappingFunction) {
        return this.delegate(false).merge(key, value, remappingFunction);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.jodah.expiringmap;

public enum ExpirationPolicy
{
    ACCESSED, 
    CREATED;
}

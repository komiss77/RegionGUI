// 
// Decompiled by Procyon v0.5.36
// 

package net.jodah.expiringmap;

public interface ExpirationListener<K, V>
{
    void expired(final K p0, final V p1);
}

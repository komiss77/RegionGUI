// 
// Decompiled by Procyon v0.5.36
// 

package net.jodah.expiringmap;

public interface EntryLoader<K, V>
{
    V load(final K p0);
}

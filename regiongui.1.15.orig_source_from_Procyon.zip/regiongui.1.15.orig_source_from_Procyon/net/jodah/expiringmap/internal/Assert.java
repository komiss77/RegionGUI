// 
// Decompiled by Procyon v0.5.36
// 

package net.jodah.expiringmap.internal;

import java.util.NoSuchElementException;

public final class Assert
{
    private Assert() {
    }
    
    public static <T> T notNull(final T t, final String str) {
        if (t == null) {
            throw new NullPointerException(str + " cannot be null");
        }
        return t;
    }
    
    public static void operation(final boolean b, final String message) {
        if (!b) {
            throw new UnsupportedOperationException(message);
        }
    }
    
    public static void state(final boolean b, final String format, final Object... args) {
        if (!b) {
            throw new IllegalStateException(String.format(format, args));
        }
    }
    
    public static void element(final Object o, final Object o2) {
        if (o == null) {
            throw new NoSuchElementException(o2.toString());
        }
    }
}

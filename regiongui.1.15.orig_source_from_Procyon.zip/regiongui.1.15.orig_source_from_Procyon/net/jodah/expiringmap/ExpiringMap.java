// 
// Decompiled by Procyon v0.5.36
// 

package net.jodah.expiringmap;

import java.util.TreeSet;
import java.util.SortedSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.ArrayList;
import java.util.concurrent.Future;
import java.util.NoSuchElementException;
import java.lang.ref.WeakReference;
import java.util.AbstractCollection;
import java.util.AbstractSet;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import java.util.Collection;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.Executors;
import net.jodah.expiringmap.internal.NamedThreadFactory;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import net.jodah.expiringmap.internal.Assert;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.atomic.AtomicLong;
import java.util.List;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ConcurrentMap;

public class ExpiringMap<K, V> implements ConcurrentMap<K, V>
{
    static volatile ScheduledExecutorService EXPIRER;
    static volatile ThreadPoolExecutor LISTENER_SERVICE;
    static ThreadFactory THREAD_FACTORY;
    List<ExpirationListener<K, V>> expirationListeners;
    List<ExpirationListener<K, V>> asyncExpirationListeners;
    private AtomicLong expirationNanos;
    private int maxSize;
    private final AtomicReference<ExpirationPolicy> expirationPolicy;
    private final EntryLoader<? super K, ? extends V> entryLoader;
    private final ExpiringEntryLoader<? super K, ? extends V> expiringEntryLoader;
    private final ReadWriteLock readWriteLock;
    private final Lock readLock;
    private final Lock writeLock;
    private final EntryMap<K, V> entries;
    private final boolean variableExpiration;
    
    public static void setThreadFactory(final ThreadFactory threadFactory) {
        ExpiringMap.THREAD_FACTORY = Assert.notNull(threadFactory, "threadFactory");
    }
    
    private ExpiringMap(final Builder<K, V> builder) {
        this.readWriteLock = new ReentrantReadWriteLock();
        this.readLock = this.readWriteLock.readLock();
        this.writeLock = this.readWriteLock.writeLock();
        if (ExpiringMap.EXPIRER == null) {
            synchronized (ExpiringMap.class) {
                if (ExpiringMap.EXPIRER == null) {
                    ExpiringMap.EXPIRER = Executors.newSingleThreadScheduledExecutor((ExpiringMap.THREAD_FACTORY == null) ? new NamedThreadFactory("ExpiringMap-Expirer") : ExpiringMap.THREAD_FACTORY);
                }
            }
        }
        if (ExpiringMap.LISTENER_SERVICE == null && ((Builder<Object, Object>)builder).asyncExpirationListeners != null) {
            synchronized (ExpiringMap.class) {
                if (ExpiringMap.LISTENER_SERVICE == null) {
                    ExpiringMap.LISTENER_SERVICE = (ThreadPoolExecutor)Executors.newCachedThreadPool((ExpiringMap.THREAD_FACTORY == null) ? new NamedThreadFactory("ExpiringMap-Listener-%s") : ExpiringMap.THREAD_FACTORY);
                }
            }
        }
        this.variableExpiration = ((Builder<Object, Object>)builder).variableExpiration;
        this.entries = (EntryMap<K, V>)(this.variableExpiration ? new EntryTreeHashMap<Object, Object>() : new EntryLinkedHashMap<Object, Object>());
        if (((Builder<Object, Object>)builder).expirationListeners != null) {
            this.expirationListeners = new CopyOnWriteArrayList<ExpirationListener<K, V>>(((Builder<Object, Object>)builder).expirationListeners);
        }
        if (((Builder<Object, Object>)builder).asyncExpirationListeners != null) {
            this.asyncExpirationListeners = new CopyOnWriteArrayList<ExpirationListener<K, V>>(((Builder<Object, Object>)builder).asyncExpirationListeners);
        }
        this.expirationPolicy = new AtomicReference<ExpirationPolicy>(((Builder<Object, Object>)builder).expirationPolicy);
        this.expirationNanos = new AtomicLong(TimeUnit.NANOSECONDS.convert(((Builder<Object, Object>)builder).duration, ((Builder<Object, Object>)builder).timeUnit));
        this.maxSize = ((Builder<Object, Object>)builder).maxSize;
        this.entryLoader = (EntryLoader<? super K, ? extends V>)((Builder<Object, Object>)builder).entryLoader;
        this.expiringEntryLoader = (ExpiringEntryLoader<? super K, ? extends V>)((Builder<Object, Object>)builder).expiringEntryLoader;
    }
    
    public static Builder<Object, Object> builder() {
        return new Builder<Object, Object>();
    }
    
    public static <K, V> ExpiringMap<K, V> create() {
        return new ExpiringMap<K, V>((Builder<K, V>)builder());
    }
    
    public synchronized void addExpirationListener(final ExpirationListener<K, V> expirationListener) {
        Assert.notNull(expirationListener, "listener");
        if (this.expirationListeners == null) {
            this.expirationListeners = new CopyOnWriteArrayList<ExpirationListener<K, V>>();
        }
        this.expirationListeners.add(expirationListener);
    }
    
    public synchronized void addAsyncExpirationListener(final ExpirationListener<K, V> expirationListener) {
        Assert.notNull(expirationListener, "listener");
        if (this.asyncExpirationListeners == null) {
            this.asyncExpirationListeners = new CopyOnWriteArrayList<ExpirationListener<K, V>>();
        }
        this.asyncExpirationListeners.add(expirationListener);
    }
    
    @Override
    public void clear() {
        this.writeLock.lock();
        try {
            final Iterator<ExpiringEntry> iterator = this.entries.values().iterator();
            while (iterator.hasNext()) {
                iterator.next().cancel();
            }
            this.entries.clear();
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    @Override
    public boolean containsKey(final Object o) {
        this.readLock.lock();
        try {
            return this.entries.containsKey(o);
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    @Override
    public boolean containsValue(final Object o) {
        this.readLock.lock();
        try {
            return this.entries.containsValue(o);
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    @Override
    public Set<Map.Entry<K, V>> entrySet() {
        return new AbstractSet<Map.Entry<K, V>>() {
            @Override
            public void clear() {
                ExpiringMap.this.clear();
            }
            
            @Override
            public boolean contains(final Object o) {
                return o instanceof Map.Entry && ExpiringMap.this.containsKey(((Map.Entry)o).getKey());
            }
            
            @Override
            public Iterator<Map.Entry<K, V>> iterator() {
                return (Iterator<Map.Entry<K, V>>)((ExpiringMap.this.entries instanceof EntryLinkedHashMap) ? (EntryLinkedHashMap)ExpiringMap.this.entries.new EntryIterator() : (EntryTreeHashMap)ExpiringMap.this.entries.new EntryIterator());
            }
            
            @Override
            public boolean remove(final Object o) {
                return o instanceof Map.Entry && ExpiringMap.this.remove(((Map.Entry)o).getKey()) != null;
            }
            
            @Override
            public int size() {
                return ExpiringMap.this.size();
            }
        };
    }
    
    @Override
    public boolean equals(final Object obj) {
        this.readLock.lock();
        try {
            return this.entries.equals(obj);
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    @Override
    public V get(final Object o) {
        final ExpiringEntry<K, V> entry = this.getEntry(o);
        if (entry == null) {
            return this.load(o);
        }
        if (ExpirationPolicy.ACCESSED.equals(entry.expirationPolicy.get())) {
            this.resetEntry(entry, false);
        }
        return entry.getValue();
    }
    
    private V load(final K k) {
        if (this.entryLoader == null && this.expiringEntryLoader == null) {
            return null;
        }
        this.writeLock.lock();
        try {
            final ExpiringEntry<K, Object> entry = this.getEntry(k);
            if (entry != null) {
                return (V)entry.getValue();
            }
            if (this.entryLoader != null) {
                final V load = (V)this.entryLoader.load((Object)k);
                this.put(k, load);
                return load;
            }
            final ExpiringValue<? extends V> load2 = this.expiringEntryLoader.load((Object)k);
            if (load2 == null) {
                this.put(k, null);
                return null;
            }
            this.put(k, load2.getValue(), (load2.getExpirationPolicy() == null) ? this.expirationPolicy.get() : load2.getExpirationPolicy(), (load2.getTimeUnit() == null) ? this.expirationNanos.get() : load2.getDuration(), (load2.getTimeUnit() == null) ? TimeUnit.NANOSECONDS : load2.getTimeUnit());
            return (V)load2.getValue();
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    public long getExpiration() {
        return TimeUnit.NANOSECONDS.toMillis(this.expirationNanos.get());
    }
    
    public long getExpiration(final K k) {
        Assert.notNull(k, "key");
        final ExpiringEntry<K, V> entry = this.getEntry(k);
        Assert.element(entry, k);
        return TimeUnit.NANOSECONDS.toMillis(entry.expirationNanos.get());
    }
    
    public ExpirationPolicy getExpirationPolicy(final K k) {
        Assert.notNull(k, "key");
        final ExpiringEntry<K, V> entry = this.getEntry(k);
        Assert.element(entry, k);
        return entry.expirationPolicy.get();
    }
    
    public long getExpectedExpiration(final K k) {
        Assert.notNull(k, "key");
        final ExpiringEntry<K, V> entry = this.getEntry(k);
        Assert.element(entry, k);
        return TimeUnit.NANOSECONDS.toMillis(entry.expectedExpiration.get() - System.nanoTime());
    }
    
    public int getMaxSize() {
        return this.maxSize;
    }
    
    @Override
    public int hashCode() {
        this.readLock.lock();
        try {
            return this.entries.hashCode();
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    @Override
    public boolean isEmpty() {
        this.readLock.lock();
        try {
            return this.entries.isEmpty();
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    @Override
    public Set<K> keySet() {
        return new AbstractSet<K>() {
            @Override
            public void clear() {
                ExpiringMap.this.clear();
            }
            
            @Override
            public boolean contains(final Object o) {
                return ExpiringMap.this.containsKey(o);
            }
            
            @Override
            public Iterator<K> iterator() {
                return (Iterator<K>)((ExpiringMap.this.entries instanceof EntryLinkedHashMap) ? (EntryLinkedHashMap)ExpiringMap.this.entries.new KeyIterator() : (EntryTreeHashMap)ExpiringMap.this.entries.new KeyIterator());
            }
            
            @Override
            public boolean remove(final Object o) {
                return ExpiringMap.this.remove(o) != null;
            }
            
            @Override
            public int size() {
                return ExpiringMap.this.size();
            }
        };
    }
    
    @Override
    public V put(final K k, final V v) {
        Assert.notNull(k, "key");
        return this.putInternal(k, v, this.expirationPolicy.get(), this.expirationNanos.get());
    }
    
    public V put(final K k, final V v, final ExpirationPolicy expirationPolicy) {
        return this.put(k, v, expirationPolicy, this.expirationNanos.get(), TimeUnit.NANOSECONDS);
    }
    
    public V put(final K k, final V v, final long n, final TimeUnit timeUnit) {
        return this.put(k, v, this.expirationPolicy.get(), n, timeUnit);
    }
    
    public V put(final K k, final V v, final ExpirationPolicy expirationPolicy, final long sourceDuration, final TimeUnit sourceUnit) {
        Assert.notNull(k, "key");
        Assert.notNull(expirationPolicy, "expirationPolicy");
        Assert.notNull(sourceUnit, "timeUnit");
        Assert.operation(this.variableExpiration, "Variable expiration is not enabled");
        return this.putInternal(k, v, expirationPolicy, TimeUnit.NANOSECONDS.convert(sourceDuration, sourceUnit));
    }
    
    @Override
    public void putAll(final Map<? extends K, ? extends V> map) {
        Assert.notNull(map, "map");
        final long value = this.expirationNanos.get();
        final ExpirationPolicy expirationPolicy = this.expirationPolicy.get();
        this.writeLock.lock();
        try {
            for (final Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
                this.putInternal(entry.getKey(), (V)entry.getValue(), expirationPolicy, value);
            }
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    @Override
    public V putIfAbsent(final K k, final V v) {
        Assert.notNull(k, "key");
        this.writeLock.lock();
        try {
            if (!this.entries.containsKey(k)) {
                return (V)this.putInternal(k, v, this.expirationPolicy.get(), this.expirationNanos.get());
            }
            return (V)this.entries.get(k).getValue();
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    @Override
    public V remove(final Object o) {
        Assert.notNull(o, "key");
        this.writeLock.lock();
        try {
            final ExpiringEntry expiringEntry = this.entries.remove(o);
            if (expiringEntry == null) {
                return null;
            }
            if (expiringEntry.cancel()) {
                this.scheduleEntry(this.entries.first());
            }
            return expiringEntry.getValue();
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    @Override
    public boolean remove(final Object o, final Object obj) {
        Assert.notNull(o, "key");
        this.writeLock.lock();
        try {
            final ExpiringEntry<K, Object> expiringEntry = this.entries.get(o);
            if (expiringEntry != null && expiringEntry.getValue().equals(obj)) {
                this.entries.remove(o);
                if (expiringEntry.cancel()) {
                    this.scheduleEntry(this.entries.first());
                }
                return true;
            }
            return false;
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    @Override
    public V replace(final K k, final V v) {
        Assert.notNull(k, "key");
        this.writeLock.lock();
        try {
            if (this.entries.containsKey(k)) {
                return (V)this.putInternal(k, v, this.expirationPolicy.get(), this.expirationNanos.get());
            }
            return null;
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    @Override
    public boolean replace(final K k, final V obj, final V v) {
        Assert.notNull(k, "key");
        this.writeLock.lock();
        try {
            final ExpiringEntry<K, Object> expiringEntry = this.entries.get(k);
            if (expiringEntry != null && expiringEntry.getValue().equals(obj)) {
                this.putInternal(k, v, this.expirationPolicy.get(), this.expirationNanos.get());
                return true;
            }
            return false;
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    public void removeExpirationListener(final ExpirationListener<K, V> obj) {
        Assert.notNull(obj, "listener");
        for (int i = 0; i < this.expirationListeners.size(); ++i) {
            if (this.expirationListeners.get(i).equals(obj)) {
                this.expirationListeners.remove(i);
                return;
            }
        }
    }
    
    public void removeAsyncExpirationListener(final ExpirationListener<K, V> obj) {
        Assert.notNull(obj, "listener");
        for (int i = 0; i < this.asyncExpirationListeners.size(); ++i) {
            if (this.asyncExpirationListeners.get(i).equals(obj)) {
                this.asyncExpirationListeners.remove(i);
                return;
            }
        }
    }
    
    public void resetExpiration(final K k) {
        Assert.notNull(k, "key");
        final ExpiringEntry<K, V> entry = this.getEntry(k);
        if (entry != null) {
            this.resetEntry(entry, false);
        }
    }
    
    public void setExpiration(final K k, final long sourceDuration, final TimeUnit sourceUnit) {
        Assert.notNull(k, "key");
        Assert.notNull(sourceUnit, "timeUnit");
        Assert.operation(this.variableExpiration, "Variable expiration is not enabled");
        this.writeLock.lock();
        try {
            final ExpiringEntry<K, V> expiringEntry = this.entries.get(k);
            if (expiringEntry != null) {
                expiringEntry.expirationNanos.set(TimeUnit.NANOSECONDS.convert(sourceDuration, sourceUnit));
                this.resetEntry(expiringEntry, true);
            }
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    public void setExpiration(final long sourceDuration, final TimeUnit sourceUnit) {
        Assert.notNull(sourceUnit, "timeUnit");
        Assert.operation(this.variableExpiration, "Variable expiration is not enabled");
        this.expirationNanos.set(TimeUnit.NANOSECONDS.convert(sourceDuration, sourceUnit));
    }
    
    public void setExpirationPolicy(final ExpirationPolicy newValue) {
        Assert.notNull(newValue, "expirationPolicy");
        this.expirationPolicy.set(newValue);
    }
    
    public void setExpirationPolicy(final K k, final ExpirationPolicy newValue) {
        Assert.notNull(k, "key");
        Assert.notNull(newValue, "expirationPolicy");
        Assert.operation(this.variableExpiration, "Variable expiration is not enabled");
        final ExpiringEntry<K, V> entry = this.getEntry(k);
        if (entry != null) {
            entry.expirationPolicy.set(newValue);
        }
    }
    
    public void setMaxSize(final int maxSize) {
        Assert.operation(maxSize > 0, "maxSize");
        this.maxSize = maxSize;
    }
    
    @Override
    public int size() {
        this.readLock.lock();
        try {
            return this.entries.size();
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    @Override
    public String toString() {
        this.readLock.lock();
        try {
            return this.entries.toString();
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    @Override
    public Collection<V> values() {
        return new AbstractCollection<V>() {
            @Override
            public void clear() {
                ExpiringMap.this.clear();
            }
            
            @Override
            public boolean contains(final Object o) {
                return ExpiringMap.this.containsValue(o);
            }
            
            @Override
            public Iterator<V> iterator() {
                return (Iterator<V>)((ExpiringMap.this.entries instanceof EntryLinkedHashMap) ? (EntryLinkedHashMap)ExpiringMap.this.entries.new ValueIterator() : (EntryTreeHashMap)ExpiringMap.this.entries.new ValueIterator());
            }
            
            @Override
            public int size() {
                return ExpiringMap.this.size();
            }
        };
    }
    
    void notifyListeners(final ExpiringEntry<K, V> expiringEntry) {
        if (this.asyncExpirationListeners != null) {
            final Iterator<ExpirationListener<K, V>> iterator = this.asyncExpirationListeners.iterator();
            while (iterator.hasNext()) {
                ExpiringMap.LISTENER_SERVICE.execute(new Runnable() {
                    final /* synthetic */ ExpirationListener val$listener = iterator.next();
                    
                    @Override
                    public void run() {
                        try {
                            this.val$listener.expired(expiringEntry.key, expiringEntry.getValue());
                        }
                        catch (Exception ex) {}
                    }
                });
            }
        }
        if (this.expirationListeners != null) {
            for (final ExpirationListener<K, V> expirationListener : this.expirationListeners) {
                try {
                    expirationListener.expired(expiringEntry.key, expiringEntry.getValue());
                }
                catch (Exception ex) {}
            }
        }
    }
    
    ExpiringEntry<K, V> getEntry(final Object o) {
        this.readLock.lock();
        try {
            return this.entries.get(o);
        }
        finally {
            this.readLock.unlock();
        }
    }
    
    V putInternal(final K k, final V v, final ExpirationPolicy expirationPolicy, final long initialValue) {
        this.writeLock.lock();
        try {
            final ExpiringEntry expiringEntry = this.entries.get(k);
            Object value = null;
            if (expiringEntry == null) {
                final ExpiringEntry<K, V> expiringEntry2 = new ExpiringEntry<K, V>(k, v, this.variableExpiration ? new AtomicReference<ExpirationPolicy>(expirationPolicy) : this.expirationPolicy, this.variableExpiration ? new AtomicLong(initialValue) : this.expirationNanos);
                if (this.entries.size() >= this.maxSize) {
                    final ExpiringEntry<K, V> first = this.entries.first();
                    this.entries.remove(first.key);
                    this.notifyListeners(first);
                }
                this.entries.put(k, expiringEntry2);
                if (this.entries.size() == 1 || this.entries.first().equals(expiringEntry2)) {
                    this.scheduleEntry(expiringEntry2);
                }
            }
            else {
                value = expiringEntry.getValue();
                if (!ExpirationPolicy.ACCESSED.equals(expirationPolicy) && ((value == null && v == null) || (value != null && value.equals(v)))) {
                    return v;
                }
                expiringEntry.setValue(v);
                this.resetEntry(expiringEntry, false);
            }
            return (V)value;
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    void resetEntry(final ExpiringEntry<K, V> expiringEntry, final boolean b) {
        this.writeLock.lock();
        try {
            final boolean cancel = expiringEntry.cancel();
            this.entries.reorder(expiringEntry);
            if (cancel || b) {
                this.scheduleEntry(this.entries.first());
            }
        }
        finally {
            this.writeLock.unlock();
        }
    }
    
    void scheduleEntry(final ExpiringEntry<K, V> referent) {
        if (referent == null || referent.scheduled) {
            return;
        }
        synchronized (referent) {
            if (referent.scheduled) {
                return;
            }
            referent.schedule(ExpiringMap.EXPIRER.schedule(new Runnable() {
                final /* synthetic */ WeakReference val$entryReference = new WeakReference((T)referent);
                
                @Override
                public void run() {
                    final ExpiringEntry expiringEntry = (ExpiringEntry)this.val$entryReference.get();
                    ExpiringMap.this.writeLock.lock();
                    try {
                        if (expiringEntry != null && expiringEntry.scheduled) {
                            ExpiringMap.this.entries.remove(expiringEntry.key);
                            ExpiringMap.this.notifyListeners(expiringEntry);
                        }
                        try {
                            final Iterator<ExpiringEntry<K, V>> valuesIterator = (Iterator<ExpiringEntry<K, V>>)ExpiringMap.this.entries.valuesIterator();
                            int n = 1;
                            while (valuesIterator.hasNext() && n != 0) {
                                final ExpiringEntry<K, V> expiringEntry2 = valuesIterator.next();
                                if (expiringEntry2.expectedExpiration.get() <= System.nanoTime()) {
                                    valuesIterator.remove();
                                    ExpiringMap.this.notifyListeners(expiringEntry2);
                                }
                                else {
                                    ExpiringMap.this.scheduleEntry(expiringEntry2);
                                    n = 0;
                                }
                            }
                        }
                        catch (NoSuchElementException ex) {}
                    }
                    finally {
                        ExpiringMap.this.writeLock.unlock();
                    }
                }
            }, referent.expectedExpiration.get() - System.nanoTime(), TimeUnit.NANOSECONDS));
        }
    }
    
    private static <K, V> Map.Entry<K, V> mapEntryFor(final ExpiringEntry<K, V> expiringEntry) {
        return new Map.Entry<K, V>() {
            @Override
            public K getKey() {
                return expiringEntry.key;
            }
            
            @Override
            public V getValue() {
                return expiringEntry.value;
            }
            
            @Override
            public V setValue(final V v) {
                throw new UnsupportedOperationException();
            }
        };
    }
    
    public static final class Builder<K, V>
    {
        private ExpirationPolicy expirationPolicy;
        private List<ExpirationListener<K, V>> expirationListeners;
        private List<ExpirationListener<K, V>> asyncExpirationListeners;
        private TimeUnit timeUnit;
        private boolean variableExpiration;
        private long duration;
        private int maxSize;
        private EntryLoader<K, V> entryLoader;
        private ExpiringEntryLoader<K, V> expiringEntryLoader;
        
        private Builder() {
            this.expirationPolicy = ExpirationPolicy.CREATED;
            this.timeUnit = TimeUnit.SECONDS;
            this.duration = 60L;
            this.maxSize = Integer.MAX_VALUE;
        }
        
        public <K1 extends K, V1 extends V> ExpiringMap<K1, V1> build() {
            return new ExpiringMap<K1, V1>(this, null);
        }
        
        public Builder<K, V> expiration(final long duration, final TimeUnit timeUnit) {
            this.duration = duration;
            this.timeUnit = Assert.notNull(timeUnit, "timeUnit");
            return this;
        }
        
        public Builder<K, V> maxSize(final int maxSize) {
            Assert.operation(maxSize > 0, "maxSize");
            this.maxSize = maxSize;
            return this;
        }
        
        public <K1 extends K, V1 extends V> Builder<K1, V1> entryLoader(final EntryLoader<? super K1, ? super V1> entryLoader) {
            this.assertNoLoaderSet();
            this.entryLoader = Assert.notNull(entryLoader, "loader");
            return (Builder<K1, V1>)this;
        }
        
        public <K1 extends K, V1 extends V> Builder<K1, V1> expiringEntryLoader(final ExpiringEntryLoader<? super K1, ? super V1> expiringEntryLoader) {
            this.assertNoLoaderSet();
            this.expiringEntryLoader = Assert.notNull(expiringEntryLoader, "loader");
            this.variableExpiration();
            return (Builder<K1, V1>)this;
        }
        
        public <K1 extends K, V1 extends V> Builder<K1, V1> expirationListener(final ExpirationListener<? super K1, ? super V1> expirationListener) {
            Assert.notNull(expirationListener, "listener");
            if (this.expirationListeners == null) {
                this.expirationListeners = new ArrayList<ExpirationListener<K, V>>();
            }
            this.expirationListeners.add((ExpirationListener<K, V>)expirationListener);
            return (Builder<K1, V1>)this;
        }
        
        public <K1 extends K, V1 extends V> Builder<K1, V1> expirationListeners(final List<ExpirationListener<? super K1, ? super V1>> list) {
            Assert.notNull(list, "listeners");
            if (this.expirationListeners == null) {
                this.expirationListeners = new ArrayList<ExpirationListener<K, V>>(list.size());
            }
            final Iterator<ExpirationListener<K, V>> iterator = list.iterator();
            while (iterator.hasNext()) {
                this.expirationListeners.add(iterator.next());
            }
            return (Builder<K1, V1>)this;
        }
        
        public <K1 extends K, V1 extends V> Builder<K1, V1> asyncExpirationListener(final ExpirationListener<? super K1, ? super V1> expirationListener) {
            Assert.notNull(expirationListener, "listener");
            if (this.asyncExpirationListeners == null) {
                this.asyncExpirationListeners = new ArrayList<ExpirationListener<K, V>>();
            }
            this.asyncExpirationListeners.add((ExpirationListener<K, V>)expirationListener);
            return (Builder<K1, V1>)this;
        }
        
        public <K1 extends K, V1 extends V> Builder<K1, V1> asyncExpirationListeners(final List<ExpirationListener<? super K1, ? super V1>> list) {
            Assert.notNull(list, "listeners");
            if (this.asyncExpirationListeners == null) {
                this.asyncExpirationListeners = new ArrayList<ExpirationListener<K, V>>(list.size());
            }
            final Iterator<ExpirationListener<K, V>> iterator = list.iterator();
            while (iterator.hasNext()) {
                this.asyncExpirationListeners.add(iterator.next());
            }
            return (Builder<K1, V1>)this;
        }
        
        public Builder<K, V> expirationPolicy(final ExpirationPolicy expirationPolicy) {
            this.expirationPolicy = Assert.notNull(expirationPolicy, "expirationPolicy");
            return this;
        }
        
        public Builder<K, V> variableExpiration() {
            this.variableExpiration = true;
            return this;
        }
        
        private void assertNoLoaderSet() {
            Assert.state(this.entryLoader == null && this.expiringEntryLoader == null, "Either entryLoader or expiringEntryLoader may be set, not both", new Object[0]);
        }
    }
    
    private static class EntryLinkedHashMap<K, V> extends LinkedHashMap<K, ExpiringEntry<K, V>> implements EntryMap<K, V>
    {
        private static final long serialVersionUID = 1L;
        
        @Override
        public boolean containsValue(final Object o) {
            final Iterator<ExpiringEntry<K, V>> iterator = this.values().iterator();
            while (iterator.hasNext()) {
                final V value = iterator.next().value;
                if (value == o || (o != null && o.equals(value))) {
                    return true;
                }
            }
            return false;
        }
        
        @Override
        public ExpiringEntry<K, V> first() {
            return this.isEmpty() ? null : this.values().iterator().next();
        }
        
        @Override
        public void reorder(final ExpiringEntry<K, V> value) {
            this.remove(value.key);
            value.resetExpiration();
            this.put(value.key, value);
        }
        
        @Override
        public Iterator<ExpiringEntry<K, V>> valuesIterator() {
            return this.values().iterator();
        }
        
        abstract class AbstractHashIterator
        {
            private final Iterator<Map.Entry<K, ExpiringEntry<K, V>>> iterator;
            private ExpiringEntry<K, V> next;
            
            AbstractHashIterator() {
                this.iterator = (Iterator<Map.Entry<K, ExpiringEntry<K, V>>>)EntryLinkedHashMap.this.entrySet().iterator();
            }
            
            public boolean hasNext() {
                return this.iterator.hasNext();
            }
            
            public ExpiringEntry<K, V> getNext() {
                return this.next = this.iterator.next().getValue();
            }
            
            public void remove() {
                this.iterator.remove();
            }
        }
        
        final class KeyIterator extends AbstractHashIterator implements Iterator<K>
        {
            @Override
            public final K next() {
                return this.getNext().key;
            }
        }
        
        final class ValueIterator extends AbstractHashIterator implements Iterator<V>
        {
            @Override
            public final V next() {
                return this.getNext().value;
            }
        }
        
        public final class EntryIterator extends AbstractHashIterator implements Iterator<Map.Entry<K, V>>
        {
            @Override
            public final Map.Entry<K, V> next() {
                return (Map.Entry<K, V>)mapEntryFor((ExpiringEntry<Object, Object>)this.getNext());
            }
        }
    }
    
    private static class EntryTreeHashMap<K, V> extends HashMap<K, ExpiringEntry<K, V>> implements EntryMap<K, V>
    {
        private static final long serialVersionUID = 1L;
        SortedSet<ExpiringEntry<K, V>> sortedSet;
        
        private EntryTreeHashMap() {
            this.sortedSet = new TreeSet<ExpiringEntry<K, V>>();
        }
        
        @Override
        public void clear() {
            super.clear();
            this.sortedSet.clear();
        }
        
        @Override
        public boolean containsValue(final Object o) {
            final Iterator<ExpiringEntry<K, V>> iterator = this.values().iterator();
            while (iterator.hasNext()) {
                final V value = iterator.next().value;
                if (value == o || (o != null && o.equals(value))) {
                    return true;
                }
            }
            return false;
        }
        
        @Override
        public ExpiringEntry<K, V> first() {
            return this.sortedSet.isEmpty() ? null : this.sortedSet.first();
        }
        
        @Override
        public ExpiringEntry<K, V> put(final K key, final ExpiringEntry<K, V> value) {
            this.sortedSet.add(value);
            return super.put(key, value);
        }
        
        @Override
        public ExpiringEntry<K, V> remove(final Object key) {
            final ExpiringEntry<K, V> expiringEntry = super.remove(key);
            if (expiringEntry != null) {
                this.sortedSet.remove(expiringEntry);
            }
            return expiringEntry;
        }
        
        @Override
        public void reorder(final ExpiringEntry<K, V> expiringEntry) {
            this.sortedSet.remove(expiringEntry);
            expiringEntry.resetExpiration();
            this.sortedSet.add(expiringEntry);
        }
        
        @Override
        public Iterator<ExpiringEntry<K, V>> valuesIterator() {
            return new ExpiringEntryIterator();
        }
        
        abstract class AbstractHashIterator
        {
            private final Iterator<ExpiringEntry<K, V>> iterator;
            protected ExpiringEntry<K, V> next;
            
            AbstractHashIterator() {
                this.iterator = EntryTreeHashMap.this.sortedSet.iterator();
            }
            
            public boolean hasNext() {
                return this.iterator.hasNext();
            }
            
            public ExpiringEntry<K, V> getNext() {
                return this.next = this.iterator.next();
            }
            
            public void remove() {
                HashMap.this.remove(this.next.key);
                this.iterator.remove();
            }
        }
        
        final class ExpiringEntryIterator extends AbstractHashIterator implements Iterator<ExpiringEntry<K, V>>
        {
            @Override
            public final ExpiringEntry<K, V> next() {
                return this.getNext();
            }
        }
        
        final class KeyIterator extends AbstractHashIterator implements Iterator<K>
        {
            @Override
            public final K next() {
                return this.getNext().key;
            }
        }
        
        final class ValueIterator extends AbstractHashIterator implements Iterator<V>
        {
            @Override
            public final V next() {
                return this.getNext().value;
            }
        }
        
        final class EntryIterator extends AbstractHashIterator implements Iterator<Map.Entry<K, V>>
        {
            @Override
            public final Map.Entry<K, V> next() {
                return (Map.Entry<K, V>)mapEntryFor((ExpiringEntry<Object, Object>)this.getNext());
            }
        }
    }
    
    static class ExpiringEntry<K, V> implements Comparable<ExpiringEntry<K, V>>
    {
        final AtomicLong expirationNanos;
        final AtomicLong expectedExpiration;
        final AtomicReference<ExpirationPolicy> expirationPolicy;
        final K key;
        volatile Future<?> entryFuture;
        V value;
        volatile boolean scheduled;
        
        ExpiringEntry(final K key, final V value, final AtomicReference<ExpirationPolicy> expirationPolicy, final AtomicLong expirationNanos) {
            this.key = key;
            this.value = value;
            this.expirationPolicy = expirationPolicy;
            this.expirationNanos = expirationNanos;
            this.expectedExpiration = new AtomicLong();
            this.resetExpiration();
        }
        
        @Override
        public int compareTo(final ExpiringEntry<K, V> expiringEntry) {
            if (this.key.equals(expiringEntry.key)) {
                return 0;
            }
            return (this.expectedExpiration.get() < expiringEntry.expectedExpiration.get()) ? -1 : 1;
        }
        
        @Override
        public int hashCode() {
            return 31 * (31 * 1 + ((this.key == null) ? 0 : this.key.hashCode())) + ((this.value == null) ? 0 : this.value.hashCode());
        }
        
        @Override
        public boolean equals(final Object o) {
            if (this == o) {
                return true;
            }
            if (o == null) {
                return false;
            }
            if (this.getClass() != o.getClass()) {
                return false;
            }
            final ExpiringEntry expiringEntry = (ExpiringEntry)o;
            if (!this.key.equals(expiringEntry.key)) {
                return false;
            }
            if (this.value == null) {
                if (expiringEntry.value != null) {
                    return false;
                }
            }
            else if (!this.value.equals(expiringEntry.value)) {
                return false;
            }
            return true;
        }
        
        @Override
        public String toString() {
            return this.value.toString();
        }
        
        synchronized boolean cancel() {
            final boolean scheduled = this.scheduled;
            if (this.entryFuture != null) {
                this.entryFuture.cancel(false);
            }
            this.entryFuture = null;
            this.scheduled = false;
            return scheduled;
        }
        
        synchronized V getValue() {
            return this.value;
        }
        
        void resetExpiration() {
            this.expectedExpiration.set(this.expirationNanos.get() + System.nanoTime());
        }
        
        synchronized void schedule(final Future<?> entryFuture) {
            this.entryFuture = entryFuture;
            this.scheduled = true;
        }
        
        synchronized void setValue(final V value) {
            this.value = value;
        }
    }
    
    private interface EntryMap<K, V> extends Map<K, ExpiringEntry<K, V>>
    {
        ExpiringEntry<K, V> first();
        
        void reorder(final ExpiringEntry<K, V> p0);
        
        Iterator<ExpiringEntry<K, V>> valuesIterator();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.data.flags;

import org.bukkit.event.inventory.InventoryClickEvent;
import com.sk89q.worldguard.protection.flags.FlagContext;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Set;
import com.sk89q.worldguard.protection.flags.DoubleFlag;
import org.bukkit.ChatColor;
import net.crytec.regiongui.util.PlayerChatInput;
import com.sk89q.worldguard.protection.flags.InvalidFlagFormat;
import org.bukkit.plugin.Plugin;
import net.crytec.regiongui.RegionGUI;
import com.sk89q.worldedit.extension.platform.Actor;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import net.crytec.regiongui.Language;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import net.crytec.regiongui.libs.commons.utils.item.ItemBuilder;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.entity.Player;
import com.sk89q.worldguard.protection.flags.BooleanFlag;
import com.sk89q.worldguard.protection.flags.IntegerFlag;
import com.sk89q.worldguard.protection.flags.SetFlag;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.flags.StringFlag;
import org.bukkit.Bukkit;
import org.bukkit.permissions.PermissionDefault;
import org.bukkit.permissions.Permission;
import org.bukkit.Material;
import com.sk89q.worldguard.protection.flags.Flag;

public class FlagSetting implements Comparable<FlagSetting>
{
    private final Flag<?> flag;
    private final String id;
    private Material icon;
    private final FlagInputType inputType;
    private final Permission permission;
    private final String displayname;
    
    public FlagSetting(final String id, final Flag<?> flag, final Material icon, final String displayname) {
        this.icon = Material.PAPER;
        this.flag = flag;
        this.id = id;
        this.displayname = displayname;
        this.icon = icon;
        this.permission = new Permission("region.flagmenu." + this.id, "Enables the use of the " + id + " flag.", PermissionDefault.TRUE);
        try {
            Bukkit.getPluginManager().addPermission(this.permission);
        }
        catch (IllegalArgumentException ex) {}
        if (flag instanceof StringFlag) {
            this.inputType = FlagInputType.STRING;
        }
        else if (flag instanceof StateFlag) {
            this.inputType = FlagInputType.STATE;
        }
        else if (flag instanceof SetFlag) {
            this.inputType = FlagInputType.SET;
        }
        else if (flag instanceof IntegerFlag) {
            this.inputType = FlagInputType.INTEGER;
        }
        else if (flag instanceof BooleanFlag) {
            this.inputType = FlagInputType.BOOLEAN;
        }
        else {
            this.inputType = FlagInputType.UNKNOWN;
        }
    }
    
    public ClickableItem getButton(final Player player, final ProtectedRegion region, final InventoryContent contents) {
        final ItemBuilder name = new ItemBuilder(this.icon).name("\ufffd7" + this.getName());
        name.setItemFlag(ItemFlag.HIDE_ATTRIBUTES);
        name.setItemFlag(ItemFlag.HIDE_ENCHANTS);
        if (region.getFlags().containsKey(this.getFlag())) {
            name.enchantment(Enchantment.ARROW_INFINITE);
            if (this.inputType == FlagInputType.STATE) {
                name.name((region.getFlag((Flag)this.getFlag()) == StateFlag.State.DENY) ? ("\ufffdc" + this.getName()) : ("\ufffda" + this.getName()));
            }
        }
        name.lore("");
        name.lore(this.getCurrentValue(region));
        return new ClickableItem(name.build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.RIGHT && region.getFlags().containsKey(this.getFlag())) {
                region.setFlag((Flag)this.getFlag(), (Object)null);
                player.sendMessage(Language.FLAG_CLEARED.toString().replace("%flag%", this.getName()));
                contents.getHost().getProvider().reopen(player, contents);
            }
            else if (this.inputType == FlagInputType.STATE || this.inputType == FlagInputType.BOOLEAN) {
                this.switchState(player, region);
                contents.getHost().getProvider().reopen(player, contents);
            }
            else {
                player.closeInventory();
                player.sendMessage(Language.FLAG_INPUT_CHAT.toChatString().replace("%flag%", this.getName()));
                PlayerChatInput.get(player, value -> {
                    try {
                        setFlag(region, this.flag, (Actor)BukkitAdapter.adapt(player), value);
                        Bukkit.getScheduler().runTaskLater((Plugin)RegionGUI.getInstance(), () -> contents.getHost().getProvider().reopen(player, contents), 1L);
                    }
                    catch (InvalidFlagFormat invalidFlagFormat) {
                        player.sendMessage(invalidFlagFormat.getMessage());
                    }
                });
            }
        });
    }
    
    private void switchState(final Player player, final ProtectedRegion region) {
        if (this.inputType == FlagInputType.STATE) {
            final StateFlag stateFlag = (StateFlag)this.getFlag();
            if (region.getFlags().containsKey(this.getFlag())) {
                if (region.getFlag((Flag)stateFlag) == StateFlag.State.DENY) {
                    region.setFlag((Flag)stateFlag, (Object)StateFlag.State.ALLOW);
                    player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
                }
                else {
                    region.setFlag((Flag)stateFlag, (Object)StateFlag.State.DENY);
                    player.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
                }
            }
            else {
                region.setFlag((Flag)stateFlag, (Object)StateFlag.State.ALLOW);
                player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            }
        }
        else {
            final BooleanFlag booleanFlag = (BooleanFlag)this.getFlag();
            if (region.getFlags().containsKey(this.getFlag())) {
                if (!(boolean)region.getFlag((Flag)booleanFlag)) {
                    region.setFlag((Flag)booleanFlag, (Object)true);
                    player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
                }
                else {
                    region.setFlag((Flag)booleanFlag, (Object)false);
                    player.sendMessage(Language.FLAG_DENIED.toString().replace("%flag%", this.getName()));
                }
            }
            else {
                region.setFlag((Flag)booleanFlag, (Object)true);
                player.sendMessage(Language.FLAG_ALLOWED.toString().replace("%flag%", this.getName()));
            }
        }
    }
    
    public String getCurrentValue(final ProtectedRegion region) {
        if (!region.getFlags().containsKey(this.getFlag())) {
            return ChatColor.RED + "Flag not set";
        }
        switch (this.inputType) {
            case BOOLEAN: {
                return region.getFlag((Flag)this.getFlag()) ? "Yes" : "No";
            }
            case DOUBLE: {
                return "" + (double)region.getFlag((Flag)this.getFlag());
            }
            case INTEGER: {
                return "" + (int)region.getFlag((Flag)this.getFlag());
            }
            case SET: {
                return (String)((Set)region.getFlag((Flag)this.getFlag())).stream().collect(Collectors.joining(",", "[", "]"));
            }
            case STATE: {
                return (region.getFlag((Flag)this.getFlag()) == StateFlag.State.DENY) ? "false" : "true";
            }
            case STRING: {
                return ((String)region.getFlag((Flag)this.getFlag())).toString();
            }
            case UNKNOWN: {
                return ChatColor.GRAY + "Unknown";
            }
            default: {
                return "Unable to query flag value";
            }
        }
    }
    
    public void setIcon(final Material mat) {
        this.icon = mat;
    }
    
    public Material getIcon() {
        return this.icon;
    }
    
    public String getId() {
        return this.id;
    }
    
    public Flag<?> getFlag() {
        return this.flag;
    }
    
    protected static <V> void setFlag(final ProtectedRegion region, final Flag<V> flag, final Actor sender, final String value) {
        region.setFlag((Flag)flag, flag.parseInput(FlagContext.create().setSender(sender).setInput(value).setObject("region", (Object)region).build()));
    }
    
    public String getName() {
        return this.displayname;
    }
    
    @Override
    public int compareTo(final FlagSetting other) {
        return this.getId().compareTo(other.getId());
    }
    
    public Permission getPermission() {
        return this.permission;
    }
}

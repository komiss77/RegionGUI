// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.data.flags;

public enum FlagInputType
{
    SET, 
    STATE, 
    DOUBLE, 
    INTEGER, 
    BOOLEAN, 
    STRING, 
    UNKNOWN;
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui;

import net.crytec.regiongui.libs.acf.CommandExecutionContext;
import java.net.URLConnection;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import net.crytec.regiongui.libs.acf.BukkitCommandExecutionContext;
import java.io.IOException;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.RegisteredServiceProvider;
import java.util.Optional;
import org.bukkit.World;
import org.bukkit.ChatColor;
import net.crytec.regiongui.libs.acf.BukkitCommandIssuer;
import net.crytec.regiongui.libs.acf.InvalidCommandArgument;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.regiongui.commands.LandAdmin;
import net.crytec.regiongui.libs.acf.BaseCommand;
import net.crytec.regiongui.commands.LandCommand;
import net.crytec.regiongui.libs.acf.BukkitCommandManager;
import net.crytec.regiongui.libs.inventoryapi.InventoryAPI;
import net.crytec.regiongui.util.PlayerChatInput;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import java.io.File;
import net.crytec.regiongui.data.ClaimEntry;
import org.bukkit.configuration.serialization.ConfigurationSerialization;
import net.crytec.regiongui.data.RegionClaim;
import net.crytec.regiongui.manager.PlayerManager;
import net.crytec.regiongui.manager.ClaimManager;
import net.crytec.regiongui.manager.FlagManager;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.plugin.java.JavaPlugin;

public final class RegionGUI extends JavaPlugin
{
    private static RegionGUI instance;
    private Economy economy;
    private FlagManager flagManager;
    private ClaimManager claimManager;
    private PlayerManager playerManager;
    
    public void onLoad() {
        RegionGUI.instance = this;
        ConfigurationSerialization.registerClass((Class)RegionClaim.class, "Template");
        ConfigurationSerialization.registerClass((Class)ClaimEntry.class, "PlayerClaim");
        if (!this.getDataFolder().exists() && !this.getDataFolder().mkdir()) {
            this.getLogger().warning("Failed to create plugin directory!");
        }
        final File file = new File(this.getDataFolder(), "config.yml");
        try {
            if (!file.exists()) {
                file.createNewFile();
                this.saveResource("config.yml", true);
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
    
    public void onEnable() {
        loadConfig0();
        if (!this.setupEconomy()) {
            this.getLogger().severe("Unable to load RegionGUI - No Economy Plugin found.");
            Bukkit.getPluginManager().disablePlugin((Plugin)this);
            return;
        }
        this.loadLanguage();
        new PlayerChatInput(this);
        new InventoryAPI(this, false);
        this.flagManager = new FlagManager(this);
        this.claimManager = new ClaimManager(this);
        this.playerManager = new PlayerManager(this, this.claimManager);
        final BukkitCommandManager manager = new BukkitCommandManager((Plugin)this);
        this.setupCommands(manager);
        manager.registerCommand(new LandCommand(this, this.playerManager));
        manager.registerCommand(new LandAdmin(this));
        final Metrics metrics = new Metrics(this);
        metrics.addCustomChart(new Metrics.SimplePie("purges_enabled", () -> this.getConfig().getBoolean("deleteOnPurge") ? "Enabled" : "Disabled"));
        metrics.addCustomChart(new Metrics.SimplePie("preview_mode", () -> this.getConfig().getBoolean("enable_previewmode") ? "Enabled" : "Disabled"));
        metrics.addCustomChart(new Metrics.SimplePie("economy", () -> (this.economy.getName() != null) ? this.economy.getName() : "Unknown"));
    }
    
    public void onDisable() {
        if (this.getPlayerManager() != null) {
            this.getPlayerManager().saveOnDisable();
        }
        if (this.claimManager != null) {
            this.claimManager.save();
        }
    }
    
    private void setupCommands(final BukkitCommandManager manager) {
        final World world;
        final String str;
        final ProtectedRegion protectedRegion;
        final InvalidCommandArgument invalidCommandArgument;
        manager.getCommandContexts().registerContext(ProtectedRegion.class, bukkitCommandExecutionContext -> {
            bukkitCommandExecutionContext.getPlayer().getWorld();
            bukkitCommandExecutionContext.popFirstArg();
            WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(world)).getRegion(str);
            if (protectedRegion == null) {
                new InvalidCommandArgument("Unable to find a WorldGuard region with id " + str + " in your current world.");
                throw invalidCommandArgument;
            }
            else {
                return protectedRegion;
            }
        });
        final Optional<RegionClaim> optional;
        manager.getCommandContexts().registerContext(RegionClaim.class, commandExecutionContext -> {
            this.getClaimManager().getTemplates(commandExecutionContext.getIssuer().getPlayer().getWorld()).stream().filter(regionClaim -> ChatColor.stripColor(regionClaim.getDisplayname()).equals(commandExecutionContext.popFirstArg())).findFirst();
            if (!optional.isPresent()) {
                throw new InvalidCommandArgument("Could not find a template with that name in your current world.");
            }
            else {
                return (RegionClaim)optional.get();
            }
        });
    }
    
    private boolean setupEconomy() {
        if (this.getServer().getPluginManager().getPlugin("Vault") == null) {
            return false;
        }
        final RegisteredServiceProvider registration = this.getServer().getServicesManager().getRegistration((Class)Economy.class);
        if (registration == null) {
            return false;
        }
        this.economy = (Economy)registration.getProvider();
        return true;
    }
    
    public void loadLanguage() {
        final File file = new File(getInstance().getDataFolder(), "lang.yml");
        if (!file.exists()) {
            try {
                getInstance().getDataFolder().mkdir();
                file.createNewFile();
                final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file);
                loadConfiguration.save(file);
                Language.setFile(loadConfiguration);
            }
            catch (IOException ex2) {
                getInstance().getLogger().severe("Could not create language file!");
                Bukkit.getPluginManager().disablePlugin((Plugin)getInstance());
            }
        }
        final YamlConfiguration loadConfiguration2 = YamlConfiguration.loadConfiguration(file);
        for (final Language language : Language.values()) {
            if (loadConfiguration2.getString(language.getPath()) == null) {
                if (language.isArray()) {
                    loadConfiguration2.set(language.getPath(), (Object)language.getDefArray());
                }
                else {
                    loadConfiguration2.set(language.getPath(), (Object)language.getDefault());
                }
            }
        }
        Language.setFile(loadConfiguration2);
        try {
            loadConfiguration2.save(file);
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    public static RegionGUI getInstance() {
        return RegionGUI.instance;
    }
    
    public Economy getEconomy() {
        return this.economy;
    }
    
    public FlagManager getFlagManager() {
        return this.flagManager;
    }
    
    public ClaimManager getClaimManager() {
        return this.claimManager;
    }
    
    public PlayerManager getPlayerManager() {
        return this.playerManager;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

public class CharUtils
{
    private static final String[] CHAR_STRING_ARRAY;
    private static final char[] HEX_DIGITS;
    public static final char LF = '\n';
    public static final char CR = '\r';
    public static final char NUL = '\0';
    
    @Deprecated
    public static Character toCharacterObject(final char c) {
        return c;
    }
    
    public static Character toCharacterObject(final String s) {
        if (StringUtils.isEmpty(s)) {
            return null;
        }
        return s.charAt(0);
    }
    
    public static char toChar(final Character c) {
        Validate.isTrue(c != null, "The Character must not be null", new Object[0]);
        return c;
    }
    
    public static char toChar(final Character c, final char c2) {
        if (c == null) {
            return c2;
        }
        return c;
    }
    
    public static char toChar(final String s) {
        Validate.isTrue(StringUtils.isNotEmpty(s), "The String must not be empty", new Object[0]);
        return s.charAt(0);
    }
    
    public static char toChar(final String s, final char c) {
        if (StringUtils.isEmpty(s)) {
            return c;
        }
        return s.charAt(0);
    }
    
    public static int toIntValue(final char c) {
        if (!isAsciiNumeric(c)) {
            throw new IllegalArgumentException("The character " + c + " is not in the range '0' - '9'");
        }
        return c - '0';
    }
    
    public static int toIntValue(final char c, final int n) {
        if (!isAsciiNumeric(c)) {
            return n;
        }
        return c - '0';
    }
    
    public static int toIntValue(final Character c) {
        Validate.isTrue(c != null, "The character must not be null", new Object[0]);
        return toIntValue((char)c);
    }
    
    public static int toIntValue(final Character c, final int n) {
        if (c == null) {
            return n;
        }
        return toIntValue((char)c, n);
    }
    
    public static String toString(final char c) {
        if (c < '\u0080') {
            return CharUtils.CHAR_STRING_ARRAY[c];
        }
        return new String(new char[] { c });
    }
    
    public static String toString(final Character c) {
        if (c == null) {
            return null;
        }
        return toString((char)c);
    }
    
    public static String unicodeEscaped(final char c) {
        return "\\u" + CharUtils.HEX_DIGITS[c >> 12 & 0xF] + CharUtils.HEX_DIGITS[c >> 8 & 0xF] + CharUtils.HEX_DIGITS[c >> 4 & 0xF] + CharUtils.HEX_DIGITS[c & '\u000f'];
    }
    
    public static String unicodeEscaped(final Character c) {
        if (c == null) {
            return null;
        }
        return unicodeEscaped((char)c);
    }
    
    public static boolean isAscii(final char c) {
        return c < '\u0080';
    }
    
    public static boolean isAsciiPrintable(final char c) {
        return c >= ' ' && c < '\u007f';
    }
    
    public static boolean isAsciiControl(final char c) {
        return c < ' ' || c == '\u007f';
    }
    
    public static boolean isAsciiAlpha(final char c) {
        return isAsciiAlphaUpper(c) || isAsciiAlphaLower(c);
    }
    
    public static boolean isAsciiAlphaUpper(final char c) {
        return c >= 'A' && c <= 'Z';
    }
    
    public static boolean isAsciiAlphaLower(final char c) {
        return c >= 'a' && c <= 'z';
    }
    
    public static boolean isAsciiNumeric(final char c) {
        return c >= '0' && c <= '9';
    }
    
    public static boolean isAsciiAlphanumeric(final char c) {
        return isAsciiAlpha(c) || isAsciiNumeric(c);
    }
    
    public static int compare(final char c, final char c2) {
        return c - c2;
    }
    
    static {
        CHAR_STRING_ARRAY = new String[128];
        HEX_DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };
        for (char c = '\0'; c < CharUtils.CHAR_STRING_ARRAY.length; ++c) {
            CharUtils.CHAR_STRING_ARRAY[c] = String.valueOf(c);
        }
    }
}

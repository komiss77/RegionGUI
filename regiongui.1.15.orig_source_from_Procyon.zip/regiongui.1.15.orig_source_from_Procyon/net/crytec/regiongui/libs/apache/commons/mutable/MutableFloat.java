// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.mutable;

public class MutableFloat extends Number implements Comparable<MutableFloat>, Mutable<Number>
{
    private static final long serialVersionUID = 5787169186L;
    private float value;
    
    public MutableFloat() {
    }
    
    public MutableFloat(final float value) {
        this.value = value;
    }
    
    public MutableFloat(final Number n) {
        this.value = n.floatValue();
    }
    
    public MutableFloat(final String s) {
        this.value = Float.parseFloat(s);
    }
    
    @Override
    public Float getValue() {
        return this.value;
    }
    
    public void setValue(final float value) {
        this.value = value;
    }
    
    @Override
    public void setValue(final Number n) {
        this.value = n.floatValue();
    }
    
    public boolean isNaN() {
        return Float.isNaN(this.value);
    }
    
    public boolean isInfinite() {
        return Float.isInfinite(this.value);
    }
    
    public void increment() {
        ++this.value;
    }
    
    public float getAndIncrement() {
        final float value = this.value;
        ++this.value;
        return value;
    }
    
    public float incrementAndGet() {
        return ++this.value;
    }
    
    public void decrement() {
        --this.value;
    }
    
    public float getAndDecrement() {
        final float value = this.value;
        --this.value;
        return value;
    }
    
    public float decrementAndGet() {
        return --this.value;
    }
    
    public void add(final float n) {
        this.value += n;
    }
    
    public void add(final Number n) {
        this.value += n.floatValue();
    }
    
    public void subtract(final float n) {
        this.value -= n;
    }
    
    public void subtract(final Number n) {
        this.value -= n.floatValue();
    }
    
    public float addAndGet(final float n) {
        return this.value += n;
    }
    
    public float addAndGet(final Number n) {
        return this.value += n.floatValue();
    }
    
    public float getAndAdd(final float n) {
        final float value = this.value;
        this.value += n;
        return value;
    }
    
    public float getAndAdd(final Number n) {
        final float value = this.value;
        this.value += n.floatValue();
        return value;
    }
    
    @Override
    public int intValue() {
        return (int)this.value;
    }
    
    @Override
    public long longValue() {
        return (long)this.value;
    }
    
    @Override
    public float floatValue() {
        return this.value;
    }
    
    @Override
    public double doubleValue() {
        return this.value;
    }
    
    public Float toFloat() {
        return this.floatValue();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof MutableFloat && Float.floatToIntBits(((MutableFloat)o).value) == Float.floatToIntBits(this.value);
    }
    
    @Override
    public int hashCode() {
        return Float.floatToIntBits(this.value);
    }
    
    @Override
    public int compareTo(final MutableFloat mutableFloat) {
        return Float.compare(this.value, mutableFloat.value);
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}

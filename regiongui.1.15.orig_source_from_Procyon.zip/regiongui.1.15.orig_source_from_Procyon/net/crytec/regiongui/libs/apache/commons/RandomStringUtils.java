// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.Random;

public class RandomStringUtils
{
    private static final Random RANDOM;
    
    public static String random(final int n) {
        return random(n, false, false);
    }
    
    public static String randomAscii(final int n) {
        return random(n, 32, 127, false, false);
    }
    
    public static String randomAscii(final int n, final int n2) {
        return randomAscii(RandomUtils.nextInt(n, n2));
    }
    
    public static String randomAlphabetic(final int n) {
        return random(n, true, false);
    }
    
    public static String randomAlphabetic(final int n, final int n2) {
        return randomAlphabetic(RandomUtils.nextInt(n, n2));
    }
    
    public static String randomAlphanumeric(final int n) {
        return random(n, true, true);
    }
    
    public static String randomAlphanumeric(final int n, final int n2) {
        return randomAlphanumeric(RandomUtils.nextInt(n, n2));
    }
    
    public static String randomGraph(final int n) {
        return random(n, 33, 126, false, false);
    }
    
    public static String randomGraph(final int n, final int n2) {
        return randomGraph(RandomUtils.nextInt(n, n2));
    }
    
    public static String randomNumeric(final int n) {
        return random(n, false, true);
    }
    
    public static String randomNumeric(final int n, final int n2) {
        return randomNumeric(RandomUtils.nextInt(n, n2));
    }
    
    public static String randomPrint(final int n) {
        return random(n, 32, 126, false, false);
    }
    
    public static String randomPrint(final int n, final int n2) {
        return randomPrint(RandomUtils.nextInt(n, n2));
    }
    
    public static String random(final int n, final boolean b, final boolean b2) {
        return random(n, 0, 0, b, b2);
    }
    
    public static String random(final int n, final int n2, final int n3, final boolean b, final boolean b2) {
        return random(n, n2, n3, b, b2, null, RandomStringUtils.RANDOM);
    }
    
    public static String random(final int n, final int n2, final int n3, final boolean b, final boolean b2, final char... array) {
        return random(n, n2, n3, b, b2, array, RandomStringUtils.RANDOM);
    }
    
    public static String random(int n, int i, int length, final boolean b, final boolean b2, final char[] array, final Random random) {
        if (n == 0) {
            return "";
        }
        if (n < 0) {
            throw new IllegalArgumentException("Requested random string length " + n + " is less than 0.");
        }
        if (array != null && array.length == 0) {
            throw new IllegalArgumentException("The chars array must not be empty");
        }
        if (i == 0 && length == 0) {
            if (array != null) {
                length = array.length;
            }
            else if (!b && !b2) {
                length = 1114111;
            }
            else {
                length = 123;
                i = 32;
            }
        }
        else if (length <= i) {
            throw new IllegalArgumentException("Parameter end (" + length + ") must be greater than start (" + i + ")");
        }
        if (array == null && ((b2 && length <= 48) || (b && length <= 65))) {
            throw new IllegalArgumentException("Parameter end (" + length + ") must be greater then (" + 48 + ") for generating digits or greater then (" + 65 + ") for generating letters.");
        }
        final StringBuilder sb = new StringBuilder(n);
        final int n2 = length - i;
        while (n-- != 0) {
            int codePoint;
            if (array == null) {
                codePoint = random.nextInt(n2) + i;
                switch (Character.getType(codePoint)) {
                    case 0:
                    case 18:
                    case 19: {
                        ++n;
                        continue;
                    }
                }
            }
            else {
                codePoint = array[random.nextInt(n2) + i];
            }
            final int charCount = Character.charCount(codePoint);
            if (n == 0 && charCount > 1) {
                ++n;
            }
            else if ((b && Character.isLetter(codePoint)) || (b2 && Character.isDigit(codePoint)) || (!b && !b2)) {
                sb.appendCodePoint(codePoint);
                if (charCount != 2) {
                    continue;
                }
                --n;
            }
            else {
                ++n;
            }
        }
        return sb.toString();
    }
    
    public static String random(final int n, final String s) {
        if (s == null) {
            return random(n, 0, 0, false, false, null, RandomStringUtils.RANDOM);
        }
        return random(n, s.toCharArray());
    }
    
    public static String random(final int n, final char... array) {
        if (array == null) {
            return random(n, 0, 0, false, false, null, RandomStringUtils.RANDOM);
        }
        return random(n, 0, array.length, false, false, array, RandomStringUtils.RANDOM);
    }
    
    static {
        RANDOM = new Random();
    }
}

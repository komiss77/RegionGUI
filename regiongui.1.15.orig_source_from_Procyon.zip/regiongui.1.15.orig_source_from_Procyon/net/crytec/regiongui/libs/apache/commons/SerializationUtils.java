// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.HashMap;
import java.io.ObjectStreamClass;
import java.util.Map;
import java.io.ObjectInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ByteArrayInputStream;
import java.io.Serializable;

public class SerializationUtils
{
    public static <T extends Serializable> T clone(final T t) {
        if (t == null) {
            return null;
        }
        final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(serialize(t));
        try {
            final ClassLoaderAwareObjectInputStream classLoaderAwareObjectInputStream = new ClassLoaderAwareObjectInputStream(byteArrayInputStream, t.getClass().getClassLoader());
            try {
                final Serializable s = (Serializable)classLoaderAwareObjectInputStream.readObject();
                classLoaderAwareObjectInputStream.close();
                return (T)s;
            }
            catch (Throwable t2) {
                try {
                    classLoaderAwareObjectInputStream.close();
                }
                catch (Throwable exception) {
                    t2.addSuppressed(exception);
                }
                throw t2;
            }
        }
        catch (ClassNotFoundException ex) {
            throw new SerializationException("ClassNotFoundException while reading cloned object data", ex);
        }
        catch (IOException ex2) {
            throw new SerializationException("IOException while reading or closing cloned object data", ex2);
        }
    }
    
    public static <T extends Serializable> T roundtrip(final T t) {
        return deserialize(serialize(t));
    }
    
    public static void serialize(final Serializable obj, final OutputStream out) {
        Validate.isTrue(out != null, "The OutputStream must not be null", new Object[0]);
        try {
            final ObjectOutputStream objectOutputStream = new ObjectOutputStream(out);
            try {
                objectOutputStream.writeObject(obj);
                objectOutputStream.close();
            }
            catch (Throwable t) {
                try {
                    objectOutputStream.close();
                }
                catch (Throwable exception) {
                    t.addSuppressed(exception);
                }
                throw t;
            }
        }
        catch (IOException ex) {
            throw new SerializationException(ex);
        }
    }
    
    public static byte[] serialize(final Serializable s) {
        final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(512);
        serialize(s, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
    
    public static <T> T deserialize(final InputStream in) {
        Validate.isTrue(in != null, "The InputStream must not be null", new Object[0]);
        try {
            final ObjectInputStream objectInputStream = new ObjectInputStream(in);
            try {
                final Object object = objectInputStream.readObject();
                objectInputStream.close();
                return (T)object;
            }
            catch (Throwable t) {
                try {
                    objectInputStream.close();
                }
                catch (Throwable exception) {
                    t.addSuppressed(exception);
                }
                throw t;
            }
        }
        catch (ClassNotFoundException | IOException ex) {
            final Object o;
            throw new SerializationException((Throwable)o);
        }
    }
    
    public static <T> T deserialize(final byte[] buf) {
        Validate.isTrue(buf != null, "The byte[] must not be null", new Object[0]);
        return deserialize(new ByteArrayInputStream(buf));
    }
    
    static class ClassLoaderAwareObjectInputStream extends ObjectInputStream
    {
        private static final Map<String, Class<?>> primitiveTypes;
        private final ClassLoader classLoader;
        
        ClassLoaderAwareObjectInputStream(final InputStream in, final ClassLoader classLoader) {
            super(in);
            this.classLoader = classLoader;
        }
        
        @Override
        protected Class<?> resolveClass(final ObjectStreamClass objectStreamClass) {
            final String name = objectStreamClass.getName();
            try {
                return Class.forName(name, false, this.classLoader);
            }
            catch (ClassNotFoundException ex2) {
                try {
                    return Class.forName(name, false, Thread.currentThread().getContextClassLoader());
                }
                catch (ClassNotFoundException ex) {
                    final Class<?> clazz = ClassLoaderAwareObjectInputStream.primitiveTypes.get(name);
                    if (clazz != null) {
                        return clazz;
                    }
                    throw ex;
                }
            }
        }
        
        static {
            (primitiveTypes = new HashMap<String, Class<?>>()).put("byte", Byte.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("short", Short.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("int", Integer.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("long", Long.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("float", Float.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("double", Double.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("boolean", Boolean.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("char", Character.TYPE);
            ClassLoaderAwareObjectInputStream.primitiveTypes.put("void", Void.TYPE);
        }
    }
}

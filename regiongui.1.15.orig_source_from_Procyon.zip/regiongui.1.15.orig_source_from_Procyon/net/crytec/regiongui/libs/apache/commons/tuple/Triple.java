// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.tuple;

import java.util.Objects;
import net.crytec.regiongui.libs.apache.commons.builder.CompareToBuilder;
import java.io.Serializable;

public abstract class Triple<L, M, R> implements Comparable<Triple<L, M, R>>, Serializable
{
    private static final long serialVersionUID = 1L;
    
    public static <L, M, R> Triple<L, M, R> of(final L l, final M m, final R r) {
        return new ImmutableTriple<L, M, R>(l, m, r);
    }
    
    public abstract L getLeft();
    
    public abstract M getMiddle();
    
    public abstract R getRight();
    
    @Override
    public int compareTo(final Triple<L, M, R> triple) {
        return new CompareToBuilder().append(this.getLeft(), triple.getLeft()).append(this.getMiddle(), triple.getMiddle()).append(this.getRight(), triple.getRight()).toComparison();
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o instanceof Triple) {
            final Triple triple = (Triple)o;
            return Objects.equals(this.getLeft(), triple.getLeft()) && Objects.equals(this.getMiddle(), triple.getMiddle()) && Objects.equals(this.getRight(), triple.getRight());
        }
        return false;
    }
    
    @Override
    public int hashCode() {
        return ((this.getLeft() == null) ? 0 : this.getLeft().hashCode()) ^ ((this.getMiddle() == null) ? 0 : this.getMiddle().hashCode()) ^ ((this.getRight() == null) ? 0 : this.getRight().hashCode());
    }
    
    @Override
    public String toString() {
        return "(" + this.getLeft() + "," + this.getMiddle() + "," + this.getRight() + ")";
    }
    
    public String toString(final String format) {
        return String.format(format, this.getLeft(), this.getMiddle(), this.getRight());
    }
}

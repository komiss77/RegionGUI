// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.mutable;

import net.crytec.regiongui.libs.apache.commons.math.NumberUtils;

public class MutableInt extends Number implements Comparable<MutableInt>, Mutable<Number>
{
    private static final long serialVersionUID = 512176391864L;
    private int value;
    
    public MutableInt() {
    }
    
    public MutableInt(final int value) {
        this.value = value;
    }
    
    public MutableInt(final Number n) {
        this.value = n.intValue();
    }
    
    public MutableInt(final String s) {
        this.value = Integer.parseInt(s);
    }
    
    @Override
    public Integer getValue() {
        return this.value;
    }
    
    public void setValue(final int value) {
        this.value = value;
    }
    
    @Override
    public void setValue(final Number n) {
        this.value = n.intValue();
    }
    
    public void increment() {
        ++this.value;
    }
    
    public int getAndIncrement() {
        final int value = this.value;
        ++this.value;
        return value;
    }
    
    public int incrementAndGet() {
        return ++this.value;
    }
    
    public void decrement() {
        --this.value;
    }
    
    public int getAndDecrement() {
        final int value = this.value;
        --this.value;
        return value;
    }
    
    public int decrementAndGet() {
        return --this.value;
    }
    
    public void add(final int n) {
        this.value += n;
    }
    
    public void add(final Number n) {
        this.value += n.intValue();
    }
    
    public void subtract(final int n) {
        this.value -= n;
    }
    
    public void subtract(final Number n) {
        this.value -= n.intValue();
    }
    
    public int addAndGet(final int n) {
        return this.value += n;
    }
    
    public int addAndGet(final Number n) {
        return this.value += n.intValue();
    }
    
    public int getAndAdd(final int n) {
        final int value = this.value;
        this.value += n;
        return value;
    }
    
    public int getAndAdd(final Number n) {
        final int value = this.value;
        this.value += n.intValue();
        return value;
    }
    
    @Override
    public int intValue() {
        return this.value;
    }
    
    @Override
    public long longValue() {
        return this.value;
    }
    
    @Override
    public float floatValue() {
        return (float)this.value;
    }
    
    @Override
    public double doubleValue() {
        return this.value;
    }
    
    public Integer toInteger() {
        return this.intValue();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof MutableInt && this.value == ((MutableInt)o).intValue();
    }
    
    @Override
    public int hashCode() {
        return this.value;
    }
    
    @Override
    public int compareTo(final MutableInt mutableInt) {
        return NumberUtils.compare(this.value, mutableInt.value);
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}

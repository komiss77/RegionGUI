// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.exception;

import java.util.HashSet;
import java.util.Set;
import java.util.Iterator;
import net.crytec.regiongui.libs.apache.commons.StringUtils;
import net.crytec.regiongui.libs.apache.commons.tuple.ImmutablePair;
import java.util.ArrayList;
import net.crytec.regiongui.libs.apache.commons.tuple.Pair;
import java.util.List;
import java.io.Serializable;

public class DefaultExceptionContext implements ExceptionContext, Serializable
{
    private static final long serialVersionUID = 20110706L;
    private final List<Pair<String, Object>> contextValues;
    
    public DefaultExceptionContext() {
        this.contextValues = new ArrayList<Pair<String, Object>>();
    }
    
    @Override
    public DefaultExceptionContext addContextValue(final String s, final Object o) {
        this.contextValues.add(new ImmutablePair<String, Object>(s, o));
        return this;
    }
    
    @Override
    public DefaultExceptionContext setContextValue(final String s, final Object o) {
        final Iterator<Pair<String, Object>> iterator = this.contextValues.iterator();
        while (iterator.hasNext()) {
            if (StringUtils.equals(s, iterator.next().getKey())) {
                iterator.remove();
            }
        }
        this.addContextValue(s, o);
        return this;
    }
    
    @Override
    public List<Object> getContextValues(final String s) {
        final ArrayList<Object> list = new ArrayList<Object>();
        for (final Pair<String, Object> pair : this.contextValues) {
            if (StringUtils.equals(s, pair.getKey())) {
                list.add(pair.getValue());
            }
        }
        return list;
    }
    
    @Override
    public Object getFirstContextValue(final String s) {
        for (final Pair<String, Object> pair : this.contextValues) {
            if (StringUtils.equals(s, pair.getKey())) {
                return pair.getValue();
            }
        }
        return null;
    }
    
    @Override
    public Set<String> getContextLabels() {
        final HashSet<String> set = new HashSet<String>();
        final Iterator<Pair<String, Object>> iterator = this.contextValues.iterator();
        while (iterator.hasNext()) {
            set.add(iterator.next().getKey());
        }
        return set;
    }
    
    @Override
    public List<Pair<String, Object>> getContextEntries() {
        return this.contextValues;
    }
    
    @Override
    public String getFormattedExceptionMessage(final String str) {
        final StringBuilder sb = new StringBuilder(256);
        if (str != null) {
            sb.append(str);
        }
        if (!this.contextValues.isEmpty()) {
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append("Exception Context:\n");
            int n = 0;
            for (final Pair<String, Object> pair : this.contextValues) {
                sb.append("\t[");
                sb.append(++n);
                sb.append(':');
                sb.append(pair.getKey());
                sb.append("=");
                final Object value = pair.getValue();
                if (value == null) {
                    sb.append("null");
                }
                else {
                    String str2;
                    try {
                        str2 = value.toString();
                    }
                    catch (Exception ex) {
                        str2 = "Exception thrown on toString(): " + ExceptionUtils.getStackTrace(ex);
                    }
                    sb.append(str2);
                }
                sb.append("]\n");
            }
            sb.append("---------------------------------");
        }
        return sb.toString();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import java.util.EnumMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;
import java.util.Map;

public class EventCountCircuitBreaker extends AbstractCircuitBreaker<Integer>
{
    private static final Map<State, StateStrategy> STRATEGY_MAP;
    private final AtomicReference<CheckIntervalData> checkIntervalData;
    private final int openingThreshold;
    private final long openingInterval;
    private final int closingThreshold;
    private final long closingInterval;
    
    public EventCountCircuitBreaker(final int openingThreshold, final long duration, final TimeUnit timeUnit, final int closingThreshold, final long duration2, final TimeUnit timeUnit2) {
        this.checkIntervalData = new AtomicReference<CheckIntervalData>(new CheckIntervalData(0, 0L));
        this.openingThreshold = openingThreshold;
        this.openingInterval = timeUnit.toNanos(duration);
        this.closingThreshold = closingThreshold;
        this.closingInterval = timeUnit2.toNanos(duration2);
    }
    
    public EventCountCircuitBreaker(final int n, final long n2, final TimeUnit timeUnit, final int n3) {
        this(n, n2, timeUnit, n3, n2, timeUnit);
    }
    
    public EventCountCircuitBreaker(final int n, final long n2, final TimeUnit timeUnit) {
        this(n, n2, timeUnit, n);
    }
    
    public int getOpeningThreshold() {
        return this.openingThreshold;
    }
    
    public long getOpeningInterval() {
        return this.openingInterval;
    }
    
    public int getClosingThreshold() {
        return this.closingThreshold;
    }
    
    public long getClosingInterval() {
        return this.closingInterval;
    }
    
    @Override
    public boolean checkState() {
        return this.performStateCheck(0);
    }
    
    @Override
    public boolean incrementAndCheckState(final Integer n) {
        return this.performStateCheck(n);
    }
    
    public boolean incrementAndCheckState() {
        return this.incrementAndCheckState(1);
    }
    
    @Override
    public void open() {
        super.open();
        this.checkIntervalData.set(new CheckIntervalData(0, this.now()));
    }
    
    @Override
    public void close() {
        super.close();
        this.checkIntervalData.set(new CheckIntervalData(0, this.now()));
    }
    
    private boolean performStateCheck(final int n) {
        CheckIntervalData checkIntervalData;
        CheckIntervalData nextCheckIntervalData;
        State oppositeState;
        do {
            final long now = this.now();
            oppositeState = this.state.get();
            checkIntervalData = this.checkIntervalData.get();
            nextCheckIntervalData = this.nextCheckIntervalData(n, checkIntervalData, oppositeState, now);
        } while (!this.updateCheckIntervalData(checkIntervalData, nextCheckIntervalData));
        if (stateStrategy(oppositeState).isStateTransition(this, checkIntervalData, nextCheckIntervalData)) {
            oppositeState = oppositeState.oppositeState();
            this.changeStateAndStartNewCheckInterval(oppositeState);
        }
        return !AbstractCircuitBreaker.isOpen(oppositeState);
    }
    
    private boolean updateCheckIntervalData(final CheckIntervalData expectedValue, final CheckIntervalData newValue) {
        return expectedValue == newValue || this.checkIntervalData.compareAndSet(expectedValue, newValue);
    }
    
    private void changeStateAndStartNewCheckInterval(final State state) {
        this.changeState(state);
        this.checkIntervalData.set(new CheckIntervalData(0, this.now()));
    }
    
    private CheckIntervalData nextCheckIntervalData(final int n, final CheckIntervalData checkIntervalData, final State state, final long n2) {
        CheckIntervalData increment;
        if (stateStrategy(state).isCheckIntervalFinished(this, checkIntervalData, n2)) {
            increment = new CheckIntervalData(n, n2);
        }
        else {
            increment = checkIntervalData.increment(n);
        }
        return increment;
    }
    
    long now() {
        return System.nanoTime();
    }
    
    private static StateStrategy stateStrategy(final State state) {
        return EventCountCircuitBreaker.STRATEGY_MAP.get(state);
    }
    
    private static Map<State, StateStrategy> createStrategyMap() {
        final EnumMap<State, StateStrategyClosed> enumMap = (EnumMap<State, StateStrategyClosed>)new EnumMap<State, StateStrategyOpen>(State.class);
        enumMap.put(State.CLOSED, (StateStrategyOpen)new StateStrategyClosed());
        enumMap.put(State.OPEN, new StateStrategyOpen());
        return (Map<State, StateStrategy>)enumMap;
    }
    
    static {
        STRATEGY_MAP = createStrategyMap();
    }
    
    private static class CheckIntervalData
    {
        private final int eventCount;
        private final long checkIntervalStart;
        
        CheckIntervalData(final int eventCount, final long checkIntervalStart) {
            this.eventCount = eventCount;
            this.checkIntervalStart = checkIntervalStart;
        }
        
        public int getEventCount() {
            return this.eventCount;
        }
        
        public long getCheckIntervalStart() {
            return this.checkIntervalStart;
        }
        
        public CheckIntervalData increment(final int n) {
            return (n == 0) ? this : new CheckIntervalData(this.getEventCount() + n, this.getCheckIntervalStart());
        }
    }
    
    private abstract static class StateStrategy
    {
        public boolean isCheckIntervalFinished(final EventCountCircuitBreaker eventCountCircuitBreaker, final CheckIntervalData checkIntervalData, final long n) {
            return n - checkIntervalData.getCheckIntervalStart() > this.fetchCheckInterval(eventCountCircuitBreaker);
        }
        
        public abstract boolean isStateTransition(final EventCountCircuitBreaker p0, final CheckIntervalData p1, final CheckIntervalData p2);
        
        protected abstract long fetchCheckInterval(final EventCountCircuitBreaker p0);
    }
    
    private static class StateStrategyClosed extends StateStrategy
    {
        @Override
        public boolean isStateTransition(final EventCountCircuitBreaker eventCountCircuitBreaker, final CheckIntervalData checkIntervalData, final CheckIntervalData checkIntervalData2) {
            return checkIntervalData2.getEventCount() > eventCountCircuitBreaker.getOpeningThreshold();
        }
        
        @Override
        protected long fetchCheckInterval(final EventCountCircuitBreaker eventCountCircuitBreaker) {
            return eventCountCircuitBreaker.getOpeningInterval();
        }
    }
    
    private static class StateStrategyOpen extends StateStrategy
    {
        @Override
        public boolean isStateTransition(final EventCountCircuitBreaker eventCountCircuitBreaker, final CheckIntervalData checkIntervalData, final CheckIntervalData checkIntervalData2) {
            return checkIntervalData2.getCheckIntervalStart() != checkIntervalData.getCheckIntervalStart() && checkIntervalData.getEventCount() < eventCountCircuitBreaker.getClosingThreshold();
        }
        
        @Override
        protected long fetchCheckInterval(final EventCountCircuitBreaker eventCountCircuitBreaker) {
            return eventCountCircuitBreaker.getClosingInterval();
        }
    }
}

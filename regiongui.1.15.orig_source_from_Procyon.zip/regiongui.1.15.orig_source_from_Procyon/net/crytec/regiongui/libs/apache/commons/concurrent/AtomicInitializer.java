// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import java.util.concurrent.atomic.AtomicReference;

public abstract class AtomicInitializer<T> implements ConcurrentInitializer<T>
{
    private final AtomicReference<T> reference;
    
    public AtomicInitializer() {
        this.reference = new AtomicReference<T>();
    }
    
    @Override
    public T get() {
        T newValue = this.reference.get();
        if (newValue == null) {
            newValue = this.initialize();
            if (!this.reference.compareAndSet(null, newValue)) {
                newValue = this.reference.get();
            }
        }
        return newValue;
    }
    
    protected abstract T initialize();
}

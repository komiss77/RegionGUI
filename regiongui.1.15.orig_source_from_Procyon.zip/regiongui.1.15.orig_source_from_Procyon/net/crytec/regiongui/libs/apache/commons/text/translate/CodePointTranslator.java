// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text.translate;

import java.io.Writer;

@Deprecated
public abstract class CodePointTranslator extends CharSequenceTranslator
{
    @Override
    public final int translate(final CharSequence seq, final int index, final Writer writer) {
        return this.translate(Character.codePointAt(seq, index), writer) ? 1 : 0;
    }
    
    public abstract boolean translate(final int p0, final Writer p1);
}

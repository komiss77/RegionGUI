// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.event;

import java.lang.reflect.Method;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Set;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.lang.reflect.InvocationTargetException;
import net.crytec.regiongui.libs.apache.commons.reflect.MethodUtils;

public class EventUtils
{
    public static <L> void addEventListener(final Object o, final Class<L> clazz, final L l) {
        try {
            MethodUtils.invokeMethod(o, "add" + clazz.getSimpleName(), l);
        }
        catch (NoSuchMethodException ex2) {
            throw new IllegalArgumentException("Class " + o.getClass().getName() + " does not have a public add" + clazz.getSimpleName() + " method which takes a parameter of type " + clazz.getName() + ".");
        }
        catch (IllegalAccessException ex3) {
            throw new IllegalArgumentException("Class " + o.getClass().getName() + " does not have an accessible add" + clazz.getSimpleName() + " method which takes a parameter of type " + clazz.getName() + ".");
        }
        catch (InvocationTargetException ex) {
            throw new RuntimeException("Unable to add listener.", ex.getCause());
        }
    }
    
    public static <L> void bindEventsToMethod(final Object o, final String s, final Object o2, final Class<L> clazz, final String... array) {
        addEventListener(o2, clazz, clazz.cast(Proxy.newProxyInstance(o.getClass().getClassLoader(), new Class[] { clazz }, new EventBindingInvocationHandler(o, s, array))));
    }
    
    private static class EventBindingInvocationHandler implements InvocationHandler
    {
        private final Object target;
        private final String methodName;
        private final Set<String> eventTypes;
        
        EventBindingInvocationHandler(final Object target, final String methodName, final String[] a) {
            this.target = target;
            this.methodName = methodName;
            this.eventTypes = new HashSet<String>(Arrays.asList(a));
        }
        
        @Override
        public Object invoke(final Object o, final Method method, final Object[] array) {
            if (!this.eventTypes.isEmpty() && !this.eventTypes.contains(method.getName())) {
                return null;
            }
            if (this.hasMatchingParametersMethod(method)) {
                return MethodUtils.invokeMethod(this.target, this.methodName, array);
            }
            return MethodUtils.invokeMethod(this.target, this.methodName);
        }
        
        private boolean hasMatchingParametersMethod(final Method method) {
            return MethodUtils.getAccessibleMethod(this.target.getClass(), this.methodName, method.getParameterTypes()) != null;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

public class ConcurrentRuntimeException extends RuntimeException
{
    private static final long serialVersionUID = -6582182735562919670L;
    
    protected ConcurrentRuntimeException() {
    }
    
    public ConcurrentRuntimeException(final Throwable t) {
        super(ConcurrentUtils.checkedException(t));
    }
    
    public ConcurrentRuntimeException(final String message, final Throwable t) {
        super(message, ConcurrentUtils.checkedException(t));
    }
}

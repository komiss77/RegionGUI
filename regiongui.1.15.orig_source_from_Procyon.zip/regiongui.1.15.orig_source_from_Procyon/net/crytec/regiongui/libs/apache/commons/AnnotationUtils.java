// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.Iterator;
import java.util.Arrays;
import net.crytec.regiongui.libs.apache.commons.builder.ToStringBuilder;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.lang.annotation.Annotation;
import net.crytec.regiongui.libs.apache.commons.builder.ToStringStyle;

public class AnnotationUtils
{
    private static final ToStringStyle TO_STRING_STYLE;
    
    public static boolean equals(final Annotation obj, final Annotation obj2) {
        if (obj == obj2) {
            return true;
        }
        if (obj == null || obj2 == null) {
            return false;
        }
        final Class<? extends Annotation> annotationType = obj.annotationType();
        final Class<? extends Annotation> annotationType2 = obj2.annotationType();
        Validate.notNull(annotationType, "Annotation %s with null annotationType()", obj);
        Validate.notNull(annotationType2, "Annotation %s with null annotationType()", obj2);
        if (!annotationType.equals(annotationType2)) {
            return false;
        }
        try {
            for (final Method method : annotationType.getDeclaredMethods()) {
                if (method.getParameterTypes().length == 0 && isValidAnnotationMemberType(method.getReturnType()) && !memberEquals(method.getReturnType(), method.invoke(obj, new Object[0]), method.invoke(obj2, new Object[0]))) {
                    return false;
                }
            }
        }
        catch (IllegalAccessException | InvocationTargetException ex) {
            return false;
        }
        return true;
    }
    
    public static int hashCode(final Annotation obj) {
        int n = 0;
        for (final Method method : obj.annotationType().getDeclaredMethods()) {
            try {
                final Object invoke = method.invoke(obj, new Object[0]);
                if (invoke == null) {
                    throw new IllegalStateException(String.format("Annotation method %s returned null", method));
                }
                n += hashMember(method.getName(), invoke);
            }
            catch (RuntimeException ex) {
                throw ex;
            }
            catch (Exception cause) {
                throw new RuntimeException(cause);
            }
        }
        return n;
    }
    
    public static String toString(final Annotation obj) {
        final ToStringBuilder toStringBuilder = new ToStringBuilder(obj, AnnotationUtils.TO_STRING_STYLE);
        for (final Method method : obj.annotationType().getDeclaredMethods()) {
            if (method.getParameterTypes().length <= 0) {
                try {
                    toStringBuilder.append(method.getName(), method.invoke(obj, new Object[0]));
                }
                catch (RuntimeException ex) {
                    throw ex;
                }
                catch (Exception cause) {
                    throw new RuntimeException(cause);
                }
            }
        }
        return toStringBuilder.build();
    }
    
    public static boolean isValidAnnotationMemberType(Class<?> componentType) {
        if (componentType == null) {
            return false;
        }
        if (componentType.isArray()) {
            componentType = componentType.getComponentType();
        }
        return componentType.isPrimitive() || componentType.isEnum() || componentType.isAnnotation() || String.class.equals(componentType) || Class.class.equals(componentType);
    }
    
    private static int hashMember(final String s, final Object o) {
        final int n = s.hashCode() * 127;
        if (o.getClass().isArray()) {
            return n ^ arrayMemberHash(o.getClass().getComponentType(), o);
        }
        if (o instanceof Annotation) {
            return n ^ hashCode((Annotation)o);
        }
        return n ^ o.hashCode();
    }
    
    private static boolean memberEquals(final Class<?> clazz, final Object o, final Object obj) {
        if (o == obj) {
            return true;
        }
        if (o == null || obj == null) {
            return false;
        }
        if (clazz.isArray()) {
            return arrayMemberEquals(clazz.getComponentType(), o, obj);
        }
        if (clazz.isAnnotation()) {
            return equals((Annotation)o, (Annotation)obj);
        }
        return o.equals(obj);
    }
    
    private static boolean arrayMemberEquals(final Class<?> clazz, final Object o, final Object o2) {
        if (clazz.isAnnotation()) {
            return annotationArrayMemberEquals((Annotation[])o, (Annotation[])o2);
        }
        if (clazz.equals(Byte.TYPE)) {
            return Arrays.equals((byte[])o, (byte[])o2);
        }
        if (clazz.equals(Short.TYPE)) {
            return Arrays.equals((short[])o, (short[])o2);
        }
        if (clazz.equals(Integer.TYPE)) {
            return Arrays.equals((int[])o, (int[])o2);
        }
        if (clazz.equals(Character.TYPE)) {
            return Arrays.equals((char[])o, (char[])o2);
        }
        if (clazz.equals(Long.TYPE)) {
            return Arrays.equals((long[])o, (long[])o2);
        }
        if (clazz.equals(Float.TYPE)) {
            return Arrays.equals((float[])o, (float[])o2);
        }
        if (clazz.equals(Double.TYPE)) {
            return Arrays.equals((double[])o, (double[])o2);
        }
        if (clazz.equals(Boolean.TYPE)) {
            return Arrays.equals((boolean[])o, (boolean[])o2);
        }
        return Arrays.equals((Object[])o, (Object[])o2);
    }
    
    private static boolean annotationArrayMemberEquals(final Annotation[] array, final Annotation[] array2) {
        if (array.length != array2.length) {
            return false;
        }
        for (int i = 0; i < array.length; ++i) {
            if (!equals(array[i], array2[i])) {
                return false;
            }
        }
        return true;
    }
    
    private static int arrayMemberHash(final Class<?> clazz, final Object o) {
        if (clazz.equals(Byte.TYPE)) {
            return Arrays.hashCode((byte[])o);
        }
        if (clazz.equals(Short.TYPE)) {
            return Arrays.hashCode((short[])o);
        }
        if (clazz.equals(Integer.TYPE)) {
            return Arrays.hashCode((int[])o);
        }
        if (clazz.equals(Character.TYPE)) {
            return Arrays.hashCode((char[])o);
        }
        if (clazz.equals(Long.TYPE)) {
            return Arrays.hashCode((long[])o);
        }
        if (clazz.equals(Float.TYPE)) {
            return Arrays.hashCode((float[])o);
        }
        if (clazz.equals(Double.TYPE)) {
            return Arrays.hashCode((double[])o);
        }
        if (clazz.equals(Boolean.TYPE)) {
            return Arrays.hashCode((boolean[])o);
        }
        return Arrays.hashCode((Object[])o);
    }
    
    static {
        TO_STRING_STYLE = new ToStringStyle() {
            private static final long serialVersionUID = 1L;
            
            {
                this.setDefaultFullDetail(true);
                this.setArrayContentDetail(true);
                this.setUseClassName(true);
                this.setUseShortClassName(true);
                this.setUseIdentityHashCode(false);
                this.setContentStart("(");
                this.setContentEnd(")");
                this.setFieldSeparator(", ");
                this.setArrayStart("[");
                this.setArrayEnd("]");
            }
            
            @Override
            protected String getShortClassName(final Class<?> clazz) {
                Class<?> clazz2 = null;
                for (final Class<?> clazz3 : ClassUtils.getAllInterfaces(clazz)) {
                    if (Annotation.class.isAssignableFrom(clazz3)) {
                        clazz2 = clazz3;
                        break;
                    }
                }
                return new StringBuilder((clazz2 == null) ? "" : clazz2.getName()).insert(0, '@').toString();
            }
            
            @Override
            protected void appendDetail(final StringBuffer sb, final String s, Object string) {
                if (string instanceof Annotation) {
                    string = AnnotationUtils.toString((Annotation)string);
                }
                super.appendDetail(sb, s, string);
            }
        };
    }
}

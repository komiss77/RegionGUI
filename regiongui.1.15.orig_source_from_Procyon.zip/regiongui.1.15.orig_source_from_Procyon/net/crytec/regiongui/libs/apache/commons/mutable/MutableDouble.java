// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.mutable;

public class MutableDouble extends Number implements Comparable<MutableDouble>, Mutable<Number>
{
    private static final long serialVersionUID = 1587163916L;
    private double value;
    
    public MutableDouble() {
    }
    
    public MutableDouble(final double value) {
        this.value = value;
    }
    
    public MutableDouble(final Number n) {
        this.value = n.doubleValue();
    }
    
    public MutableDouble(final String s) {
        this.value = Double.parseDouble(s);
    }
    
    @Override
    public Double getValue() {
        return this.value;
    }
    
    public void setValue(final double value) {
        this.value = value;
    }
    
    @Override
    public void setValue(final Number n) {
        this.value = n.doubleValue();
    }
    
    public boolean isNaN() {
        return Double.isNaN(this.value);
    }
    
    public boolean isInfinite() {
        return Double.isInfinite(this.value);
    }
    
    public void increment() {
        ++this.value;
    }
    
    public double getAndIncrement() {
        final double value = this.value;
        ++this.value;
        return value;
    }
    
    public double incrementAndGet() {
        return ++this.value;
    }
    
    public void decrement() {
        --this.value;
    }
    
    public double getAndDecrement() {
        final double value = this.value;
        --this.value;
        return value;
    }
    
    public double decrementAndGet() {
        return --this.value;
    }
    
    public void add(final double n) {
        this.value += n;
    }
    
    public void add(final Number n) {
        this.value += n.doubleValue();
    }
    
    public void subtract(final double n) {
        this.value -= n;
    }
    
    public void subtract(final Number n) {
        this.value -= n.doubleValue();
    }
    
    public double addAndGet(final double n) {
        return this.value += n;
    }
    
    public double addAndGet(final Number n) {
        return this.value += n.doubleValue();
    }
    
    public double getAndAdd(final double n) {
        final double value = this.value;
        this.value += n;
        return value;
    }
    
    public double getAndAdd(final Number n) {
        final double value = this.value;
        this.value += n.doubleValue();
        return value;
    }
    
    @Override
    public int intValue() {
        return (int)this.value;
    }
    
    @Override
    public long longValue() {
        return (long)this.value;
    }
    
    @Override
    public float floatValue() {
        return (float)this.value;
    }
    
    @Override
    public double doubleValue() {
        return this.value;
    }
    
    public Double toDouble() {
        return this.doubleValue();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof MutableDouble && Double.doubleToLongBits(((MutableDouble)o).value) == Double.doubleToLongBits(this.value);
    }
    
    @Override
    public int hashCode() {
        final long doubleToLongBits = Double.doubleToLongBits(this.value);
        return (int)(doubleToLongBits ^ doubleToLongBits >>> 32);
    }
    
    @Override
    public int compareTo(final MutableDouble mutableDouble) {
        return Double.compare(this.value, mutableDouble.value);
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

public interface ConcurrentInitializer<T>
{
    T get() throws ConcurrentException;
}

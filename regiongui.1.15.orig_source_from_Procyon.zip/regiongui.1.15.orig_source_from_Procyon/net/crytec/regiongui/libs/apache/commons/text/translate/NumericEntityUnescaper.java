// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text.translate;

import java.io.Writer;
import java.util.Collection;
import java.util.Arrays;
import java.util.EnumSet;

@Deprecated
public class NumericEntityUnescaper extends CharSequenceTranslator
{
    private final EnumSet<OPTION> options;
    
    public NumericEntityUnescaper(final OPTION... a) {
        if (a.length > 0) {
            this.options = EnumSet.copyOf(Arrays.asList(a));
        }
        else {
            this.options = EnumSet.copyOf(Arrays.asList(OPTION.semiColonRequired));
        }
    }
    
    public boolean isSet(final OPTION o) {
        return this.options != null && this.options.contains(o);
    }
    
    @Override
    public int translate(final CharSequence charSequence, final int n, final Writer writer) {
        final int length = charSequence.length();
        if (charSequence.charAt(n) == '&' && n < length - 2 && charSequence.charAt(n + 1) == '#') {
            int n2 = n + 2;
            int n3 = 0;
            final char char1 = charSequence.charAt(n2);
            if (char1 == 'x' || char1 == 'X') {
                ++n2;
                n3 = 1;
                if (n2 == length) {
                    return 0;
                }
            }
            int n4;
            for (n4 = n2; n4 < length && ((charSequence.charAt(n4) >= '0' && charSequence.charAt(n4) <= '9') || (charSequence.charAt(n4) >= 'a' && charSequence.charAt(n4) <= 'f') || (charSequence.charAt(n4) >= 'A' && charSequence.charAt(n4) <= 'F')); ++n4) {}
            final int n5 = (n4 != length && charSequence.charAt(n4) == ';') ? 1 : 0;
            if (n5 == 0) {
                if (this.isSet(OPTION.semiColonRequired)) {
                    return 0;
                }
                if (this.isSet(OPTION.errorIfNoSemiColon)) {
                    throw new IllegalArgumentException("Semi-colon required at end of numeric entity");
                }
            }
            int n6;
            try {
                if (n3 != 0) {
                    n6 = Integer.parseInt(charSequence.subSequence(n2, n4).toString(), 16);
                }
                else {
                    n6 = Integer.parseInt(charSequence.subSequence(n2, n4).toString(), 10);
                }
            }
            catch (NumberFormatException ex) {
                return 0;
            }
            if (n6 > 65535) {
                final char[] chars = Character.toChars(n6);
                writer.write(chars[0]);
                writer.write(chars[1]);
            }
            else {
                writer.write(n6);
            }
            return 2 + n4 - n2 + n3 + n5;
        }
        return 0;
    }
    
    public enum OPTION
    {
        semiColonRequired, 
        semiColonOptional, 
        errorIfNoSemiColon;
    }
}

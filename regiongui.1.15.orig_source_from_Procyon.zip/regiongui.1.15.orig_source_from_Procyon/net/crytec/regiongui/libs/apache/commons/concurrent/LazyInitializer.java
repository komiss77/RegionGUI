// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

public abstract class LazyInitializer<T> implements ConcurrentInitializer<T>
{
    private static final Object NO_INIT;
    private volatile T object;
    
    public LazyInitializer() {
        this.object = (T)LazyInitializer.NO_INIT;
    }
    
    @Override
    public T get() {
        T t = this.object;
        if (t == LazyInitializer.NO_INIT) {
            synchronized (this) {
                t = this.object;
                if (t == LazyInitializer.NO_INIT) {
                    t = (this.object = this.initialize());
                }
            }
        }
        return t;
    }
    
    protected abstract T initialize();
    
    static {
        NO_INIT = new Object();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.HashMap;
import java.util.Collections;
import java.util.Set;
import net.crytec.regiongui.libs.apache.commons.mutable.MutableObject;
import java.lang.reflect.Modifier;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ClassUtils
{
    public static final char PACKAGE_SEPARATOR_CHAR = '.';
    public static final String PACKAGE_SEPARATOR;
    public static final char INNER_CLASS_SEPARATOR_CHAR = '$';
    public static final String INNER_CLASS_SEPARATOR;
    private static final Map<String, Class<?>> namePrimitiveMap;
    private static final Map<Class<?>, Class<?>> primitiveWrapperMap;
    private static final Map<Class<?>, Class<?>> wrapperPrimitiveMap;
    private static final Map<String, String> abbreviationMap;
    private static final Map<String, String> reverseAbbreviationMap;
    
    public static String getShortClassName(final Object o, final String s) {
        if (o == null) {
            return s;
        }
        return getShortClassName(o.getClass());
    }
    
    public static String getShortClassName(final Class<?> clazz) {
        if (clazz == null) {
            return "";
        }
        return getShortClassName(clazz.getName());
    }
    
    public static String getShortClassName(String s) {
        if (StringUtils.isEmpty(s)) {
            return "";
        }
        final StringBuilder obj = new StringBuilder();
        if (s.startsWith("[")) {
            while (s.charAt(0) == '[') {
                s = s.substring(1);
                obj.append("[]");
            }
            if (s.charAt(0) == 'L' && s.charAt(s.length() - 1) == ';') {
                s = s.substring(1, s.length() - 1);
            }
            if (ClassUtils.reverseAbbreviationMap.containsKey(s)) {
                s = ClassUtils.reverseAbbreviationMap.get(s);
            }
        }
        final int lastIndex = s.lastIndexOf(46);
        final int index = s.indexOf(36, (lastIndex == -1) ? 0 : (lastIndex + 1));
        String str = s.substring(lastIndex + 1);
        if (index != -1) {
            str = str.replace('$', '.');
        }
        return str + (Object)obj;
    }
    
    public static String getSimpleName(final Class<?> clazz) {
        return getSimpleName(clazz, "");
    }
    
    public static String getSimpleName(final Class<?> clazz, final String s) {
        return (clazz == null) ? s : clazz.getSimpleName();
    }
    
    public static String getSimpleName(final Object o) {
        return getSimpleName(o, "");
    }
    
    public static String getSimpleName(final Object o, final String s) {
        return (o == null) ? s : o.getClass().getSimpleName();
    }
    
    public static String getName(final Class<?> clazz) {
        return getName(clazz, "");
    }
    
    public static String getName(final Class<?> clazz, final String s) {
        return (clazz == null) ? s : clazz.getName();
    }
    
    public static String getName(final Object o) {
        return getName(o, "");
    }
    
    public static String getName(final Object o, final String s) {
        return (o == null) ? s : o.getClass().getName();
    }
    
    public static String getPackageName(final Object o, final String s) {
        if (o == null) {
            return s;
        }
        return getPackageName(o.getClass());
    }
    
    public static String getPackageName(final Class<?> clazz) {
        if (clazz == null) {
            return "";
        }
        return getPackageName(clazz.getName());
    }
    
    public static String getPackageName(String s) {
        if (StringUtils.isEmpty(s)) {
            return "";
        }
        while (s.charAt(0) == '[') {
            s = s.substring(1);
        }
        if (s.charAt(0) == 'L' && s.charAt(s.length() - 1) == ';') {
            s = s.substring(1);
        }
        final int lastIndex = s.lastIndexOf(46);
        if (lastIndex == -1) {
            return "";
        }
        return s.substring(0, lastIndex);
    }
    
    public static String getAbbreviatedName(final Class<?> clazz, final int n) {
        if (clazz == null) {
            return "";
        }
        return getAbbreviatedName(clazz.getName(), n);
    }
    
    public static String getAbbreviatedName(final String s, final int n) {
        if (n <= 0) {
            throw new IllegalArgumentException("len must be > 0");
        }
        if (s == null) {
            return "";
        }
        int n2 = n;
        final int countMatches = StringUtils.countMatches(s, '.');
        final String[] array = new String[countMatches + 1];
        int fromIndex = s.length() - 1;
        for (int i = countMatches; i >= 0; --i) {
            final int lastIndex = s.lastIndexOf(46, fromIndex);
            final String substring = s.substring(lastIndex + 1, fromIndex + 1);
            n2 -= substring.length();
            if (i > 0) {
                --n2;
            }
            if (i == countMatches) {
                array[i] = substring;
            }
            else if (n2 > 0) {
                array[i] = substring;
            }
            else {
                array[i] = substring.substring(0, 1);
            }
            fromIndex = lastIndex - 1;
        }
        return StringUtils.join((Object[])array, '.');
    }
    
    public static List<Class<?>> getAllSuperclasses(final Class<?> clazz) {
        if (clazz == null) {
            return null;
        }
        final ArrayList<Class<?>> list = new ArrayList<Class<?>>();
        for (Class<?> clazz2 = clazz.getSuperclass(); clazz2 != null; clazz2 = clazz2.getSuperclass()) {
            list.add(clazz2);
        }
        return list;
    }
    
    public static List<Class<?>> getAllInterfaces(final Class<?> clazz) {
        if (clazz == null) {
            return null;
        }
        final LinkedHashSet<Class<?>> c = new LinkedHashSet<Class<?>>();
        getAllInterfaces(clazz, c);
        return new ArrayList<Class<?>>(c);
    }
    
    private static void getAllInterfaces(Class<?> superclass, final HashSet<Class<?>> set) {
        while (superclass != null) {
            for (final Class e : superclass.getInterfaces()) {
                if (set.add(e)) {
                    getAllInterfaces(e, set);
                }
            }
            superclass = superclass.getSuperclass();
        }
    }
    
    public static List<Class<?>> convertClassNamesToClasses(final List<String> list) {
        if (list == null) {
            return null;
        }
        final ArrayList<Class<?>> list2 = new ArrayList<Class<?>>(list.size());
        for (final String className : list) {
            try {
                list2.add(Class.forName(className));
            }
            catch (Exception ex) {
                list2.add(null);
            }
        }
        return list2;
    }
    
    public static List<String> convertClassesToClassNames(final List<Class<?>> list) {
        if (list == null) {
            return null;
        }
        final ArrayList<String> list2 = new ArrayList<String>(list.size());
        for (final Class<?> clazz : list) {
            if (clazz == null) {
                list2.add(null);
            }
            else {
                list2.add(clazz.getName());
            }
        }
        return list2;
    }
    
    public static boolean isAssignable(final Class<?>[] array, final Class<?>... array2) {
        return isAssignable(array, array2, true);
    }
    
    public static boolean isAssignable(Class<?>[] empty_CLASS_ARRAY, Class<?>[] empty_CLASS_ARRAY2, final boolean b) {
        if (!ArrayUtils.isSameLength(empty_CLASS_ARRAY, empty_CLASS_ARRAY2)) {
            return false;
        }
        if (empty_CLASS_ARRAY == null) {
            empty_CLASS_ARRAY = ArrayUtils.EMPTY_CLASS_ARRAY;
        }
        if (empty_CLASS_ARRAY2 == null) {
            empty_CLASS_ARRAY2 = ArrayUtils.EMPTY_CLASS_ARRAY;
        }
        for (int i = 0; i < empty_CLASS_ARRAY.length; ++i) {
            if (!isAssignable(empty_CLASS_ARRAY[i], empty_CLASS_ARRAY2[i], b)) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isPrimitiveOrWrapper(final Class<?> clazz) {
        return clazz != null && (clazz.isPrimitive() || isPrimitiveWrapper(clazz));
    }
    
    public static boolean isPrimitiveWrapper(final Class<?> clazz) {
        return ClassUtils.wrapperPrimitiveMap.containsKey(clazz);
    }
    
    public static boolean isAssignable(final Class<?> clazz, final Class<?> clazz2) {
        return isAssignable(clazz, clazz2, true);
    }
    
    public static boolean isAssignable(Class<?> clazz, final Class<?> clazz2, final boolean b) {
        if (clazz2 == null) {
            return false;
        }
        if (clazz == null) {
            return !clazz2.isPrimitive();
        }
        if (b) {
            if (clazz.isPrimitive() && !clazz2.isPrimitive()) {
                clazz = primitiveToWrapper(clazz);
                if (clazz == null) {
                    return false;
                }
            }
            if (clazz2.isPrimitive() && !clazz.isPrimitive()) {
                clazz = wrapperToPrimitive(clazz);
                if (clazz == null) {
                    return false;
                }
            }
        }
        if (clazz.equals(clazz2)) {
            return true;
        }
        if (!clazz.isPrimitive()) {
            return clazz2.isAssignableFrom(clazz);
        }
        if (!clazz2.isPrimitive()) {
            return false;
        }
        if (Integer.TYPE.equals(clazz)) {
            return Long.TYPE.equals(clazz2) || Float.TYPE.equals(clazz2) || Double.TYPE.equals(clazz2);
        }
        if (Long.TYPE.equals(clazz)) {
            return Float.TYPE.equals(clazz2) || Double.TYPE.equals(clazz2);
        }
        if (Boolean.TYPE.equals(clazz)) {
            return false;
        }
        if (Double.TYPE.equals(clazz)) {
            return false;
        }
        if (Float.TYPE.equals(clazz)) {
            return Double.TYPE.equals(clazz2);
        }
        if (Character.TYPE.equals(clazz)) {
            return Integer.TYPE.equals(clazz2) || Long.TYPE.equals(clazz2) || Float.TYPE.equals(clazz2) || Double.TYPE.equals(clazz2);
        }
        if (Short.TYPE.equals(clazz)) {
            return Integer.TYPE.equals(clazz2) || Long.TYPE.equals(clazz2) || Float.TYPE.equals(clazz2) || Double.TYPE.equals(clazz2);
        }
        return Byte.TYPE.equals(clazz) && (Short.TYPE.equals(clazz2) || Integer.TYPE.equals(clazz2) || Long.TYPE.equals(clazz2) || Float.TYPE.equals(clazz2) || Double.TYPE.equals(clazz2));
    }
    
    public static Class<?> primitiveToWrapper(final Class<?> clazz) {
        Class<?> clazz2 = clazz;
        if (clazz != null && clazz.isPrimitive()) {
            clazz2 = ClassUtils.primitiveWrapperMap.get(clazz);
        }
        return clazz2;
    }
    
    public static Class<?>[] primitivesToWrappers(final Class<?>... array) {
        if (array == null) {
            return null;
        }
        if (array.length == 0) {
            return array;
        }
        final Class[] array2 = new Class[array.length];
        for (int i = 0; i < array.length; ++i) {
            array2[i] = primitiveToWrapper(array[i]);
        }
        return (Class<?>[])array2;
    }
    
    public static Class<?> wrapperToPrimitive(final Class<?> clazz) {
        return ClassUtils.wrapperPrimitiveMap.get(clazz);
    }
    
    public static Class<?>[] wrappersToPrimitives(final Class<?>... array) {
        if (array == null) {
            return null;
        }
        if (array.length == 0) {
            return array;
        }
        final Class[] array2 = new Class[array.length];
        for (int i = 0; i < array.length; ++i) {
            array2[i] = wrapperToPrimitive(array[i]);
        }
        return (Class<?>[])array2;
    }
    
    public static boolean isInnerClass(final Class<?> clazz) {
        return clazz != null && clazz.getEnclosingClass() != null;
    }
    
    public static Class<?> getClass(final ClassLoader loader, final String s, final boolean initialize) {
        try {
            Class<?> forName;
            if (ClassUtils.namePrimitiveMap.containsKey(s)) {
                forName = ClassUtils.namePrimitiveMap.get(s);
            }
            else {
                forName = Class.forName(toCanonicalName(s), initialize, loader);
            }
            return forName;
        }
        catch (ClassNotFoundException ex) {
            final int lastIndex = s.lastIndexOf(46);
            if (lastIndex != -1) {
                try {
                    return getClass(loader, s.substring(0, lastIndex) + '$' + s.substring(lastIndex + 1), initialize);
                }
                catch (ClassNotFoundException ex2) {}
            }
            throw ex;
        }
    }
    
    public static Class<?> getClass(final ClassLoader classLoader, final String s) {
        return getClass(classLoader, s, true);
    }
    
    public static Class<?> getClass(final String s) {
        return getClass(s, true);
    }
    
    public static Class<?> getClass(final String s, final boolean b) {
        final ClassLoader contextClassLoader = Thread.currentThread().getContextClassLoader();
        return getClass((contextClassLoader == null) ? ClassUtils.class.getClassLoader() : contextClassLoader, s, b);
    }
    
    public static Method getPublicMethod(final Class<?> clazz, final String str, final Class<?>... array) {
        final Method method = clazz.getMethod(str, array);
        if (Modifier.isPublic(method.getDeclaringClass().getModifiers())) {
            return method;
        }
        final ArrayList<Class> list = new ArrayList<Class>();
        list.addAll((Collection<?>)getAllInterfaces(clazz));
        list.addAll((Collection<?>)getAllSuperclasses(clazz));
        for (final Class clazz2 : list) {
            if (!Modifier.isPublic(clazz2.getModifiers())) {
                continue;
            }
            Method method2;
            try {
                method2 = clazz2.getMethod(str, (Class[])array);
            }
            catch (NoSuchMethodException ex) {
                continue;
            }
            if (Modifier.isPublic(method2.getDeclaringClass().getModifiers())) {
                return method2;
            }
        }
        throw new NoSuchMethodException("Can't find a public method for " + str + " " + ArrayUtils.toString(array));
    }
    
    private static String toCanonicalName(String str) {
        str = StringUtils.deleteWhitespace(str);
        Validate.notNull(str, "className must not be null.", new Object[0]);
        if (str.endsWith("[]")) {
            final StringBuilder sb = new StringBuilder();
            while (str.endsWith("[]")) {
                str = str.substring(0, str.length() - 2);
                sb.append("[");
            }
            final String str2 = ClassUtils.abbreviationMap.get(str);
            if (str2 != null) {
                sb.append(str2);
            }
            else {
                sb.append("L").append(str).append(";");
            }
            str = sb.toString();
        }
        return str;
    }
    
    public static Class<?>[] toClass(final Object... array) {
        if (array == null) {
            return null;
        }
        if (array.length == 0) {
            return ArrayUtils.EMPTY_CLASS_ARRAY;
        }
        final Class[] array2 = new Class[array.length];
        for (int i = 0; i < array.length; ++i) {
            array2[i] = ((array[i] == null) ? null : array[i].getClass());
        }
        return (Class<?>[])array2;
    }
    
    public static String getShortCanonicalName(final Object o, final String s) {
        if (o == null) {
            return s;
        }
        return getShortCanonicalName(o.getClass().getName());
    }
    
    public static String getCanonicalName(final Class<?> clazz) {
        return getCanonicalName(clazz, "");
    }
    
    public static String getCanonicalName(final Class<?> clazz, final String s) {
        if (clazz == null) {
            return s;
        }
        final String canonicalName = clazz.getCanonicalName();
        return (canonicalName == null) ? s : canonicalName;
    }
    
    public static String getCanonicalName(final Object o) {
        return getCanonicalName(o, "");
    }
    
    public static String getCanonicalName(final Object o, final String s) {
        if (o == null) {
            return s;
        }
        final String canonicalName = o.getClass().getCanonicalName();
        return (canonicalName == null) ? s : canonicalName;
    }
    
    public static String getShortCanonicalName(final Class<?> clazz) {
        if (clazz == null) {
            return "";
        }
        return getShortCanonicalName(clazz.getName());
    }
    
    public static String getShortCanonicalName(final String s) {
        return getShortClassName(getCanonicalName(s));
    }
    
    public static String getPackageCanonicalName(final Object o, final String s) {
        if (o == null) {
            return s;
        }
        return getPackageCanonicalName(o.getClass().getName());
    }
    
    public static String getPackageCanonicalName(final Class<?> clazz) {
        if (clazz == null) {
            return "";
        }
        return getPackageCanonicalName(clazz.getName());
    }
    
    public static String getPackageCanonicalName(final String s) {
        return getPackageName(getCanonicalName(s));
    }
    
    private static String getCanonicalName(String str) {
        str = StringUtils.deleteWhitespace(str);
        if (str == null) {
            return null;
        }
        int n = 0;
        while (str.startsWith("[")) {
            ++n;
            str = str.substring(1);
        }
        if (n < 1) {
            return str;
        }
        if (str.startsWith("L")) {
            str = str.substring(1, str.endsWith(";") ? (str.length() - 1) : str.length());
        }
        else if (!str.isEmpty()) {
            str = ClassUtils.reverseAbbreviationMap.get(str.substring(0, 1));
        }
        final StringBuilder sb = new StringBuilder(str);
        for (int i = 0; i < n; ++i) {
            sb.append("[]");
        }
        return sb.toString();
    }
    
    public static Iterable<Class<?>> hierarchy(final Class<?> clazz) {
        return hierarchy(clazz, Interfaces.EXCLUDE);
    }
    
    public static Iterable<Class<?>> hierarchy(final Class<?> clazz, final Interfaces interfaces) {
        final Iterable<Class<?>> iterable = new Iterable<Class<?>>() {
            @Override
            public Iterator<Class<?>> iterator() {
                return new Iterator<Class<?>>() {
                    final /* synthetic */ MutableObject val$next = new MutableObject((T)clazz);
                    
                    @Override
                    public boolean hasNext() {
                        return this.val$next.getValue() != null;
                    }
                    
                    @Override
                    public Class<?> next() {
                        final Class<?> clazz = this.val$next.getValue();
                        this.val$next.setValue(clazz.getSuperclass());
                        return clazz;
                    }
                    
                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
        if (interfaces != Interfaces.INCLUDE) {
            return iterable;
        }
        return new Iterable<Class<?>>() {
            @Override
            public Iterator<Class<?>> iterator() {
                return new Iterator<Class<?>>() {
                    Iterator<Class<?>> interfaces = Collections.emptySet().iterator();
                    final /* synthetic */ Iterator val$wrapped = iterable.iterator();
                    final /* synthetic */ Set val$seenInterfaces = new HashSet();
                    
                    @Override
                    public boolean hasNext() {
                        return this.interfaces.hasNext() || this.val$wrapped.hasNext();
                    }
                    
                    @Override
                    public Class<?> next() {
                        if (this.interfaces.hasNext()) {
                            final Class<?> clazz = this.interfaces.next();
                            this.val$seenInterfaces.add(clazz);
                            return clazz;
                        }
                        final Class<?> clazz2 = this.val$wrapped.next();
                        final LinkedHashSet<Class<?>> set = new LinkedHashSet<Class<?>>();
                        this.walkInterfaces(set, clazz2);
                        this.interfaces = (Iterator<Class<?>>)set.iterator();
                        return clazz2;
                    }
                    
                    private void walkInterfaces(final Set<Class<?>> set, final Class<?> clazz) {
                        for (final Class clazz2 : clazz.getInterfaces()) {
                            if (!this.val$seenInterfaces.contains(clazz2)) {
                                set.add(clazz2);
                            }
                            this.walkInterfaces(set, clazz2);
                        }
                    }
                    
                    @Override
                    public void remove() {
                        throw new UnsupportedOperationException();
                    }
                };
            }
        };
    }
    
    static {
        PACKAGE_SEPARATOR = String.valueOf('.');
        INNER_CLASS_SEPARATOR = String.valueOf('$');
        (namePrimitiveMap = new HashMap<String, Class<?>>()).put("boolean", Boolean.TYPE);
        ClassUtils.namePrimitiveMap.put("byte", Byte.TYPE);
        ClassUtils.namePrimitiveMap.put("char", Character.TYPE);
        ClassUtils.namePrimitiveMap.put("short", Short.TYPE);
        ClassUtils.namePrimitiveMap.put("int", Integer.TYPE);
        ClassUtils.namePrimitiveMap.put("long", Long.TYPE);
        ClassUtils.namePrimitiveMap.put("double", Double.TYPE);
        ClassUtils.namePrimitiveMap.put("float", Float.TYPE);
        ClassUtils.namePrimitiveMap.put("void", Void.TYPE);
        (primitiveWrapperMap = new HashMap<Class<?>, Class<?>>()).put(Boolean.TYPE, Boolean.class);
        ClassUtils.primitiveWrapperMap.put(Byte.TYPE, Byte.class);
        ClassUtils.primitiveWrapperMap.put(Character.TYPE, Character.class);
        ClassUtils.primitiveWrapperMap.put(Short.TYPE, Short.class);
        ClassUtils.primitiveWrapperMap.put(Integer.TYPE, Integer.class);
        ClassUtils.primitiveWrapperMap.put(Long.TYPE, Long.class);
        ClassUtils.primitiveWrapperMap.put(Double.TYPE, Double.class);
        ClassUtils.primitiveWrapperMap.put(Float.TYPE, Float.class);
        ClassUtils.primitiveWrapperMap.put(Void.TYPE, Void.TYPE);
        wrapperPrimitiveMap = new HashMap<Class<?>, Class<?>>();
        for (final Map.Entry<Class<?>, Class<?>> entry : ClassUtils.primitiveWrapperMap.entrySet()) {
            final Class<?> clazz = entry.getKey();
            final Class<?> obj = entry.getValue();
            if (!clazz.equals(obj)) {
                ClassUtils.wrapperPrimitiveMap.put(obj, clazz);
            }
        }
        final HashMap<String, String> m = new HashMap<String, String>();
        m.put("int", "I");
        m.put("boolean", "Z");
        m.put("float", "F");
        m.put("long", "J");
        m.put("short", "S");
        m.put("byte", "B");
        m.put("double", "D");
        m.put("char", "C");
        final HashMap<String, String> i = new HashMap<String, String>();
        for (final Map.Entry<String, String> entry2 : m.entrySet()) {
            i.put(entry2.getValue(), entry2.getKey());
        }
        abbreviationMap = Collections.unmodifiableMap((Map<?, ?>)m);
        reverseAbbreviationMap = Collections.unmodifiableMap((Map<?, ?>)i);
    }
    
    public enum Interfaces
    {
        INCLUDE, 
        EXCLUDE;
    }
}

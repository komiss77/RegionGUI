// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.reflect;

import java.lang.reflect.Type;

public interface Typed<T>
{
    Type getType();
}

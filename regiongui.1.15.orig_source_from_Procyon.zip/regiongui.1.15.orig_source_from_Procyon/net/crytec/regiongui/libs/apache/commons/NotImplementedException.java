// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

public class NotImplementedException extends UnsupportedOperationException
{
    private static final long serialVersionUID = 20131021L;
    private final String code;
    
    public NotImplementedException(final String s) {
        this(s, (String)null);
    }
    
    public NotImplementedException(final Throwable t) {
        this(t, null);
    }
    
    public NotImplementedException(final String s, final Throwable t) {
        this(s, t, null);
    }
    
    public NotImplementedException(final String message, final String code) {
        super(message);
        this.code = code;
    }
    
    public NotImplementedException(final Throwable cause, final String code) {
        super(cause);
        this.code = code;
    }
    
    public NotImplementedException(final String message, final Throwable cause, final String code) {
        super(message, cause);
        this.code = code;
    }
    
    public String getCode() {
        return this.code;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.mutable;

import net.crytec.regiongui.libs.apache.commons.math.NumberUtils;

public class MutableByte extends Number implements Comparable<MutableByte>, Mutable<Number>
{
    private static final long serialVersionUID = -1585823265L;
    private byte value;
    
    public MutableByte() {
    }
    
    public MutableByte(final byte value) {
        this.value = value;
    }
    
    public MutableByte(final Number n) {
        this.value = n.byteValue();
    }
    
    public MutableByte(final String s) {
        this.value = Byte.parseByte(s);
    }
    
    @Override
    public Byte getValue() {
        return this.value;
    }
    
    public void setValue(final byte value) {
        this.value = value;
    }
    
    @Override
    public void setValue(final Number n) {
        this.value = n.byteValue();
    }
    
    public void increment() {
        ++this.value;
    }
    
    public byte getAndIncrement() {
        final byte value = this.value;
        ++this.value;
        return value;
    }
    
    public byte incrementAndGet() {
        return (byte)(++this.value);
    }
    
    public void decrement() {
        --this.value;
    }
    
    public byte getAndDecrement() {
        final byte value = this.value;
        --this.value;
        return value;
    }
    
    public byte decrementAndGet() {
        return (byte)(--this.value);
    }
    
    public void add(final byte b) {
        this.value += b;
    }
    
    public void add(final Number n) {
        this.value += n.byteValue();
    }
    
    public void subtract(final byte b) {
        this.value -= b;
    }
    
    public void subtract(final Number n) {
        this.value -= n.byteValue();
    }
    
    public byte addAndGet(final byte b) {
        return this.value += b;
    }
    
    public byte addAndGet(final Number n) {
        return this.value += n.byteValue();
    }
    
    public byte getAndAdd(final byte b) {
        final byte value = this.value;
        this.value += b;
        return value;
    }
    
    public byte getAndAdd(final Number n) {
        final byte value = this.value;
        this.value += n.byteValue();
        return value;
    }
    
    @Override
    public byte byteValue() {
        return this.value;
    }
    
    @Override
    public int intValue() {
        return this.value;
    }
    
    @Override
    public long longValue() {
        return this.value;
    }
    
    @Override
    public float floatValue() {
        return this.value;
    }
    
    @Override
    public double doubleValue() {
        return this.value;
    }
    
    public Byte toByte() {
        return this.byteValue();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof MutableByte && this.value == ((MutableByte)o).byteValue();
    }
    
    @Override
    public int hashCode() {
        return this.value;
    }
    
    @Override
    public int compareTo(final MutableByte mutableByte) {
        return NumberUtils.compare(this.value, mutableByte.value);
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.Comparator;
import java.io.Serializable;

public final class Range<T> implements Serializable
{
    private static final long serialVersionUID = 1L;
    private final Comparator<T> comparator;
    private final T minimum;
    private final T maximum;
    private transient int hashCode;
    private transient String toString;
    
    public static <T extends Comparable<T>> Range<T> is(final T t) {
        return between(t, t, null);
    }
    
    public static <T> Range<T> is(final T t, final Comparator<T> comparator) {
        return between(t, t, comparator);
    }
    
    public static <T extends Comparable<T>> Range<T> between(final T t, final T t2) {
        return between(t, t2, null);
    }
    
    public static <T> Range<T> between(final T t, final T t2, final Comparator<T> comparator) {
        return new Range<T>(t, t2, comparator);
    }
    
    private Range(final T maximum, final T minimum, final Comparator<T> comparator) {
        if (maximum == null || minimum == null) {
            throw new IllegalArgumentException("Elements in a range must not be null: element1=" + maximum + ", element2=" + minimum);
        }
        if (comparator == null) {
            this.comparator = (Comparator<T>)ComparableComparator.INSTANCE;
        }
        else {
            this.comparator = comparator;
        }
        if (this.comparator.compare(maximum, minimum) < 1) {
            this.minimum = maximum;
            this.maximum = minimum;
        }
        else {
            this.minimum = minimum;
            this.maximum = maximum;
        }
    }
    
    public T getMinimum() {
        return this.minimum;
    }
    
    public T getMaximum() {
        return this.maximum;
    }
    
    public Comparator<T> getComparator() {
        return this.comparator;
    }
    
    public boolean isNaturalOrdering() {
        return this.comparator == ComparableComparator.INSTANCE;
    }
    
    public boolean contains(final T t) {
        return t != null && this.comparator.compare(t, this.minimum) > -1 && this.comparator.compare(t, this.maximum) < 1;
    }
    
    public boolean isAfter(final T t) {
        return t != null && this.comparator.compare(t, this.minimum) < 0;
    }
    
    public boolean isStartedBy(final T t) {
        return t != null && this.comparator.compare(t, this.minimum) == 0;
    }
    
    public boolean isEndedBy(final T t) {
        return t != null && this.comparator.compare(t, this.maximum) == 0;
    }
    
    public boolean isBefore(final T t) {
        return t != null && this.comparator.compare(t, this.maximum) > 0;
    }
    
    public int elementCompareTo(final T t) {
        Validate.notNull(t, "Element is null", new Object[0]);
        if (this.isAfter(t)) {
            return -1;
        }
        if (this.isBefore(t)) {
            return 1;
        }
        return 0;
    }
    
    public boolean containsRange(final Range<T> range) {
        return range != null && this.contains(range.minimum) && this.contains(range.maximum);
    }
    
    public boolean isAfterRange(final Range<T> range) {
        return range != null && this.isAfter(range.maximum);
    }
    
    public boolean isOverlappedBy(final Range<T> range) {
        return range != null && (range.contains((Object)this.minimum) || range.contains((Object)this.maximum) || this.contains(range.minimum));
    }
    
    public boolean isBeforeRange(final Range<T> range) {
        return range != null && this.isBefore(range.minimum);
    }
    
    public Range<T> intersectionWith(final Range<T> range) {
        if (!this.isOverlappedBy(range)) {
            throw new IllegalArgumentException(String.format("Cannot calculate intersection with non-overlapping range %s", range));
        }
        if (this.equals(range)) {
            return this;
        }
        return between((this.getComparator().compare(this.minimum, range.minimum) < 0) ? range.minimum : this.minimum, (this.getComparator().compare(this.maximum, range.maximum) < 0) ? this.maximum : range.maximum, this.getComparator());
    }
    
    @Override
    public boolean equals(final Object o) {
        if (o == this) {
            return true;
        }
        if (o == null || o.getClass() != this.getClass()) {
            return false;
        }
        final Range range = (Range)o;
        return this.minimum.equals(range.minimum) && this.maximum.equals(range.maximum);
    }
    
    @Override
    public int hashCode() {
        int hashCode = this.hashCode;
        if (this.hashCode == 0) {
            hashCode = 37 * (37 * (37 * 17 + this.getClass().hashCode()) + this.minimum.hashCode()) + this.maximum.hashCode();
            this.hashCode = hashCode;
        }
        return hashCode;
    }
    
    @Override
    public String toString() {
        if (this.toString == null) {
            this.toString = "[" + this.minimum + ".." + this.maximum + "]";
        }
        return this.toString;
    }
    
    public String toString(final String format) {
        return String.format(format, this.minimum, this.maximum, this.comparator);
    }
    
    private enum ComparableComparator implements Comparator
    {
        INSTANCE;
        
        @Override
        public int compare(final Object o, final Object o2) {
            return ((Comparable)o).compareTo(o2);
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.mutable;

import net.crytec.regiongui.libs.apache.commons.math.NumberUtils;

public class MutableLong extends Number implements Comparable<MutableLong>, Mutable<Number>
{
    private static final long serialVersionUID = 62986528375L;
    private long value;
    
    public MutableLong() {
    }
    
    public MutableLong(final long value) {
        this.value = value;
    }
    
    public MutableLong(final Number n) {
        this.value = n.longValue();
    }
    
    public MutableLong(final String s) {
        this.value = Long.parseLong(s);
    }
    
    @Override
    public Long getValue() {
        return this.value;
    }
    
    public void setValue(final long value) {
        this.value = value;
    }
    
    @Override
    public void setValue(final Number n) {
        this.value = n.longValue();
    }
    
    public void increment() {
        ++this.value;
    }
    
    public long getAndIncrement() {
        final long value = this.value;
        ++this.value;
        return value;
    }
    
    public long incrementAndGet() {
        return ++this.value;
    }
    
    public void decrement() {
        --this.value;
    }
    
    public long getAndDecrement() {
        final long value = this.value;
        --this.value;
        return value;
    }
    
    public long decrementAndGet() {
        return --this.value;
    }
    
    public void add(final long n) {
        this.value += n;
    }
    
    public void add(final Number n) {
        this.value += n.longValue();
    }
    
    public void subtract(final long n) {
        this.value -= n;
    }
    
    public void subtract(final Number n) {
        this.value -= n.longValue();
    }
    
    public long addAndGet(final long n) {
        return this.value += n;
    }
    
    public long addAndGet(final Number n) {
        return this.value += n.longValue();
    }
    
    public long getAndAdd(final long n) {
        final long value = this.value;
        this.value += n;
        return value;
    }
    
    public long getAndAdd(final Number n) {
        final long value = this.value;
        this.value += n.longValue();
        return value;
    }
    
    @Override
    public int intValue() {
        return (int)this.value;
    }
    
    @Override
    public long longValue() {
        return this.value;
    }
    
    @Override
    public float floatValue() {
        return (float)this.value;
    }
    
    @Override
    public double doubleValue() {
        return (double)this.value;
    }
    
    public Long toLong() {
        return this.longValue();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof MutableLong && this.value == ((MutableLong)o).longValue();
    }
    
    @Override
    public int hashCode() {
        return (int)(this.value ^ this.value >>> 32);
    }
    
    @Override
    public int compareTo(final MutableLong mutableLong) {
        return NumberUtils.compare(this.value, mutableLong.value);
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}

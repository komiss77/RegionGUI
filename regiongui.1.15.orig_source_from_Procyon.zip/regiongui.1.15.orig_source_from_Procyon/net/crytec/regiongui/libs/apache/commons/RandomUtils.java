// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.Random;

public class RandomUtils
{
    private static final Random RANDOM;
    
    public static boolean nextBoolean() {
        return RandomUtils.RANDOM.nextBoolean();
    }
    
    public static byte[] nextBytes(final int n) {
        Validate.isTrue(n >= 0, "Count cannot be negative.", new Object[0]);
        final byte[] bytes = new byte[n];
        RandomUtils.RANDOM.nextBytes(bytes);
        return bytes;
    }
    
    public static int nextInt(final int n, final int n2) {
        Validate.isTrue(n2 >= n, "Start value must be smaller or equal to end value.", new Object[0]);
        Validate.isTrue(n >= 0, "Both range values must be non-negative.", new Object[0]);
        if (n == n2) {
            return n;
        }
        return n + RandomUtils.RANDOM.nextInt(n2 - n);
    }
    
    public static int nextInt() {
        return nextInt(0, Integer.MAX_VALUE);
    }
    
    public static long nextLong(final long n, final long n2) {
        Validate.isTrue(n2 >= n, "Start value must be smaller or equal to end value.", new Object[0]);
        Validate.isTrue(n >= 0L, "Both range values must be non-negative.", new Object[0]);
        if (n == n2) {
            return n;
        }
        return (long)nextDouble((double)n, (double)n2);
    }
    
    public static long nextLong() {
        return nextLong(0L, Long.MAX_VALUE);
    }
    
    public static double nextDouble(final double n, final double n2) {
        Validate.isTrue(n2 >= n, "Start value must be smaller or equal to end value.", new Object[0]);
        Validate.isTrue(n >= 0.0, "Both range values must be non-negative.", new Object[0]);
        if (n == n2) {
            return n;
        }
        return n + (n2 - n) * RandomUtils.RANDOM.nextDouble();
    }
    
    public static double nextDouble() {
        return nextDouble(0.0, Double.MAX_VALUE);
    }
    
    public static float nextFloat(final float n, final float n2) {
        Validate.isTrue(n2 >= n, "Start value must be smaller or equal to end value.", new Object[0]);
        Validate.isTrue(n >= 0.0f, "Both range values must be non-negative.", new Object[0]);
        if (n == n2) {
            return n;
        }
        return n + (n2 - n) * RandomUtils.RANDOM.nextFloat();
    }
    
    public static float nextFloat() {
        return nextFloat(0.0f, Float.MAX_VALUE);
    }
    
    static {
        RANDOM = new Random();
    }
}

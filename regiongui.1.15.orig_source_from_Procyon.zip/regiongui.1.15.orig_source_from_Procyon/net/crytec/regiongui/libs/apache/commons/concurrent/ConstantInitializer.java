// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import java.util.Objects;

public class ConstantInitializer<T> implements ConcurrentInitializer<T>
{
    private static final String FMT_TO_STRING = "ConstantInitializer@%d [ object = %s ]";
    private final T object;
    
    public ConstantInitializer(final T object) {
        this.object = object;
    }
    
    public final T getObject() {
        return this.object;
    }
    
    @Override
    public T get() {
        return this.getObject();
    }
    
    @Override
    public int hashCode() {
        return (this.getObject() != null) ? this.getObject().hashCode() : 0;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o instanceof ConstantInitializer && Objects.equals(this.getObject(), ((ConstantInitializer)o).getObject()));
    }
    
    @Override
    public String toString() {
        return String.format("ConstantInitializer@%d [ object = %s ]", System.identityHashCode(this), String.valueOf(this.getObject()));
    }
}

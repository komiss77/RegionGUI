// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.builder;

import java.lang.reflect.AccessibleObject;
import java.lang.annotation.Annotation;
import java.util.Arrays;
import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.ArrayList;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;
import java.util.Collection;

public class ReflectionToStringBuilder extends ToStringBuilder
{
    private boolean appendStatics;
    private boolean appendTransients;
    private boolean excludeNullValues;
    protected String[] excludeFieldNames;
    private Class<?> upToClass;
    
    public static String toString(final Object o) {
        return toString(o, null, false, false, null);
    }
    
    public static String toString(final Object o, final ToStringStyle toStringStyle) {
        return toString(o, toStringStyle, false, false, null);
    }
    
    public static String toString(final Object o, final ToStringStyle toStringStyle, final boolean b) {
        return toString(o, toStringStyle, b, false, null);
    }
    
    public static String toString(final Object o, final ToStringStyle toStringStyle, final boolean b, final boolean b2) {
        return toString(o, toStringStyle, b, b2, null);
    }
    
    public static <T> String toString(final T t, final ToStringStyle toStringStyle, final boolean b, final boolean b2, final Class<? super T> clazz) {
        return new ReflectionToStringBuilder((T)t, toStringStyle, null, (Class<? super T>)clazz, b, b2).toString();
    }
    
    public static <T> String toString(final T t, final ToStringStyle toStringStyle, final boolean b, final boolean b2, final boolean b3, final Class<? super T> clazz) {
        return new ReflectionToStringBuilder((T)t, toStringStyle, null, (Class<? super T>)clazz, b, b2, b3).toString();
    }
    
    public static String toStringExclude(final Object o, final Collection<String> collection) {
        return toStringExclude(o, toNoNullStringArray(collection));
    }
    
    static String[] toNoNullStringArray(final Collection<String> collection) {
        if (collection == null) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        return toNoNullStringArray(collection.toArray());
    }
    
    static String[] toNoNullStringArray(final Object[] array) {
        final ArrayList<String> list = new ArrayList<String>(array.length);
        for (final Object o : array) {
            if (o != null) {
                list.add(o.toString());
            }
        }
        return list.toArray(ArrayUtils.EMPTY_STRING_ARRAY);
    }
    
    public static String toStringExclude(final Object o, final String... excludeFieldNames) {
        return new ReflectionToStringBuilder(o).setExcludeFieldNames(excludeFieldNames).toString();
    }
    
    private static Object checkNotNull(final Object o) {
        Validate.isTrue(o != null, "The Object passed in should not be null.", new Object[0]);
        return o;
    }
    
    public ReflectionToStringBuilder(final Object o) {
        super(checkNotNull(o));
        this.appendStatics = false;
        this.appendTransients = false;
        this.upToClass = null;
    }
    
    public ReflectionToStringBuilder(final Object o, final ToStringStyle toStringStyle) {
        super(checkNotNull(o), toStringStyle);
        this.appendStatics = false;
        this.appendTransients = false;
        this.upToClass = null;
    }
    
    public ReflectionToStringBuilder(final Object o, final ToStringStyle toStringStyle, final StringBuffer sb) {
        super(checkNotNull(o), toStringStyle, sb);
        this.appendStatics = false;
        this.appendTransients = false;
        this.upToClass = null;
    }
    
    public <T> ReflectionToStringBuilder(final T t, final ToStringStyle toStringStyle, final StringBuffer sb, final Class<? super T> upToClass, final boolean appendTransients, final boolean appendStatics) {
        super(checkNotNull(t), toStringStyle, sb);
        this.appendStatics = false;
        this.appendTransients = false;
        this.upToClass = null;
        this.setUpToClass(upToClass);
        this.setAppendTransients(appendTransients);
        this.setAppendStatics(appendStatics);
    }
    
    public <T> ReflectionToStringBuilder(final T t, final ToStringStyle toStringStyle, final StringBuffer sb, final Class<? super T> upToClass, final boolean appendTransients, final boolean appendStatics, final boolean excludeNullValues) {
        super(checkNotNull(t), toStringStyle, sb);
        this.appendStatics = false;
        this.appendTransients = false;
        this.upToClass = null;
        this.setUpToClass(upToClass);
        this.setAppendTransients(appendTransients);
        this.setAppendStatics(appendStatics);
        this.setExcludeNullValues(excludeNullValues);
    }
    
    protected boolean accept(final Field field) {
        return field.getName().indexOf(36) == -1 && (!Modifier.isTransient(field.getModifiers()) || this.isAppendTransients()) && (!Modifier.isStatic(field.getModifiers()) || this.isAppendStatics()) && (this.excludeFieldNames == null || Arrays.binarySearch(this.excludeFieldNames, field.getName()) < 0) && !field.isAnnotationPresent(ToStringExclude.class);
    }
    
    protected void appendFieldsIn(final Class<?> clazz) {
        if (clazz.isArray()) {
            this.reflectionAppendArray(this.getObject());
            return;
        }
        final Field[] declaredFields = clazz.getDeclaredFields();
        AccessibleObject.setAccessible(declaredFields, true);
        for (final Field field : declaredFields) {
            final String name = field.getName();
            if (this.accept(field)) {
                try {
                    final Object value = this.getValue(field);
                    if (!this.excludeNullValues || value != null) {
                        this.append(name, value, !field.isAnnotationPresent(ToStringSummary.class));
                    }
                }
                catch (IllegalAccessException ex) {
                    throw new InternalError("Unexpected IllegalAccessException: " + ex.getMessage());
                }
            }
        }
    }
    
    public String[] getExcludeFieldNames() {
        return this.excludeFieldNames.clone();
    }
    
    public Class<?> getUpToClass() {
        return this.upToClass;
    }
    
    protected Object getValue(final Field field) {
        return field.get(this.getObject());
    }
    
    public boolean isAppendStatics() {
        return this.appendStatics;
    }
    
    public boolean isAppendTransients() {
        return this.appendTransients;
    }
    
    public boolean isExcludeNullValues() {
        return this.excludeNullValues;
    }
    
    public ReflectionToStringBuilder reflectionAppendArray(final Object o) {
        this.getStyle().reflectionAppendArrayDetail(this.getStringBuffer(), null, o);
        return this;
    }
    
    public void setAppendStatics(final boolean appendStatics) {
        this.appendStatics = appendStatics;
    }
    
    public void setAppendTransients(final boolean appendTransients) {
        this.appendTransients = appendTransients;
    }
    
    public void setExcludeNullValues(final boolean excludeNullValues) {
        this.excludeNullValues = excludeNullValues;
    }
    
    public ReflectionToStringBuilder setExcludeFieldNames(final String... array) {
        if (array == null) {
            this.excludeFieldNames = null;
        }
        else {
            Arrays.sort(this.excludeFieldNames = toNoNullStringArray(array));
        }
        return this;
    }
    
    public void setUpToClass(final Class<?> upToClass) {
        if (upToClass != null) {
            final Object object = this.getObject();
            if (object != null && !upToClass.isInstance(object)) {
                throw new IllegalArgumentException("Specified class is not a superclass of the object");
            }
        }
        this.upToClass = upToClass;
    }
    
    @Override
    public String toString() {
        if (this.getObject() == null) {
            return this.getStyle().getNullText();
        }
        Class<?> clazz = this.getObject().getClass();
        this.appendFieldsIn(clazz);
        while (clazz.getSuperclass() != null && clazz != this.getUpToClass()) {
            clazz = clazz.getSuperclass();
            this.appendFieldsIn(clazz);
        }
        return super.toString();
    }
}

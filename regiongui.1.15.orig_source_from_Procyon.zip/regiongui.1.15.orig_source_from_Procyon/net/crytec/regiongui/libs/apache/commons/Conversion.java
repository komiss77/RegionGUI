// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.UUID;

public class Conversion
{
    private static final boolean[] TTTT;
    private static final boolean[] FTTT;
    private static final boolean[] TFTT;
    private static final boolean[] FFTT;
    private static final boolean[] TTFT;
    private static final boolean[] FTFT;
    private static final boolean[] TFFT;
    private static final boolean[] FFFT;
    private static final boolean[] TTTF;
    private static final boolean[] FTTF;
    private static final boolean[] TFTF;
    private static final boolean[] FFTF;
    private static final boolean[] TTFF;
    private static final boolean[] FTFF;
    private static final boolean[] TFFF;
    private static final boolean[] FFFF;
    
    public static int hexDigitToInt(final char c) {
        final int digit = Character.digit(c, 16);
        if (digit < 0) {
            throw new IllegalArgumentException("Cannot interpret '" + c + "' as a hexadecimal digit");
        }
        return digit;
    }
    
    public static int hexDigitMsb0ToInt(final char c) {
        switch (c) {
            case '0': {
                return 0;
            }
            case '1': {
                return 8;
            }
            case '2': {
                return 4;
            }
            case '3': {
                return 12;
            }
            case '4': {
                return 2;
            }
            case '5': {
                return 10;
            }
            case '6': {
                return 6;
            }
            case '7': {
                return 14;
            }
            case '8': {
                return 1;
            }
            case '9': {
                return 9;
            }
            case 'A':
            case 'a': {
                return 5;
            }
            case 'B':
            case 'b': {
                return 13;
            }
            case 'C':
            case 'c': {
                return 3;
            }
            case 'D':
            case 'd': {
                return 11;
            }
            case 'E':
            case 'e': {
                return 7;
            }
            case 'F':
            case 'f': {
                return 15;
            }
            default: {
                throw new IllegalArgumentException("Cannot interpret '" + c + "' as a hexadecimal digit");
            }
        }
    }
    
    public static boolean[] hexDigitToBinary(final char c) {
        switch (c) {
            case '0': {
                return Conversion.FFFF.clone();
            }
            case '1': {
                return Conversion.TFFF.clone();
            }
            case '2': {
                return Conversion.FTFF.clone();
            }
            case '3': {
                return Conversion.TTFF.clone();
            }
            case '4': {
                return Conversion.FFTF.clone();
            }
            case '5': {
                return Conversion.TFTF.clone();
            }
            case '6': {
                return Conversion.FTTF.clone();
            }
            case '7': {
                return Conversion.TTTF.clone();
            }
            case '8': {
                return Conversion.FFFT.clone();
            }
            case '9': {
                return Conversion.TFFT.clone();
            }
            case 'A':
            case 'a': {
                return Conversion.FTFT.clone();
            }
            case 'B':
            case 'b': {
                return Conversion.TTFT.clone();
            }
            case 'C':
            case 'c': {
                return Conversion.FFTT.clone();
            }
            case 'D':
            case 'd': {
                return Conversion.TFTT.clone();
            }
            case 'E':
            case 'e': {
                return Conversion.FTTT.clone();
            }
            case 'F':
            case 'f': {
                return Conversion.TTTT.clone();
            }
            default: {
                throw new IllegalArgumentException("Cannot interpret '" + c + "' as a hexadecimal digit");
            }
        }
    }
    
    public static boolean[] hexDigitMsb0ToBinary(final char c) {
        switch (c) {
            case '0': {
                return Conversion.FFFF.clone();
            }
            case '1': {
                return Conversion.FFFT.clone();
            }
            case '2': {
                return Conversion.FFTF.clone();
            }
            case '3': {
                return Conversion.FFTT.clone();
            }
            case '4': {
                return Conversion.FTFF.clone();
            }
            case '5': {
                return Conversion.FTFT.clone();
            }
            case '6': {
                return Conversion.FTTF.clone();
            }
            case '7': {
                return Conversion.FTTT.clone();
            }
            case '8': {
                return Conversion.TFFF.clone();
            }
            case '9': {
                return Conversion.TFFT.clone();
            }
            case 'A':
            case 'a': {
                return Conversion.TFTF.clone();
            }
            case 'B':
            case 'b': {
                return Conversion.TFTT.clone();
            }
            case 'C':
            case 'c': {
                return Conversion.TTFF.clone();
            }
            case 'D':
            case 'd': {
                return Conversion.TTFT.clone();
            }
            case 'E':
            case 'e': {
                return Conversion.TTTF.clone();
            }
            case 'F':
            case 'f': {
                return Conversion.TTTT.clone();
            }
            default: {
                throw new IllegalArgumentException("Cannot interpret '" + c + "' as a hexadecimal digit");
            }
        }
    }
    
    public static char binaryToHexDigit(final boolean[] array) {
        return binaryToHexDigit(array, 0);
    }
    
    public static char binaryToHexDigit(final boolean[] array, final int n) {
        if (array.length == 0) {
            throw new IllegalArgumentException("Cannot convert an empty array.");
        }
        if (array.length > n + 3 && array[n + 3]) {
            if (array.length > n + 2 && array[n + 2]) {
                if (array.length > n + 1 && array[n + 1]) {
                    return array[n] ? 'f' : 'e';
                }
                return array[n] ? 'd' : 'c';
            }
            else {
                if (array.length > n + 1 && array[n + 1]) {
                    return array[n] ? 'b' : 'a';
                }
                return array[n] ? '9' : '8';
            }
        }
        else if (array.length > n + 2 && array[n + 2]) {
            if (array.length > n + 1 && array[n + 1]) {
                return array[n] ? '7' : '6';
            }
            return array[n] ? '5' : '4';
        }
        else {
            if (array.length > n + 1 && array[n + 1]) {
                return array[n] ? '3' : '2';
            }
            return array[n] ? '1' : '0';
        }
    }
    
    public static char binaryToHexDigitMsb0_4bits(final boolean[] array) {
        return binaryToHexDigitMsb0_4bits(array, 0);
    }
    
    public static char binaryToHexDigitMsb0_4bits(final boolean[] array, final int i) {
        if (array.length > 8) {
            throw new IllegalArgumentException("src.length>8: src.length=" + array.length);
        }
        if (array.length - i < 4) {
            throw new IllegalArgumentException("src.length-srcPos<4: src.length=" + array.length + ", srcPos=" + i);
        }
        if (array[i + 3]) {
            if (array[i + 2]) {
                if (array[i + 1]) {
                    return array[i] ? 'f' : '7';
                }
                return array[i] ? 'b' : '3';
            }
            else {
                if (array[i + 1]) {
                    return array[i] ? 'd' : '5';
                }
                return array[i] ? '9' : '1';
            }
        }
        else if (array[i + 2]) {
            if (array[i + 1]) {
                return array[i] ? 'e' : '6';
            }
            return array[i] ? 'a' : '2';
        }
        else {
            if (array[i + 1]) {
                return array[i] ? 'c' : '4';
            }
            return array[i] ? '8' : '0';
        }
    }
    
    public static char binaryBeMsb0ToHexDigit(final boolean[] array) {
        return binaryBeMsb0ToHexDigit(array, 0);
    }
    
    public static char binaryBeMsb0ToHexDigit(boolean[] array, int n) {
        if (array.length == 0) {
            throw new IllegalArgumentException("Cannot convert an empty array.");
        }
        final int n2 = array.length - 1 - n;
        final int min = Math.min(4, n2 + 1);
        final boolean[] array2 = new boolean[4];
        System.arraycopy(array, n2 + 1 - min, array2, 4 - min, min);
        array = array2;
        n = 0;
        if (array[n]) {
            if (array.length > n + 1 && array[n + 1]) {
                if (array.length > n + 2 && array[n + 2]) {
                    return (array.length > n + 3 && array[n + 3]) ? 'f' : 'e';
                }
                return (array.length > n + 3 && array[n + 3]) ? 'd' : 'c';
            }
            else {
                if (array.length > n + 2 && array[n + 2]) {
                    return (array.length > n + 3 && array[n + 3]) ? 'b' : 'a';
                }
                return (array.length > n + 3 && array[n + 3]) ? '9' : '8';
            }
        }
        else if (array.length > n + 1 && array[n + 1]) {
            if (array.length > n + 2 && array[n + 2]) {
                return (array.length > n + 3 && array[n + 3]) ? '7' : '6';
            }
            return (array.length > n + 3 && array[n + 3]) ? '5' : '4';
        }
        else {
            if (array.length > n + 2 && array[n + 2]) {
                return (array.length > n + 3 && array[n + 3]) ? '3' : '2';
            }
            return (array.length > n + 3 && array[n + 3]) ? '1' : '0';
        }
    }
    
    public static char intToHexDigit(final int n) {
        final char forDigit = Character.forDigit(n, 16);
        if (forDigit == '\0') {
            throw new IllegalArgumentException("nibble value not between 0 and 15: " + n);
        }
        return forDigit;
    }
    
    public static char intToHexDigitMsb0(final int i) {
        switch (i) {
            case 0: {
                return '0';
            }
            case 1: {
                return '8';
            }
            case 2: {
                return '4';
            }
            case 3: {
                return 'c';
            }
            case 4: {
                return '2';
            }
            case 5: {
                return 'a';
            }
            case 6: {
                return '6';
            }
            case 7: {
                return 'e';
            }
            case 8: {
                return '1';
            }
            case 9: {
                return '9';
            }
            case 10: {
                return '5';
            }
            case 11: {
                return 'd';
            }
            case 12: {
                return '3';
            }
            case 13: {
                return 'b';
            }
            case 14: {
                return '7';
            }
            case 15: {
                return 'f';
            }
            default: {
                throw new IllegalArgumentException("nibble value not between 0 and 15: " + i);
            }
        }
    }
    
    public static long intArrayToLong(final int[] array, final int n, final long n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 32 + n3 >= 64) {
            throw new IllegalArgumentException("(nInts-1)*32+dstPos is greater or equal to than 64");
        }
        long n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 32 + n3;
            n5 = ((n5 & ~(4294967295L << n6)) | (0xFFFFFFFFL & (long)array[i + n]) << n6);
        }
        return n5;
    }
    
    public static long shortArrayToLong(final short[] array, final int n, final long n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 16 + n3 >= 64) {
            throw new IllegalArgumentException("(nShorts-1)*16+dstPos is greater or equal to than 64");
        }
        long n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 16 + n3;
            n5 = ((n5 & ~(65535L << n6)) | (0xFFFFL & (long)array[i + n]) << n6);
        }
        return n5;
    }
    
    public static int shortArrayToInt(final short[] array, final int n, final int n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 16 + n3 >= 32) {
            throw new IllegalArgumentException("(nShorts-1)*16+dstPos is greater or equal to than 32");
        }
        int n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 16 + n3;
            n5 = ((n5 & ~(65535 << n6)) | (0xFFFF & array[i + n]) << n6);
        }
        return n5;
    }
    
    public static long byteArrayToLong(final byte[] array, final int n, final long n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 8 + n3 >= 64) {
            throw new IllegalArgumentException("(nBytes-1)*8+dstPos is greater or equal to than 64");
        }
        long n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 8 + n3;
            n5 = ((n5 & ~(255L << n6)) | (0xFFL & (long)array[i + n]) << n6);
        }
        return n5;
    }
    
    public static int byteArrayToInt(final byte[] array, final int n, final int n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 8 + n3 >= 32) {
            throw new IllegalArgumentException("(nBytes-1)*8+dstPos is greater or equal to than 32");
        }
        int n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 8 + n3;
            n5 = ((n5 & ~(255 << n6)) | (0xFF & array[i + n]) << n6);
        }
        return n5;
    }
    
    public static short byteArrayToShort(final byte[] array, final int n, final short n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 8 + n3 >= 16) {
            throw new IllegalArgumentException("(nBytes-1)*8+dstPos is greater or equal to than 16");
        }
        short n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 8 + n3;
            n5 = (short)((n5 & ~(255 << n6)) | (0xFF & array[i + n]) << n6);
        }
        return n5;
    }
    
    public static long hexToLong(final String s, final int n, final long n2, final int n3, final int n4) {
        if (0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 4 + n3 >= 64) {
            throw new IllegalArgumentException("(nHexs-1)*4+dstPos is greater or equal to than 64");
        }
        long n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 4 + n3;
            n5 = ((n5 & ~(15L << n6)) | (0xFL & (long)hexDigitToInt(s.charAt(i + n))) << n6);
        }
        return n5;
    }
    
    public static int hexToInt(final String s, final int n, final int n2, final int n3, final int n4) {
        if (0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 4 + n3 >= 32) {
            throw new IllegalArgumentException("(nHexs-1)*4+dstPos is greater or equal to than 32");
        }
        int n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 4 + n3;
            n5 = ((n5 & ~(15 << n6)) | (0xF & hexDigitToInt(s.charAt(i + n))) << n6);
        }
        return n5;
    }
    
    public static short hexToShort(final String s, final int n, final short n2, final int n3, final int n4) {
        if (0 == n4) {
            return n2;
        }
        if ((n4 - 1) * 4 + n3 >= 16) {
            throw new IllegalArgumentException("(nHexs-1)*4+dstPos is greater or equal to than 16");
        }
        short n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i * 4 + n3;
            n5 = (short)((n5 & ~(15 << n6)) | (0xF & hexDigitToInt(s.charAt(i + n))) << n6);
        }
        return n5;
    }
    
    public static byte hexToByte(final String s, final int n, final byte b, final int n2, final int n3) {
        if (0 == n3) {
            return b;
        }
        if ((n3 - 1) * 4 + n2 >= 8) {
            throw new IllegalArgumentException("(nHexs-1)*4+dstPos is greater or equal to than 8");
        }
        byte b2 = b;
        for (int i = 0; i < n3; ++i) {
            final int n4 = i * 4 + n2;
            b2 = (byte)((b2 & ~(15 << n4)) | (0xF & hexDigitToInt(s.charAt(i + n))) << n4);
        }
        return b2;
    }
    
    public static long binaryToLong(final boolean[] array, final int n, final long n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if (n4 - 1 + n3 >= 64) {
            throw new IllegalArgumentException("nBools-1+dstPos is greater or equal to than 64");
        }
        long n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i + n3;
            n5 = ((n5 & ~(1L << n6)) | (array[i + n] ? 1 : 0) << n6);
        }
        return n5;
    }
    
    public static int binaryToInt(final boolean[] array, final int n, final int n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if (n4 - 1 + n3 >= 32) {
            throw new IllegalArgumentException("nBools-1+dstPos is greater or equal to than 32");
        }
        int n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i + n3;
            n5 = ((n5 & ~(1 << n6)) | (array[i + n] ? 1 : 0) << n6);
        }
        return n5;
    }
    
    public static short binaryToShort(final boolean[] array, final int n, final short n2, final int n3, final int n4) {
        if ((array.length == 0 && n == 0) || 0 == n4) {
            return n2;
        }
        if (n4 - 1 + n3 >= 16) {
            throw new IllegalArgumentException("nBools-1+dstPos is greater or equal to than 16");
        }
        short n5 = n2;
        for (int i = 0; i < n4; ++i) {
            final int n6 = i + n3;
            n5 = (short)((n5 & ~(1 << n6)) | (array[i + n] ? 1 : 0) << n6);
        }
        return n5;
    }
    
    public static byte binaryToByte(final boolean[] array, final int n, final byte b, final int n2, final int n3) {
        if ((array.length == 0 && n == 0) || 0 == n3) {
            return b;
        }
        if (n3 - 1 + n2 >= 8) {
            throw new IllegalArgumentException("nBools-1+dstPos is greater or equal to than 8");
        }
        byte b2 = b;
        for (int i = 0; i < n3; ++i) {
            final int n4 = i + n2;
            b2 = (byte)((b2 & ~(1 << n4)) | (array[i + n] ? 1 : 0) << n4);
        }
        return b2;
    }
    
    public static int[] longToIntArray(final long n, final int n2, final int[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if ((n4 - 1) * 32 + n2 >= 64) {
            throw new IllegalArgumentException("(nInts-1)*32+srcPos is greater or equal to than 64");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = (int)(-1L & n >> i * 32 + n2);
        }
        return array;
    }
    
    public static short[] longToShortArray(final long n, final int n2, final short[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if ((n4 - 1) * 16 + n2 >= 64) {
            throw new IllegalArgumentException("(nShorts-1)*16+srcPos is greater or equal to than 64");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = (short)(0xFFFFL & n >> i * 16 + n2);
        }
        return array;
    }
    
    public static short[] intToShortArray(final int n, final int n2, final short[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if ((n4 - 1) * 16 + n2 >= 32) {
            throw new IllegalArgumentException("(nShorts-1)*16+srcPos is greater or equal to than 32");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = (short)(0xFFFF & n >> i * 16 + n2);
        }
        return array;
    }
    
    public static byte[] longToByteArray(final long n, final int n2, final byte[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if ((n4 - 1) * 8 + n2 >= 64) {
            throw new IllegalArgumentException("(nBytes-1)*8+srcPos is greater or equal to than 64");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = (byte)(0xFFL & n >> i * 8 + n2);
        }
        return array;
    }
    
    public static byte[] intToByteArray(final int n, final int n2, final byte[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if ((n4 - 1) * 8 + n2 >= 32) {
            throw new IllegalArgumentException("(nBytes-1)*8+srcPos is greater or equal to than 32");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = (byte)(0xFF & n >> i * 8 + n2);
        }
        return array;
    }
    
    public static byte[] shortToByteArray(final short n, final int n2, final byte[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if ((n4 - 1) * 8 + n2 >= 16) {
            throw new IllegalArgumentException("(nBytes-1)*8+srcPos is greater or equal to than 16");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = (byte)(0xFF & n >> i * 8 + n2);
        }
        return array;
    }
    
    public static String longToHex(final long n, final int n2, final String str, final int n3, final int n4) {
        if (0 == n4) {
            return str;
        }
        if ((n4 - 1) * 4 + n2 >= 64) {
            throw new IllegalArgumentException("(nHexs-1)*4+srcPos is greater or equal to than 64");
        }
        final StringBuilder sb = new StringBuilder(str);
        int length = sb.length();
        for (int i = 0; i < n4; ++i) {
            final int n5 = (int)(0xFL & n >> i * 4 + n2);
            if (n3 + i == length) {
                ++length;
                sb.append(intToHexDigit(n5));
            }
            else {
                sb.setCharAt(n3 + i, intToHexDigit(n5));
            }
        }
        return sb.toString();
    }
    
    public static String intToHex(final int n, final int n2, final String str, final int n3, final int n4) {
        if (0 == n4) {
            return str;
        }
        if ((n4 - 1) * 4 + n2 >= 32) {
            throw new IllegalArgumentException("(nHexs-1)*4+srcPos is greater or equal to than 32");
        }
        final StringBuilder sb = new StringBuilder(str);
        int length = sb.length();
        for (int i = 0; i < n4; ++i) {
            final int n5 = 0xF & n >> i * 4 + n2;
            if (n3 + i == length) {
                ++length;
                sb.append(intToHexDigit(n5));
            }
            else {
                sb.setCharAt(n3 + i, intToHexDigit(n5));
            }
        }
        return sb.toString();
    }
    
    public static String shortToHex(final short n, final int n2, final String str, final int n3, final int n4) {
        if (0 == n4) {
            return str;
        }
        if ((n4 - 1) * 4 + n2 >= 16) {
            throw new IllegalArgumentException("(nHexs-1)*4+srcPos is greater or equal to than 16");
        }
        final StringBuilder sb = new StringBuilder(str);
        int length = sb.length();
        for (int i = 0; i < n4; ++i) {
            final int n5 = 0xF & n >> i * 4 + n2;
            if (n3 + i == length) {
                ++length;
                sb.append(intToHexDigit(n5));
            }
            else {
                sb.setCharAt(n3 + i, intToHexDigit(n5));
            }
        }
        return sb.toString();
    }
    
    public static String byteToHex(final byte b, final int n, final String str, final int n2, final int n3) {
        if (0 == n3) {
            return str;
        }
        if ((n3 - 1) * 4 + n >= 8) {
            throw new IllegalArgumentException("(nHexs-1)*4+srcPos is greater or equal to than 8");
        }
        final StringBuilder sb = new StringBuilder(str);
        int length = sb.length();
        for (int i = 0; i < n3; ++i) {
            final int n4 = 0xF & b >> i * 4 + n;
            if (n2 + i == length) {
                ++length;
                sb.append(intToHexDigit(n4));
            }
            else {
                sb.setCharAt(n2 + i, intToHexDigit(n4));
            }
        }
        return sb.toString();
    }
    
    public static boolean[] longToBinary(final long n, final int n2, final boolean[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if (n4 - 1 + n2 >= 64) {
            throw new IllegalArgumentException("nBools-1+srcPos is greater or equal to than 64");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = ((0x1L & n >> i + n2) != 0x0L);
        }
        return array;
    }
    
    public static boolean[] intToBinary(final int n, final int n2, final boolean[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if (n4 - 1 + n2 >= 32) {
            throw new IllegalArgumentException("nBools-1+srcPos is greater or equal to than 32");
        }
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = ((0x1 & n >> i + n2) != 0x0);
        }
        return array;
    }
    
    public static boolean[] shortToBinary(final short n, final int n2, final boolean[] array, final int n3, final int n4) {
        if (0 == n4) {
            return array;
        }
        if (n4 - 1 + n2 >= 16) {
            throw new IllegalArgumentException("nBools-1+srcPos is greater or equal to than 16");
        }
        assert n4 - 1 < 16 - n2;
        for (int i = 0; i < n4; ++i) {
            array[n3 + i] = ((0x1 & n >> i + n2) != 0x0);
        }
        return array;
    }
    
    public static boolean[] byteToBinary(final byte b, final int n, final boolean[] array, final int n2, final int n3) {
        if (0 == n3) {
            return array;
        }
        if (n3 - 1 + n >= 8) {
            throw new IllegalArgumentException("nBools-1+srcPos is greater or equal to than 8");
        }
        for (int i = 0; i < n3; ++i) {
            array[n2 + i] = ((0x1 & b >> i + n) != 0x0);
        }
        return array;
    }
    
    public static byte[] uuidToByteArray(final UUID uuid, final byte[] array, final int n, final int n2) {
        if (0 == n2) {
            return array;
        }
        if (n2 > 16) {
            throw new IllegalArgumentException("nBytes is greater than 16");
        }
        longToByteArray(uuid.getMostSignificantBits(), 0, array, n, (n2 > 8) ? 8 : n2);
        if (n2 >= 8) {
            longToByteArray(uuid.getLeastSignificantBits(), 0, array, n + 8, n2 - 8);
        }
        return array;
    }
    
    public static UUID byteArrayToUuid(final byte[] array, final int n) {
        if (array.length - n < 16) {
            throw new IllegalArgumentException("Need at least 16 bytes for UUID");
        }
        return new UUID(byteArrayToLong(array, n, 0L, 0, 8), byteArrayToLong(array, n + 8, 0L, 0, 8));
    }
    
    static {
        TTTT = new boolean[] { true, true, true, true };
        FTTT = new boolean[] { false, true, true, true };
        TFTT = new boolean[] { true, false, true, true };
        FFTT = new boolean[] { false, false, true, true };
        TTFT = new boolean[] { true, true, false, true };
        FTFT = new boolean[] { false, true, false, true };
        TFFT = new boolean[] { true, false, false, true };
        FFFT = new boolean[] { false, false, false, true };
        TTTF = new boolean[] { true, true, true, false };
        FTTF = new boolean[] { false, true, true, false };
        TFTF = new boolean[] { true, false, true, false };
        FFTF = new boolean[] { false, false, true, false };
        TTFF = new boolean[] { true, true, false, false };
        FTFF = new boolean[] { false, true, false, false };
        TFFF = new boolean[] { true, false, false, false };
        FFFF = new boolean[] { false, false, false, false };
    }
}

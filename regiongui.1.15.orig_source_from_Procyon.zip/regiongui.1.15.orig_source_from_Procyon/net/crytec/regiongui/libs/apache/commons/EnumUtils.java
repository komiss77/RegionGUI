// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.Collection;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;

public class EnumUtils
{
    private static final String NULL_ELEMENTS_NOT_PERMITTED = "null elements not permitted";
    private static final String CANNOT_STORE_S_S_VALUES_IN_S_BITS = "Cannot store %s %s values in %s bits";
    private static final String S_DOES_NOT_SEEM_TO_BE_AN_ENUM_TYPE = "%s does not seem to be an Enum type";
    private static final String ENUM_CLASS_MUST_BE_DEFINED = "EnumClass must be defined.";
    
    public static <E extends Enum<E>> Map<String, E> getEnumMap(final Class<E> clazz) {
        final LinkedHashMap<String, E> linkedHashMap = new LinkedHashMap<String, E>();
        for (final Enum<E> enum1 : clazz.getEnumConstants()) {
            linkedHashMap.put(enum1.name(), (E)enum1);
        }
        return linkedHashMap;
    }
    
    public static <E extends Enum<E>> List<E> getEnumList(final Class<E> clazz) {
        return new ArrayList<E>((Collection<? extends E>)Arrays.asList((E[])clazz.getEnumConstants()));
    }
    
    public static <E extends Enum<E>> boolean isValidEnum(final Class<E> clazz, final String s) {
        return getEnum(clazz, s) != null;
    }
    
    public static <E extends Enum<E>> boolean isValidEnumIgnoreCase(final Class<E> clazz, final String s) {
        return getEnumIgnoreCase(clazz, s) != null;
    }
    
    public static <E extends Enum<E>> E getEnum(final Class<E> enumType, final String name) {
        if (name == null) {
            return null;
        }
        try {
            return Enum.valueOf(enumType, name);
        }
        catch (IllegalArgumentException ex) {
            return null;
        }
    }
    
    public static <E extends Enum<E>> E getEnumIgnoreCase(final Class<E> clazz, final String anotherString) {
        if (anotherString == null || !clazz.isEnum()) {
            return null;
        }
        for (final Enum<E> enum1 : clazz.getEnumConstants()) {
            if (enum1.name().equalsIgnoreCase(anotherString)) {
                return (E)enum1;
            }
        }
        return null;
    }
    
    public static <E extends Enum<E>> long generateBitVector(final Class<E> clazz, final Iterable<? extends E> iterable) {
        checkBitVectorable(clazz);
        Validate.notNull(iterable);
        long n = 0L;
        for (final Enum enum1 : iterable) {
            Validate.isTrue(enum1 != null, "null elements not permitted", new Object[0]);
            n |= 1L << enum1.ordinal();
        }
        return n;
    }
    
    public static <E extends Enum<E>> long[] generateBitVectors(final Class<E> elementType, final Iterable<? extends E> iterable) {
        asEnum(elementType);
        Validate.notNull(iterable);
        final EnumSet<E> none = EnumSet.noneOf(elementType);
        for (final Enum<E> e : iterable) {
            Validate.isTrue(e != null, "null elements not permitted", new Object[0]);
            none.add((E)e);
        }
        final long[] array = new long[(elementType.getEnumConstants().length - 1) / 64 + 1];
        for (final Enum enum1 : none) {
            final long[] array2 = array;
            final int n = enum1.ordinal() / 64;
            array2[n] |= 1L << enum1.ordinal() % 64;
        }
        ArrayUtils.reverse(array);
        return array;
    }
    
    @SafeVarargs
    public static <E extends Enum<E>> long generateBitVector(final Class<E> clazz, final E... a) {
        Validate.noNullElements(a);
        return generateBitVector(clazz, (Iterable<? extends E>)Arrays.asList(a));
    }
    
    @SafeVarargs
    public static <E extends Enum<E>> long[] generateBitVectors(final Class<E> elementType, final E... elements) {
        asEnum(elementType);
        Validate.noNullElements(elements);
        final EnumSet<E> none = EnumSet.noneOf(elementType);
        Collections.addAll(none, elements);
        final long[] array = new long[(elementType.getEnumConstants().length - 1) / 64 + 1];
        for (final Enum enum1 : none) {
            final long[] array2 = array;
            final int n = enum1.ordinal() / 64;
            array2[n] |= 1L << enum1.ordinal() % 64;
        }
        ArrayUtils.reverse(array);
        return array;
    }
    
    public static <E extends Enum<E>> EnumSet<E> processBitVector(final Class<E> clazz, final long n) {
        checkBitVectorable(clazz).getEnumConstants();
        return processBitVectors(clazz, n);
    }
    
    public static <E extends Enum<E>> EnumSet<E> processBitVectors(final Class<E> clazz, final long... array) {
        final EnumSet<E> none = EnumSet.noneOf((Class<E>)asEnum((Class<E>)clazz));
        final long[] clone = ArrayUtils.clone(Validate.notNull(array));
        ArrayUtils.reverse(clone);
        for (final Enum<E> e : clazz.getEnumConstants()) {
            final int n = e.ordinal() / 64;
            if (n < clone.length && (clone[n] & 1L << e.ordinal() % 64) != 0x0L) {
                none.add((E)e);
            }
        }
        return none;
    }
    
    private static <E extends Enum<E>> Class<E> checkBitVectorable(final Class<E> clazz) {
        final Enum[] array = asEnum((Class<Enum>)clazz).getEnumConstants();
        Validate.isTrue(array.length <= 64, "Cannot store %s %s values in %s bits", array.length, clazz.getSimpleName(), 64);
        return clazz;
    }
    
    private static <E extends Enum<E>> Class<E> asEnum(final Class<E> clazz) {
        Validate.notNull(clazz, "EnumClass must be defined.", new Object[0]);
        Validate.isTrue(clazz.isEnum(), "%s does not seem to be an Enum type", clazz);
        return clazz;
    }
}

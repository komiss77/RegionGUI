// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.mutable;

import net.crytec.regiongui.libs.apache.commons.math.NumberUtils;

public class MutableShort extends Number implements Comparable<MutableShort>, Mutable<Number>
{
    private static final long serialVersionUID = -2135791679L;
    private short value;
    
    public MutableShort() {
    }
    
    public MutableShort(final short value) {
        this.value = value;
    }
    
    public MutableShort(final Number n) {
        this.value = n.shortValue();
    }
    
    public MutableShort(final String s) {
        this.value = Short.parseShort(s);
    }
    
    @Override
    public Short getValue() {
        return this.value;
    }
    
    public void setValue(final short value) {
        this.value = value;
    }
    
    @Override
    public void setValue(final Number n) {
        this.value = n.shortValue();
    }
    
    public void increment() {
        ++this.value;
    }
    
    public short getAndIncrement() {
        final short value = this.value;
        ++this.value;
        return value;
    }
    
    public short incrementAndGet() {
        return (short)(++this.value);
    }
    
    public void decrement() {
        --this.value;
    }
    
    public short getAndDecrement() {
        final short value = this.value;
        --this.value;
        return value;
    }
    
    public short decrementAndGet() {
        return (short)(--this.value);
    }
    
    public void add(final short n) {
        this.value += n;
    }
    
    public void add(final Number n) {
        this.value += n.shortValue();
    }
    
    public void subtract(final short n) {
        this.value -= n;
    }
    
    public void subtract(final Number n) {
        this.value -= n.shortValue();
    }
    
    public short addAndGet(final short n) {
        return this.value += n;
    }
    
    public short addAndGet(final Number n) {
        return this.value += n.shortValue();
    }
    
    public short getAndAdd(final short n) {
        final short value = this.value;
        this.value += n;
        return value;
    }
    
    public short getAndAdd(final Number n) {
        final short value = this.value;
        this.value += n.shortValue();
        return value;
    }
    
    @Override
    public short shortValue() {
        return this.value;
    }
    
    @Override
    public int intValue() {
        return this.value;
    }
    
    @Override
    public long longValue() {
        return this.value;
    }
    
    @Override
    public float floatValue() {
        return this.value;
    }
    
    @Override
    public double doubleValue() {
        return this.value;
    }
    
    public Short toShort() {
        return this.shortValue();
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof MutableShort && this.value == ((MutableShort)o).shortValue();
    }
    
    @Override
    public int hashCode() {
        return this.value;
    }
    
    @Override
    public int compareTo(final MutableShort mutableShort) {
        return NumberUtils.compare(this.value, mutableShort.value);
    }
    
    @Override
    public String toString() {
        return String.valueOf(this.value);
    }
}

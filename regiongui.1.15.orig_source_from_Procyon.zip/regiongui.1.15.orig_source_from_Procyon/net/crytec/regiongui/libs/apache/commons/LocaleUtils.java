// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.HashSet;
import java.util.Collection;
import java.util.Arrays;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.Collections;
import java.util.ArrayList;
import java.util.Locale;
import java.util.List;
import java.util.concurrent.ConcurrentMap;

public class LocaleUtils
{
    private static final ConcurrentMap<String, List<Locale>> cLanguagesByCountry;
    private static final ConcurrentMap<String, List<Locale>> cCountriesByLanguage;
    
    public static Locale toLocale(final String s) {
        if (s == null) {
            return null;
        }
        if (s.isEmpty()) {
            return new Locale("", "");
        }
        if (s.contains("#")) {
            throw new IllegalArgumentException("Invalid locale format: " + s);
        }
        final int length = s.length();
        if (length < 2) {
            throw new IllegalArgumentException("Invalid locale format: " + s);
        }
        if (s.charAt(0) != '_') {
            return parseLocale(s);
        }
        if (length < 3) {
            throw new IllegalArgumentException("Invalid locale format: " + s);
        }
        final char char1 = s.charAt(1);
        final char char2 = s.charAt(2);
        if (!Character.isUpperCase(char1) || !Character.isUpperCase(char2)) {
            throw new IllegalArgumentException("Invalid locale format: " + s);
        }
        if (length == 3) {
            return new Locale("", s.substring(1, 3));
        }
        if (length < 5) {
            throw new IllegalArgumentException("Invalid locale format: " + s);
        }
        if (s.charAt(3) != '_') {
            throw new IllegalArgumentException("Invalid locale format: " + s);
        }
        return new Locale("", s.substring(1, 3), s.substring(4));
    }
    
    private static Locale parseLocale(final String s) {
        if (isISO639LanguageCode(s)) {
            return new Locale(s);
        }
        final String[] split = s.split("_", -1);
        final String s2 = split[0];
        if (split.length == 2) {
            final String country = split[1];
            if ((isISO639LanguageCode(s2) && isISO3166CountryCode(country)) || isNumericAreaCode(country)) {
                return new Locale(s2, country);
            }
        }
        else if (split.length == 3) {
            final String country2 = split[1];
            final String variant = split[2];
            if (isISO639LanguageCode(s2) && (country2.isEmpty() || isISO3166CountryCode(country2) || isNumericAreaCode(country2)) && !variant.isEmpty()) {
                return new Locale(s2, country2, variant);
            }
        }
        throw new IllegalArgumentException("Invalid locale format: " + s);
    }
    
    private static boolean isISO639LanguageCode(final String s) {
        return StringUtils.isAllLowerCase(s) && (s.length() == 2 || s.length() == 3);
    }
    
    private static boolean isISO3166CountryCode(final String s) {
        return StringUtils.isAllUpperCase(s) && s.length() == 2;
    }
    
    private static boolean isNumericAreaCode(final String s) {
        return StringUtils.isNumeric(s) && s.length() == 3;
    }
    
    public static List<Locale> localeLookupList(final Locale locale) {
        return localeLookupList(locale, locale);
    }
    
    public static List<Locale> localeLookupList(final Locale locale, final Locale locale2) {
        final ArrayList<Locale> list = new ArrayList<Locale>(4);
        if (locale != null) {
            list.add(locale);
            if (!locale.getVariant().isEmpty()) {
                list.add(new Locale(locale.getLanguage(), locale.getCountry()));
            }
            if (!locale.getCountry().isEmpty()) {
                list.add(new Locale(locale.getLanguage(), ""));
            }
            if (!list.contains(locale2)) {
                list.add(locale2);
            }
        }
        return (List<Locale>)Collections.unmodifiableList((List<?>)list);
    }
    
    public static List<Locale> availableLocaleList() {
        return SyncAvoid.AVAILABLE_LOCALE_LIST;
    }
    
    public static Set<Locale> availableLocaleSet() {
        return SyncAvoid.AVAILABLE_LOCALE_SET;
    }
    
    public static boolean isAvailableLocale(final Locale locale) {
        return availableLocaleList().contains(locale);
    }
    
    public static List<Locale> languagesByCountry(final String s) {
        if (s == null) {
            return Collections.emptyList();
        }
        List<Locale> list = LocaleUtils.cLanguagesByCountry.get(s);
        if (list == null) {
            final ArrayList<Locale> list2 = new ArrayList<Locale>();
            for (final Locale locale : availableLocaleList()) {
                if (s.equals(locale.getCountry()) && locale.getVariant().isEmpty()) {
                    list2.add(locale);
                }
            }
            LocaleUtils.cLanguagesByCountry.putIfAbsent(s, (List<Locale>)Collections.unmodifiableList((List<?>)list2));
            list = LocaleUtils.cLanguagesByCountry.get(s);
        }
        return list;
    }
    
    public static List<Locale> countriesByLanguage(final String s) {
        if (s == null) {
            return Collections.emptyList();
        }
        List<Locale> list = LocaleUtils.cCountriesByLanguage.get(s);
        if (list == null) {
            final ArrayList<Locale> list2 = new ArrayList<Locale>();
            for (final Locale locale : availableLocaleList()) {
                if (s.equals(locale.getLanguage()) && !locale.getCountry().isEmpty() && locale.getVariant().isEmpty()) {
                    list2.add(locale);
                }
            }
            LocaleUtils.cCountriesByLanguage.putIfAbsent(s, (List<Locale>)Collections.unmodifiableList((List<?>)list2));
            list = LocaleUtils.cCountriesByLanguage.get(s);
        }
        return list;
    }
    
    static {
        cLanguagesByCountry = new ConcurrentHashMap<String, List<Locale>>();
        cCountriesByLanguage = new ConcurrentHashMap<String, List<Locale>>();
    }
    
    static class SyncAvoid
    {
        private static final List<Locale> AVAILABLE_LOCALE_LIST;
        private static final Set<Locale> AVAILABLE_LOCALE_SET;
        
        static {
            final ArrayList<Locale> list = new ArrayList<Locale>(Arrays.asList(Locale.getAvailableLocales()));
            AVAILABLE_LOCALE_LIST = Collections.unmodifiableList((List<?>)list);
            AVAILABLE_LOCALE_SET = Collections.unmodifiableSet((Set<?>)new HashSet<Object>(list));
        }
    }
}

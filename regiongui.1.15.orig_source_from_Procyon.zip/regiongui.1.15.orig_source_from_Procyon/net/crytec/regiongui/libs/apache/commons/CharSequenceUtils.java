// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

public class CharSequenceUtils
{
    private static final int NOT_FOUND = -1;
    
    public static CharSequence subSequence(final CharSequence charSequence, final int n) {
        return (charSequence == null) ? null : charSequence.subSequence(n, charSequence.length());
    }
    
    static int indexOf(final CharSequence charSequence, final int n, int fromIndex) {
        if (charSequence instanceof String) {
            return ((String)charSequence).indexOf(n, fromIndex);
        }
        final int length = charSequence.length();
        if (fromIndex < 0) {
            fromIndex = 0;
        }
        if (n < 65536) {
            for (int i = fromIndex; i < length; ++i) {
                if (charSequence.charAt(i) == n) {
                    return i;
                }
            }
        }
        if (n <= 1114111) {
            final char[] chars = Character.toChars(n);
            for (int j = fromIndex; j < length - 1; ++j) {
                final char char1 = charSequence.charAt(j);
                final char char2 = charSequence.charAt(j + 1);
                if (char1 == chars[0] && char2 == chars[1]) {
                    return j;
                }
            }
        }
        return -1;
    }
    
    static int indexOf(final CharSequence charSequence, final CharSequence charSequence2, final int fromIndex) {
        return charSequence.toString().indexOf(charSequence2.toString(), fromIndex);
    }
    
    static int lastIndexOf(final CharSequence charSequence, final int n, int fromIndex) {
        if (charSequence instanceof String) {
            return ((String)charSequence).lastIndexOf(n, fromIndex);
        }
        final int length = charSequence.length();
        if (fromIndex < 0) {
            return -1;
        }
        if (fromIndex >= length) {
            fromIndex = length - 1;
        }
        if (n < 65536) {
            for (int i = fromIndex; i >= 0; --i) {
                if (charSequence.charAt(i) == n) {
                    return i;
                }
            }
        }
        if (n <= 1114111) {
            final char[] chars = Character.toChars(n);
            if (fromIndex == length - 1) {
                return -1;
            }
            for (int j = fromIndex; j >= 0; --j) {
                final char char1 = charSequence.charAt(j);
                final char char2 = charSequence.charAt(j + 1);
                if (chars[0] == char1 && chars[1] == char2) {
                    return j;
                }
            }
        }
        return -1;
    }
    
    static int lastIndexOf(final CharSequence charSequence, final CharSequence charSequence2, final int fromIndex) {
        return charSequence.toString().lastIndexOf(charSequence2.toString(), fromIndex);
    }
    
    static char[] toCharArray(final CharSequence charSequence) {
        if (charSequence instanceof String) {
            return ((String)charSequence).toCharArray();
        }
        final int length = charSequence.length();
        final char[] array = new char[charSequence.length()];
        for (int i = 0; i < length; ++i) {
            array[i] = charSequence.charAt(i);
        }
        return array;
    }
    
    static boolean regionMatches(final CharSequence charSequence, final boolean ignoreCase, final int toffset, final CharSequence charSequence2, final int ooffset, final int len) {
        if (charSequence instanceof String && charSequence2 instanceof String) {
            return ((String)charSequence).regionMatches(ignoreCase, toffset, (String)charSequence2, ooffset, len);
        }
        int n = toffset;
        int n2 = ooffset;
        int n3 = len;
        final int n4 = charSequence.length() - toffset;
        final int n5 = charSequence2.length() - ooffset;
        if (toffset < 0 || ooffset < 0 || len < 0) {
            return false;
        }
        if (n4 < len || n5 < len) {
            return false;
        }
        while (n3-- > 0) {
            final char char1 = charSequence.charAt(n++);
            final char char2 = charSequence2.charAt(n2++);
            if (char1 == char2) {
                continue;
            }
            if (!ignoreCase) {
                return false;
            }
            if (Character.toUpperCase(char1) != Character.toUpperCase(char2) && Character.toLowerCase(char1) != Character.toLowerCase(char2)) {
                return false;
            }
        }
        return true;
    }
}

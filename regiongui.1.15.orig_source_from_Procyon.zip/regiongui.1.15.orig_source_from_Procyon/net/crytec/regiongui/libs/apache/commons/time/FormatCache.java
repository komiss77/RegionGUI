// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.time;

import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.text.DateFormat;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.text.Format;

abstract class FormatCache<F extends Format>
{
    static final int NONE = -1;
    private final ConcurrentMap<MultipartKey, F> cInstanceCache;
    private static final ConcurrentMap<MultipartKey, String> cDateTimeInstanceCache;
    
    FormatCache() {
        this.cInstanceCache = new ConcurrentHashMap<MultipartKey, F>(7);
    }
    
    public F getInstance() {
        return this.getDateTimeInstance(3, 3, TimeZone.getDefault(), Locale.getDefault());
    }
    
    public F getInstance(final String s, TimeZone default1, Locale default2) {
        Validate.notNull(s, "pattern must not be null", new Object[0]);
        if (default1 == null) {
            default1 = TimeZone.getDefault();
        }
        if (default2 == null) {
            default2 = Locale.getDefault();
        }
        final MultipartKey multipartKey = new MultipartKey(new Object[] { s, default1, default2 });
        Format instance = this.cInstanceCache.get(multipartKey);
        if (instance == null) {
            instance = this.createInstance(s, default1, default2);
            final Format format = this.cInstanceCache.putIfAbsent(multipartKey, (F)instance);
            if (format != null) {
                instance = format;
            }
        }
        return (F)instance;
    }
    
    protected abstract F createInstance(final String p0, final TimeZone p1, final Locale p2);
    
    private F getDateTimeInstance(final Integer n, final Integer n2, final TimeZone timeZone, Locale default1) {
        if (default1 == null) {
            default1 = Locale.getDefault();
        }
        return this.getInstance(getPatternForStyle(n, n2, default1), timeZone, default1);
    }
    
    F getDateTimeInstance(final int i, final int j, final TimeZone timeZone, final Locale locale) {
        return this.getDateTimeInstance(Integer.valueOf(i), Integer.valueOf(j), timeZone, locale);
    }
    
    F getDateInstance(final int i, final TimeZone timeZone, final Locale locale) {
        return this.getDateTimeInstance(i, null, timeZone, locale);
    }
    
    F getTimeInstance(final int i, final TimeZone timeZone, final Locale locale) {
        return this.getDateTimeInstance(null, i, timeZone, locale);
    }
    
    static String getPatternForStyle(final Integer n, final Integer n2, final Locale locale) {
        final MultipartKey multipartKey = new MultipartKey(new Object[] { n, n2, locale });
        String pattern = FormatCache.cDateTimeInstanceCache.get(multipartKey);
        if (pattern == null) {
            try {
                DateFormat dateFormat;
                if (n == null) {
                    dateFormat = DateFormat.getTimeInstance(n2, locale);
                }
                else if (n2 == null) {
                    dateFormat = DateFormat.getDateInstance(n, locale);
                }
                else {
                    dateFormat = DateFormat.getDateTimeInstance(n, n2, locale);
                }
                pattern = ((SimpleDateFormat)dateFormat).toPattern();
                final String s = FormatCache.cDateTimeInstanceCache.putIfAbsent(multipartKey, pattern);
                if (s != null) {
                    pattern = s;
                }
            }
            catch (ClassCastException ex) {
                throw new IllegalArgumentException("No date time pattern for locale: " + locale);
            }
        }
        return pattern;
    }
    
    static {
        cDateTimeInstanceCache = new ConcurrentHashMap<MultipartKey, String>(7);
    }
    
    private static class MultipartKey
    {
        private final Object[] keys;
        private int hashCode;
        
        MultipartKey(final Object... keys) {
            this.keys = keys;
        }
        
        @Override
        public boolean equals(final Object o) {
            return Arrays.equals(this.keys, ((MultipartKey)o).keys);
        }
        
        @Override
        public int hashCode() {
            if (this.hashCode == 0) {
                int hashCode = 0;
                for (final Object o : this.keys) {
                    if (o != null) {
                        hashCode = hashCode * 7 + o.hashCode();
                    }
                }
                this.hashCode = hashCode;
            }
            return this.hashCode;
        }
    }
}

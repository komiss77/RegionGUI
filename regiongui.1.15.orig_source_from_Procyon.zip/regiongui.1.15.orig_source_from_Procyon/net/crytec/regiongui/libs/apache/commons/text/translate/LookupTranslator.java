// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text.translate;

import java.io.Writer;
import java.util.HashSet;
import java.util.HashMap;

@Deprecated
public class LookupTranslator extends CharSequenceTranslator
{
    private final HashMap<String, String> lookupMap;
    private final HashSet<Character> prefixSet;
    private final int shortest;
    private final int longest;
    
    public LookupTranslator(final CharSequence[]... array) {
        this.lookupMap = new HashMap<String, String>();
        this.prefixSet = new HashSet<Character>();
        int shortest = Integer.MAX_VALUE;
        int longest = 0;
        if (array != null) {
            for (final CharSequence[] array2 : array) {
                this.lookupMap.put(array2[0].toString(), array2[1].toString());
                this.prefixSet.add(array2[0].charAt(0));
                final int length2 = array2[0].length();
                if (length2 < shortest) {
                    shortest = length2;
                }
                if (length2 > longest) {
                    longest = length2;
                }
            }
        }
        this.shortest = shortest;
        this.longest = longest;
    }
    
    @Override
    public int translate(final CharSequence charSequence, final int n, final Writer writer) {
        if (this.prefixSet.contains(charSequence.charAt(n))) {
            int longest = this.longest;
            if (n + this.longest > charSequence.length()) {
                longest = charSequence.length() - n;
            }
            for (int i = longest; i >= this.shortest; --i) {
                final String str = this.lookupMap.get(charSequence.subSequence(n, n + i).toString());
                if (str != null) {
                    writer.write(str);
                    return i;
                }
            }
        }
        return 0;
    }
}

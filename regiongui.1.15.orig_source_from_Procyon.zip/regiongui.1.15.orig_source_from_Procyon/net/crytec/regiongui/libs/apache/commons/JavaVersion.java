// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import net.crytec.regiongui.libs.apache.commons.math.NumberUtils;

public enum JavaVersion
{
    JAVA_0_9(1.5f, "0.9"), 
    JAVA_1_1(1.1f, "1.1"), 
    JAVA_1_2(1.2f, "1.2"), 
    JAVA_1_3(1.3f, "1.3"), 
    JAVA_1_4(1.4f, "1.4"), 
    JAVA_1_5(1.5f, "1.5"), 
    JAVA_1_6(1.6f, "1.6"), 
    JAVA_1_7(1.7f, "1.7"), 
    JAVA_1_8(1.8f, "1.8"), 
    @Deprecated
    JAVA_1_9(9.0f, "9"), 
    JAVA_9(9.0f, "9"), 
    JAVA_10(10.0f, "10"), 
    JAVA_11(11.0f, "11"), 
    JAVA_12(12.0f, "12"), 
    JAVA_13(13.0f, "13"), 
    JAVA_RECENT(maxVersion(), Float.toString(maxVersion()));
    
    private final float value;
    private final String name;
    
    private JavaVersion(final float value, final String name2) {
        this.value = value;
        this.name = name2;
    }
    
    public boolean atLeast(final JavaVersion javaVersion) {
        return this.value >= javaVersion.value;
    }
    
    public boolean atMost(final JavaVersion javaVersion) {
        return this.value <= javaVersion.value;
    }
    
    static JavaVersion getJavaVersion(final String s) {
        return get(s);
    }
    
    static JavaVersion get(final String s) {
        if ("0.9".equals(s)) {
            return JavaVersion.JAVA_0_9;
        }
        if ("1.1".equals(s)) {
            return JavaVersion.JAVA_1_1;
        }
        if ("1.2".equals(s)) {
            return JavaVersion.JAVA_1_2;
        }
        if ("1.3".equals(s)) {
            return JavaVersion.JAVA_1_3;
        }
        if ("1.4".equals(s)) {
            return JavaVersion.JAVA_1_4;
        }
        if ("1.5".equals(s)) {
            return JavaVersion.JAVA_1_5;
        }
        if ("1.6".equals(s)) {
            return JavaVersion.JAVA_1_6;
        }
        if ("1.7".equals(s)) {
            return JavaVersion.JAVA_1_7;
        }
        if ("1.8".equals(s)) {
            return JavaVersion.JAVA_1_8;
        }
        if ("9".equals(s)) {
            return JavaVersion.JAVA_9;
        }
        if ("10".equals(s)) {
            return JavaVersion.JAVA_10;
        }
        if ("11".equals(s)) {
            return JavaVersion.JAVA_11;
        }
        if ("12".equals(s)) {
            return JavaVersion.JAVA_12;
        }
        if ("13".equals(s)) {
            return JavaVersion.JAVA_13;
        }
        if (s == null) {
            return null;
        }
        final float floatVersion = toFloatVersion(s);
        if (floatVersion - 1.0 < 1.0) {
            final int max = Math.max(s.indexOf(46), s.indexOf(44));
            if (Float.parseFloat(s.substring(max + 1, Math.max(s.length(), s.indexOf(44, max)))) > 0.9f) {
                return JavaVersion.JAVA_RECENT;
            }
        }
        else if (floatVersion > 10.0f) {
            return JavaVersion.JAVA_RECENT;
        }
        return null;
    }
    
    @Override
    public String toString() {
        return this.name;
    }
    
    private static float maxVersion() {
        final float floatVersion = toFloatVersion(System.getProperty("java.specification.version", "99.0"));
        if (floatVersion > 0.0f) {
            return floatVersion;
        }
        return 99.0f;
    }
    
    private static float toFloatVersion(final String s) {
        if (!s.contains(".")) {
            return NumberUtils.toFloat(s, -1.0f);
        }
        final String[] split = s.split("\\.");
        if (split.length >= 2) {
            return NumberUtils.toFloat(split[0] + '.' + split[1], -1.0f);
        }
        return -1.0f;
    }
}

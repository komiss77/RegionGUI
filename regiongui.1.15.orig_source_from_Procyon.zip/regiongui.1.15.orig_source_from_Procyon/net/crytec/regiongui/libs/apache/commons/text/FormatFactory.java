// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text;

import java.text.Format;
import java.util.Locale;

@Deprecated
public interface FormatFactory
{
    Format getFormat(final String p0, final String p1, final Locale p2);
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.builder;

import java.util.HashSet;
import java.util.Collection;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.lang.reflect.Field;
import java.lang.annotation.Annotation;
import java.lang.reflect.Modifier;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;
import java.lang.reflect.AccessibleObject;
import java.util.Set;

public class HashCodeBuilder implements Builder<Integer>
{
    private static final int DEFAULT_INITIAL_VALUE = 17;
    private static final int DEFAULT_MULTIPLIER_VALUE = 37;
    private static final ThreadLocal<Set<IDKey>> REGISTRY;
    private final int iConstant;
    private int iTotal;
    
    static Set<IDKey> getRegistry() {
        return HashCodeBuilder.REGISTRY.get();
    }
    
    static boolean isRegistered(final Object o) {
        final Set<IDKey> registry = getRegistry();
        return registry != null && registry.contains(new IDKey(o));
    }
    
    private static void reflectionAppend(final Object obj, final Class<?> clazz, final HashCodeBuilder hashCodeBuilder, final boolean b, final String[] array) {
        if (isRegistered(obj)) {
            return;
        }
        try {
            register(obj);
            final Field[] declaredFields = clazz.getDeclaredFields();
            AccessibleObject.setAccessible(declaredFields, true);
            for (final Field field : declaredFields) {
                if (!ArrayUtils.contains(array, field.getName()) && !field.getName().contains("$") && (b || !Modifier.isTransient(field.getModifiers())) && !Modifier.isStatic(field.getModifiers()) && !field.isAnnotationPresent(HashCodeExclude.class)) {
                    try {
                        hashCodeBuilder.append(field.get(obj));
                    }
                    catch (IllegalAccessException ex) {
                        throw new InternalError("Unexpected IllegalAccessException");
                    }
                }
            }
        }
        finally {
            unregister(obj);
        }
    }
    
    public static int reflectionHashCode(final int n, final int n2, final Object o) {
        return reflectionHashCode(n, n2, o, false, null, new String[0]);
    }
    
    public static int reflectionHashCode(final int n, final int n2, final Object o, final boolean b) {
        return reflectionHashCode(n, n2, o, b, null, new String[0]);
    }
    
    public static <T> int reflectionHashCode(final int n, final int n2, final T t, final boolean b, final Class<? super T> clazz, final String... array) {
        Validate.isTrue(t != null, "The object to build a hash code for must not be null", new Object[0]);
        final HashCodeBuilder hashCodeBuilder = new HashCodeBuilder(n, n2);
        Class<?> clazz2 = t.getClass();
        reflectionAppend(t, clazz2, hashCodeBuilder, b, array);
        while (clazz2.getSuperclass() != null && clazz2 != clazz) {
            clazz2 = clazz2.getSuperclass();
            reflectionAppend(t, clazz2, hashCodeBuilder, b, array);
        }
        return hashCodeBuilder.toHashCode();
    }
    
    public static int reflectionHashCode(final Object o, final boolean b) {
        return reflectionHashCode(17, 37, o, b, null, new String[0]);
    }
    
    public static int reflectionHashCode(final Object o, final Collection<String> collection) {
        return reflectionHashCode(o, ReflectionToStringBuilder.toNoNullStringArray(collection));
    }
    
    public static int reflectionHashCode(final Object o, final String... array) {
        return reflectionHashCode(17, 37, o, false, null, array);
    }
    
    private static void register(final Object o) {
        Set<IDKey> registry = getRegistry();
        if (registry == null) {
            registry = new HashSet<IDKey>();
            HashCodeBuilder.REGISTRY.set(registry);
        }
        registry.add(new IDKey(o));
    }
    
    private static void unregister(final Object o) {
        final Set<IDKey> registry = getRegistry();
        if (registry != null) {
            registry.remove(new IDKey(o));
            if (registry.isEmpty()) {
                HashCodeBuilder.REGISTRY.remove();
            }
        }
    }
    
    public HashCodeBuilder() {
        this.iTotal = 0;
        this.iConstant = 37;
        this.iTotal = 17;
    }
    
    public HashCodeBuilder(final int iTotal, final int iConstant) {
        this.iTotal = 0;
        Validate.isTrue(iTotal % 2 != 0, "HashCodeBuilder requires an odd initial value", new Object[0]);
        Validate.isTrue(iConstant % 2 != 0, "HashCodeBuilder requires an odd multiplier", new Object[0]);
        this.iConstant = iConstant;
        this.iTotal = iTotal;
    }
    
    public HashCodeBuilder append(final boolean b) {
        this.iTotal = this.iTotal * this.iConstant + (b ? 0 : 1);
        return this;
    }
    
    public HashCodeBuilder append(final boolean[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final byte b) {
        this.iTotal = this.iTotal * this.iConstant + b;
        return this;
    }
    
    public HashCodeBuilder append(final byte[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final char c) {
        this.iTotal = this.iTotal * this.iConstant + c;
        return this;
    }
    
    public HashCodeBuilder append(final char[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final double value) {
        return this.append(Double.doubleToLongBits(value));
    }
    
    public HashCodeBuilder append(final double[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final float value) {
        this.iTotal = this.iTotal * this.iConstant + Float.floatToIntBits(value);
        return this;
    }
    
    public HashCodeBuilder append(final float[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final int n) {
        this.iTotal = this.iTotal * this.iConstant + n;
        return this;
    }
    
    public HashCodeBuilder append(final int[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final long n) {
        this.iTotal = this.iTotal * this.iConstant + (int)(n ^ n >> 32);
        return this;
    }
    
    public HashCodeBuilder append(final long[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final Object o) {
        if (o == null) {
            this.iTotal *= this.iConstant;
        }
        else if (o.getClass().isArray()) {
            this.appendArray(o);
        }
        else {
            this.iTotal = this.iTotal * this.iConstant + o.hashCode();
        }
        return this;
    }
    
    private void appendArray(final Object o) {
        if (o instanceof long[]) {
            this.append((long[])o);
        }
        else if (o instanceof int[]) {
            this.append((int[])o);
        }
        else if (o instanceof short[]) {
            this.append((short[])o);
        }
        else if (o instanceof char[]) {
            this.append((char[])o);
        }
        else if (o instanceof byte[]) {
            this.append((byte[])o);
        }
        else if (o instanceof double[]) {
            this.append((double[])o);
        }
        else if (o instanceof float[]) {
            this.append((float[])o);
        }
        else if (o instanceof boolean[]) {
            this.append((boolean[])o);
        }
        else {
            this.append((Object[])o);
        }
    }
    
    public HashCodeBuilder append(final Object[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder append(final short n) {
        this.iTotal = this.iTotal * this.iConstant + n;
        return this;
    }
    
    public HashCodeBuilder append(final short[] array) {
        if (array == null) {
            this.iTotal *= this.iConstant;
        }
        else {
            for (int length = array.length, i = 0; i < length; ++i) {
                this.append(array[i]);
            }
        }
        return this;
    }
    
    public HashCodeBuilder appendSuper(final int n) {
        this.iTotal = this.iTotal * this.iConstant + n;
        return this;
    }
    
    public int toHashCode() {
        return this.iTotal;
    }
    
    @Override
    public Integer build() {
        return this.toHashCode();
    }
    
    @Override
    public int hashCode() {
        return this.toHashCode();
    }
    
    static {
        REGISTRY = new ThreadLocal<Set<IDKey>>();
    }
}

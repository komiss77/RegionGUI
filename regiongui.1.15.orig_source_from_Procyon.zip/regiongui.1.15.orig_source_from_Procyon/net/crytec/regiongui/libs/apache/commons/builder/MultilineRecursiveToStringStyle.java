// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.builder;

import net.crytec.regiongui.libs.apache.commons.ClassUtils;

public class MultilineRecursiveToStringStyle extends RecursiveToStringStyle
{
    private static final long serialVersionUID = 1L;
    private static final int INDENT = 2;
    private int spaces;
    
    public MultilineRecursiveToStringStyle() {
        this.spaces = 2;
        this.resetIndent();
    }
    
    private void resetIndent() {
        this.setArrayStart("{" + System.lineSeparator() + (Object)this.spacer(this.spaces));
        this.setArraySeparator("," + System.lineSeparator() + (Object)this.spacer(this.spaces));
        this.setArrayEnd(System.lineSeparator() + (Object)this.spacer(this.spaces - 2) + "}");
        this.setContentStart("[" + System.lineSeparator() + (Object)this.spacer(this.spaces));
        this.setFieldSeparator("," + System.lineSeparator() + (Object)this.spacer(this.spaces));
        this.setContentEnd(System.lineSeparator() + (Object)this.spacer(this.spaces - 2) + "]");
    }
    
    private StringBuilder spacer(final int n) {
        final StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; ++i) {
            sb.append(" ");
        }
        return sb;
    }
    
    @Override
    public void appendDetail(final StringBuffer sb, final String s, final Object o) {
        if (!ClassUtils.isPrimitiveWrapper(o.getClass()) && !String.class.equals(o.getClass()) && this.accept(o.getClass())) {
            this.spaces += 2;
            this.resetIndent();
            sb.append(ReflectionToStringBuilder.toString(o, this));
            this.spaces -= 2;
            this.resetIndent();
        }
        else {
            super.appendDetail(sb, s, o);
        }
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final Object[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void reflectionAppendArrayDetail(final StringBuffer sb, final String s, final Object o) {
        this.spaces += 2;
        this.resetIndent();
        super.reflectionAppendArrayDetail(sb, s, o);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final long[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final int[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final short[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final byte[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final char[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final double[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final float[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
    
    @Override
    protected void appendDetail(final StringBuffer sb, final String s, final boolean[] array) {
        this.spaces += 2;
        this.resetIndent();
        super.appendDetail(sb, s, array);
        this.spaces -= 2;
        this.resetIndent();
    }
}

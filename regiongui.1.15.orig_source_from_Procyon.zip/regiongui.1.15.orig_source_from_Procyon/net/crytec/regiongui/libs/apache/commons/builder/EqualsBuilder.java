// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.builder;

import net.crytec.regiongui.libs.apache.commons.ClassUtils;
import java.lang.reflect.Field;
import java.lang.annotation.Annotation;
import java.lang.reflect.Modifier;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;
import java.lang.reflect.AccessibleObject;
import java.util.Collection;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import net.crytec.regiongui.libs.apache.commons.tuple.Pair;
import java.util.Set;

public class EqualsBuilder implements Builder<Boolean>
{
    private static final ThreadLocal<Set<Pair<IDKey, IDKey>>> REGISTRY;
    private boolean isEquals;
    private boolean testTransients;
    private boolean testRecursive;
    private List<Class<?>> bypassReflectionClasses;
    private Class<?> reflectUpToClass;
    private String[] excludeFields;
    
    static Set<Pair<IDKey, IDKey>> getRegistry() {
        return EqualsBuilder.REGISTRY.get();
    }
    
    static Pair<IDKey, IDKey> getRegisterPair(final Object o, final Object o2) {
        return Pair.of(new IDKey(o), new IDKey(o2));
    }
    
    static boolean isRegistered(final Object o, final Object o2) {
        final Set<Pair<IDKey, IDKey>> registry = getRegistry();
        final Pair<IDKey, IDKey> registerPair = getRegisterPair(o, o2);
        final Pair<IDKey, IDKey> of = Pair.of(registerPair.getRight(), registerPair.getLeft());
        return registry != null && (registry.contains(registerPair) || registry.contains(of));
    }
    
    private static void register(final Object o, final Object o2) {
        Set<Pair<IDKey, IDKey>> registry = getRegistry();
        if (registry == null) {
            registry = new HashSet<Pair<IDKey, IDKey>>();
            EqualsBuilder.REGISTRY.set(registry);
        }
        registry.add(getRegisterPair(o, o2));
    }
    
    private static void unregister(final Object o, final Object o2) {
        final Set<Pair<IDKey, IDKey>> registry = getRegistry();
        if (registry != null) {
            registry.remove(getRegisterPair(o, o2));
            if (registry.isEmpty()) {
                EqualsBuilder.REGISTRY.remove();
            }
        }
    }
    
    public EqualsBuilder() {
        this.isEquals = true;
        this.testTransients = false;
        this.testRecursive = false;
        this.reflectUpToClass = null;
        this.excludeFields = null;
        (this.bypassReflectionClasses = new ArrayList<Class<?>>()).add(String.class);
    }
    
    public EqualsBuilder setTestTransients(final boolean testTransients) {
        this.testTransients = testTransients;
        return this;
    }
    
    public EqualsBuilder setTestRecursive(final boolean testRecursive) {
        this.testRecursive = testRecursive;
        return this;
    }
    
    public EqualsBuilder setBypassReflectionClasses(final List<Class<?>> bypassReflectionClasses) {
        this.bypassReflectionClasses = bypassReflectionClasses;
        return this;
    }
    
    public EqualsBuilder setReflectUpToClass(final Class<?> reflectUpToClass) {
        this.reflectUpToClass = reflectUpToClass;
        return this;
    }
    
    public EqualsBuilder setExcludeFields(final String... excludeFields) {
        this.excludeFields = excludeFields;
        return this;
    }
    
    public static boolean reflectionEquals(final Object o, final Object o2, final Collection<String> collection) {
        return reflectionEquals(o, o2, ReflectionToStringBuilder.toNoNullStringArray(collection));
    }
    
    public static boolean reflectionEquals(final Object o, final Object o2, final String... array) {
        return reflectionEquals(o, o2, false, null, array);
    }
    
    public static boolean reflectionEquals(final Object o, final Object o2, final boolean b) {
        return reflectionEquals(o, o2, b, null, new String[0]);
    }
    
    public static boolean reflectionEquals(final Object o, final Object o2, final boolean b, final Class<?> clazz, final String... array) {
        return reflectionEquals(o, o2, b, clazz, false, array);
    }
    
    public static boolean reflectionEquals(final Object o, final Object o2, final boolean testTransients, final Class<?> reflectUpToClass, final boolean testRecursive, final String... excludeFields) {
        return o == o2 || (o != null && o2 != null && new EqualsBuilder().setExcludeFields(excludeFields).setReflectUpToClass(reflectUpToClass).setTestTransients(testTransients).setTestRecursive(testRecursive).reflectionAppend(o, o2).isEquals());
    }
    
    public EqualsBuilder reflectionAppend(final Object o, final Object obj) {
        if (!this.isEquals) {
            return this;
        }
        if (o == obj) {
            return this;
        }
        if (o == null || obj == null) {
            this.isEquals = false;
            return this;
        }
        final Class<?> class1 = o.getClass();
        final Class<?> class2 = obj.getClass();
        Class<?> superclass;
        if (class1.isInstance(obj)) {
            superclass = class1;
            if (!class2.isInstance(o)) {
                superclass = class2;
            }
        }
        else {
            if (!class2.isInstance(o)) {
                this.isEquals = false;
                return this;
            }
            superclass = class2;
            if (!class1.isInstance(obj)) {
                superclass = class1;
            }
        }
        try {
            if (superclass.isArray()) {
                this.append(o, obj);
            }
            else if (this.bypassReflectionClasses != null && (this.bypassReflectionClasses.contains(class1) || this.bypassReflectionClasses.contains(class2))) {
                this.isEquals = o.equals(obj);
            }
            else {
                this.reflectionAppend(o, obj, superclass);
                while (superclass.getSuperclass() != null && superclass != this.reflectUpToClass) {
                    superclass = superclass.getSuperclass();
                    this.reflectionAppend(o, obj, superclass);
                }
            }
        }
        catch (IllegalArgumentException ex) {
            this.isEquals = false;
            return this;
        }
        return this;
    }
    
    private void reflectionAppend(final Object obj, final Object obj2, final Class<?> clazz) {
        if (isRegistered(obj, obj2)) {
            return;
        }
        try {
            register(obj, obj2);
            final Field[] declaredFields = clazz.getDeclaredFields();
            AccessibleObject.setAccessible(declaredFields, true);
            for (int n = 0; n < declaredFields.length && this.isEquals; ++n) {
                final Field field = declaredFields[n];
                if (!ArrayUtils.contains(this.excludeFields, field.getName()) && !field.getName().contains("$") && (this.testTransients || !Modifier.isTransient(field.getModifiers())) && !Modifier.isStatic(field.getModifiers()) && !field.isAnnotationPresent(EqualsExclude.class)) {
                    try {
                        this.append(field.get(obj), field.get(obj2));
                    }
                    catch (IllegalAccessException ex) {
                        throw new InternalError("Unexpected IllegalAccessException");
                    }
                }
            }
        }
        finally {
            unregister(obj, obj2);
        }
    }
    
    public EqualsBuilder appendSuper(final boolean isEquals) {
        if (!this.isEquals) {
            return this;
        }
        this.isEquals = isEquals;
        return this;
    }
    
    public EqualsBuilder append(final Object o, final Object obj) {
        if (!this.isEquals) {
            return this;
        }
        if (o == obj) {
            return this;
        }
        if (o == null || obj == null) {
            this.setEquals(false);
            return this;
        }
        final Class<?> class1 = o.getClass();
        if (class1.isArray()) {
            this.appendArray(o, obj);
        }
        else if (this.testRecursive && !ClassUtils.isPrimitiveOrWrapper(class1)) {
            this.reflectionAppend(o, obj);
        }
        else {
            this.isEquals = o.equals(obj);
        }
        return this;
    }
    
    private void appendArray(final Object o, final Object o2) {
        if (o.getClass() != o2.getClass()) {
            this.setEquals(false);
        }
        else if (o instanceof long[]) {
            this.append((long[])o, (long[])o2);
        }
        else if (o instanceof int[]) {
            this.append((int[])o, (int[])o2);
        }
        else if (o instanceof short[]) {
            this.append((short[])o, (short[])o2);
        }
        else if (o instanceof char[]) {
            this.append((char[])o, (char[])o2);
        }
        else if (o instanceof byte[]) {
            this.append((byte[])o, (byte[])o2);
        }
        else if (o instanceof double[]) {
            this.append((double[])o, (double[])o2);
        }
        else if (o instanceof float[]) {
            this.append((float[])o, (float[])o2);
        }
        else if (o instanceof boolean[]) {
            this.append((boolean[])o, (boolean[])o2);
        }
        else {
            this.append((Object[])o, (Object[])o2);
        }
    }
    
    public EqualsBuilder append(final long n, final long n2) {
        if (!this.isEquals) {
            return this;
        }
        this.isEquals = (n == n2);
        return this;
    }
    
    public EqualsBuilder append(final int n, final int n2) {
        if (!this.isEquals) {
            return this;
        }
        this.isEquals = (n == n2);
        return this;
    }
    
    public EqualsBuilder append(final short n, final short n2) {
        if (!this.isEquals) {
            return this;
        }
        this.isEquals = (n == n2);
        return this;
    }
    
    public EqualsBuilder append(final char c, final char c2) {
        if (!this.isEquals) {
            return this;
        }
        this.isEquals = (c == c2);
        return this;
    }
    
    public EqualsBuilder append(final byte b, final byte b2) {
        if (!this.isEquals) {
            return this;
        }
        this.isEquals = (b == b2);
        return this;
    }
    
    public EqualsBuilder append(final double value, final double value2) {
        if (!this.isEquals) {
            return this;
        }
        return this.append(Double.doubleToLongBits(value), Double.doubleToLongBits(value2));
    }
    
    public EqualsBuilder append(final float value, final float value2) {
        if (!this.isEquals) {
            return this;
        }
        return this.append(Float.floatToIntBits(value), Float.floatToIntBits(value2));
    }
    
    public EqualsBuilder append(final boolean b, final boolean b2) {
        if (!this.isEquals) {
            return this;
        }
        this.isEquals = (b == b2);
        return this;
    }
    
    public EqualsBuilder append(final Object[] array, final Object[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final long[] array, final long[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final int[] array, final int[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final short[] array, final short[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final char[] array, final char[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final byte[] array, final byte[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final double[] array, final double[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final float[] array, final float[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public EqualsBuilder append(final boolean[] array, final boolean[] array2) {
        if (!this.isEquals) {
            return this;
        }
        if (array == array2) {
            return this;
        }
        if (array == null || array2 == null) {
            this.setEquals(false);
            return this;
        }
        if (array.length != array2.length) {
            this.setEquals(false);
            return this;
        }
        for (int n = 0; n < array.length && this.isEquals; ++n) {
            this.append(array[n], array2[n]);
        }
        return this;
    }
    
    public boolean isEquals() {
        return this.isEquals;
    }
    
    @Override
    public Boolean build() {
        return this.isEquals();
    }
    
    protected void setEquals(final boolean isEquals) {
        this.isEquals = isEquals;
    }
    
    public void reset() {
        this.isEquals = true;
    }
    
    static {
        REGISTRY = new ThreadLocal<Set<Pair<IDKey, IDKey>>>();
    }
}

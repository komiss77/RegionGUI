// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Callable;

public class CallableBackgroundInitializer<T> extends BackgroundInitializer<T>
{
    private final Callable<T> callable;
    
    public CallableBackgroundInitializer(final Callable<T> callable) {
        this.checkCallable(callable);
        this.callable = callable;
    }
    
    public CallableBackgroundInitializer(final Callable<T> callable, final ExecutorService executorService) {
        super(executorService);
        this.checkCallable(callable);
        this.callable = callable;
    }
    
    @Override
    protected T initialize() {
        return this.callable.call();
    }
    
    private void checkCallable(final Callable<T> callable) {
        Validate.isTrue(callable != null, "Callable must not be null!", new Object[0]);
    }
}

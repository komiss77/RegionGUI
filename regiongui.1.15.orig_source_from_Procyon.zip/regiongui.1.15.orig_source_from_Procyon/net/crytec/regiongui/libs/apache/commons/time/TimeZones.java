// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.time;

public class TimeZones
{
    public static final String GMT_ID = "GMT";
    
    private TimeZones() {
    }
}

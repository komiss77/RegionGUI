// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.event;

import java.lang.reflect.Method;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.lang.reflect.Array;
import java.io.ObjectInputStream;
import java.util.Iterator;
import java.io.IOException;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.io.ObjectOutputStream;
import java.util.concurrent.CopyOnWriteArrayList;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.List;
import java.io.Serializable;

public class EventListenerSupport<L> implements Serializable
{
    private static final long serialVersionUID = 3593265990380473632L;
    private List<L> listeners;
    private transient L proxy;
    private transient L[] prototypeArray;
    
    public static <T> EventListenerSupport<T> create(final Class<T> clazz) {
        return new EventListenerSupport<T>(clazz);
    }
    
    public EventListenerSupport(final Class<L> clazz) {
        this(clazz, Thread.currentThread().getContextClassLoader());
    }
    
    public EventListenerSupport(final Class<L> clazz, final ClassLoader classLoader) {
        this();
        Validate.notNull(clazz, "Listener interface cannot be null.", new Object[0]);
        Validate.notNull(classLoader, "ClassLoader cannot be null.", new Object[0]);
        Validate.isTrue(clazz.isInterface(), "Class {0} is not an interface", clazz.getName());
        this.initializeTransientFields(clazz, classLoader);
    }
    
    private EventListenerSupport() {
        this.listeners = new CopyOnWriteArrayList<L>();
    }
    
    public L fire() {
        return this.proxy;
    }
    
    public void addListener(final L l) {
        this.addListener(l, true);
    }
    
    public void addListener(final L l, final boolean b) {
        Validate.notNull(l, "Listener object cannot be null.", new Object[0]);
        if (b) {
            this.listeners.add(l);
        }
        else if (!this.listeners.contains(l)) {
            this.listeners.add(l);
        }
    }
    
    int getListenerCount() {
        return this.listeners.size();
    }
    
    public void removeListener(final L l) {
        Validate.notNull(l, "Listener object cannot be null.", new Object[0]);
        this.listeners.remove(l);
    }
    
    public L[] getListeners() {
        return this.listeners.toArray(this.prototypeArray);
    }
    
    private void writeObject(final ObjectOutputStream objectOutputStream) {
        final ArrayList<L> list = new ArrayList<L>();
        ObjectOutputStream objectOutputStream2 = new ObjectOutputStream(new ByteArrayOutputStream());
        for (final L next : this.listeners) {
            try {
                objectOutputStream2.writeObject(next);
                list.add(next);
            }
            catch (IOException ex) {
                objectOutputStream2 = new ObjectOutputStream(new ByteArrayOutputStream());
            }
        }
        objectOutputStream.writeObject(list.toArray(this.prototypeArray));
    }
    
    private void readObject(final ObjectInputStream objectInputStream) {
        final Object[] toCopyIn = (Object[])objectInputStream.readObject();
        this.listeners = new CopyOnWriteArrayList<L>((L[])toCopyIn);
        this.initializeTransientFields(((L[])toCopyIn).getClass().getComponentType(), Thread.currentThread().getContextClassLoader());
    }
    
    private void initializeTransientFields(final Class<L> componentType, final ClassLoader classLoader) {
        this.prototypeArray = (L[])Array.newInstance(componentType, 0);
        this.createProxy(componentType, classLoader);
    }
    
    private void createProxy(final Class<L> clazz, final ClassLoader loader) {
        this.proxy = clazz.cast(Proxy.newProxyInstance(loader, new Class[] { clazz }, this.createInvocationHandler()));
    }
    
    protected InvocationHandler createInvocationHandler() {
        return new ProxyInvocationHandler();
    }
    
    protected class ProxyInvocationHandler implements InvocationHandler
    {
        @Override
        public Object invoke(final Object o, final Method method, final Object[] args) {
            final Iterator<Object> iterator = EventListenerSupport.this.listeners.iterator();
            while (iterator.hasNext()) {
                method.invoke(iterator.next(), args);
            }
            return null;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.regex.Pattern;

public class RegExUtils
{
    public static String removeAll(final String s, final Pattern pattern) {
        return replaceAll(s, pattern, "");
    }
    
    public static String removeAll(final String s, final String s2) {
        return replaceAll(s, s2, "");
    }
    
    public static String removeFirst(final String s, final Pattern pattern) {
        return replaceFirst(s, pattern, "");
    }
    
    public static String removeFirst(final String s, final String s2) {
        return replaceFirst(s, s2, "");
    }
    
    public static String removePattern(final String s, final String s2) {
        return replacePattern(s, s2, "");
    }
    
    public static String replaceAll(final String input, final Pattern pattern, final String replacement) {
        if (input == null || pattern == null || replacement == null) {
            return input;
        }
        return pattern.matcher(input).replaceAll(replacement);
    }
    
    public static String replaceAll(final String s, final String regex, final String replacement) {
        if (s == null || regex == null || replacement == null) {
            return s;
        }
        return s.replaceAll(regex, replacement);
    }
    
    public static String replaceFirst(final String input, final Pattern pattern, final String replacement) {
        if (input == null || pattern == null || replacement == null) {
            return input;
        }
        return pattern.matcher(input).replaceFirst(replacement);
    }
    
    public static String replaceFirst(final String s, final String regex, final String replacement) {
        if (s == null || regex == null || replacement == null) {
            return s;
        }
        return s.replaceFirst(regex, replacement);
    }
    
    public static String replacePattern(final String input, final String regex, final String replacement) {
        if (input == null || regex == null || replacement == null) {
            return input;
        }
        return Pattern.compile(regex, 32).matcher(input).replaceAll(replacement);
    }
}

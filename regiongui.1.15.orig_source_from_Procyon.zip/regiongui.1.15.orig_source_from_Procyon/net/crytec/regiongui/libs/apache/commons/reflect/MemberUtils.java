// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.reflect;

import net.crytec.regiongui.libs.apache.commons.ClassUtils;
import java.lang.reflect.Method;
import java.lang.reflect.Constructor;
import java.lang.reflect.Modifier;
import java.lang.reflect.Member;
import java.lang.reflect.AccessibleObject;

abstract class MemberUtils
{
    private static final int ACCESS_TEST = 7;
    private static final Class<?>[] ORDERED_PRIMITIVE_TYPES;
    
    static boolean setAccessibleWorkaround(final AccessibleObject accessibleObject) {
        if (accessibleObject == null || accessibleObject.isAccessible()) {
            return false;
        }
        final Member member = (Member)accessibleObject;
        if (!accessibleObject.isAccessible() && Modifier.isPublic(member.getModifiers()) && isPackageAccess(member.getDeclaringClass().getModifiers())) {
            try {
                accessibleObject.setAccessible(true);
                return true;
            }
            catch (SecurityException ex) {}
        }
        return false;
    }
    
    static boolean isPackageAccess(final int n) {
        return (n & 0x7) == 0x0;
    }
    
    static boolean isAccessible(final Member member) {
        return member != null && Modifier.isPublic(member.getModifiers()) && !member.isSynthetic();
    }
    
    static int compareConstructorFit(final Constructor<?> constructor, final Constructor<?> constructor2, final Class<?>[] array) {
        return compareParameterTypes(of(constructor), of(constructor2), array);
    }
    
    static int compareMethodFit(final Method method, final Method method2, final Class<?>[] array) {
        return compareParameterTypes(of(method), of(method2), array);
    }
    
    private static int compareParameterTypes(final Executable executable, final Executable executable2, final Class<?>[] array) {
        return Float.compare(getTotalTransformationCost(array, executable), getTotalTransformationCost(array, executable2));
    }
    
    private static float getTotalTransformationCost(final Class<?>[] array, final Executable executable) {
        final Class<?>[] parameterTypes = executable.getParameterTypes();
        final boolean varArgs = executable.isVarArgs();
        float n = 0.0f;
        final long n2 = varArgs ? (parameterTypes.length - 1) : ((long)parameterTypes.length);
        if (array.length < n2) {
            return Float.MAX_VALUE;
        }
        for (int n3 = 0; n3 < n2; ++n3) {
            n += getObjectTransformationCost(array[n3], parameterTypes[n3]);
        }
        if (varArgs) {
            final boolean b = array.length < parameterTypes.length;
            final boolean b2 = array.length == parameterTypes.length && array[array.length - 1].isArray();
            final Class<?> componentType = parameterTypes[parameterTypes.length - 1].getComponentType();
            if (b) {
                n += getObjectTransformationCost(componentType, Object.class) + 0.001f;
            }
            else if (b2) {
                n += getObjectTransformationCost(array[array.length - 1].getComponentType(), componentType) + 0.001f;
            }
            else {
                for (int i = parameterTypes.length - 1; i < array.length; ++i) {
                    n += getObjectTransformationCost(array[i], componentType) + 0.001f;
                }
            }
        }
        return n;
    }
    
    private static float getObjectTransformationCost(Class<?> superclass, final Class<?> clazz) {
        if (clazz.isPrimitive()) {
            return getPrimitivePromotionCost(superclass, clazz);
        }
        float n = 0.0f;
        while (superclass != null && !clazz.equals(superclass)) {
            if (clazz.isInterface() && ClassUtils.isAssignable(superclass, clazz)) {
                n += 0.25f;
                break;
            }
            ++n;
            superclass = superclass.getSuperclass();
        }
        if (superclass == null) {
            n += 1.5f;
        }
        return n;
    }
    
    private static float getPrimitivePromotionCost(final Class<?> clazz, final Class<?> clazz2) {
        float n = 0.0f;
        Class<?> wrapperToPrimitive = clazz;
        if (!wrapperToPrimitive.isPrimitive()) {
            n += 0.1f;
            wrapperToPrimitive = ClassUtils.wrapperToPrimitive(wrapperToPrimitive);
        }
        for (int n2 = 0; wrapperToPrimitive != clazz2 && n2 < MemberUtils.ORDERED_PRIMITIVE_TYPES.length; ++n2) {
            if (wrapperToPrimitive == MemberUtils.ORDERED_PRIMITIVE_TYPES[n2]) {
                n += 0.1f;
                if (n2 < MemberUtils.ORDERED_PRIMITIVE_TYPES.length - 1) {
                    wrapperToPrimitive = MemberUtils.ORDERED_PRIMITIVE_TYPES[n2 + 1];
                }
            }
        }
        return n;
    }
    
    static boolean isMatchingMethod(final Method method, final Class<?>[] array) {
        return isMatchingExecutable(of(method), array);
    }
    
    static boolean isMatchingConstructor(final Constructor<?> constructor, final Class<?>[] array) {
        return isMatchingExecutable(of(constructor), array);
    }
    
    private static boolean isMatchingExecutable(final Executable executable, final Class<?>[] array) {
        final Class<?>[] parameterTypes = executable.getParameterTypes();
        if (ClassUtils.isAssignable(array, parameterTypes, true)) {
            return true;
        }
        if (executable.isVarArgs()) {
            int i;
            for (i = 0; i < parameterTypes.length - 1 && i < array.length; ++i) {
                if (!ClassUtils.isAssignable(array[i], parameterTypes[i], true)) {
                    return false;
                }
            }
            final Class<?> componentType = parameterTypes[parameterTypes.length - 1].getComponentType();
            while (i < array.length) {
                if (!ClassUtils.isAssignable(array[i], componentType, true)) {
                    return false;
                }
                ++i;
            }
            return true;
        }
        return false;
    }
    
    static {
        ORDERED_PRIMITIVE_TYPES = new Class[] { Byte.TYPE, Short.TYPE, Character.TYPE, Integer.TYPE, Long.TYPE, Float.TYPE, Double.TYPE };
    }
    
    private static final class Executable
    {
        private final Class<?>[] parameterTypes;
        private final boolean isVarArgs;
        
        private static Executable of(final Method method) {
            return new Executable(method);
        }
        
        private static Executable of(final Constructor<?> constructor) {
            return new Executable(constructor);
        }
        
        private Executable(final Method method) {
            this.parameterTypes = method.getParameterTypes();
            this.isVarArgs = method.isVarArgs();
        }
        
        private Executable(final Constructor<?> constructor) {
            this.parameterTypes = (Class<?>[])constructor.getParameterTypes();
            this.isVarArgs = constructor.isVarArgs();
        }
        
        public Class<?>[] getParameterTypes() {
            return this.parameterTypes;
        }
        
        public boolean isVarArgs() {
            return this.isVarArgs;
        }
    }
}

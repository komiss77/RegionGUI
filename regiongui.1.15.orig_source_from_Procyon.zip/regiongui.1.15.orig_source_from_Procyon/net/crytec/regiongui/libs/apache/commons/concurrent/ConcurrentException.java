// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

public class ConcurrentException extends Exception
{
    private static final long serialVersionUID = 6622707671812226130L;
    
    protected ConcurrentException() {
    }
    
    public ConcurrentException(final Throwable t) {
        super(ConcurrentUtils.checkedException(t));
    }
    
    public ConcurrentException(final String message, final Throwable t) {
        super(message, ConcurrentUtils.checkedException(t));
    }
}

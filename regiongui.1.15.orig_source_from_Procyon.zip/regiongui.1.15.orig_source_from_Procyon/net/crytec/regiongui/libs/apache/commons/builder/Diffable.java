// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.builder;

public interface Diffable<T>
{
    DiffResult diff(final T p0);
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.tuple;

public final class ImmutableTriple<L, M, R> extends Triple<L, M, R>
{
    private static final ImmutableTriple NULL;
    private static final long serialVersionUID = 1L;
    public final L left;
    public final M middle;
    public final R right;
    
    public static <L, M, R> ImmutableTriple<L, M, R> nullTriple() {
        return (ImmutableTriple<L, M, R>)ImmutableTriple.NULL;
    }
    
    public static <L, M, R> ImmutableTriple<L, M, R> of(final L l, final M m, final R r) {
        return new ImmutableTriple<L, M, R>(l, m, r);
    }
    
    public ImmutableTriple(final L left, final M middle, final R right) {
        this.left = left;
        this.middle = middle;
        this.right = right;
    }
    
    @Override
    public L getLeft() {
        return this.left;
    }
    
    @Override
    public M getMiddle() {
        return this.middle;
    }
    
    @Override
    public R getRight() {
        return this.right;
    }
    
    static {
        NULL = of((Object)null, (Object)null, (Object)null);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text;

import java.util.Objects;
import net.crytec.regiongui.libs.apache.commons.ObjectUtils;
import java.util.Iterator;
import java.util.Collection;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.text.ParsePosition;
import java.text.Format;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Map;
import java.text.MessageFormat;

@Deprecated
public class ExtendedMessageFormat extends MessageFormat
{
    private static final long serialVersionUID = -2362048321261811743L;
    private static final int HASH_SEED = 31;
    private static final String DUMMY_PATTERN = "";
    private static final char START_FMT = ',';
    private static final char END_FE = '}';
    private static final char START_FE = '{';
    private static final char QUOTE = '\'';
    private String toPattern;
    private final Map<String, ? extends FormatFactory> registry;
    
    public ExtendedMessageFormat(final String s) {
        this(s, Locale.getDefault());
    }
    
    public ExtendedMessageFormat(final String s, final Locale locale) {
        this(s, locale, null);
    }
    
    public ExtendedMessageFormat(final String s, final Map<String, ? extends FormatFactory> map) {
        this(s, Locale.getDefault(), map);
    }
    
    public ExtendedMessageFormat(final String s, final Locale locale, final Map<String, ? extends FormatFactory> registry) {
        super("");
        this.setLocale(locale);
        this.registry = registry;
        this.applyPattern(s);
    }
    
    @Override
    public String toPattern() {
        return this.toPattern;
    }
    
    @Override
    public final void applyPattern(final String pattern) {
        if (this.registry == null) {
            super.applyPattern(pattern);
            this.toPattern = super.toPattern();
            return;
        }
        final ArrayList<Format> list = new ArrayList<Format>();
        final ArrayList<String> list2 = new ArrayList<String>();
        final StringBuilder sb = new StringBuilder(pattern.length());
        final ParsePosition parsePosition = new ParsePosition(0);
        final char[] charArray = pattern.toCharArray();
        int n = 0;
        while (parsePosition.getIndex() < pattern.length()) {
            switch (charArray[parsePosition.getIndex()]) {
                case '\'': {
                    this.appendQuotedString(pattern, parsePosition, sb);
                    continue;
                }
                case '{': {
                    ++n;
                    this.seekNonWs(pattern, parsePosition);
                    final int index = parsePosition.getIndex();
                    sb.append('{').append(this.readArgumentIndex(pattern, this.next(parsePosition)));
                    this.seekNonWs(pattern, parsePosition);
                    Format format = null;
                    String formatDescription = null;
                    if (charArray[parsePosition.getIndex()] == ',') {
                        formatDescription = this.parseFormatDescription(pattern, this.next(parsePosition));
                        format = this.getFormat(formatDescription);
                        if (format == null) {
                            sb.append(',').append(formatDescription);
                        }
                    }
                    list.add(format);
                    list2.add((format == null) ? null : formatDescription);
                    Validate.isTrue(list.size() == n);
                    Validate.isTrue(list2.size() == n);
                    if (charArray[parsePosition.getIndex()] != '}') {
                        throw new IllegalArgumentException("Unreadable format element at position " + index);
                    }
                    break;
                }
            }
            sb.append(charArray[parsePosition.getIndex()]);
            this.next(parsePosition);
        }
        super.applyPattern(sb.toString());
        this.toPattern = this.insertFormats(super.toPattern(), list2);
        if (this.containsElements(list)) {
            final Format[] formats = this.getFormats();
            int n2 = 0;
            for (final Format format2 : list) {
                if (format2 != null) {
                    formats[n2] = format2;
                }
                ++n2;
            }
            super.setFormats(formats);
        }
    }
    
    @Override
    public void setFormat(final int n, final Format format) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void setFormatByArgumentIndex(final int n, final Format format) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void setFormats(final Format[] array) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public void setFormatsByArgumentIndex(final Format[] array) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public boolean equals(final Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!super.equals(obj)) {
            return false;
        }
        if (ObjectUtils.notEqual(this.getClass(), obj.getClass())) {
            return false;
        }
        final ExtendedMessageFormat extendedMessageFormat = (ExtendedMessageFormat)obj;
        return !ObjectUtils.notEqual(this.toPattern, extendedMessageFormat.toPattern) && !ObjectUtils.notEqual(this.registry, extendedMessageFormat.registry);
    }
    
    @Override
    public int hashCode() {
        return 31 * (31 * super.hashCode() + Objects.hashCode(this.registry)) + Objects.hashCode(this.toPattern);
    }
    
    private Format getFormat(final String s) {
        if (this.registry != null) {
            String trim = s;
            String trim2 = null;
            final int index = s.indexOf(44);
            if (index > 0) {
                trim = s.substring(0, index).trim();
                trim2 = s.substring(index + 1).trim();
            }
            final FormatFactory formatFactory = (FormatFactory)this.registry.get(trim);
            if (formatFactory != null) {
                return formatFactory.getFormat(trim, trim2, this.getLocale());
            }
        }
        return null;
    }
    
    private int readArgumentIndex(final String s, final ParsePosition parsePosition) {
        final int index = parsePosition.getIndex();
        this.seekNonWs(s, parsePosition);
        final StringBuilder sb = new StringBuilder();
        int n = 0;
        while (n == 0 && parsePosition.getIndex() < s.length()) {
            char c = s.charAt(parsePosition.getIndex());
            Label_0149: {
                if (Character.isWhitespace(c)) {
                    this.seekNonWs(s, parsePosition);
                    c = s.charAt(parsePosition.getIndex());
                    if (c != ',' && c != '}') {
                        n = 1;
                        break Label_0149;
                    }
                }
                if ((c == ',' || c == '}') && sb.length() > 0) {
                    try {
                        return Integer.parseInt(sb.toString());
                    }
                    catch (NumberFormatException ex) {}
                }
                n = (Character.isDigit(c) ? 0 : 1);
                sb.append(c);
            }
            this.next(parsePosition);
        }
        if (n != 0) {
            throw new IllegalArgumentException("Invalid format argument index at position " + index + ": " + s.substring(index, parsePosition.getIndex()));
        }
        throw new IllegalArgumentException("Unterminated format element at position " + index);
    }
    
    private String parseFormatDescription(final String s, final ParsePosition parsePosition) {
        final int index = parsePosition.getIndex();
        this.seekNonWs(s, parsePosition);
        final int index2 = parsePosition.getIndex();
        int n = 1;
        while (parsePosition.getIndex() < s.length()) {
            switch (s.charAt(parsePosition.getIndex())) {
                case '{': {
                    ++n;
                    break;
                }
                case '}': {
                    if (--n == 0) {
                        return s.substring(index2, parsePosition.getIndex());
                    }
                    break;
                }
                case '\'': {
                    this.getQuotedString(s, parsePosition);
                    break;
                }
            }
            this.next(parsePosition);
        }
        throw new IllegalArgumentException("Unterminated format element at position " + index);
    }
    
    private String insertFormats(final String s, final ArrayList<String> list) {
        if (!this.containsElements(list)) {
            return s;
        }
        final StringBuilder sb = new StringBuilder(s.length() * 2);
        final ParsePosition parsePosition = new ParsePosition(0);
        int index = -1;
        int n = 0;
        while (parsePosition.getIndex() < s.length()) {
            final char char1 = s.charAt(parsePosition.getIndex());
            switch (char1) {
                case 39: {
                    this.appendQuotedString(s, parsePosition, sb);
                    continue;
                }
                case 123: {
                    ++n;
                    sb.append('{').append(this.readArgumentIndex(s, this.next(parsePosition)));
                    if (n == 1) {
                        ++index;
                        final String str = list.get(index);
                        if (str == null) {
                            continue;
                        }
                        sb.append(',').append(str);
                        continue;
                    }
                    continue;
                }
                case 125: {
                    --n;
                    break;
                }
            }
            sb.append(char1);
            this.next(parsePosition);
        }
        return sb.toString();
    }
    
    private void seekNonWs(final String s, final ParsePosition parsePosition) {
        final char[] charArray = s.toCharArray();
        int match;
        do {
            match = StrMatcher.splitMatcher().isMatch(charArray, parsePosition.getIndex());
            parsePosition.setIndex(parsePosition.getIndex() + match);
        } while (match > 0 && parsePosition.getIndex() < s.length());
    }
    
    private ParsePosition next(final ParsePosition parsePosition) {
        parsePosition.setIndex(parsePosition.getIndex() + 1);
        return parsePosition;
    }
    
    private StringBuilder appendQuotedString(final String s, final ParsePosition parsePosition, final StringBuilder sb) {
        assert s.toCharArray()[parsePosition.getIndex()] == '\'' : "Quoted string must start with quote character";
        if (sb != null) {
            sb.append('\'');
        }
        this.next(parsePosition);
        final int index = parsePosition.getIndex();
        final char[] charArray = s.toCharArray();
        final int offset = index;
        int i = parsePosition.getIndex();
        while (i < s.length()) {
            switch (charArray[parsePosition.getIndex()]) {
                case '\'': {
                    this.next(parsePosition);
                    return (sb == null) ? null : sb.append(charArray, offset, parsePosition.getIndex() - offset);
                }
                default: {
                    this.next(parsePosition);
                    ++i;
                    continue;
                }
            }
        }
        throw new IllegalArgumentException("Unterminated quoted string at position " + index);
    }
    
    private void getQuotedString(final String s, final ParsePosition parsePosition) {
        this.appendQuotedString(s, parsePosition, null);
    }
    
    private boolean containsElements(final Collection<?> collection) {
        if (collection == null || collection.isEmpty()) {
            return false;
        }
        final Iterator<?> iterator = collection.iterator();
        while (iterator.hasNext()) {
            if (iterator.next() != null) {
                return true;
            }
        }
        return false;
    }
}

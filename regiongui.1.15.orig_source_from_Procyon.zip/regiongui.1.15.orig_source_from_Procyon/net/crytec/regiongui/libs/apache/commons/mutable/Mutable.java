// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.mutable;

public interface Mutable<T>
{
    T getValue();
    
    void setValue(final T p0);
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.nio.charset.Charset;
import java.util.Locale;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Iterator;
import java.util.ArrayList;
import java.text.Normalizer;
import java.util.regex.Pattern;

public class StringUtils
{
    private static final int STRING_BUILDER_SIZE = 256;
    public static final String SPACE = " ";
    public static final String EMPTY = "";
    public static final String LF = "\n";
    public static final String CR = "\r";
    public static final int INDEX_NOT_FOUND = -1;
    private static final int PAD_LIMIT = 8192;
    
    public static boolean isEmpty(final CharSequence charSequence) {
        return charSequence == null || charSequence.length() == 0;
    }
    
    public static boolean isNotEmpty(final CharSequence charSequence) {
        return !isEmpty(charSequence);
    }
    
    public static boolean isAnyEmpty(final CharSequence... array) {
        if (ArrayUtils.isEmpty(array)) {
            return false;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (isEmpty(array[i])) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean isNoneEmpty(final CharSequence... array) {
        return !isAnyEmpty(array);
    }
    
    public static boolean isAllEmpty(final CharSequence... array) {
        if (ArrayUtils.isEmpty(array)) {
            return true;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (isNotEmpty(array[i])) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isBlank(final CharSequence charSequence) {
        final int length;
        if (charSequence == null || (length = charSequence.length()) == 0) {
            return true;
        }
        for (int i = 0; i < length; ++i) {
            if (!Character.isWhitespace(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isNotBlank(final CharSequence charSequence) {
        return !isBlank(charSequence);
    }
    
    public static boolean isAnyBlank(final CharSequence... array) {
        if (ArrayUtils.isEmpty(array)) {
            return false;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (isBlank(array[i])) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean isNoneBlank(final CharSequence... array) {
        return !isAnyBlank(array);
    }
    
    public static boolean isAllBlank(final CharSequence... array) {
        if (ArrayUtils.isEmpty(array)) {
            return true;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (isNotBlank(array[i])) {
                return false;
            }
        }
        return true;
    }
    
    public static String trim(final String s) {
        return (s == null) ? null : s.trim();
    }
    
    public static String trimToNull(final String s) {
        final String trim = trim(s);
        return isEmpty(trim) ? null : trim;
    }
    
    public static String trimToEmpty(final String s) {
        return (s == null) ? "" : s.trim();
    }
    
    public static String truncate(final String s, final int n) {
        return truncate(s, 0, n);
    }
    
    public static String truncate(final String s, final int n, final int n2) {
        if (n < 0) {
            throw new IllegalArgumentException("offset cannot be negative");
        }
        if (n2 < 0) {
            throw new IllegalArgumentException("maxWith cannot be negative");
        }
        if (s == null) {
            return null;
        }
        if (n > s.length()) {
            return "";
        }
        if (s.length() > n2) {
            return s.substring(n, (n + n2 > s.length()) ? s.length() : (n + n2));
        }
        return s.substring(n);
    }
    
    public static String strip(final String s) {
        return strip(s, null);
    }
    
    public static String stripToNull(String strip) {
        if (strip == null) {
            return null;
        }
        strip = strip(strip, null);
        return strip.isEmpty() ? null : strip;
    }
    
    public static String stripToEmpty(final String s) {
        return (s == null) ? "" : strip(s, null);
    }
    
    public static String strip(String stripStart, final String s) {
        if (isEmpty(stripStart)) {
            return stripStart;
        }
        stripStart = stripStart(stripStart, s);
        return stripEnd(stripStart, s);
    }
    
    public static String stripStart(final String s, final String s2) {
        final int length;
        if (s == null || (length = s.length()) == 0) {
            return s;
        }
        int beginIndex = 0;
        if (s2 == null) {
            while (beginIndex != length && Character.isWhitespace(s.charAt(beginIndex))) {
                ++beginIndex;
            }
        }
        else {
            if (s2.isEmpty()) {
                return s;
            }
            while (beginIndex != length && s2.indexOf(s.charAt(beginIndex)) != -1) {
                ++beginIndex;
            }
        }
        return s.substring(beginIndex);
    }
    
    public static String stripEnd(final String s, final String s2) {
        int length;
        if (s == null || (length = s.length()) == 0) {
            return s;
        }
        if (s2 == null) {
            while (length != 0 && Character.isWhitespace(s.charAt(length - 1))) {
                --length;
            }
        }
        else {
            if (s2.isEmpty()) {
                return s;
            }
            while (length != 0 && s2.indexOf(s.charAt(length - 1)) != -1) {
                --length;
            }
        }
        return s.substring(0, length);
    }
    
    public static String[] stripAll(final String... array) {
        return stripAll(array, null);
    }
    
    public static String[] stripAll(final String[] array, final String s) {
        final int length;
        if (array == null || (length = array.length) == 0) {
            return array;
        }
        final String[] array2 = new String[length];
        for (int i = 0; i < length; ++i) {
            array2[i] = strip(array[i], s);
        }
        return array2;
    }
    
    public static String stripAccents(final String src) {
        if (src == null) {
            return null;
        }
        final Pattern compile = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        final StringBuilder input = new StringBuilder(Normalizer.normalize(src, Normalizer.Form.NFD));
        convertRemainingAccentCharacters(input);
        return compile.matcher(input).replaceAll("");
    }
    
    private static void convertRemainingAccentCharacters(final StringBuilder sb) {
        for (int i = 0; i < sb.length(); ++i) {
            if (sb.charAt(i) == '\u0141') {
                sb.deleteCharAt(i);
                sb.insert(i, 'L');
            }
            else if (sb.charAt(i) == '\u0142') {
                sb.deleteCharAt(i);
                sb.insert(i, 'l');
            }
        }
    }
    
    public static boolean equals(final CharSequence charSequence, final CharSequence obj) {
        if (charSequence == obj) {
            return true;
        }
        if (charSequence == null || obj == null) {
            return false;
        }
        if (charSequence.length() != obj.length()) {
            return false;
        }
        if (charSequence instanceof String && obj instanceof String) {
            return charSequence.equals(obj);
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (charSequence.charAt(i) != obj.charAt(i)) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean equalsIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2) {
        return charSequence == charSequence2 || (charSequence != null && charSequence2 != null && charSequence.length() == charSequence2.length() && CharSequenceUtils.regionMatches(charSequence, true, 0, charSequence2, 0, charSequence.length()));
    }
    
    public static int compare(final String s, final String s2) {
        return compare(s, s2, true);
    }
    
    public static int compare(final String s, final String anotherString, final boolean b) {
        if (s == anotherString) {
            return 0;
        }
        if (s == null) {
            return b ? -1 : 1;
        }
        if (anotherString == null) {
            return b ? 1 : -1;
        }
        return s.compareTo(anotherString);
    }
    
    public static int compareIgnoreCase(final String s, final String s2) {
        return compareIgnoreCase(s, s2, true);
    }
    
    public static int compareIgnoreCase(final String s, final String str, final boolean b) {
        if (s == str) {
            return 0;
        }
        if (s == null) {
            return b ? -1 : 1;
        }
        if (str == null) {
            return b ? 1 : -1;
        }
        return s.compareToIgnoreCase(str);
    }
    
    public static boolean equalsAny(final CharSequence charSequence, final CharSequence... array) {
        if (ArrayUtils.isNotEmpty(array)) {
            for (int length = array.length, i = 0; i < length; ++i) {
                if (equals(charSequence, array[i])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static boolean equalsAnyIgnoreCase(final CharSequence charSequence, final CharSequence... array) {
        if (ArrayUtils.isNotEmpty(array)) {
            for (int length = array.length, i = 0; i < length; ++i) {
                if (equalsIgnoreCase(charSequence, array[i])) {
                    return true;
                }
            }
        }
        return false;
    }
    
    public static int indexOf(final CharSequence charSequence, final int n) {
        if (isEmpty(charSequence)) {
            return -1;
        }
        return CharSequenceUtils.indexOf(charSequence, n, 0);
    }
    
    public static int indexOf(final CharSequence charSequence, final int n, final int n2) {
        if (isEmpty(charSequence)) {
            return -1;
        }
        return CharSequenceUtils.indexOf(charSequence, n, n2);
    }
    
    public static int indexOf(final CharSequence charSequence, final CharSequence charSequence2) {
        if (charSequence == null || charSequence2 == null) {
            return -1;
        }
        return CharSequenceUtils.indexOf(charSequence, charSequence2, 0);
    }
    
    public static int indexOf(final CharSequence charSequence, final CharSequence charSequence2, final int n) {
        if (charSequence == null || charSequence2 == null) {
            return -1;
        }
        return CharSequenceUtils.indexOf(charSequence, charSequence2, n);
    }
    
    public static int ordinalIndexOf(final CharSequence charSequence, final CharSequence charSequence2, final int n) {
        return ordinalIndexOf(charSequence, charSequence2, n, false);
    }
    
    private static int ordinalIndexOf(final CharSequence charSequence, final CharSequence charSequence2, final int n, final boolean b) {
        if (charSequence == null || charSequence2 == null || n <= 0) {
            return -1;
        }
        if (charSequence2.length() == 0) {
            return b ? charSequence.length() : 0;
        }
        int n2 = 0;
        int n3 = b ? charSequence.length() : -1;
        do {
            if (b) {
                n3 = CharSequenceUtils.lastIndexOf(charSequence, charSequence2, n3 - 1);
            }
            else {
                n3 = CharSequenceUtils.indexOf(charSequence, charSequence2, n3 + 1);
            }
            if (n3 < 0) {
                return n3;
            }
        } while (++n2 < n);
        return n3;
    }
    
    public static int indexOfIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2) {
        return indexOfIgnoreCase(charSequence, charSequence2, 0);
    }
    
    public static int indexOfIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2, int n) {
        if (charSequence == null || charSequence2 == null) {
            return -1;
        }
        if (n < 0) {
            n = 0;
        }
        final int n2 = charSequence.length() - charSequence2.length() + 1;
        if (n > n2) {
            return -1;
        }
        if (charSequence2.length() == 0) {
            return n;
        }
        for (int i = n; i < n2; ++i) {
            if (CharSequenceUtils.regionMatches(charSequence, true, i, charSequence2, 0, charSequence2.length())) {
                return i;
            }
        }
        return -1;
    }
    
    public static int lastIndexOf(final CharSequence charSequence, final int n) {
        if (isEmpty(charSequence)) {
            return -1;
        }
        return CharSequenceUtils.lastIndexOf(charSequence, n, charSequence.length());
    }
    
    public static int lastIndexOf(final CharSequence charSequence, final int n, final int n2) {
        if (isEmpty(charSequence)) {
            return -1;
        }
        return CharSequenceUtils.lastIndexOf(charSequence, n, n2);
    }
    
    public static int lastIndexOf(final CharSequence charSequence, final CharSequence charSequence2) {
        if (charSequence == null || charSequence2 == null) {
            return -1;
        }
        return CharSequenceUtils.lastIndexOf(charSequence, charSequence2, charSequence.length());
    }
    
    public static int lastOrdinalIndexOf(final CharSequence charSequence, final CharSequence charSequence2, final int n) {
        return ordinalIndexOf(charSequence, charSequence2, n, true);
    }
    
    public static int lastIndexOf(final CharSequence charSequence, final CharSequence charSequence2, final int n) {
        if (charSequence == null || charSequence2 == null) {
            return -1;
        }
        return CharSequenceUtils.lastIndexOf(charSequence, charSequence2, n);
    }
    
    public static int lastIndexOfIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2) {
        if (charSequence == null || charSequence2 == null) {
            return -1;
        }
        return lastIndexOfIgnoreCase(charSequence, charSequence2, charSequence.length());
    }
    
    public static int lastIndexOfIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2, int n) {
        if (charSequence == null || charSequence2 == null) {
            return -1;
        }
        if (n > charSequence.length() - charSequence2.length()) {
            n = charSequence.length() - charSequence2.length();
        }
        if (n < 0) {
            return -1;
        }
        if (charSequence2.length() == 0) {
            return n;
        }
        for (int i = n; i >= 0; --i) {
            if (CharSequenceUtils.regionMatches(charSequence, true, i, charSequence2, 0, charSequence2.length())) {
                return i;
            }
        }
        return -1;
    }
    
    public static boolean contains(final CharSequence charSequence, final int n) {
        return !isEmpty(charSequence) && CharSequenceUtils.indexOf(charSequence, n, 0) >= 0;
    }
    
    public static boolean contains(final CharSequence charSequence, final CharSequence charSequence2) {
        return charSequence != null && charSequence2 != null && CharSequenceUtils.indexOf(charSequence, charSequence2, 0) >= 0;
    }
    
    public static boolean containsIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2) {
        if (charSequence == null || charSequence2 == null) {
            return false;
        }
        final int length = charSequence2.length();
        for (int n = charSequence.length() - length, i = 0; i <= n; ++i) {
            if (CharSequenceUtils.regionMatches(charSequence, true, i, charSequence2, 0, length)) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean containsWhitespace(final CharSequence charSequence) {
        if (isEmpty(charSequence)) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (Character.isWhitespace(charSequence.charAt(i))) {
                return true;
            }
        }
        return false;
    }
    
    public static int indexOfAny(final CharSequence charSequence, final char... array) {
        if (isEmpty(charSequence) || ArrayUtils.isEmpty(array)) {
            return -1;
        }
        final int length = charSequence.length();
        final int n = length - 1;
        final int length2 = array.length;
        final int n2 = length2 - 1;
        for (int i = 0; i < length; ++i) {
            final char char1 = charSequence.charAt(i);
            for (int j = 0; j < length2; ++j) {
                if (array[j] == char1) {
                    if (i >= n || j >= n2 || !Character.isHighSurrogate(char1)) {
                        return i;
                    }
                    if (array[j + 1] == charSequence.charAt(i + 1)) {
                        return i;
                    }
                }
            }
        }
        return -1;
    }
    
    public static int indexOfAny(final CharSequence charSequence, final String s) {
        if (isEmpty(charSequence) || isEmpty(s)) {
            return -1;
        }
        return indexOfAny(charSequence, s.toCharArray());
    }
    
    public static boolean containsAny(final CharSequence charSequence, final char... array) {
        if (isEmpty(charSequence) || ArrayUtils.isEmpty(array)) {
            return false;
        }
        final int length = charSequence.length();
        final int length2 = array.length;
        final int n = length - 1;
        final int n2 = length2 - 1;
        for (int i = 0; i < length; ++i) {
            final char char1 = charSequence.charAt(i);
            for (int j = 0; j < length2; ++j) {
                if (array[j] == char1) {
                    if (!Character.isHighSurrogate(char1)) {
                        return true;
                    }
                    if (j == n2) {
                        return true;
                    }
                    if (i < n && array[j + 1] == charSequence.charAt(i + 1)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
    
    public static boolean containsAny(final CharSequence charSequence, final CharSequence charSequence2) {
        return charSequence2 != null && containsAny(charSequence, CharSequenceUtils.toCharArray(charSequence2));
    }
    
    public static boolean containsAny(final CharSequence charSequence, final CharSequence... array) {
        if (isEmpty(charSequence) || ArrayUtils.isEmpty(array)) {
            return false;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (contains(charSequence, array[i])) {
                return true;
            }
        }
        return false;
    }
    
    public static int indexOfAnyBut(final CharSequence charSequence, final char... array) {
        if (isEmpty(charSequence) || ArrayUtils.isEmpty(array)) {
            return -1;
        }
        final int length = charSequence.length();
        final int n = length - 1;
        final int length2 = array.length;
        final int n2 = length2 - 1;
        int i = 0;
    Label_0040:
        while (i < length) {
            final char char1 = charSequence.charAt(i);
            for (int j = 0; j < length2; ++j) {
                if (array[j] == char1 && (i >= n || j >= n2 || !Character.isHighSurrogate(char1) || array[j + 1] == charSequence.charAt(i + 1))) {
                    ++i;
                    continue Label_0040;
                }
            }
            return i;
        }
        return -1;
    }
    
    public static int indexOfAnyBut(final CharSequence charSequence, final CharSequence charSequence2) {
        if (isEmpty(charSequence) || isEmpty(charSequence2)) {
            return -1;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            final char char1 = charSequence.charAt(i);
            final boolean b = CharSequenceUtils.indexOf(charSequence2, char1, 0) >= 0;
            if (i + 1 < length && Character.isHighSurrogate(char1)) {
                final char char2 = charSequence.charAt(i + 1);
                if (b && CharSequenceUtils.indexOf(charSequence2, char2, 0) < 0) {
                    return i;
                }
            }
            else if (!b) {
                return i;
            }
        }
        return -1;
    }
    
    public static boolean containsOnly(final CharSequence charSequence, final char... array) {
        return array != null && charSequence != null && (charSequence.length() == 0 || (array.length != 0 && indexOfAnyBut(charSequence, array) == -1));
    }
    
    public static boolean containsOnly(final CharSequence charSequence, final String s) {
        return charSequence != null && s != null && containsOnly(charSequence, s.toCharArray());
    }
    
    public static boolean containsNone(final CharSequence charSequence, final char... array) {
        if (charSequence == null || array == null) {
            return true;
        }
        final int length = charSequence.length();
        final int n = length - 1;
        final int length2 = array.length;
        final int n2 = length2 - 1;
        for (int i = 0; i < length; ++i) {
            final char char1 = charSequence.charAt(i);
            for (int j = 0; j < length2; ++j) {
                if (array[j] == char1) {
                    if (!Character.isHighSurrogate(char1)) {
                        return false;
                    }
                    if (j == n2) {
                        return false;
                    }
                    if (i < n && array[j + 1] == charSequence.charAt(i + 1)) {
                        return false;
                    }
                }
            }
        }
        return true;
    }
    
    public static boolean containsNone(final CharSequence charSequence, final String s) {
        return charSequence == null || s == null || containsNone(charSequence, s.toCharArray());
    }
    
    public static int indexOfAny(final CharSequence charSequence, final CharSequence... array) {
        if (charSequence == null || array == null) {
            return -1;
        }
        int n = Integer.MAX_VALUE;
        for (final CharSequence charSequence2 : array) {
            if (charSequence2 != null) {
                final int index = CharSequenceUtils.indexOf(charSequence, charSequence2, 0);
                if (index != -1) {
                    if (index < n) {
                        n = index;
                    }
                }
            }
        }
        return (n == Integer.MAX_VALUE) ? -1 : n;
    }
    
    public static int lastIndexOfAny(final CharSequence charSequence, final CharSequence... array) {
        if (charSequence == null || array == null) {
            return -1;
        }
        int n = -1;
        for (final CharSequence charSequence2 : array) {
            if (charSequence2 != null) {
                final int lastIndex = CharSequenceUtils.lastIndexOf(charSequence, charSequence2, charSequence.length());
                if (lastIndex > n) {
                    n = lastIndex;
                }
            }
        }
        return n;
    }
    
    public static String substring(final String s, int beginIndex) {
        if (s == null) {
            return null;
        }
        if (beginIndex < 0) {
            beginIndex += s.length();
        }
        if (beginIndex < 0) {
            beginIndex = 0;
        }
        if (beginIndex > s.length()) {
            return "";
        }
        return s.substring(beginIndex);
    }
    
    public static String substring(final String s, int beginIndex, int length) {
        if (s == null) {
            return null;
        }
        if (length < 0) {
            length += s.length();
        }
        if (beginIndex < 0) {
            beginIndex += s.length();
        }
        if (length > s.length()) {
            length = s.length();
        }
        if (beginIndex > length) {
            return "";
        }
        if (beginIndex < 0) {
            beginIndex = 0;
        }
        if (length < 0) {
            length = 0;
        }
        return s.substring(beginIndex, length);
    }
    
    public static String left(final String s, final int endIndex) {
        if (s == null) {
            return null;
        }
        if (endIndex < 0) {
            return "";
        }
        if (s.length() <= endIndex) {
            return s;
        }
        return s.substring(0, endIndex);
    }
    
    public static String right(final String s, final int n) {
        if (s == null) {
            return null;
        }
        if (n < 0) {
            return "";
        }
        if (s.length() <= n) {
            return s;
        }
        return s.substring(s.length() - n);
    }
    
    public static String mid(final String s, int n, final int n2) {
        if (s == null) {
            return null;
        }
        if (n2 < 0 || n > s.length()) {
            return "";
        }
        if (n < 0) {
            n = 0;
        }
        if (s.length() <= n + n2) {
            return s.substring(n);
        }
        return s.substring(n, n + n2);
    }
    
    private static StringBuilder newStringBuilder(final int n) {
        return new StringBuilder(n * 16);
    }
    
    public static String substringBefore(final String s, final String str) {
        if (isEmpty(s) || str == null) {
            return s;
        }
        if (str.isEmpty()) {
            return "";
        }
        final int index = s.indexOf(str);
        if (index == -1) {
            return s;
        }
        return s.substring(0, index);
    }
    
    public static String substringAfter(final String s, final String str) {
        if (isEmpty(s)) {
            return s;
        }
        if (str == null) {
            return "";
        }
        final int index = s.indexOf(str);
        if (index == -1) {
            return "";
        }
        return s.substring(index + str.length());
    }
    
    public static String substringBeforeLast(final String s, final String str) {
        if (isEmpty(s) || isEmpty(str)) {
            return s;
        }
        final int lastIndex = s.lastIndexOf(str);
        if (lastIndex == -1) {
            return s;
        }
        return s.substring(0, lastIndex);
    }
    
    public static String substringAfterLast(final String s, final String str) {
        if (isEmpty(s)) {
            return s;
        }
        if (isEmpty(str)) {
            return "";
        }
        final int lastIndex = s.lastIndexOf(str);
        if (lastIndex == -1 || lastIndex == s.length() - str.length()) {
            return "";
        }
        return s.substring(lastIndex + str.length());
    }
    
    public static String substringBetween(final String s, final String s2) {
        return substringBetween(s, s2, s2);
    }
    
    public static String substringBetween(final String s, final String str, final String str2) {
        if (s == null || str == null || str2 == null) {
            return null;
        }
        final int index = s.indexOf(str);
        if (index != -1) {
            final int index2 = s.indexOf(str2, index + str.length());
            if (index2 != -1) {
                return s.substring(index + str.length(), index2);
            }
        }
        return null;
    }
    
    public static String[] substringsBetween(final String s, final String str, final String str2) {
        if (s == null || isEmpty(str) || isEmpty(str2)) {
            return null;
        }
        final int length = s.length();
        if (length == 0) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        final int length2 = str2.length();
        final int length3 = str.length();
        final ArrayList<String> list = new ArrayList<String>();
        int index2;
        for (int i = 0; i < length - length2; i = index2 + length2) {
            final int index = s.indexOf(str, i);
            if (index < 0) {
                break;
            }
            final int n = index + length3;
            index2 = s.indexOf(str2, n);
            if (index2 < 0) {
                break;
            }
            list.add(s.substring(n, index2));
        }
        if (list.isEmpty()) {
            return null;
        }
        return list.toArray(new String[list.size()]);
    }
    
    public static String[] split(final String s) {
        return split(s, null, -1);
    }
    
    public static String[] split(final String s, final char c) {
        return splitWorker(s, c, false);
    }
    
    public static String[] split(final String s, final String s2) {
        return splitWorker(s, s2, -1, false);
    }
    
    public static String[] split(final String s, final String s2, final int n) {
        return splitWorker(s, s2, n, false);
    }
    
    public static String[] splitByWholeSeparator(final String s, final String s2) {
        return splitByWholeSeparatorWorker(s, s2, -1, false);
    }
    
    public static String[] splitByWholeSeparator(final String s, final String s2, final int n) {
        return splitByWholeSeparatorWorker(s, s2, n, false);
    }
    
    public static String[] splitByWholeSeparatorPreserveAllTokens(final String s, final String s2) {
        return splitByWholeSeparatorWorker(s, s2, -1, true);
    }
    
    public static String[] splitByWholeSeparatorPreserveAllTokens(final String s, final String s2, final int n) {
        return splitByWholeSeparatorWorker(s, s2, n, true);
    }
    
    private static String[] splitByWholeSeparatorWorker(final String s, final String s2, final int n, final boolean b) {
        if (s == null) {
            return null;
        }
        final int length = s.length();
        if (length == 0) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        if (s2 == null || "".equals(s2)) {
            return splitWorker(s, null, n, b);
        }
        final int length2 = s2.length();
        final ArrayList<String> list = new ArrayList<String>();
        int n2 = 0;
        int beginIndex = 0;
        int i = 0;
        while (i < length) {
            i = s.indexOf(s2, beginIndex);
            if (i > -1) {
                if (i > beginIndex) {
                    if (++n2 == n) {
                        i = length;
                        list.add(s.substring(beginIndex));
                    }
                    else {
                        list.add(s.substring(beginIndex, i));
                        beginIndex = i + length2;
                    }
                }
                else {
                    if (b) {
                        if (++n2 == n) {
                            i = length;
                            list.add(s.substring(beginIndex));
                        }
                        else {
                            list.add("");
                        }
                    }
                    beginIndex = i + length2;
                }
            }
            else {
                list.add(s.substring(beginIndex));
                i = length;
            }
        }
        return list.toArray(new String[list.size()]);
    }
    
    public static String[] splitPreserveAllTokens(final String s) {
        return splitWorker(s, null, -1, true);
    }
    
    public static String[] splitPreserveAllTokens(final String s, final char c) {
        return splitWorker(s, c, true);
    }
    
    private static String[] splitWorker(final String s, final char c, final boolean b) {
        if (s == null) {
            return null;
        }
        final int length = s.length();
        if (length == 0) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        final ArrayList<String> list = new ArrayList<String>();
        int i = 0;
        int n = 0;
        int n2 = 0;
        boolean b2 = false;
        while (i < length) {
            if (s.charAt(i) == c) {
                if (n2 != 0 || b) {
                    list.add(s.substring(n, i));
                    n2 = 0;
                    b2 = true;
                }
                n = ++i;
            }
            else {
                b2 = false;
                n2 = 1;
                ++i;
            }
        }
        if (n2 != 0 || (b && b2)) {
            list.add(s.substring(n, i));
        }
        return list.toArray(new String[list.size()]);
    }
    
    public static String[] splitPreserveAllTokens(final String s, final String s2) {
        return splitWorker(s, s2, -1, true);
    }
    
    public static String[] splitPreserveAllTokens(final String s, final String s2, final int n) {
        return splitWorker(s, s2, n, true);
    }
    
    private static String[] splitWorker(final String s, final String s2, final int n, final boolean b) {
        if (s == null) {
            return null;
        }
        final int length = s.length();
        if (length == 0) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        final ArrayList<String> list = new ArrayList<String>();
        int n2 = 1;
        int i = 0;
        int n3 = 0;
        int n4 = 0;
        boolean b2 = false;
        if (s2 == null) {
            while (i < length) {
                if (Character.isWhitespace(s.charAt(i))) {
                    if (n4 != 0 || b) {
                        b2 = true;
                        if (n2++ == n) {
                            i = length;
                            b2 = false;
                        }
                        list.add(s.substring(n3, i));
                        n4 = 0;
                    }
                    n3 = ++i;
                }
                else {
                    b2 = false;
                    n4 = 1;
                    ++i;
                }
            }
        }
        else if (s2.length() == 1) {
            final char char1 = s2.charAt(0);
            while (i < length) {
                if (s.charAt(i) == char1) {
                    if (n4 != 0 || b) {
                        b2 = true;
                        if (n2++ == n) {
                            i = length;
                            b2 = false;
                        }
                        list.add(s.substring(n3, i));
                        n4 = 0;
                    }
                    n3 = ++i;
                }
                else {
                    b2 = false;
                    n4 = 1;
                    ++i;
                }
            }
        }
        else {
            while (i < length) {
                if (s2.indexOf(s.charAt(i)) >= 0) {
                    if (n4 != 0 || b) {
                        b2 = true;
                        if (n2++ == n) {
                            i = length;
                            b2 = false;
                        }
                        list.add(s.substring(n3, i));
                        n4 = 0;
                    }
                    n3 = ++i;
                }
                else {
                    b2 = false;
                    n4 = 1;
                    ++i;
                }
            }
        }
        if (n4 != 0 || (b && b2)) {
            list.add(s.substring(n3, i));
        }
        return list.toArray(new String[list.size()]);
    }
    
    public static String[] splitByCharacterType(final String s) {
        return splitByCharacterType(s, false);
    }
    
    public static String[] splitByCharacterTypeCamelCase(final String s) {
        return splitByCharacterType(s, true);
    }
    
    private static String[] splitByCharacterType(final String s, final boolean b) {
        if (s == null) {
            return null;
        }
        if (s.isEmpty()) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        final char[] charArray = s.toCharArray();
        final ArrayList<String> list = new ArrayList<String>();
        int offset = 0;
        int type = Character.getType(charArray[offset]);
        for (int i = offset + 1; i < charArray.length; ++i) {
            final int type2 = Character.getType(charArray[i]);
            if (type2 != type) {
                if (b && type2 == 2 && type == 1) {
                    final int n = i - 1;
                    if (n != offset) {
                        list.add(new String(charArray, offset, n - offset));
                        offset = n;
                    }
                }
                else {
                    list.add(new String(charArray, offset, i - offset));
                    offset = i;
                }
                type = type2;
            }
        }
        list.add(new String(charArray, offset, charArray.length - offset));
        return list.toArray(new String[list.size()]);
    }
    
    @SafeVarargs
    public static <T> String join(final T... array) {
        return join((Object[])array, null);
    }
    
    public static String join(final Object[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final long[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final int[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final short[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final byte[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final char[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final float[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final double[] array, final char c) {
        if (array == null) {
            return null;
        }
        return join(array, c, 0, array.length);
    }
    
    public static String join(final Object[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            if (array[i] != null) {
                stringBuilder.append(array[i]);
            }
        }
        return stringBuilder.toString();
    }
    
    public static String join(final long[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            stringBuilder.append(array[i]);
        }
        return stringBuilder.toString();
    }
    
    public static String join(final int[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            stringBuilder.append(array[i]);
        }
        return stringBuilder.toString();
    }
    
    public static String join(final byte[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            stringBuilder.append(array[i]);
        }
        return stringBuilder.toString();
    }
    
    public static String join(final short[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            stringBuilder.append(array[i]);
        }
        return stringBuilder.toString();
    }
    
    public static String join(final char[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            stringBuilder.append(array[i]);
        }
        return stringBuilder.toString();
    }
    
    public static String join(final double[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            stringBuilder.append(array[i]);
        }
        return stringBuilder.toString();
    }
    
    public static String join(final float[] array, final char c, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(c);
            }
            stringBuilder.append(array[i]);
        }
        return stringBuilder.toString();
    }
    
    public static String join(final Object[] array, final String s) {
        if (array == null) {
            return null;
        }
        return join(array, s, 0, array.length);
    }
    
    public static String join(final Object[] array, String str, final int n, final int n2) {
        if (array == null) {
            return null;
        }
        if (str == null) {
            str = "";
        }
        final int n3 = n2 - n;
        if (n3 <= 0) {
            return "";
        }
        final StringBuilder stringBuilder = newStringBuilder(n3);
        for (int i = n; i < n2; ++i) {
            if (i > n) {
                stringBuilder.append(str);
            }
            if (array[i] != null) {
                stringBuilder.append(array[i]);
            }
        }
        return stringBuilder.toString();
    }
    
    public static String join(final Iterator<?> iterator, final char c) {
        if (iterator == null) {
            return null;
        }
        if (!iterator.hasNext()) {
            return "";
        }
        final Object next = iterator.next();
        if (!iterator.hasNext()) {
            return Objects.toString(next, "");
        }
        final StringBuilder sb = new StringBuilder(256);
        if (next != null) {
            sb.append(next);
        }
        while (iterator.hasNext()) {
            sb.append(c);
            final Object next2 = iterator.next();
            if (next2 != null) {
                sb.append(next2);
            }
        }
        return sb.toString();
    }
    
    public static String join(final Iterator<?> iterator, final String str) {
        if (iterator == null) {
            return null;
        }
        if (!iterator.hasNext()) {
            return "";
        }
        final Object next = iterator.next();
        if (!iterator.hasNext()) {
            return Objects.toString(next, "");
        }
        final StringBuilder sb = new StringBuilder(256);
        if (next != null) {
            sb.append(next);
        }
        while (iterator.hasNext()) {
            if (str != null) {
                sb.append(str);
            }
            final Object next2 = iterator.next();
            if (next2 != null) {
                sb.append(next2);
            }
        }
        return sb.toString();
    }
    
    public static String join(final Iterable<?> iterable, final char c) {
        if (iterable == null) {
            return null;
        }
        return join(iterable.iterator(), c);
    }
    
    public static String join(final Iterable<?> iterable, final String s) {
        if (iterable == null) {
            return null;
        }
        return join(iterable.iterator(), s);
    }
    
    public static String join(final List<?> list, final char c, final int n, final int n2) {
        if (list == null) {
            return null;
        }
        if (n2 - n <= 0) {
            return "";
        }
        return join(list.subList(n, n2).iterator(), c);
    }
    
    public static String join(final List<?> list, final String s, final int n, final int n2) {
        if (list == null) {
            return null;
        }
        if (n2 - n <= 0) {
            return "";
        }
        return join(list.subList(n, n2).iterator(), s);
    }
    
    public static String joinWith(final String s, final Object... a) {
        if (a == null) {
            throw new IllegalArgumentException("Object varargs must not be null");
        }
        final String defaultString = defaultString(s);
        final StringBuilder sb = new StringBuilder();
        final Iterator<Object> iterator = Arrays.asList(a).iterator();
        while (iterator.hasNext()) {
            sb.append(Objects.toString(iterator.next(), ""));
            if (iterator.hasNext()) {
                sb.append(defaultString);
            }
        }
        return sb.toString();
    }
    
    public static String deleteWhitespace(final String s) {
        if (isEmpty(s)) {
            return s;
        }
        final int length = s.length();
        final char[] value = new char[length];
        int count = 0;
        for (int i = 0; i < length; ++i) {
            if (!Character.isWhitespace(s.charAt(i))) {
                value[count++] = s.charAt(i);
            }
        }
        if (count == length) {
            return s;
        }
        return new String(value, 0, count);
    }
    
    public static String removeStart(final String s, final String prefix) {
        if (isEmpty(s) || isEmpty(prefix)) {
            return s;
        }
        if (s.startsWith(prefix)) {
            return s.substring(prefix.length());
        }
        return s;
    }
    
    public static String removeStartIgnoreCase(final String s, final String s2) {
        if (isEmpty(s) || isEmpty(s2)) {
            return s;
        }
        if (startsWithIgnoreCase(s, s2)) {
            return s.substring(s2.length());
        }
        return s;
    }
    
    public static String removeEnd(final String s, final String suffix) {
        if (isEmpty(s) || isEmpty(suffix)) {
            return s;
        }
        if (s.endsWith(suffix)) {
            return s.substring(0, s.length() - suffix.length());
        }
        return s;
    }
    
    public static String removeEndIgnoreCase(final String s, final String s2) {
        if (isEmpty(s) || isEmpty(s2)) {
            return s;
        }
        if (endsWithIgnoreCase(s, s2)) {
            return s.substring(0, s.length() - s2.length());
        }
        return s;
    }
    
    public static String remove(final String s, final String s2) {
        if (isEmpty(s) || isEmpty(s2)) {
            return s;
        }
        return replace(s, s2, "", -1);
    }
    
    public static String removeIgnoreCase(final String s, final String s2) {
        if (isEmpty(s) || isEmpty(s2)) {
            return s;
        }
        return replaceIgnoreCase(s, s2, "", -1);
    }
    
    public static String remove(final String s, final char ch) {
        if (isEmpty(s) || s.indexOf(ch) == -1) {
            return s;
        }
        final char[] charArray = s.toCharArray();
        int count = 0;
        for (int i = 0; i < charArray.length; ++i) {
            if (charArray[i] != ch) {
                charArray[count++] = charArray[i];
            }
        }
        return new String(charArray, 0, count);
    }
    
    @Deprecated
    public static String removeAll(final String s, final String s2) {
        return RegExUtils.removeAll(s, s2);
    }
    
    @Deprecated
    public static String removeFirst(final String s, final String s2) {
        return replaceFirst(s, s2, "");
    }
    
    public static String replaceOnce(final String s, final String s2, final String s3) {
        return replace(s, s2, s3, 1);
    }
    
    public static String replaceOnceIgnoreCase(final String s, final String s2, final String s3) {
        return replaceIgnoreCase(s, s2, s3, 1);
    }
    
    @Deprecated
    public static String replacePattern(final String s, final String s2, final String s3) {
        return RegExUtils.replacePattern(s, s2, s3);
    }
    
    @Deprecated
    public static String removePattern(final String s, final String s2) {
        return RegExUtils.removePattern(s, s2);
    }
    
    @Deprecated
    public static String replaceAll(final String s, final String s2, final String s3) {
        return RegExUtils.replaceAll(s, s2, s3);
    }
    
    @Deprecated
    public static String replaceFirst(final String s, final String s2, final String s3) {
        return RegExUtils.replaceFirst(s, s2, s3);
    }
    
    public static String replace(final String s, final String s2, final String s3) {
        return replace(s, s2, s3, -1);
    }
    
    public static String replaceIgnoreCase(final String s, final String s2, final String s3) {
        return replaceIgnoreCase(s, s2, s3, -1);
    }
    
    public static String replace(final String s, final String s2, final String s3, final int n) {
        return replace(s, s2, s3, n, false);
    }
    
    private static String replace(final String s, String lowerCase, final String str, int n, final boolean b) {
        if (isEmpty(s) || isEmpty(lowerCase) || str == null || n == 0) {
            return s;
        }
        String lowerCase2 = s;
        if (b) {
            lowerCase2 = s.toLowerCase();
            lowerCase = lowerCase.toLowerCase();
        }
        int n2 = 0;
        int i = lowerCase2.indexOf(lowerCase, n2);
        if (i == -1) {
            return s;
        }
        final int length = lowerCase.length();
        final int n3 = str.length() - length;
        final StringBuilder sb = new StringBuilder(s.length() + ((n3 < 0) ? 0 : n3) * ((n < 0) ? 16 : ((n > 64) ? 64 : n)));
        while (i != -1) {
            sb.append(s, n2, i).append(str);
            n2 = i + length;
            if (--n == 0) {
                break;
            }
            i = lowerCase2.indexOf(lowerCase, n2);
        }
        sb.append(s, n2, s.length());
        return sb.toString();
    }
    
    public static String replaceIgnoreCase(final String s, final String s2, final String s3, final int n) {
        return replace(s, s2, s3, n, true);
    }
    
    public static String replaceEach(final String s, final String[] array, final String[] array2) {
        return replaceEach(s, array, array2, false, 0);
    }
    
    public static String replaceEachRepeatedly(final String s, final String[] array, final String[] array2) {
        return replaceEach(s, array, array2, true, (array == null) ? 0 : array.length);
    }
    
    private static String replaceEach(final String s, final String[] array, final String[] array2, final boolean b, final int n) {
        if (s == null || s.isEmpty() || array == null || array.length == 0 || array2 == null || array2.length == 0) {
            return s;
        }
        if (n < 0) {
            throw new IllegalStateException("Aborting to protect against StackOverflowError - output of one loop is the input of another");
        }
        final int length = array.length;
        final int length2 = array2.length;
        if (length != length2) {
            throw new IllegalArgumentException("Search and Replace array lengths don't match: " + length + " vs " + length2);
        }
        final boolean[] array3 = new boolean[length];
        int i = -1;
        int n2 = -1;
        for (int j = 0; j < length; ++j) {
            if (!array3[j] && array[j] != null && !array[j].isEmpty()) {
                if (array2[j] != null) {
                    final int index = s.indexOf(array[j]);
                    if (index == -1) {
                        array3[j] = true;
                    }
                    else if (i == -1 || index < i) {
                        i = index;
                        n2 = j;
                    }
                }
            }
        }
        if (i == -1) {
            return s;
        }
        int fromIndex = 0;
        int a = 0;
        for (int k = 0; k < array.length; ++k) {
            if (array[k] != null) {
                if (array2[k] != null) {
                    final int n3 = array2[k].length() - array[k].length();
                    if (n3 > 0) {
                        a += 3 * n3;
                    }
                }
            }
        }
        final StringBuilder sb = new StringBuilder(s.length() + Math.min(a, s.length() / 5));
        while (i != -1) {
            for (int l = fromIndex; l < i; ++l) {
                sb.append(s.charAt(l));
            }
            sb.append(array2[n2]);
            fromIndex = i + array[n2].length();
            i = -1;
            n2 = -1;
            for (int n4 = 0; n4 < length; ++n4) {
                if (!array3[n4] && array[n4] != null && !array[n4].isEmpty()) {
                    if (array2[n4] != null) {
                        final int index2 = s.indexOf(array[n4], fromIndex);
                        if (index2 == -1) {
                            array3[n4] = true;
                        }
                        else if (i == -1 || index2 < i) {
                            i = index2;
                            n2 = n4;
                        }
                    }
                }
            }
        }
        for (int length3 = s.length(), index3 = fromIndex; index3 < length3; ++index3) {
            sb.append(s.charAt(index3));
        }
        final String string = sb.toString();
        if (!b) {
            return string;
        }
        return replaceEach(string, array, array2, b, n - 1);
    }
    
    public static String replaceChars(final String s, final char oldChar, final char newChar) {
        if (s == null) {
            return null;
        }
        return s.replace(oldChar, newChar);
    }
    
    public static String replaceChars(final String s, final String s2, String s3) {
        if (isEmpty(s) || isEmpty(s2)) {
            return s;
        }
        if (s3 == null) {
            s3 = "";
        }
        boolean b = false;
        final int length = s3.length();
        final int length2 = s.length();
        final StringBuilder sb = new StringBuilder(length2);
        for (int i = 0; i < length2; ++i) {
            final char char1 = s.charAt(i);
            final int index = s2.indexOf(char1);
            if (index >= 0) {
                b = true;
                if (index < length) {
                    sb.append(s3.charAt(index));
                }
            }
            else {
                sb.append(char1);
            }
        }
        if (b) {
            return sb.toString();
        }
        return s;
    }
    
    public static String overlay(final String s, String str, int endIndex, int beginIndex) {
        if (s == null) {
            return null;
        }
        if (str == null) {
            str = "";
        }
        final int length = s.length();
        if (endIndex < 0) {
            endIndex = 0;
        }
        if (endIndex > length) {
            endIndex = length;
        }
        if (beginIndex < 0) {
            beginIndex = 0;
        }
        if (beginIndex > length) {
            beginIndex = length;
        }
        if (endIndex > beginIndex) {
            final int n = endIndex;
            endIndex = beginIndex;
            beginIndex = n;
        }
        return s.substring(0, endIndex) + str + s.substring(beginIndex);
    }
    
    public static String chomp(final String s) {
        if (isEmpty(s)) {
            return s;
        }
        if (s.length() != 1) {
            int n = s.length() - 1;
            final char char1 = s.charAt(n);
            if (char1 == '\n') {
                if (s.charAt(n - 1) == '\r') {
                    --n;
                }
            }
            else if (char1 != '\r') {
                ++n;
            }
            return s.substring(0, n);
        }
        final char char2 = s.charAt(0);
        if (char2 == '\r' || char2 == '\n') {
            return "";
        }
        return s;
    }
    
    @Deprecated
    public static String chomp(final String s, final String s2) {
        return removeEnd(s, s2);
    }
    
    public static String chop(final String s) {
        if (s == null) {
            return null;
        }
        final int length = s.length();
        if (length < 2) {
            return "";
        }
        final int n = length - 1;
        final String substring = s.substring(0, n);
        if (s.charAt(n) == '\n' && substring.charAt(n - 1) == '\r') {
            return substring.substring(0, n - 1);
        }
        return substring;
    }
    
    public static String repeat(final String str, final int n) {
        if (str == null) {
            return null;
        }
        if (n <= 0) {
            return "";
        }
        final int length = str.length();
        if (n == 1 || length == 0) {
            return str;
        }
        if (length == 1 && n <= 8192) {
            return repeat(str.charAt(0), n);
        }
        final int capacity = length * n;
        switch (length) {
            case 1: {
                return repeat(str.charAt(0), n);
            }
            case 2: {
                final char char1 = str.charAt(0);
                final char char2 = str.charAt(1);
                final char[] value = new char[capacity];
                for (int i = n * 2 - 2; i >= 0; --i, --i) {
                    value[i] = char1;
                    value[i + 1] = char2;
                }
                return new String(value);
            }
            default: {
                final StringBuilder sb = new StringBuilder(capacity);
                for (int j = 0; j < n; ++j) {
                    sb.append(str);
                }
                return sb.toString();
            }
        }
    }
    
    public static String repeat(final String str, final String str2, final int n) {
        if (str == null || str2 == null) {
            return repeat(str, n);
        }
        return removeEnd(repeat(str + str2, n), str2);
    }
    
    public static String repeat(final char c, final int n) {
        if (n <= 0) {
            return "";
        }
        final char[] value = new char[n];
        for (int i = n - 1; i >= 0; --i) {
            value[i] = c;
        }
        return new String(value);
    }
    
    public static String rightPad(final String s, final int n) {
        return rightPad(s, n, ' ');
    }
    
    public static String rightPad(final String s, final int n, final char c) {
        if (s == null) {
            return null;
        }
        final int n2 = n - s.length();
        if (n2 <= 0) {
            return s;
        }
        if (n2 > 8192) {
            return rightPad(s, n, String.valueOf(c));
        }
        return s.concat(repeat(c, n2));
    }
    
    public static String rightPad(final String s, final int n, String str) {
        if (s == null) {
            return null;
        }
        if (isEmpty(str)) {
            str = " ";
        }
        final int length = str.length();
        final int endIndex = n - s.length();
        if (endIndex <= 0) {
            return s;
        }
        if (length == 1 && endIndex <= 8192) {
            return rightPad(s, n, str.charAt(0));
        }
        if (endIndex == length) {
            return s.concat(str);
        }
        if (endIndex < length) {
            return s.concat(str.substring(0, endIndex));
        }
        final char[] value = new char[endIndex];
        final char[] charArray = str.toCharArray();
        for (int i = 0; i < endIndex; ++i) {
            value[i] = charArray[i % length];
        }
        return s.concat(new String(value));
    }
    
    public static String leftPad(final String s, final int n) {
        return leftPad(s, n, ' ');
    }
    
    public static String leftPad(final String str, final int n, final char c) {
        if (str == null) {
            return null;
        }
        final int n2 = n - str.length();
        if (n2 <= 0) {
            return str;
        }
        if (n2 > 8192) {
            return leftPad(str, n, String.valueOf(c));
        }
        return repeat(c, n2).concat(str);
    }
    
    public static String leftPad(final String str, final int n, String s) {
        if (str == null) {
            return null;
        }
        if (isEmpty(s)) {
            s = " ";
        }
        final int length = s.length();
        final int endIndex = n - str.length();
        if (endIndex <= 0) {
            return str;
        }
        if (length == 1 && endIndex <= 8192) {
            return leftPad(str, n, s.charAt(0));
        }
        if (endIndex == length) {
            return s.concat(str);
        }
        if (endIndex < length) {
            return s.substring(0, endIndex).concat(str);
        }
        final char[] value = new char[endIndex];
        final char[] charArray = s.toCharArray();
        for (int i = 0; i < endIndex; ++i) {
            value[i] = charArray[i % length];
        }
        return new String(value).concat(str);
    }
    
    public static int length(final CharSequence charSequence) {
        return (charSequence == null) ? 0 : charSequence.length();
    }
    
    public static String center(final String s, final int n) {
        return center(s, n, ' ');
    }
    
    public static String center(String s, final int n, final char c) {
        if (s == null || n <= 0) {
            return s;
        }
        final int length = s.length();
        final int n2 = n - length;
        if (n2 <= 0) {
            return s;
        }
        s = leftPad(s, length + n2 / 2, c);
        s = rightPad(s, n, c);
        return s;
    }
    
    public static String center(String s, final int n, String s2) {
        if (s == null || n <= 0) {
            return s;
        }
        if (isEmpty(s2)) {
            s2 = " ";
        }
        final int length = s.length();
        final int n2 = n - length;
        if (n2 <= 0) {
            return s;
        }
        s = leftPad(s, length + n2 / 2, s2);
        s = rightPad(s, n, s2);
        return s;
    }
    
    public static String upperCase(final String s) {
        if (s == null) {
            return null;
        }
        return s.toUpperCase();
    }
    
    public static String upperCase(final String s, final Locale locale) {
        if (s == null) {
            return null;
        }
        return s.toUpperCase(locale);
    }
    
    public static String lowerCase(final String s) {
        if (s == null) {
            return null;
        }
        return s.toLowerCase();
    }
    
    public static String lowerCase(final String s, final Locale locale) {
        if (s == null) {
            return null;
        }
        return s.toLowerCase(locale);
    }
    
    public static String capitalize(final String s) {
        final int length;
        if (s == null || (length = s.length()) == 0) {
            return s;
        }
        final int codePoint = s.codePointAt(0);
        final int titleCase = Character.toTitleCase(codePoint);
        if (codePoint == titleCase) {
            return s;
        }
        final int[] codePoints = new int[length];
        int count = 0;
        codePoints[count++] = titleCase;
        int codePoint2;
        for (int i = Character.charCount(codePoint); i < length; i += Character.charCount(codePoint2)) {
            codePoint2 = s.codePointAt(i);
            codePoints[count++] = codePoint2;
        }
        return new String(codePoints, 0, count);
    }
    
    public static String uncapitalize(final String s) {
        final int length;
        if (s == null || (length = s.length()) == 0) {
            return s;
        }
        final int codePoint = s.codePointAt(0);
        final int lowerCase = Character.toLowerCase(codePoint);
        if (codePoint == lowerCase) {
            return s;
        }
        final int[] codePoints = new int[length];
        int count = 0;
        codePoints[count++] = lowerCase;
        int codePoint2;
        for (int i = Character.charCount(codePoint); i < length; i += Character.charCount(codePoint2)) {
            codePoint2 = s.codePointAt(i);
            codePoints[count++] = codePoint2;
        }
        return new String(codePoints, 0, count);
    }
    
    public static String swapCase(final String s) {
        if (isEmpty(s)) {
            return s;
        }
        final int length = s.length();
        final int[] codePoints = new int[length];
        int count = 0;
        int codePoint2;
        for (int i = 0; i < length; i += Character.charCount(codePoint2)) {
            final int codePoint = s.codePointAt(i);
            if (Character.isUpperCase(codePoint)) {
                codePoint2 = Character.toLowerCase(codePoint);
            }
            else if (Character.isTitleCase(codePoint)) {
                codePoint2 = Character.toLowerCase(codePoint);
            }
            else if (Character.isLowerCase(codePoint)) {
                codePoint2 = Character.toUpperCase(codePoint);
            }
            else {
                codePoint2 = codePoint;
            }
            codePoints[count++] = codePoint2;
        }
        return new String(codePoints, 0, count);
    }
    
    public static int countMatches(final CharSequence charSequence, final CharSequence charSequence2) {
        if (isEmpty(charSequence) || isEmpty(charSequence2)) {
            return 0;
        }
        int n = 0;
        int index;
        for (int n2 = 0; (index = CharSequenceUtils.indexOf(charSequence, charSequence2, n2)) != -1; n2 = index + charSequence2.length()) {
            ++n;
        }
        return n;
    }
    
    public static int countMatches(final CharSequence charSequence, final char c) {
        if (isEmpty(charSequence)) {
            return 0;
        }
        int n = 0;
        for (int i = 0; i < charSequence.length(); ++i) {
            if (c == charSequence.charAt(i)) {
                ++n;
            }
        }
        return n;
    }
    
    public static boolean isAlpha(final CharSequence charSequence) {
        if (isEmpty(charSequence)) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isLetter(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isAlphaSpace(final CharSequence charSequence) {
        if (charSequence == null) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isLetter(charSequence.charAt(i)) && charSequence.charAt(i) != ' ') {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isAlphanumeric(final CharSequence charSequence) {
        if (isEmpty(charSequence)) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isLetterOrDigit(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isAlphanumericSpace(final CharSequence charSequence) {
        if (charSequence == null) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isLetterOrDigit(charSequence.charAt(i)) && charSequence.charAt(i) != ' ') {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isAsciiPrintable(final CharSequence charSequence) {
        if (charSequence == null) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!CharUtils.isAsciiPrintable(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isNumeric(final CharSequence charSequence) {
        if (isEmpty(charSequence)) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isDigit(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isNumericSpace(final CharSequence charSequence) {
        if (charSequence == null) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isDigit(charSequence.charAt(i)) && charSequence.charAt(i) != ' ') {
                return false;
            }
        }
        return true;
    }
    
    public static String getDigits(final String s) {
        if (isEmpty(s)) {
            return s;
        }
        final int length = s.length();
        final StringBuilder sb = new StringBuilder(length);
        for (int i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (Character.isDigit(char1)) {
                sb.append(char1);
            }
        }
        return sb.toString();
    }
    
    public static boolean isWhitespace(final CharSequence charSequence) {
        if (charSequence == null) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isWhitespace(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isAllLowerCase(final CharSequence charSequence) {
        if (charSequence == null || isEmpty(charSequence)) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isLowerCase(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isAllUpperCase(final CharSequence charSequence) {
        if (charSequence == null || isEmpty(charSequence)) {
            return false;
        }
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (!Character.isUpperCase(charSequence.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean isMixedCase(final CharSequence charSequence) {
        if (isEmpty(charSequence) || charSequence.length() == 1) {
            return false;
        }
        int n = 0;
        int n2 = 0;
        for (int length = charSequence.length(), i = 0; i < length; ++i) {
            if (n != 0 && n2 != 0) {
                return true;
            }
            if (Character.isUpperCase(charSequence.charAt(i))) {
                n = 1;
            }
            else if (Character.isLowerCase(charSequence.charAt(i))) {
                n2 = 1;
            }
        }
        return n != 0 && n2 != 0;
    }
    
    public static String defaultString(final String s) {
        return defaultString(s, "");
    }
    
    public static String defaultString(final String s, final String s2) {
        return (s == null) ? s2 : s;
    }
    
    @SafeVarargs
    public static <T extends CharSequence> T firstNonBlank(final T... array) {
        if (array != null) {
            for (final CharSequence charSequence : array) {
                if (isNotBlank(charSequence)) {
                    return (T)charSequence;
                }
            }
        }
        return null;
    }
    
    @SafeVarargs
    public static <T extends CharSequence> T firstNonEmpty(final T... array) {
        if (array != null) {
            for (final CharSequence charSequence : array) {
                if (isNotEmpty(charSequence)) {
                    return (T)charSequence;
                }
            }
        }
        return null;
    }
    
    public static <T extends CharSequence> T defaultIfBlank(final T t, final T t2) {
        return isBlank(t) ? t2 : t;
    }
    
    public static <T extends CharSequence> T defaultIfEmpty(final T t, final T t2) {
        return isEmpty(t) ? t2 : t;
    }
    
    public static String rotate(final String s, final int n) {
        if (s == null) {
            return null;
        }
        final int length = s.length();
        if (n == 0 || length == 0 || n % length == 0) {
            return s;
        }
        final StringBuilder sb = new StringBuilder(length);
        final int n2 = -(n % length);
        sb.append(substring(s, n2));
        sb.append(substring(s, 0, n2));
        return sb.toString();
    }
    
    public static String reverse(final String str) {
        if (str == null) {
            return null;
        }
        return new StringBuilder(str).reverse().toString();
    }
    
    public static String reverseDelimited(final String s, final char c) {
        if (s == null) {
            return null;
        }
        final String[] split = split(s, c);
        ArrayUtils.reverse(split);
        return join((Object[])split, c);
    }
    
    public static String abbreviate(final String s, final int n) {
        return abbreviate(s, "...", 0, n);
    }
    
    public static String abbreviate(final String s, final int n, final int n2) {
        return abbreviate(s, "...", n, n2);
    }
    
    public static String abbreviate(final String s, final String s2, final int n) {
        return abbreviate(s, s2, 0, n);
    }
    
    public static String abbreviate(final String s, final String str, int length, final int n) {
        if (isEmpty(s) || isEmpty(str)) {
            return s;
        }
        final int length2 = str.length();
        final int i = length2 + 1;
        final int j = length2 + length2 + 1;
        if (n < i) {
            throw new IllegalArgumentException(String.format("Minimum abbreviation width is %d", i));
        }
        if (s.length() <= n) {
            return s;
        }
        if (length > s.length()) {
            length = s.length();
        }
        if (s.length() - length < n - length2) {
            length = s.length() - (n - length2);
        }
        if (length <= length2 + 1) {
            return s.substring(0, n - length2) + str;
        }
        if (n < j) {
            throw new IllegalArgumentException(String.format("Minimum abbreviation width with offset is %d", j));
        }
        if (length + n - length2 < s.length()) {
            return str + abbreviate(s.substring(length), str, n - length2);
        }
        return str + s.substring(s.length() - (n - length2));
    }
    
    public static String abbreviateMiddle(final String s, final String str, final int n) {
        if (isEmpty(s) || isEmpty(str)) {
            return s;
        }
        if (n >= s.length() || n < str.length() + 2) {
            return s;
        }
        final int n2 = n - str.length();
        return s.substring(0, n2 / 2 + n2 % 2) + str + s.substring(s.length() - n2 / 2);
    }
    
    public static String difference(final String s, final String s2) {
        if (s == null) {
            return s2;
        }
        if (s2 == null) {
            return s;
        }
        final int indexOfDifference = indexOfDifference(s, s2);
        if (indexOfDifference == -1) {
            return "";
        }
        return s2.substring(indexOfDifference);
    }
    
    public static int indexOfDifference(final CharSequence charSequence, final CharSequence charSequence2) {
        if (charSequence == charSequence2) {
            return -1;
        }
        if (charSequence == null || charSequence2 == null) {
            return 0;
        }
        int n;
        for (n = 0; n < charSequence.length() && n < charSequence2.length() && charSequence.charAt(n) == charSequence2.charAt(n); ++n) {}
        if (n < charSequence2.length() || n < charSequence.length()) {
            return n;
        }
        return -1;
    }
    
    public static int indexOfDifference(final CharSequence... array) {
        if (array == null || array.length <= 1) {
            return -1;
        }
        boolean b = false;
        boolean b2 = true;
        final int length = array.length;
        int min = Integer.MAX_VALUE;
        int max = 0;
        for (final CharSequence charSequence : array) {
            if (charSequence == null) {
                b = true;
                min = 0;
            }
            else {
                b2 = false;
                min = Math.min(charSequence.length(), min);
                max = Math.max(charSequence.length(), max);
            }
        }
        if (b2 || (max == 0 && !b)) {
            return -1;
        }
        if (min == 0) {
            return 0;
        }
        int n = -1;
        for (int j = 0; j < min; ++j) {
            final char char1 = array[0].charAt(j);
            for (int k = 1; k < length; ++k) {
                if (array[k].charAt(j) != char1) {
                    n = j;
                    break;
                }
            }
            if (n != -1) {
                break;
            }
        }
        if (n == -1 && min != max) {
            return min;
        }
        return n;
    }
    
    public static String getCommonPrefix(final String... array) {
        if (array == null || array.length == 0) {
            return "";
        }
        final int indexOfDifference = indexOfDifference((CharSequence[])array);
        if (indexOfDifference == -1) {
            if (array[0] == null) {
                return "";
            }
            return array[0];
        }
        else {
            if (indexOfDifference == 0) {
                return "";
            }
            return array[0].substring(0, indexOfDifference);
        }
    }
    
    @Deprecated
    public static int getLevenshteinDistance(CharSequence charSequence, CharSequence charSequence2) {
        if (charSequence == null || charSequence2 == null) {
            throw new IllegalArgumentException("Strings must not be null");
        }
        int length = charSequence.length();
        int n = charSequence2.length();
        if (length == 0) {
            return n;
        }
        if (n == 0) {
            return length;
        }
        if (length > n) {
            final CharSequence charSequence3 = charSequence;
            charSequence = charSequence2;
            charSequence2 = charSequence3;
            length = n;
            n = charSequence2.length();
        }
        final int[] array = new int[length + 1];
        for (int i = 0; i <= length; ++i) {
            array[i] = i;
        }
        for (int j = 1; j <= n; ++j) {
            int n2 = array[0];
            final char char1 = charSequence2.charAt(j - 1);
            array[0] = j;
            for (int k = 1; k <= length; ++k) {
                final int n3 = array[k];
                array[k] = Math.min(Math.min(array[k - 1] + 1, array[k] + 1), n2 + ((charSequence.charAt(k - 1) != char1) ? 1 : 0));
                n2 = n3;
            }
        }
        return array[length];
    }
    
    @Deprecated
    public static int getLevenshteinDistance(CharSequence charSequence, CharSequence charSequence2, final int b) {
        if (charSequence == null || charSequence2 == null) {
            throw new IllegalArgumentException("Strings must not be null");
        }
        if (b < 0) {
            throw new IllegalArgumentException("Threshold must not be negative");
        }
        int length = charSequence.length();
        int n = charSequence2.length();
        if (length == 0) {
            return (n <= b) ? n : -1;
        }
        if (n == 0) {
            return (length <= b) ? length : -1;
        }
        if (Math.abs(length - n) > b) {
            return -1;
        }
        if (length > n) {
            final CharSequence charSequence3 = charSequence;
            charSequence = charSequence2;
            charSequence2 = charSequence3;
            length = n;
            n = charSequence2.length();
        }
        int[] a = new int[length + 1];
        int[] a2 = new int[length + 1];
        final int fromIndex = Math.min(length, b) + 1;
        for (int i = 0; i < fromIndex; ++i) {
            a[i] = i;
        }
        Arrays.fill(a, fromIndex, a.length, Integer.MAX_VALUE);
        Arrays.fill(a2, Integer.MAX_VALUE);
        for (int j = 1; j <= n; ++j) {
            final char char1 = charSequence2.charAt(j - 1);
            a2[0] = j;
            final int max = Math.max(1, j - b);
            final int n2 = (j > Integer.MAX_VALUE - b) ? length : Math.min(length, j + b);
            if (max > n2) {
                return -1;
            }
            if (max > 1) {
                a2[max - 1] = Integer.MAX_VALUE;
            }
            for (int k = max; k <= n2; ++k) {
                if (charSequence.charAt(k - 1) == char1) {
                    a2[k] = a[k - 1];
                }
                else {
                    a2[k] = 1 + Math.min(Math.min(a2[k - 1], a[k]), a[k - 1]);
                }
            }
            final int[] array = a;
            a = a2;
            a2 = array;
        }
        if (a[length] <= b) {
            return a[length];
        }
        return -1;
    }
    
    @Deprecated
    public static double getJaroWinklerDistance(final CharSequence charSequence, final CharSequence charSequence2) {
        if (charSequence == null || charSequence2 == null) {
            throw new IllegalArgumentException("Strings must not be null");
        }
        final int[] matches = matches(charSequence, charSequence2);
        final double n = matches[0];
        if (n == 0.0) {
            return 0.0;
        }
        final double n2 = (n / charSequence.length() + n / charSequence2.length() + (n - matches[1]) / n) / 3.0;
        return Math.round(((n2 < 0.7) ? n2 : (n2 + Math.min(0.1, 1.0 / matches[3]) * matches[2] * (1.0 - n2))) * 100.0) / 100.0;
    }
    
    private static int[] matches(final CharSequence charSequence, final CharSequence charSequence2) {
        CharSequence charSequence3;
        CharSequence charSequence4;
        if (charSequence.length() > charSequence2.length()) {
            charSequence3 = charSequence;
            charSequence4 = charSequence2;
        }
        else {
            charSequence3 = charSequence2;
            charSequence4 = charSequence;
        }
        final int max = Math.max(charSequence3.length() / 2 - 1, 0);
        final int[] a = new int[charSequence4.length()];
        Arrays.fill(a, -1);
        final boolean[] array = new boolean[charSequence3.length()];
        int n = 0;
        for (int i = 0; i < charSequence4.length(); ++i) {
            final char char1 = charSequence4.charAt(i);
            for (int j = Math.max(i - max, 0); j < Math.min(i + max + 1, charSequence3.length()); ++j) {
                if (!array[j] && char1 == charSequence3.charAt(j)) {
                    array[a[i] = j] = true;
                    ++n;
                    break;
                }
            }
        }
        final char[] array2 = new char[n];
        final char[] array3 = new char[n];
        int k = 0;
        int n2 = 0;
        while (k < charSequence4.length()) {
            if (a[k] != -1) {
                array2[n2] = charSequence4.charAt(k);
                ++n2;
            }
            ++k;
        }
        int l = 0;
        int n3 = 0;
        while (l < charSequence3.length()) {
            if (array[l]) {
                array3[n3] = charSequence3.charAt(l);
                ++n3;
            }
            ++l;
        }
        int n4 = 0;
        for (int n5 = 0; n5 < array2.length; ++n5) {
            if (array2[n5] != array3[n5]) {
                ++n4;
            }
        }
        int n6 = 0;
        for (int n7 = 0; n7 < charSequence4.length() && charSequence.charAt(n7) == charSequence2.charAt(n7); ++n7) {
            ++n6;
        }
        return new int[] { n, n4 / 2, n6, charSequence3.length() };
    }
    
    @Deprecated
    public static int getFuzzyDistance(final CharSequence charSequence, final CharSequence charSequence2, final Locale locale) {
        if (charSequence == null || charSequence2 == null) {
            throw new IllegalArgumentException("Strings must not be null");
        }
        if (locale == null) {
            throw new IllegalArgumentException("Locale must not be null");
        }
        final String lowerCase = charSequence.toString().toLowerCase(locale);
        final String lowerCase2 = charSequence2.toString().toLowerCase(locale);
        int n = 0;
        int index = 0;
        int n2 = Integer.MIN_VALUE;
        for (int i = 0; i < lowerCase2.length(); ++i) {
            final char char1 = lowerCase2.charAt(i);
            for (int n3 = 0; index < lowerCase.length() && n3 == 0; ++index) {
                if (char1 == lowerCase.charAt(index)) {
                    ++n;
                    if (n2 + 1 == index) {
                        n += 2;
                    }
                    n2 = index;
                    n3 = 1;
                }
            }
        }
        return n;
    }
    
    public static boolean startsWith(final CharSequence charSequence, final CharSequence charSequence2) {
        return startsWith(charSequence, charSequence2, false);
    }
    
    public static boolean startsWithIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2) {
        return startsWith(charSequence, charSequence2, true);
    }
    
    private static boolean startsWith(final CharSequence charSequence, final CharSequence charSequence2, final boolean b) {
        if (charSequence == null || charSequence2 == null) {
            return charSequence == charSequence2;
        }
        return charSequence2.length() <= charSequence.length() && CharSequenceUtils.regionMatches(charSequence, b, 0, charSequence2, 0, charSequence2.length());
    }
    
    public static boolean startsWithAny(final CharSequence charSequence, final CharSequence... array) {
        if (isEmpty(charSequence) || ArrayUtils.isEmpty(array)) {
            return false;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (startsWith(charSequence, array[i])) {
                return true;
            }
        }
        return false;
    }
    
    public static boolean endsWith(final CharSequence charSequence, final CharSequence charSequence2) {
        return endsWith(charSequence, charSequence2, false);
    }
    
    public static boolean endsWithIgnoreCase(final CharSequence charSequence, final CharSequence charSequence2) {
        return endsWith(charSequence, charSequence2, true);
    }
    
    private static boolean endsWith(final CharSequence charSequence, final CharSequence charSequence2, final boolean b) {
        if (charSequence == null || charSequence2 == null) {
            return charSequence == charSequence2;
        }
        return charSequence2.length() <= charSequence.length() && CharSequenceUtils.regionMatches(charSequence, b, charSequence.length() - charSequence2.length(), charSequence2, 0, charSequence2.length());
    }
    
    public static String normalizeSpace(final String s) {
        if (isEmpty(s)) {
            return s;
        }
        final int length = s.length();
        final char[] value = new char[length];
        int n = 0;
        int n2 = 0;
        int n3 = 1;
        for (int i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (Character.isWhitespace(char1)) {
                if (n2 == 0 && n3 == 0) {
                    value[n++] = " ".charAt(0);
                }
                ++n2;
            }
            else {
                n3 = 0;
                value[n++] = ((char1 == ' ') ? ' ' : char1);
                n2 = 0;
            }
        }
        if (n3 != 0) {
            return "";
        }
        return new String(value, 0, n - ((n2 > 0) ? 1 : 0)).trim();
    }
    
    public static boolean endsWithAny(final CharSequence charSequence, final CharSequence... array) {
        if (isEmpty(charSequence) || ArrayUtils.isEmpty(array)) {
            return false;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (endsWith(charSequence, array[i])) {
                return true;
            }
        }
        return false;
    }
    
    private static String appendIfMissing(final String str, final CharSequence charSequence, final boolean b, final CharSequence... array) {
        if (str == null || isEmpty(charSequence) || endsWith(str, charSequence, b)) {
            return str;
        }
        if (array != null && array.length > 0) {
            for (int length = array.length, i = 0; i < length; ++i) {
                if (endsWith(str, array[i], b)) {
                    return str;
                }
            }
        }
        return str + charSequence.toString();
    }
    
    public static String appendIfMissing(final String s, final CharSequence charSequence, final CharSequence... array) {
        return appendIfMissing(s, charSequence, false, array);
    }
    
    public static String appendIfMissingIgnoreCase(final String s, final CharSequence charSequence, final CharSequence... array) {
        return appendIfMissing(s, charSequence, true, array);
    }
    
    private static String prependIfMissing(final String str, final CharSequence charSequence, final boolean b, final CharSequence... array) {
        if (str == null || isEmpty(charSequence) || startsWith(str, charSequence, b)) {
            return str;
        }
        if (array != null && array.length > 0) {
            for (int length = array.length, i = 0; i < length; ++i) {
                if (startsWith(str, array[i], b)) {
                    return str;
                }
            }
        }
        return charSequence.toString() + str;
    }
    
    public static String prependIfMissing(final String s, final CharSequence charSequence, final CharSequence... array) {
        return prependIfMissing(s, charSequence, false, array);
    }
    
    public static String prependIfMissingIgnoreCase(final String s, final CharSequence charSequence, final CharSequence... array) {
        return prependIfMissing(s, charSequence, true, array);
    }
    
    @Deprecated
    public static String toString(final byte[] array, final String charsetName) {
        return (charsetName != null) ? new String(array, charsetName) : new String(array, Charset.defaultCharset());
    }
    
    public static String toEncodedString(final byte[] bytes, final Charset charset) {
        return new String(bytes, (charset != null) ? charset : Charset.defaultCharset());
    }
    
    public static String wrap(final String str, final char c) {
        if (isEmpty(str) || c == '\0') {
            return str;
        }
        return c + str + c;
    }
    
    public static String wrap(final String str, final String str2) {
        if (isEmpty(str) || isEmpty(str2)) {
            return str;
        }
        return str2.concat(str).concat(str2);
    }
    
    public static String wrapIfMissing(final String str, final char c) {
        if (isEmpty(str) || c == '\0') {
            return str;
        }
        final StringBuilder sb = new StringBuilder(str.length() + 2);
        if (str.charAt(0) != c) {
            sb.append(c);
        }
        sb.append(str);
        if (str.charAt(str.length() - 1) != c) {
            sb.append(c);
        }
        return sb.toString();
    }
    
    public static String wrapIfMissing(final String str, final String s) {
        if (isEmpty(str) || isEmpty(s)) {
            return str;
        }
        final StringBuilder sb = new StringBuilder(str.length() + s.length() + s.length());
        if (!str.startsWith(s)) {
            sb.append(s);
        }
        sb.append(str);
        if (!str.endsWith(s)) {
            sb.append(s);
        }
        return sb.toString();
    }
    
    public static String unwrap(final String s, final String s2) {
        if (isEmpty(s) || isEmpty(s2)) {
            return s;
        }
        if (startsWith(s, s2) && endsWith(s, s2)) {
            final int index = s.indexOf(s2);
            final int lastIndex = s.lastIndexOf(s2);
            final int length = s2.length();
            if (index != -1 && lastIndex != -1) {
                return s.substring(index + length, lastIndex);
            }
        }
        return s;
    }
    
    public static String unwrap(final String s, final char c) {
        if (isEmpty(s) || c == '\0') {
            return s;
        }
        if (s.charAt(0) == c && s.charAt(s.length() - 1) == c) {
            final int endIndex = s.length() - 1;
            if (endIndex != -1) {
                return s.substring(1, endIndex);
            }
        }
        return s;
    }
    
    public static int[] toCodePoints(final CharSequence charSequence) {
        if (charSequence == null) {
            return null;
        }
        if (charSequence.length() == 0) {
            return ArrayUtils.EMPTY_INT_ARRAY;
        }
        final String string = charSequence.toString();
        final int[] array = new int[string.codePointCount(0, string.length())];
        int index = 0;
        for (int i = 0; i < array.length; ++i) {
            array[i] = string.codePointAt(index);
            index += Character.charCount(array[i]);
        }
        return array;
    }
    
    public static String valueOf(final char[] data) {
        return (data == null) ? null : String.valueOf(data);
    }
}

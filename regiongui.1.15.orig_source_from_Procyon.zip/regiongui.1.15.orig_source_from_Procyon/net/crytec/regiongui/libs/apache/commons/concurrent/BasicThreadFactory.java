// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import net.crytec.regiongui.libs.apache.commons.Validate;
import net.crytec.regiongui.libs.apache.commons.builder.Builder;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.ThreadFactory;

public class BasicThreadFactory implements ThreadFactory
{
    private final AtomicLong threadCounter;
    private final ThreadFactory wrappedFactory;
    private final Thread.UncaughtExceptionHandler uncaughtExceptionHandler;
    private final String namingPattern;
    private final Integer priority;
    private final Boolean daemon;
    
    private BasicThreadFactory(final Builder builder) {
        if (builder.wrappedFactory == null) {
            this.wrappedFactory = Executors.defaultThreadFactory();
        }
        else {
            this.wrappedFactory = builder.wrappedFactory;
        }
        this.namingPattern = builder.namingPattern;
        this.priority = builder.priority;
        this.daemon = builder.daemon;
        this.uncaughtExceptionHandler = builder.exceptionHandler;
        this.threadCounter = new AtomicLong();
    }
    
    public final ThreadFactory getWrappedFactory() {
        return this.wrappedFactory;
    }
    
    public final String getNamingPattern() {
        return this.namingPattern;
    }
    
    public final Boolean getDaemonFlag() {
        return this.daemon;
    }
    
    public final Integer getPriority() {
        return this.priority;
    }
    
    public final Thread.UncaughtExceptionHandler getUncaughtExceptionHandler() {
        return this.uncaughtExceptionHandler;
    }
    
    public long getThreadCount() {
        return this.threadCounter.get();
    }
    
    @Override
    public Thread newThread(final Runnable runnable) {
        final Thread thread = this.getWrappedFactory().newThread(runnable);
        this.initializeThread(thread);
        return thread;
    }
    
    private void initializeThread(final Thread thread) {
        if (this.getNamingPattern() != null) {
            thread.setName(String.format(this.getNamingPattern(), this.threadCounter.incrementAndGet()));
        }
        if (this.getUncaughtExceptionHandler() != null) {
            thread.setUncaughtExceptionHandler(this.getUncaughtExceptionHandler());
        }
        if (this.getPriority() != null) {
            thread.setPriority(this.getPriority());
        }
        if (this.getDaemonFlag() != null) {
            thread.setDaemon(this.getDaemonFlag());
        }
    }
    
    public static class Builder implements net.crytec.regiongui.libs.apache.commons.builder.Builder<BasicThreadFactory>
    {
        private ThreadFactory wrappedFactory;
        private Thread.UncaughtExceptionHandler exceptionHandler;
        private String namingPattern;
        private Integer priority;
        private Boolean daemon;
        
        public Builder wrappedFactory(final ThreadFactory wrappedFactory) {
            Validate.notNull(wrappedFactory, "Wrapped ThreadFactory must not be null!", new Object[0]);
            this.wrappedFactory = wrappedFactory;
            return this;
        }
        
        public Builder namingPattern(final String namingPattern) {
            Validate.notNull(namingPattern, "Naming pattern must not be null!", new Object[0]);
            this.namingPattern = namingPattern;
            return this;
        }
        
        public Builder daemon(final boolean b) {
            this.daemon = b;
            return this;
        }
        
        public Builder priority(final int i) {
            this.priority = i;
            return this;
        }
        
        public Builder uncaughtExceptionHandler(final Thread.UncaughtExceptionHandler exceptionHandler) {
            Validate.notNull(exceptionHandler, "Uncaught exception handler must not be null!", new Object[0]);
            this.exceptionHandler = exceptionHandler;
            return this;
        }
        
        public void reset() {
            this.wrappedFactory = null;
            this.exceptionHandler = null;
            this.namingPattern = null;
            this.priority = null;
            this.daemon = null;
        }
        
        @Override
        public BasicThreadFactory build() {
            final BasicThreadFactory basicThreadFactory = new BasicThreadFactory(this, null);
            this.reset();
            return basicThreadFactory;
        }
    }
}

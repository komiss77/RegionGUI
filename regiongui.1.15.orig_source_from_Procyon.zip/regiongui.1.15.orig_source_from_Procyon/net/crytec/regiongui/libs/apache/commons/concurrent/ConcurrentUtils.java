// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import java.util.concurrent.TimeUnit;
import java.util.concurrent.Future;
import java.util.concurrent.ConcurrentMap;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.concurrent.ExecutionException;

public class ConcurrentUtils
{
    private ConcurrentUtils() {
    }
    
    public static ConcurrentException extractCause(final ExecutionException ex) {
        if (ex == null || ex.getCause() == null) {
            return null;
        }
        throwCause(ex);
        return new ConcurrentException(ex.getMessage(), ex.getCause());
    }
    
    public static ConcurrentRuntimeException extractCauseUnchecked(final ExecutionException ex) {
        if (ex == null || ex.getCause() == null) {
            return null;
        }
        throwCause(ex);
        return new ConcurrentRuntimeException(ex.getMessage(), ex.getCause());
    }
    
    public static void handleCause(final ExecutionException ex) {
        final ConcurrentException cause = extractCause(ex);
        if (cause != null) {
            throw cause;
        }
    }
    
    public static void handleCauseUnchecked(final ExecutionException ex) {
        final ConcurrentRuntimeException causeUnchecked = extractCauseUnchecked(ex);
        if (causeUnchecked != null) {
            throw causeUnchecked;
        }
    }
    
    static Throwable checkedException(final Throwable obj) {
        Validate.isTrue(obj != null && !(obj instanceof RuntimeException) && !(obj instanceof Error), "Not a checked exception: " + obj, new Object[0]);
        return obj;
    }
    
    private static void throwCause(final ExecutionException ex) {
        if (ex.getCause() instanceof RuntimeException) {
            throw (RuntimeException)ex.getCause();
        }
        if (ex.getCause() instanceof Error) {
            throw (Error)ex.getCause();
        }
    }
    
    public static <T> T initialize(final ConcurrentInitializer<T> concurrentInitializer) {
        return (concurrentInitializer != null) ? concurrentInitializer.get() : null;
    }
    
    public static <T> T initializeUnchecked(final ConcurrentInitializer<T> concurrentInitializer) {
        try {
            return (T)initialize((ConcurrentInitializer<Object>)concurrentInitializer);
        }
        catch (ConcurrentException ex) {
            throw new ConcurrentRuntimeException(ex.getCause());
        }
    }
    
    public static <K, V> V putIfAbsent(final ConcurrentMap<K, V> concurrentMap, final K k, final V v) {
        if (concurrentMap == null) {
            return null;
        }
        final V putIfAbsent = concurrentMap.putIfAbsent(k, v);
        return (putIfAbsent != null) ? putIfAbsent : v;
    }
    
    public static <K, V> V createIfAbsent(final ConcurrentMap<K, V> concurrentMap, final K k, final ConcurrentInitializer<V> concurrentInitializer) {
        if (concurrentMap == null || concurrentInitializer == null) {
            return null;
        }
        final V value = concurrentMap.get(k);
        if (value == null) {
            return putIfAbsent(concurrentMap, k, concurrentInitializer.get());
        }
        return value;
    }
    
    public static <K, V> V createIfAbsentUnchecked(final ConcurrentMap<K, V> concurrentMap, final K k, final ConcurrentInitializer<V> concurrentInitializer) {
        try {
            return (V)createIfAbsent((ConcurrentMap<Object, Object>)concurrentMap, k, (ConcurrentInitializer<Object>)concurrentInitializer);
        }
        catch (ConcurrentException ex) {
            throw new ConcurrentRuntimeException(ex.getCause());
        }
    }
    
    public static <T> Future<T> constantFuture(final T t) {
        return new ConstantFuture<T>(t);
    }
    
    static final class ConstantFuture<T> implements Future<T>
    {
        private final T value;
        
        ConstantFuture(final T value) {
            this.value = value;
        }
        
        @Override
        public boolean isDone() {
            return true;
        }
        
        @Override
        public T get() {
            return this.value;
        }
        
        @Override
        public T get(final long n, final TimeUnit timeUnit) {
            return this.value;
        }
        
        @Override
        public boolean isCancelled() {
            return false;
        }
        
        @Override
        public boolean cancel(final boolean b) {
            return false;
        }
    }
}

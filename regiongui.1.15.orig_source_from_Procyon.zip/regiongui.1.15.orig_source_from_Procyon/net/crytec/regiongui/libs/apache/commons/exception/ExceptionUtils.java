// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.exception;

import java.lang.reflect.UndeclaredThrowableException;
import net.crytec.regiongui.libs.apache.commons.StringUtils;
import net.crytec.regiongui.libs.apache.commons.ClassUtils;
import java.util.StringTokenizer;
import java.io.Writer;
import java.io.StringWriter;
import java.util.Collection;
import java.io.PrintWriter;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.io.PrintStream;
import java.util.ArrayList;
import java.lang.reflect.Method;
import java.lang.reflect.InvocationTargetException;
import java.util.List;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;

public class ExceptionUtils
{
    static final String WRAPPED_MARKER = " [wrapped] ";
    private static final String[] CAUSE_METHOD_NAMES;
    
    @Deprecated
    public static String[] getDefaultCauseMethodNames() {
        return ArrayUtils.clone(ExceptionUtils.CAUSE_METHOD_NAMES);
    }
    
    @Deprecated
    public static Throwable getCause(final Throwable t) {
        return getCause(t, null);
    }
    
    @Deprecated
    public static Throwable getCause(final Throwable t, String[] cause_METHOD_NAMES) {
        if (t == null) {
            return null;
        }
        if (cause_METHOD_NAMES == null) {
            final Throwable cause = t.getCause();
            if (cause != null) {
                return cause;
            }
            cause_METHOD_NAMES = ExceptionUtils.CAUSE_METHOD_NAMES;
        }
        for (final String s : cause_METHOD_NAMES) {
            if (s != null) {
                final Throwable causeUsingMethodName = getCauseUsingMethodName(t, s);
                if (causeUsingMethodName != null) {
                    return causeUsingMethodName;
                }
            }
        }
        return null;
    }
    
    public static Throwable getRootCause(final Throwable t) {
        final List<Throwable> throwableList = getThrowableList(t);
        return throwableList.isEmpty() ? null : throwableList.get(throwableList.size() - 1);
    }
    
    private static Throwable getCauseUsingMethodName(final Throwable obj, final String name) {
        Method method = null;
        try {
            method = obj.getClass().getMethod(name, (Class<?>[])new Class[0]);
        }
        catch (NoSuchMethodException ex) {}
        catch (SecurityException ex2) {}
        if (method != null && Throwable.class.isAssignableFrom(method.getReturnType())) {
            try {
                return (Throwable)method.invoke(obj, new Object[0]);
            }
            catch (IllegalAccessException ex3) {}
            catch (IllegalArgumentException ex4) {}
            catch (InvocationTargetException ex5) {}
        }
        return null;
    }
    
    public static int getThrowableCount(final Throwable t) {
        return getThrowableList(t).size();
    }
    
    public static Throwable[] getThrowables(final Throwable t) {
        final List<Throwable> throwableList = getThrowableList(t);
        return throwableList.toArray(new Throwable[throwableList.size()]);
    }
    
    public static List<Throwable> getThrowableList(Throwable cause) {
        ArrayList<Throwable> list;
        for (list = new ArrayList<Throwable>(); cause != null && !list.contains(cause); cause = cause.getCause()) {
            list.add(cause);
        }
        return list;
    }
    
    public static int indexOfThrowable(final Throwable t, final Class<?> clazz) {
        return indexOf(t, clazz, 0, false);
    }
    
    public static int indexOfThrowable(final Throwable t, final Class<?> clazz, final int n) {
        return indexOf(t, clazz, n, false);
    }
    
    public static int indexOfType(final Throwable t, final Class<?> clazz) {
        return indexOf(t, clazz, 0, true);
    }
    
    public static int indexOfType(final Throwable t, final Class<?> clazz, final int n) {
        return indexOf(t, clazz, n, true);
    }
    
    private static int indexOf(final Throwable t, final Class<?> clazz, int n, final boolean b) {
        if (t == null || clazz == null) {
            return -1;
        }
        if (n < 0) {
            n = 0;
        }
        final Throwable[] throwables = getThrowables(t);
        if (n >= throwables.length) {
            return -1;
        }
        if (b) {
            for (int i = n; i < throwables.length; ++i) {
                if (clazz.isAssignableFrom(throwables[i].getClass())) {
                    return i;
                }
            }
        }
        else {
            for (int j = n; j < throwables.length; ++j) {
                if (clazz.equals(throwables[j].getClass())) {
                    return j;
                }
            }
        }
        return -1;
    }
    
    public static void printRootCauseStackTrace(final Throwable t) {
        printRootCauseStackTrace(t, System.err);
    }
    
    public static void printRootCauseStackTrace(final Throwable t, final PrintStream printStream) {
        if (t == null) {
            return;
        }
        Validate.isTrue(printStream != null, "The PrintStream must not be null", new Object[0]);
        final String[] rootCauseStackTrace = getRootCauseStackTrace(t);
        for (int length = rootCauseStackTrace.length, i = 0; i < length; ++i) {
            printStream.println(rootCauseStackTrace[i]);
        }
        printStream.flush();
    }
    
    public static void printRootCauseStackTrace(final Throwable t, final PrintWriter printWriter) {
        if (t == null) {
            return;
        }
        Validate.isTrue(printWriter != null, "The PrintWriter must not be null", new Object[0]);
        final String[] rootCauseStackTrace = getRootCauseStackTrace(t);
        for (int length = rootCauseStackTrace.length, i = 0; i < length; ++i) {
            printWriter.println(rootCauseStackTrace[i]);
        }
        printWriter.flush();
    }
    
    public static String[] getRootCauseStackTrace(final Throwable t) {
        if (t == null) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        final Throwable[] throwables = getThrowables(t);
        final int length = throwables.length;
        final ArrayList<String> list = new ArrayList<String>();
        List<String> list2 = getStackFrameList(throwables[length - 1]);
        int n = length;
        while (--n >= 0) {
            final List<String> list3 = list2;
            if (n != 0) {
                list2 = getStackFrameList(throwables[n - 1]);
                removeCommonFrames(list3, list2);
            }
            if (n == length - 1) {
                list.add(throwables[n].toString());
            }
            else {
                list.add(" [wrapped] " + throwables[n].toString());
            }
            list.addAll((Collection<?>)list3);
        }
        return list.toArray(new String[list.size()]);
    }
    
    public static void removeCommonFrames(final List<String> list, final List<String> list2) {
        if (list == null || list2 == null) {
            throw new IllegalArgumentException("The List must not be null");
        }
        for (int n = list.size() - 1, n2 = list2.size() - 1; n >= 0 && n2 >= 0; --n, --n2) {
            if (list.get(n).equals(list2.get(n2))) {
                list.remove(n);
            }
        }
    }
    
    public static String getStackTrace(final Throwable t) {
        final StringWriter out = new StringWriter();
        t.printStackTrace(new PrintWriter(out, true));
        return out.getBuffer().toString();
    }
    
    public static String[] getStackFrames(final Throwable t) {
        if (t == null) {
            return ArrayUtils.EMPTY_STRING_ARRAY;
        }
        return getStackFrames(getStackTrace(t));
    }
    
    static String[] getStackFrames(final String str) {
        final StringTokenizer stringTokenizer = new StringTokenizer(str, System.lineSeparator());
        final ArrayList<String> list = new ArrayList<String>();
        while (stringTokenizer.hasMoreTokens()) {
            list.add(stringTokenizer.nextToken());
        }
        return list.toArray(new String[list.size()]);
    }
    
    static List<String> getStackFrameList(final Throwable t) {
        final StringTokenizer stringTokenizer = new StringTokenizer(getStackTrace(t), System.lineSeparator());
        final ArrayList<String> list = new ArrayList<String>();
        boolean b = false;
        while (stringTokenizer.hasMoreTokens()) {
            final String nextToken = stringTokenizer.nextToken();
            final int index = nextToken.indexOf("at");
            if (index != -1 && nextToken.substring(0, index).trim().isEmpty()) {
                b = true;
                list.add(nextToken);
            }
            else {
                if (b) {
                    break;
                }
                continue;
            }
        }
        return list;
    }
    
    public static String getMessage(final Throwable t) {
        if (t == null) {
            return "";
        }
        return ClassUtils.getShortClassName(t, null) + ": " + StringUtils.defaultString(t.getMessage());
    }
    
    public static String getRootCauseMessage(final Throwable t) {
        final Throwable rootCause = getRootCause(t);
        return getMessage((rootCause == null) ? t : rootCause);
    }
    
    public static <R> R rethrow(final Throwable t) {
        return (R)typeErasure(t);
    }
    
    private static <R, T extends Throwable> R typeErasure(final Throwable t) throws T {
        throw t;
    }
    
    public static <R> R wrapAndThrow(final Throwable undeclaredThrowable) {
        if (undeclaredThrowable instanceof RuntimeException) {
            throw (RuntimeException)undeclaredThrowable;
        }
        if (undeclaredThrowable instanceof Error) {
            throw (Error)undeclaredThrowable;
        }
        throw new UndeclaredThrowableException(undeclaredThrowable);
    }
    
    public static boolean hasCause(Throwable cause, final Class<? extends Throwable> clazz) {
        if (cause instanceof UndeclaredThrowableException) {
            cause = cause.getCause();
        }
        return clazz.isInstance(cause);
    }
    
    static {
        CAUSE_METHOD_NAMES = new String[] { "getCause", "getNextException", "getTargetException", "getException", "getSourceException", "getRootCause", "getCausedByException", "getNested", "getLinkedException", "getNestedException", "getLinkedCause", "getThrowable" };
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.reflect;

import net.crytec.regiongui.libs.apache.commons.BooleanUtils;

public class InheritanceUtils
{
    public static int distance(final Class<?> clazz, final Class<?> obj) {
        if (clazz == null || obj == null) {
            return -1;
        }
        if (clazz.equals(obj)) {
            return 0;
        }
        final Class<?> superclass = clazz.getSuperclass();
        final int integer = BooleanUtils.toInteger(obj.equals(superclass));
        if (integer == 1) {
            return integer;
        }
        final int n = integer + distance(superclass, obj);
        return (n > 0) ? (n + 1) : -1;
    }
}

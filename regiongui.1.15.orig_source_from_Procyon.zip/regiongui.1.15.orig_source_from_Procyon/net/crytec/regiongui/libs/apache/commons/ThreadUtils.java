// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Collection;

public class ThreadUtils
{
    public static final AlwaysTruePredicate ALWAYS_TRUE_PREDICATE;
    
    public static Thread findThreadById(final long n, final ThreadGroup threadGroup) {
        Validate.isTrue(threadGroup != null, "The thread group must not be null", new Object[0]);
        final Thread threadById = findThreadById(n);
        if (threadById != null && threadGroup.equals(threadById.getThreadGroup())) {
            return threadById;
        }
        return null;
    }
    
    public static Thread findThreadById(final long n, final String anObject) {
        Validate.isTrue(anObject != null, "The thread group name must not be null", new Object[0]);
        final Thread threadById = findThreadById(n);
        if (threadById != null && threadById.getThreadGroup() != null && threadById.getThreadGroup().getName().equals(anObject)) {
            return threadById;
        }
        return null;
    }
    
    public static Collection<Thread> findThreadsByName(final String s, final ThreadGroup threadGroup) {
        return findThreads(threadGroup, false, new NamePredicate(s));
    }
    
    public static Collection<Thread> findThreadsByName(final String s, final String s2) {
        Validate.isTrue(s != null, "The thread name must not be null", new Object[0]);
        Validate.isTrue(s2 != null, "The thread group name must not be null", new Object[0]);
        final Collection<ThreadGroup> threadGroups = findThreadGroups(new NamePredicate(s2));
        if (threadGroups.isEmpty()) {
            return (Collection<Thread>)Collections.emptyList();
        }
        final ArrayList<Thread> c = new ArrayList<Thread>();
        final NamePredicate namePredicate = new NamePredicate(s);
        final Iterator<ThreadGroup> iterator = threadGroups.iterator();
        while (iterator.hasNext()) {
            c.addAll((Collection<?>)findThreads(iterator.next(), false, namePredicate));
        }
        return (Collection<Thread>)Collections.unmodifiableCollection((Collection<?>)c);
    }
    
    public static Collection<ThreadGroup> findThreadGroupsByName(final String s) {
        return findThreadGroups(new NamePredicate(s));
    }
    
    public static Collection<ThreadGroup> getAllThreadGroups() {
        return findThreadGroups(ThreadUtils.ALWAYS_TRUE_PREDICATE);
    }
    
    public static ThreadGroup getSystemThreadGroup() {
        ThreadGroup threadGroup;
        for (threadGroup = Thread.currentThread().getThreadGroup(); threadGroup.getParent() != null; threadGroup = threadGroup.getParent()) {}
        return threadGroup;
    }
    
    public static Collection<Thread> getAllThreads() {
        return findThreads(ThreadUtils.ALWAYS_TRUE_PREDICATE);
    }
    
    public static Collection<Thread> findThreadsByName(final String s) {
        return findThreads(new NamePredicate(s));
    }
    
    public static Thread findThreadById(final long n) {
        final Collection<Thread> threads = findThreads(new ThreadIdPredicate(n));
        return threads.isEmpty() ? null : threads.iterator().next();
    }
    
    public static Collection<Thread> findThreads(final ThreadPredicate threadPredicate) {
        return findThreads(getSystemThreadGroup(), true, threadPredicate);
    }
    
    public static Collection<ThreadGroup> findThreadGroups(final ThreadGroupPredicate threadGroupPredicate) {
        return findThreadGroups(getSystemThreadGroup(), true, threadGroupPredicate);
    }
    
    public static Collection<Thread> findThreads(final ThreadGroup threadGroup, final boolean recurse, final ThreadPredicate threadPredicate) {
        Validate.isTrue(threadGroup != null, "The group must not be null", new Object[0]);
        Validate.isTrue(threadPredicate != null, "The predicate must not be null", new Object[0]);
        int i = threadGroup.activeCount();
        Thread[] list;
        do {
            list = new Thread[i + i / 2 + 1];
            i = threadGroup.enumerate(list, recurse);
        } while (i >= list.length);
        final ArrayList<Thread> c = new ArrayList<Thread>(i);
        for (int j = 0; j < i; ++j) {
            if (threadPredicate.test(list[j])) {
                c.add(list[j]);
            }
        }
        return (Collection<Thread>)Collections.unmodifiableCollection((Collection<?>)c);
    }
    
    public static Collection<ThreadGroup> findThreadGroups(final ThreadGroup threadGroup, final boolean recurse, final ThreadGroupPredicate threadGroupPredicate) {
        Validate.isTrue(threadGroup != null, "The group must not be null", new Object[0]);
        Validate.isTrue(threadGroupPredicate != null, "The predicate must not be null", new Object[0]);
        int i = threadGroup.activeGroupCount();
        ThreadGroup[] list;
        do {
            list = new ThreadGroup[i + i / 2 + 1];
            i = threadGroup.enumerate(list, recurse);
        } while (i >= list.length);
        final ArrayList<ThreadGroup> c = new ArrayList<ThreadGroup>(i);
        for (int j = 0; j < i; ++j) {
            if (threadGroupPredicate.test(list[j])) {
                c.add(list[j]);
            }
        }
        return (Collection<ThreadGroup>)Collections.unmodifiableCollection((Collection<?>)c);
    }
    
    static {
        ALWAYS_TRUE_PREDICATE = new AlwaysTruePredicate();
    }
    
    private static final class AlwaysTruePredicate implements ThreadPredicate, ThreadGroupPredicate
    {
        @Override
        public boolean test(final ThreadGroup threadGroup) {
            return true;
        }
        
        @Override
        public boolean test(final Thread thread) {
            return true;
        }
    }
    
    public static class NamePredicate implements ThreadPredicate, ThreadGroupPredicate
    {
        private final String name;
        
        public NamePredicate(final String name) {
            Validate.isTrue(name != null, "The name must not be null", new Object[0]);
            this.name = name;
        }
        
        @Override
        public boolean test(final ThreadGroup threadGroup) {
            return threadGroup != null && threadGroup.getName().equals(this.name);
        }
        
        @Override
        public boolean test(final Thread thread) {
            return thread != null && thread.getName().equals(this.name);
        }
    }
    
    public static class ThreadIdPredicate implements ThreadPredicate
    {
        private final long threadId;
        
        public ThreadIdPredicate(final long threadId) {
            if (threadId <= 0L) {
                throw new IllegalArgumentException("The thread id must be greater than zero");
            }
            this.threadId = threadId;
        }
        
        @Override
        public boolean test(final Thread thread) {
            return thread != null && thread.getId() == this.threadId;
        }
    }
    
    @FunctionalInterface
    public interface ThreadGroupPredicate
    {
        boolean test(final ThreadGroup p0);
    }
    
    @FunctionalInterface
    public interface ThreadPredicate
    {
        boolean test(final Thread p0);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.time;

import java.util.regex.Matcher;
import java.util.TimeZone;
import java.util.regex.Pattern;

public class FastTimeZone
{
    private static final Pattern GMT_PATTERN;
    private static final TimeZone GREENWICH;
    
    public static TimeZone getGmtTimeZone() {
        return FastTimeZone.GREENWICH;
    }
    
    public static TimeZone getGmtTimeZone(final String input) {
        if ("Z".equals(input) || "UTC".equals(input)) {
            return FastTimeZone.GREENWICH;
        }
        final Matcher matcher = FastTimeZone.GMT_PATTERN.matcher(input);
        if (!matcher.matches()) {
            return null;
        }
        final int int1 = parseInt(matcher.group(2));
        final int int2 = parseInt(matcher.group(4));
        if (int1 == 0 && int2 == 0) {
            return FastTimeZone.GREENWICH;
        }
        return new GmtTimeZone(parseSign(matcher.group(1)), int1, int2);
    }
    
    public static TimeZone getTimeZone(final String id) {
        final TimeZone gmtTimeZone = getGmtTimeZone(id);
        if (gmtTimeZone != null) {
            return gmtTimeZone;
        }
        return TimeZone.getTimeZone(id);
    }
    
    private static int parseInt(final String s) {
        return (s != null) ? Integer.parseInt(s) : 0;
    }
    
    private static boolean parseSign(final String s) {
        return s != null && s.charAt(0) == '-';
    }
    
    private FastTimeZone() {
    }
    
    static {
        GMT_PATTERN = Pattern.compile("^(?:(?i)GMT)?([+-])?(\\d\\d?)?(:?(\\d\\d?))?$");
        GREENWICH = new GmtTimeZone(false, 0, 0);
    }
}

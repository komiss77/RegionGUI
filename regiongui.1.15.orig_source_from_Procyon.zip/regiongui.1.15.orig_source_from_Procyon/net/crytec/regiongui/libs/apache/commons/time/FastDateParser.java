// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.time;

import java.text.DateFormatSymbols;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.concurrent.ConcurrentHashMap;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.HashMap;
import java.util.Map;
import java.util.ListIterator;
import java.text.ParseException;
import java.text.ParsePosition;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ConcurrentMap;
import java.util.Comparator;
import java.util.List;
import java.util.TimeZone;
import java.util.Locale;
import java.io.Serializable;

public class FastDateParser implements DateParser, Serializable
{
    private static final long serialVersionUID = 3L;
    static final Locale JAPANESE_IMPERIAL;
    private final String pattern;
    private final TimeZone timeZone;
    private final Locale locale;
    private final int century;
    private final int startYear;
    private transient List<StrategyAndWidth> patterns;
    private static final Comparator<String> LONGER_FIRST_LOWERCASE;
    private static final ConcurrentMap<Locale, Strategy>[] caches;
    private static final Strategy ABBREVIATED_YEAR_STRATEGY;
    private static final Strategy NUMBER_MONTH_STRATEGY;
    private static final Strategy LITERAL_YEAR_STRATEGY;
    private static final Strategy WEEK_OF_YEAR_STRATEGY;
    private static final Strategy WEEK_OF_MONTH_STRATEGY;
    private static final Strategy DAY_OF_YEAR_STRATEGY;
    private static final Strategy DAY_OF_MONTH_STRATEGY;
    private static final Strategy DAY_OF_WEEK_STRATEGY;
    private static final Strategy DAY_OF_WEEK_IN_MONTH_STRATEGY;
    private static final Strategy HOUR_OF_DAY_STRATEGY;
    private static final Strategy HOUR24_OF_DAY_STRATEGY;
    private static final Strategy HOUR12_STRATEGY;
    private static final Strategy HOUR_STRATEGY;
    private static final Strategy MINUTE_STRATEGY;
    private static final Strategy SECOND_STRATEGY;
    private static final Strategy MILLISECOND_STRATEGY;
    
    protected FastDateParser(final String s, final TimeZone timeZone, final Locale locale) {
        this(s, timeZone, locale, null);
    }
    
    protected FastDateParser(final String pattern, final TimeZone timeZone, final Locale locale, final Date time) {
        this.pattern = pattern;
        this.timeZone = timeZone;
        this.locale = locale;
        final Calendar instance = Calendar.getInstance(timeZone, locale);
        int value;
        if (time != null) {
            instance.setTime(time);
            value = instance.get(1);
        }
        else if (locale.equals(FastDateParser.JAPANESE_IMPERIAL)) {
            value = 0;
        }
        else {
            instance.setTime(new Date());
            value = instance.get(1) - 80;
        }
        this.century = value / 100 * 100;
        this.startYear = value - this.century;
        this.init(instance);
    }
    
    private void init(final Calendar calendar) {
        this.patterns = new ArrayList<StrategyAndWidth>();
        final StrategyParser strategyParser = new StrategyParser(calendar);
        while (true) {
            final StrategyAndWidth nextStrategy = strategyParser.getNextStrategy();
            if (nextStrategy == null) {
                break;
            }
            this.patterns.add(nextStrategy);
        }
    }
    
    private static boolean isFormatLetter(final char c) {
        return (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z');
    }
    
    @Override
    public String getPattern() {
        return this.pattern;
    }
    
    @Override
    public TimeZone getTimeZone() {
        return this.timeZone;
    }
    
    @Override
    public Locale getLocale() {
        return this.locale;
    }
    
    @Override
    public boolean equals(final Object o) {
        if (!(o instanceof FastDateParser)) {
            return false;
        }
        final FastDateParser fastDateParser = (FastDateParser)o;
        return this.pattern.equals(fastDateParser.pattern) && this.timeZone.equals(fastDateParser.timeZone) && this.locale.equals(fastDateParser.locale);
    }
    
    @Override
    public int hashCode() {
        return this.pattern.hashCode() + 13 * (this.timeZone.hashCode() + 13 * this.locale.hashCode());
    }
    
    @Override
    public String toString() {
        return "FastDateParser[" + this.pattern + "," + this.locale + "," + this.timeZone.getID() + "]";
    }
    
    private void readObject(final ObjectInputStream objectInputStream) {
        objectInputStream.defaultReadObject();
        this.init(Calendar.getInstance(this.timeZone, this.locale));
    }
    
    @Override
    public Object parseObject(final String s) {
        return this.parse(s);
    }
    
    @Override
    public Date parse(final String s) {
        final ParsePosition parsePosition = new ParsePosition(0);
        final Date parse = this.parse(s, parsePosition);
        if (parse != null) {
            return parse;
        }
        if (this.locale.equals(FastDateParser.JAPANESE_IMPERIAL)) {
            throw new ParseException("(The " + this.locale + " locale does not support dates before 1868 AD)\nUnparseable date: \"" + s, parsePosition.getErrorIndex());
        }
        throw new ParseException("Unparseable date: " + s, parsePosition.getErrorIndex());
    }
    
    @Override
    public Object parseObject(final String s, final ParsePosition parsePosition) {
        return this.parse(s, parsePosition);
    }
    
    @Override
    public Date parse(final String s, final ParsePosition parsePosition) {
        final Calendar instance = Calendar.getInstance(this.timeZone, this.locale);
        instance.clear();
        return this.parse(s, parsePosition, instance) ? instance.getTime() : null;
    }
    
    @Override
    public boolean parse(final String s, final ParsePosition parsePosition, final Calendar calendar) {
        final ListIterator<StrategyAndWidth> listIterator = this.patterns.listIterator();
        while (listIterator.hasNext()) {
            final StrategyAndWidth strategyAndWidth = listIterator.next();
            if (!strategyAndWidth.strategy.parse(this, calendar, s, parsePosition, strategyAndWidth.getMaxWidth(listIterator))) {
                return false;
            }
        }
        return true;
    }
    
    private static StringBuilder simpleQuote(final StringBuilder sb, final String s) {
        for (int i = 0; i < s.length(); ++i) {
            final char char1 = s.charAt(i);
            switch (char1) {
                case 36:
                case 40:
                case 41:
                case 42:
                case 43:
                case 46:
                case 63:
                case 91:
                case 92:
                case 94:
                case 123:
                case 124: {
                    sb.append('\\');
                    break;
                }
            }
            sb.append(char1);
        }
        if (sb.charAt(sb.length() - 1) == '.') {
            sb.append('?');
        }
        return sb;
    }
    
    private static Map<String, Integer> appendDisplayNames(final Calendar calendar, final Locale locale, final int field, final StringBuilder sb) {
        final HashMap<String, Integer> hashMap = new HashMap<String, Integer>();
        final Map<String, Integer> displayNames = calendar.getDisplayNames(field, 0, locale);
        final TreeSet<String> set = new TreeSet<String>(FastDateParser.LONGER_FIRST_LOWERCASE);
        for (final Map.Entry<String, Integer> entry : displayNames.entrySet()) {
            final String lowerCase = entry.getKey().toLowerCase(locale);
            if (set.add(lowerCase)) {
                hashMap.put(lowerCase, entry.getValue());
            }
        }
        final Iterator<String> iterator2 = set.iterator();
        while (iterator2.hasNext()) {
            simpleQuote(sb, iterator2.next()).append('|');
        }
        return hashMap;
    }
    
    private int adjustYear(final int n) {
        final int n2 = this.century + n;
        return (n >= this.startYear) ? n2 : (n2 + 100);
    }
    
    private Strategy getStrategy(final char c, final int n, final Calendar calendar) {
        switch (c) {
            default: {
                throw new IllegalArgumentException("Format '" + c + "' not supported");
            }
            case 'D': {
                return FastDateParser.DAY_OF_YEAR_STRATEGY;
            }
            case 'E': {
                return this.getLocaleSpecificStrategy(7, calendar);
            }
            case 'F': {
                return FastDateParser.DAY_OF_WEEK_IN_MONTH_STRATEGY;
            }
            case 'G': {
                return this.getLocaleSpecificStrategy(0, calendar);
            }
            case 'H': {
                return FastDateParser.HOUR_OF_DAY_STRATEGY;
            }
            case 'K': {
                return FastDateParser.HOUR_STRATEGY;
            }
            case 'M': {
                return (n >= 3) ? this.getLocaleSpecificStrategy(2, calendar) : FastDateParser.NUMBER_MONTH_STRATEGY;
            }
            case 'S': {
                return FastDateParser.MILLISECOND_STRATEGY;
            }
            case 'W': {
                return FastDateParser.WEEK_OF_MONTH_STRATEGY;
            }
            case 'a': {
                return this.getLocaleSpecificStrategy(9, calendar);
            }
            case 'd': {
                return FastDateParser.DAY_OF_MONTH_STRATEGY;
            }
            case 'h': {
                return FastDateParser.HOUR12_STRATEGY;
            }
            case 'k': {
                return FastDateParser.HOUR24_OF_DAY_STRATEGY;
            }
            case 'm': {
                return FastDateParser.MINUTE_STRATEGY;
            }
            case 's': {
                return FastDateParser.SECOND_STRATEGY;
            }
            case 'u': {
                return FastDateParser.DAY_OF_WEEK_STRATEGY;
            }
            case 'w': {
                return FastDateParser.WEEK_OF_YEAR_STRATEGY;
            }
            case 'Y':
            case 'y': {
                return (n > 2) ? FastDateParser.LITERAL_YEAR_STRATEGY : FastDateParser.ABBREVIATED_YEAR_STRATEGY;
            }
            case 'X': {
                return ISO8601TimeZoneStrategy.getStrategy(n);
            }
            case 'Z': {
                if (n == 2) {
                    return ISO8601TimeZoneStrategy.ISO_8601_3_STRATEGY;
                }
                return this.getLocaleSpecificStrategy(15, calendar);
            }
            case 'z': {
                return this.getLocaleSpecificStrategy(15, calendar);
            }
        }
    }
    
    private static ConcurrentMap<Locale, Strategy> getCache(final int n) {
        synchronized (FastDateParser.caches) {
            if (FastDateParser.caches[n] == null) {
                FastDateParser.caches[n] = new ConcurrentHashMap<Locale, Strategy>(3);
            }
            return FastDateParser.caches[n];
        }
    }
    
    private Strategy getLocaleSpecificStrategy(final int n, final Calendar calendar) {
        final ConcurrentMap<Locale, Strategy> cache = getCache(n);
        Strategy strategy = cache.get(this.locale);
        if (strategy == null) {
            strategy = ((n == 15) ? new TimeZoneStrategy(this.locale) : new CaseInsensitiveTextStrategy(n, calendar, this.locale));
            final Strategy strategy2 = cache.putIfAbsent(this.locale, strategy);
            if (strategy2 != null) {
                return strategy2;
            }
        }
        return strategy;
    }
    
    static {
        JAPANESE_IMPERIAL = new Locale("ja", "JP", "JP");
        LONGER_FIRST_LOWERCASE = new Comparator<String>() {
            @Override
            public int compare(final String anotherString, final String s) {
                return s.compareTo(anotherString);
            }
        };
        caches = new ConcurrentMap[17];
        ABBREVIATED_YEAR_STRATEGY = new NumberStrategy() {
            @Override
            int modify(final FastDateParser fastDateParser, final int n) {
                return (n < 100) ? fastDateParser.adjustYear(n) : n;
            }
        };
        NUMBER_MONTH_STRATEGY = new NumberStrategy() {
            @Override
            int modify(final FastDateParser fastDateParser, final int n) {
                return n - 1;
            }
        };
        LITERAL_YEAR_STRATEGY = new NumberStrategy(1);
        WEEK_OF_YEAR_STRATEGY = new NumberStrategy(3);
        WEEK_OF_MONTH_STRATEGY = new NumberStrategy(4);
        DAY_OF_YEAR_STRATEGY = new NumberStrategy(6);
        DAY_OF_MONTH_STRATEGY = new NumberStrategy(5);
        DAY_OF_WEEK_STRATEGY = new NumberStrategy() {
            @Override
            int modify(final FastDateParser fastDateParser, final int n) {
                return (n == 7) ? 1 : (n + 1);
            }
        };
        DAY_OF_WEEK_IN_MONTH_STRATEGY = new NumberStrategy(8);
        HOUR_OF_DAY_STRATEGY = new NumberStrategy(11);
        HOUR24_OF_DAY_STRATEGY = new NumberStrategy() {
            @Override
            int modify(final FastDateParser fastDateParser, final int n) {
                return (n == 24) ? 0 : n;
            }
        };
        HOUR12_STRATEGY = new NumberStrategy() {
            @Override
            int modify(final FastDateParser fastDateParser, final int n) {
                return (n == 12) ? 0 : n;
            }
        };
        HOUR_STRATEGY = new NumberStrategy(10);
        MINUTE_STRATEGY = new NumberStrategy(12);
        SECOND_STRATEGY = new NumberStrategy(13);
        MILLISECOND_STRATEGY = new NumberStrategy(14);
    }
    
    private static class StrategyAndWidth
    {
        final Strategy strategy;
        final int width;
        
        StrategyAndWidth(final Strategy strategy, final int width) {
            this.strategy = strategy;
            this.width = width;
        }
        
        int getMaxWidth(final ListIterator<StrategyAndWidth> listIterator) {
            if (!this.strategy.isNumber() || !listIterator.hasNext()) {
                return 0;
            }
            final Strategy strategy = listIterator.next().strategy;
            listIterator.previous();
            return strategy.isNumber() ? this.width : 0;
        }
    }
    
    private class StrategyParser
    {
        private final Calendar definingCalendar;
        private int currentIdx;
        
        StrategyParser(final Calendar definingCalendar) {
            this.definingCalendar = definingCalendar;
        }
        
        StrategyAndWidth getNextStrategy() {
            if (this.currentIdx >= FastDateParser.this.pattern.length()) {
                return null;
            }
            final char char1 = FastDateParser.this.pattern.charAt(this.currentIdx);
            if (isFormatLetter(char1)) {
                return this.letterPattern(char1);
            }
            return this.literal();
        }
        
        private StrategyAndWidth letterPattern(final char c) {
            final int currentIdx = this.currentIdx;
            while (++this.currentIdx < FastDateParser.this.pattern.length() && FastDateParser.this.pattern.charAt(this.currentIdx) == c) {}
            final int n = this.currentIdx - currentIdx;
            return new StrategyAndWidth(FastDateParser.this.getStrategy(c, n, this.definingCalendar), n);
        }
        
        private StrategyAndWidth literal() {
            boolean b = false;
            final StringBuilder sb = new StringBuilder();
            while (this.currentIdx < FastDateParser.this.pattern.length()) {
                final char char1 = FastDateParser.this.pattern.charAt(this.currentIdx);
                if (!b && isFormatLetter(char1)) {
                    break;
                }
                if (char1 == '\'' && (++this.currentIdx == FastDateParser.this.pattern.length() || FastDateParser.this.pattern.charAt(this.currentIdx) != '\'')) {
                    b = !b;
                }
                else {
                    ++this.currentIdx;
                    sb.append(char1);
                }
            }
            if (b) {
                throw new IllegalArgumentException("Unterminated quote");
            }
            final String string = sb.toString();
            return new StrategyAndWidth(new CopyQuotedStrategy(string), string.length());
        }
    }
    
    private abstract static class Strategy
    {
        boolean isNumber() {
            return false;
        }
        
        abstract boolean parse(final FastDateParser p0, final Calendar p1, final String p2, final ParsePosition p3, final int p4);
    }
    
    private abstract static class PatternStrategy extends Strategy
    {
        private Pattern pattern;
        
        void createPattern(final StringBuilder sb) {
            this.createPattern(sb.toString());
        }
        
        void createPattern(final String regex) {
            this.pattern = Pattern.compile(regex);
        }
        
        @Override
        boolean isNumber() {
            return false;
        }
        
        @Override
        boolean parse(final FastDateParser fastDateParser, final Calendar calendar, final String s, final ParsePosition parsePosition, final int n) {
            final Matcher matcher = this.pattern.matcher(s.substring(parsePosition.getIndex()));
            if (!matcher.lookingAt()) {
                parsePosition.setErrorIndex(parsePosition.getIndex());
                return false;
            }
            parsePosition.setIndex(parsePosition.getIndex() + matcher.end(1));
            this.setCalendar(fastDateParser, calendar, matcher.group(1));
            return true;
        }
        
        abstract void setCalendar(final FastDateParser p0, final Calendar p1, final String p2);
    }
    
    private static class CopyQuotedStrategy extends Strategy
    {
        private final String formatField;
        
        CopyQuotedStrategy(final String formatField) {
            this.formatField = formatField;
        }
        
        @Override
        boolean isNumber() {
            return false;
        }
        
        @Override
        boolean parse(final FastDateParser fastDateParser, final Calendar calendar, final String s, final ParsePosition parsePosition, final int n) {
            for (int i = 0; i < this.formatField.length(); ++i) {
                final int errorIndex = i + parsePosition.getIndex();
                if (errorIndex == s.length()) {
                    parsePosition.setErrorIndex(errorIndex);
                    return false;
                }
                if (this.formatField.charAt(i) != s.charAt(errorIndex)) {
                    parsePosition.setErrorIndex(errorIndex);
                    return false;
                }
            }
            parsePosition.setIndex(this.formatField.length() + parsePosition.getIndex());
            return true;
        }
    }
    
    private static class CaseInsensitiveTextStrategy extends PatternStrategy
    {
        private final int field;
        final Locale locale;
        private final Map<String, Integer> lKeyValues;
        
        CaseInsensitiveTextStrategy(final int field, final Calendar calendar, final Locale locale) {
            this.field = field;
            this.locale = locale;
            final StringBuilder sb = new StringBuilder();
            sb.append("((?iu)");
            this.lKeyValues = appendDisplayNames(calendar, locale, field, sb);
            sb.setLength(sb.length() - 1);
            sb.append(")");
            this.createPattern(sb);
        }
        
        @Override
        void setCalendar(final FastDateParser fastDateParser, final Calendar calendar, final String s) {
            final String lowerCase = s.toLowerCase(this.locale);
            Integer n = this.lKeyValues.get(lowerCase);
            if (n == null) {
                n = this.lKeyValues.get(lowerCase + '.');
            }
            calendar.set(this.field, n);
        }
    }
    
    private static class NumberStrategy extends Strategy
    {
        private final int field;
        
        NumberStrategy(final int field) {
            this.field = field;
        }
        
        @Override
        boolean isNumber() {
            return true;
        }
        
        @Override
        boolean parse(final FastDateParser fastDateParser, final Calendar calendar, final String s, final ParsePosition parsePosition, final int n) {
            int index = parsePosition.getIndex();
            int length = s.length();
            if (n == 0) {
                while (index < length && Character.isWhitespace(s.charAt(index))) {
                    ++index;
                }
                parsePosition.setIndex(index);
            }
            else {
                final int n2 = index + n;
                if (length > n2) {
                    length = n2;
                }
            }
            while (index < length && Character.isDigit(s.charAt(index))) {
                ++index;
            }
            if (parsePosition.getIndex() == index) {
                parsePosition.setErrorIndex(index);
                return false;
            }
            final int int1 = Integer.parseInt(s.substring(parsePosition.getIndex(), index));
            parsePosition.setIndex(index);
            calendar.set(this.field, this.modify(fastDateParser, int1));
            return true;
        }
        
        int modify(final FastDateParser fastDateParser, final int n) {
            return n;
        }
    }
    
    static class TimeZoneStrategy extends PatternStrategy
    {
        private static final String RFC_822_TIME_ZONE = "[+-]\\d{4}";
        private static final String GMT_OPTION = "GMT[+-]\\d{1,2}:\\d{2}";
        private final Locale locale;
        private final Map<String, TzInfo> tzNames;
        private static final int ID = 0;
        
        TimeZoneStrategy(final Locale locale) {
            this.tzNames = new HashMap<String, TzInfo>();
            this.locale = locale;
            final StringBuilder sb = new StringBuilder();
            sb.append("((?iu)[+-]\\d{4}|GMT[+-]\\d{1,2}:\\d{2}");
            final TreeSet<String> set = new TreeSet<String>(FastDateParser.LONGER_FIRST_LOWERCASE);
            for (final String[] array : DateFormatSymbols.getInstance(locale).getZoneStrings()) {
                final String id = array[0];
                if (!id.equalsIgnoreCase("GMT")) {
                    final TimeZone timeZone = TimeZone.getTimeZone(id);
                    TzInfo tzInfo = new TzInfo(timeZone, false);
                    for (int j = 1; j < array.length; ++j) {
                        switch (j) {
                            case 3: {
                                tzInfo = new TzInfo(timeZone, true);
                                break;
                            }
                            case 5: {
                                tzInfo = tzInfo;
                                break;
                            }
                        }
                        if (array[j] != null) {
                            final String lowerCase = array[j].toLowerCase(locale);
                            if (set.add(lowerCase)) {
                                this.tzNames.put(lowerCase, tzInfo);
                            }
                        }
                    }
                }
            }
            final Iterator<Object> iterator = set.iterator();
            while (iterator.hasNext()) {
                simpleQuote(sb.append('|'), iterator.next());
            }
            sb.append(")");
            this.createPattern(sb);
        }
        
        @Override
        void setCalendar(final FastDateParser fastDateParser, final Calendar calendar, final String s) {
            final TimeZone gmtTimeZone = FastTimeZone.getGmtTimeZone(s);
            if (gmtTimeZone != null) {
                calendar.setTimeZone(gmtTimeZone);
            }
            else {
                final String lowerCase = s.toLowerCase(this.locale);
                TzInfo tzInfo = this.tzNames.get(lowerCase);
                if (tzInfo == null) {
                    tzInfo = this.tzNames.get(lowerCase + '.');
                }
                calendar.set(16, tzInfo.dstOffset);
                calendar.set(15, tzInfo.zone.getRawOffset());
            }
        }
        
        private static class TzInfo
        {
            TimeZone zone;
            int dstOffset;
            
            TzInfo(final TimeZone zone, final boolean b) {
                this.zone = zone;
                this.dstOffset = (b ? zone.getDSTSavings() : 0);
            }
        }
    }
    
    private static class ISO8601TimeZoneStrategy extends PatternStrategy
    {
        private static final Strategy ISO_8601_1_STRATEGY;
        private static final Strategy ISO_8601_2_STRATEGY;
        private static final Strategy ISO_8601_3_STRATEGY;
        
        ISO8601TimeZoneStrategy(final String s) {
            this.createPattern(s);
        }
        
        @Override
        void setCalendar(final FastDateParser fastDateParser, final Calendar calendar, final String s) {
            calendar.setTimeZone(FastTimeZone.getGmtTimeZone(s));
        }
        
        static Strategy getStrategy(final int n) {
            switch (n) {
                case 1: {
                    return ISO8601TimeZoneStrategy.ISO_8601_1_STRATEGY;
                }
                case 2: {
                    return ISO8601TimeZoneStrategy.ISO_8601_2_STRATEGY;
                }
                case 3: {
                    return ISO8601TimeZoneStrategy.ISO_8601_3_STRATEGY;
                }
                default: {
                    throw new IllegalArgumentException("invalid number of X");
                }
            }
        }
        
        static {
            ISO_8601_1_STRATEGY = new ISO8601TimeZoneStrategy("(Z|(?:[+-]\\d{2}))");
            ISO_8601_2_STRATEGY = new ISO8601TimeZoneStrategy("(Z|(?:[+-]\\d{2}\\d{2}))");
            ISO_8601_3_STRATEGY = new ISO8601TimeZoneStrategy("(Z|(?:[+-]\\d{2}(?::)\\d{2}))");
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.math;

import java.lang.reflect.Array;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.math.BigInteger;
import net.crytec.regiongui.libs.apache.commons.StringUtils;
import java.math.RoundingMode;
import java.math.BigDecimal;

public class NumberUtils
{
    public static final Long LONG_ZERO;
    public static final Long LONG_ONE;
    public static final Long LONG_MINUS_ONE;
    public static final Integer INTEGER_ZERO;
    public static final Integer INTEGER_ONE;
    public static final Integer INTEGER_TWO;
    public static final Integer INTEGER_MINUS_ONE;
    public static final Short SHORT_ZERO;
    public static final Short SHORT_ONE;
    public static final Short SHORT_MINUS_ONE;
    public static final Byte BYTE_ZERO;
    public static final Byte BYTE_ONE;
    public static final Byte BYTE_MINUS_ONE;
    public static final Double DOUBLE_ZERO;
    public static final Double DOUBLE_ONE;
    public static final Double DOUBLE_MINUS_ONE;
    public static final Float FLOAT_ZERO;
    public static final Float FLOAT_ONE;
    public static final Float FLOAT_MINUS_ONE;
    
    public static int toInt(final String s) {
        return toInt(s, 0);
    }
    
    public static int toInt(final String s, final int n) {
        if (s == null) {
            return n;
        }
        try {
            return Integer.parseInt(s);
        }
        catch (NumberFormatException ex) {
            return n;
        }
    }
    
    public static long toLong(final String s) {
        return toLong(s, 0L);
    }
    
    public static long toLong(final String s, final long n) {
        if (s == null) {
            return n;
        }
        try {
            return Long.parseLong(s);
        }
        catch (NumberFormatException ex) {
            return n;
        }
    }
    
    public static float toFloat(final String s) {
        return toFloat(s, 0.0f);
    }
    
    public static float toFloat(final String s, final float n) {
        if (s == null) {
            return n;
        }
        try {
            return Float.parseFloat(s);
        }
        catch (NumberFormatException ex) {
            return n;
        }
    }
    
    public static double toDouble(final String s) {
        return toDouble(s, 0.0);
    }
    
    public static double toDouble(final String s, final double n) {
        if (s == null) {
            return n;
        }
        try {
            return Double.parseDouble(s);
        }
        catch (NumberFormatException ex) {
            return n;
        }
    }
    
    public static double toDouble(final BigDecimal bigDecimal) {
        return toDouble(bigDecimal, 0.0);
    }
    
    public static double toDouble(final BigDecimal bigDecimal, final double n) {
        return (bigDecimal == null) ? n : bigDecimal.doubleValue();
    }
    
    public static byte toByte(final String s) {
        return toByte(s, (byte)0);
    }
    
    public static byte toByte(final String s, final byte b) {
        if (s == null) {
            return b;
        }
        try {
            return Byte.parseByte(s);
        }
        catch (NumberFormatException ex) {
            return b;
        }
    }
    
    public static short toShort(final String s) {
        return toShort(s, (short)0);
    }
    
    public static short toShort(final String s, final short n) {
        if (s == null) {
            return n;
        }
        try {
            return Short.parseShort(s);
        }
        catch (NumberFormatException ex) {
            return n;
        }
    }
    
    public static BigDecimal toScaledBigDecimal(final BigDecimal bigDecimal) {
        return toScaledBigDecimal(bigDecimal, NumberUtils.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }
    
    public static BigDecimal toScaledBigDecimal(final BigDecimal bigDecimal, final int newScale, final RoundingMode roundingMode) {
        if (bigDecimal == null) {
            return BigDecimal.ZERO;
        }
        return bigDecimal.setScale(newScale, (roundingMode == null) ? RoundingMode.HALF_EVEN : roundingMode);
    }
    
    public static BigDecimal toScaledBigDecimal(final Float n) {
        return toScaledBigDecimal(n, NumberUtils.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }
    
    public static BigDecimal toScaledBigDecimal(final Float n, final int n2, final RoundingMode roundingMode) {
        if (n == null) {
            return BigDecimal.ZERO;
        }
        return toScaledBigDecimal(BigDecimal.valueOf(n), n2, roundingMode);
    }
    
    public static BigDecimal toScaledBigDecimal(final Double n) {
        return toScaledBigDecimal(n, NumberUtils.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }
    
    public static BigDecimal toScaledBigDecimal(final Double n, final int n2, final RoundingMode roundingMode) {
        if (n == null) {
            return BigDecimal.ZERO;
        }
        return toScaledBigDecimal(BigDecimal.valueOf(n), n2, roundingMode);
    }
    
    public static BigDecimal toScaledBigDecimal(final String s) {
        return toScaledBigDecimal(s, NumberUtils.INTEGER_TWO, RoundingMode.HALF_EVEN);
    }
    
    public static BigDecimal toScaledBigDecimal(final String s, final int n, final RoundingMode roundingMode) {
        if (s == null) {
            return BigDecimal.ZERO;
        }
        return toScaledBigDecimal(createBigDecimal(s), n, roundingMode);
    }
    
    public static Number createNumber(final String str) {
        if (str == null) {
            return null;
        }
        if (StringUtils.isBlank(str)) {
            throw new NumberFormatException("A blank string is not a valid number");
        }
        final String[] array = { "0x", "0X", "-0x", "-0X", "#", "-#" };
        int n = 0;
        for (final String prefix : array) {
            if (str.startsWith(prefix)) {
                n += prefix.length();
                break;
            }
        }
        if (n > 0) {
            int char1 = 0;
            for (int j = n; j < str.length(); ++j) {
                char1 = str.charAt(j);
                if (char1 != 48) {
                    break;
                }
                ++n;
            }
            final int n2 = str.length() - n;
            if (n2 > 16 || (n2 == 16 && char1 > 55)) {
                return createBigInteger(str);
            }
            if (n2 > 8 || (n2 == 8 && char1 > 55)) {
                return createLong(str);
            }
            return createInteger(str);
        }
        else {
            final char char2 = str.charAt(str.length() - 1);
            final int index = str.indexOf(46);
            final int endIndex = str.indexOf(101) + str.indexOf(69) + 1;
            String s;
            String s2;
            if (index > -1) {
                if (endIndex > -1) {
                    if (endIndex < index || endIndex > str.length()) {
                        throw new NumberFormatException(str + " is not a valid number.");
                    }
                    s = str.substring(index + 1, endIndex);
                }
                else {
                    s = str.substring(index + 1);
                }
                s2 = getMantissa(str, index);
            }
            else {
                if (endIndex > -1) {
                    if (endIndex > str.length()) {
                        throw new NumberFormatException(str + " is not a valid number.");
                    }
                    s2 = getMantissa(str, endIndex);
                }
                else {
                    s2 = getMantissa(str);
                }
                s = null;
            }
            if (!Character.isDigit(char2) && char2 != '.') {
                String substring;
                if (endIndex > -1 && endIndex < str.length() - 1) {
                    substring = str.substring(endIndex + 1, str.length() - 1);
                }
                else {
                    substring = null;
                }
                final String substring2 = str.substring(0, str.length() - 1);
                final boolean b = isAllZeros(s2) && isAllZeros(substring);
                switch (char2) {
                    case 'L':
                    case 'l': {
                        if (s == null && substring == null) {
                            if (substring2.isEmpty() || substring2.charAt(0) != '-' || !isDigits(substring2.substring(1))) {
                                if (!isDigits(substring2)) {
                                    throw new NumberFormatException(str + " is not a valid number.");
                                }
                            }
                            try {
                                return createLong(substring2);
                            }
                            catch (NumberFormatException ex) {
                                return createBigInteger(substring2);
                            }
                        }
                        throw new NumberFormatException(str + " is not a valid number.");
                    }
                    case 'F':
                    case 'f': {
                        try {
                            final Float float1 = createFloat(str);
                            if (!float1.isInfinite() && (float1 != 0.0f || b)) {
                                return float1;
                            }
                        }
                        catch (NumberFormatException ex2) {}
                    }
                    case 'D':
                    case 'd': {
                        try {
                            final Double double1 = createDouble(str);
                            if (!double1.isInfinite() && (double1.floatValue() != 0.0 || b)) {
                                return double1;
                            }
                        }
                        catch (NumberFormatException ex3) {}
                        try {
                            return createBigDecimal(substring2);
                        }
                        catch (NumberFormatException ex4) {}
                        break;
                    }
                }
                throw new NumberFormatException(str + " is not a valid number.");
            }
            String substring3;
            if (endIndex > -1 && endIndex < str.length() - 1) {
                substring3 = str.substring(endIndex + 1, str.length());
            }
            else {
                substring3 = null;
            }
            if (s == null && substring3 == null) {
                try {
                    return createInteger(str);
                }
                catch (NumberFormatException ex5) {
                    try {
                        return createLong(str);
                    }
                    catch (NumberFormatException ex6) {
                        return createBigInteger(str);
                    }
                }
            }
            final boolean b2 = isAllZeros(s2) && isAllZeros(substring3);
            try {
                final Float float2 = createFloat(str);
                final Double double2 = createDouble(str);
                if (!float2.isInfinite() && (float2 != 0.0f || b2) && float2.toString().equals(double2.toString())) {
                    return float2;
                }
                if (!double2.isInfinite() && (double2 != 0.0 || b2)) {
                    final BigDecimal bigDecimal = createBigDecimal(str);
                    if (bigDecimal.compareTo(BigDecimal.valueOf(double2)) == 0) {
                        return double2;
                    }
                    return bigDecimal;
                }
            }
            catch (NumberFormatException ex7) {}
            return createBigDecimal(str);
        }
    }
    
    private static String getMantissa(final String s) {
        return getMantissa(s, s.length());
    }
    
    private static String getMantissa(final String s, final int n) {
        final char char1 = s.charAt(0);
        return (char1 == '-' || char1 == '+') ? s.substring(1, n) : s.substring(0, n);
    }
    
    private static boolean isAllZeros(final String s) {
        if (s == null) {
            return true;
        }
        for (int i = s.length() - 1; i >= 0; --i) {
            if (s.charAt(i) != '0') {
                return false;
            }
        }
        return !s.isEmpty();
    }
    
    public static Float createFloat(final String s) {
        if (s == null) {
            return null;
        }
        return Float.valueOf(s);
    }
    
    public static Double createDouble(final String s) {
        if (s == null) {
            return null;
        }
        return Double.valueOf(s);
    }
    
    public static Integer createInteger(final String nm) {
        if (nm == null) {
            return null;
        }
        return Integer.decode(nm);
    }
    
    public static Long createLong(final String nm) {
        if (nm == null) {
            return null;
        }
        return Long.decode(nm);
    }
    
    public static BigInteger createBigInteger(final String s) {
        if (s == null) {
            return null;
        }
        int beginIndex = 0;
        int radix = 10;
        boolean b = false;
        if (s.startsWith("-")) {
            b = true;
            beginIndex = 1;
        }
        if (s.startsWith("0x", beginIndex) || s.startsWith("0X", beginIndex)) {
            radix = 16;
            beginIndex += 2;
        }
        else if (s.startsWith("#", beginIndex)) {
            radix = 16;
            ++beginIndex;
        }
        else if (s.startsWith("0", beginIndex) && s.length() > beginIndex + 1) {
            radix = 8;
            ++beginIndex;
        }
        final BigInteger bigInteger = new BigInteger(s.substring(beginIndex), radix);
        return b ? bigInteger.negate() : bigInteger;
    }
    
    public static BigDecimal createBigDecimal(final String s) {
        if (s == null) {
            return null;
        }
        if (StringUtils.isBlank(s)) {
            throw new NumberFormatException("A blank string is not a valid number");
        }
        if (s.trim().startsWith("--")) {
            throw new NumberFormatException(s + " is not a valid number.");
        }
        return new BigDecimal(s);
    }
    
    public static long min(final long... array) {
        validateArray(array);
        long n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] < n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static int min(final int... array) {
        validateArray(array);
        int n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] < n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static short min(final short... array) {
        validateArray(array);
        short n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] < n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static byte min(final byte... array) {
        validateArray(array);
        byte b = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] < b) {
                b = array[i];
            }
        }
        return b;
    }
    
    public static double min(final double... array) {
        validateArray(array);
        double n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (Double.isNaN(array[i])) {
                return Double.NaN;
            }
            if (array[i] < n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static float min(final float... array) {
        validateArray(array);
        float n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (Float.isNaN(array[i])) {
                return Float.NaN;
            }
            if (array[i] < n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static long max(final long... array) {
        validateArray(array);
        long n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] > n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static int max(final int... array) {
        validateArray(array);
        int n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] > n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static short max(final short... array) {
        validateArray(array);
        short n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] > n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static byte max(final byte... array) {
        validateArray(array);
        byte b = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (array[i] > b) {
                b = array[i];
            }
        }
        return b;
    }
    
    public static double max(final double... array) {
        validateArray(array);
        double n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (Double.isNaN(array[i])) {
                return Double.NaN;
            }
            if (array[i] > n) {
                n = array[i];
            }
        }
        return n;
    }
    
    public static float max(final float... array) {
        validateArray(array);
        float n = array[0];
        for (int i = 1; i < array.length; ++i) {
            if (Float.isNaN(array[i])) {
                return Float.NaN;
            }
            if (array[i] > n) {
                n = array[i];
            }
        }
        return n;
    }
    
    private static void validateArray(final Object o) {
        Validate.isTrue(o != null, "The Array must not be null", new Object[0]);
        Validate.isTrue(Array.getLength(o) != 0, "Array cannot be empty.", new Object[0]);
    }
    
    public static long min(long n, final long n2, final long n3) {
        if (n2 < n) {
            n = n2;
        }
        if (n3 < n) {
            n = n3;
        }
        return n;
    }
    
    public static int min(int n, final int n2, final int n3) {
        if (n2 < n) {
            n = n2;
        }
        if (n3 < n) {
            n = n3;
        }
        return n;
    }
    
    public static short min(short n, final short n2, final short n3) {
        if (n2 < n) {
            n = n2;
        }
        if (n3 < n) {
            n = n3;
        }
        return n;
    }
    
    public static byte min(byte b, final byte b2, final byte b3) {
        if (b2 < b) {
            b = b2;
        }
        if (b3 < b) {
            b = b3;
        }
        return b;
    }
    
    public static double min(final double a, final double b, final double b2) {
        return Math.min(Math.min(a, b), b2);
    }
    
    public static float min(final float a, final float b, final float b2) {
        return Math.min(Math.min(a, b), b2);
    }
    
    public static long max(long n, final long n2, final long n3) {
        if (n2 > n) {
            n = n2;
        }
        if (n3 > n) {
            n = n3;
        }
        return n;
    }
    
    public static int max(int n, final int n2, final int n3) {
        if (n2 > n) {
            n = n2;
        }
        if (n3 > n) {
            n = n3;
        }
        return n;
    }
    
    public static short max(short n, final short n2, final short n3) {
        if (n2 > n) {
            n = n2;
        }
        if (n3 > n) {
            n = n3;
        }
        return n;
    }
    
    public static byte max(byte b, final byte b2, final byte b3) {
        if (b2 > b) {
            b = b2;
        }
        if (b3 > b) {
            b = b3;
        }
        return b;
    }
    
    public static double max(final double a, final double b, final double b2) {
        return Math.max(Math.max(a, b), b2);
    }
    
    public static float max(final float a, final float b, final float b2) {
        return Math.max(Math.max(a, b), b2);
    }
    
    public static boolean isDigits(final String s) {
        return StringUtils.isNumeric(s);
    }
    
    @Deprecated
    public static boolean isNumber(final String s) {
        return isCreatable(s);
    }
    
    public static boolean isCreatable(final String s) {
        if (StringUtils.isEmpty(s)) {
            return false;
        }
        final char[] charArray = s.toCharArray();
        int length = charArray.length;
        int n = 0;
        int n2 = 0;
        int n3 = 0;
        boolean b = false;
        final int n4 = (charArray[0] == '-' || charArray[0] == '+') ? 1 : 0;
        if (length > n4 + 1 && charArray[n4] == '0' && !StringUtils.contains(s, 46)) {
            if (charArray[n4 + 1] == 'x' || charArray[n4 + 1] == 'X') {
                int i = n4 + 2;
                if (i == length) {
                    return false;
                }
                while (i < charArray.length) {
                    if ((charArray[i] < '0' || charArray[i] > '9') && (charArray[i] < 'a' || charArray[i] > 'f') && (charArray[i] < 'A' || charArray[i] > 'F')) {
                        return false;
                    }
                    ++i;
                }
                return true;
            }
            else if (Character.isDigit(charArray[n4 + 1])) {
                for (int j = n4 + 1; j < charArray.length; ++j) {
                    if (charArray[j] < '0' || charArray[j] > '7') {
                        return false;
                    }
                }
                return true;
            }
        }
        --length;
        int n5;
        for (n5 = n4; n5 < length || (n5 < length + 1 && n3 != 0 && !b); ++n5) {
            if (charArray[n5] >= '0' && charArray[n5] <= '9') {
                b = true;
                n3 = 0;
            }
            else if (charArray[n5] == '.') {
                if (n2 != 0 || n != 0) {
                    return false;
                }
                n2 = 1;
            }
            else if (charArray[n5] == 'e' || charArray[n5] == 'E') {
                if (n != 0) {
                    return false;
                }
                if (!b) {
                    return false;
                }
                n = 1;
                n3 = 1;
            }
            else {
                if (charArray[n5] != '+' && charArray[n5] != '-') {
                    return false;
                }
                if (n3 == 0) {
                    return false;
                }
                n3 = 0;
                b = false;
            }
        }
        if (n5 >= charArray.length) {
            return n3 == 0 && b;
        }
        if (charArray[n5] >= '0' && charArray[n5] <= '9') {
            return true;
        }
        if (charArray[n5] == 'e' || charArray[n5] == 'E') {
            return false;
        }
        if (charArray[n5] == '.') {
            return n2 == 0 && n == 0 && b;
        }
        if (n3 == 0 && (charArray[n5] == 'd' || charArray[n5] == 'D' || charArray[n5] == 'f' || charArray[n5] == 'F')) {
            return b;
        }
        return (charArray[n5] == 'l' || charArray[n5] == 'L') && b && n == 0 && n2 == 0;
    }
    
    public static boolean isParsable(final String s) {
        if (StringUtils.isEmpty(s)) {
            return false;
        }
        if (s.charAt(s.length() - 1) == '.') {
            return false;
        }
        if (s.charAt(0) == '-') {
            return s.length() != 1 && withDecimalsParsing(s, 1);
        }
        return withDecimalsParsing(s, 0);
    }
    
    private static boolean withDecimalsParsing(final String s, final int n) {
        int n2 = 0;
        for (int i = n; i < s.length(); ++i) {
            final boolean b = s.charAt(i) == '.';
            if (b) {
                ++n2;
            }
            if (n2 > 1) {
                return false;
            }
            if (!b && !Character.isDigit(s.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static int compare(final int n, final int n2) {
        if (n == n2) {
            return 0;
        }
        return (n < n2) ? -1 : 1;
    }
    
    public static int compare(final long n, final long n2) {
        if (n == n2) {
            return 0;
        }
        return (n < n2) ? -1 : 1;
    }
    
    public static int compare(final short n, final short n2) {
        if (n == n2) {
            return 0;
        }
        return (n < n2) ? -1 : 1;
    }
    
    public static int compare(final byte b, final byte b2) {
        return b - b2;
    }
    
    static {
        LONG_ZERO = 0L;
        LONG_ONE = 1L;
        LONG_MINUS_ONE = -1L;
        INTEGER_ZERO = 0;
        INTEGER_ONE = 1;
        INTEGER_TWO = 2;
        INTEGER_MINUS_ONE = -1;
        SHORT_ZERO = 0;
        SHORT_ONE = 1;
        SHORT_MINUS_ONE = -1;
        BYTE_ZERO = 0;
        BYTE_ONE = 1;
        BYTE_MINUS_ONE = -1;
        DOUBLE_ZERO = 0.0;
        DOUBLE_ONE = 1.0;
        DOUBLE_MINUS_ONE = -1.0;
        FLOAT_ZERO = 0.0f;
        FLOAT_ONE = 1.0f;
        FLOAT_MINUS_ONE = -1.0f;
    }
}

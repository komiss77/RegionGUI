// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.lang.reflect.UndeclaredThrowableException;
import java.io.UncheckedIOException;
import java.io.IOException;

public class Functions
{
    public static <T extends Throwable> void run(final FailableRunnable<T> failableRunnable) {
        try {
            failableRunnable.run();
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    public static <O, T extends Throwable> O call(final FailableCallable<O, T> failableCallable) {
        try {
            return failableCallable.call();
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    public static <O, T extends Throwable> void accept(final FailableConsumer<O, T> failableConsumer, final O o) {
        try {
            failableConsumer.accept(o);
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    public static <O1, O2, T extends Throwable> void accept(final FailableBiConsumer<O1, O2, T> failableBiConsumer, final O1 o1, final O2 o2) {
        try {
            failableBiConsumer.accept(o1, o2);
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    public static <I, O, T extends Throwable> O apply(final FailableFunction<I, O, T> failableFunction, final I n) {
        try {
            return failableFunction.apply(n);
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    public static <I1, I2, O, T extends Throwable> O apply(final FailableBiFunction<I1, I2, O, T> failableBiFunction, final I1 i1, final I2 i2) {
        try {
            return failableBiFunction.apply(i1, i2);
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    public static <O, T extends Throwable> boolean test(final FailablePredicate<O, T> failablePredicate, final O o) {
        try {
            return failablePredicate.test(o);
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    public static <O1, O2, T extends Throwable> boolean test(final FailableBiPredicate<O1, O2, T> failableBiPredicate, final O1 o1, final O2 o2) {
        try {
            return failableBiPredicate.test(o1, o2);
        }
        catch (Throwable t) {
            throw rethrow(t);
        }
    }
    
    @SafeVarargs
    public static void tryWithResources(final FailableRunnable<? extends Throwable> failableRunnable, final FailableConsumer<Throwable, ? extends Throwable> failableConsumer, final FailableRunnable<? extends Throwable>... array) {
        FailableConsumer<Throwable, ? extends Throwable> failableConsumer2;
        if (failableConsumer == null) {
            failableConsumer2 = (t -> rethrow(t));
        }
        else {
            failableConsumer2 = failableConsumer;
        }
        if (array != null) {
            for (int length = array.length, i = 0; i < length; ++i) {
                if (array[i] == null) {
                    throw new NullPointerException("A resource action must not be null.");
                }
            }
        }
        Throwable t2 = null;
        try {
            failableRunnable.run();
        }
        catch (Throwable t3) {
            t2 = t3;
        }
        if (array != null) {
            for (final FailableRunnable<? extends Throwable> failableRunnable2 : array) {
                try {
                    failableRunnable2.run();
                }
                catch (Throwable t4) {
                    if (t2 == null) {
                        t2 = t4;
                    }
                }
            }
        }
        if (t2 != null) {
            try {
                failableConsumer2.accept(t2);
            }
            catch (Throwable t5) {
                throw rethrow(t5);
            }
        }
    }
    
    @SafeVarargs
    public static void tryWithResources(final FailableRunnable<? extends Throwable> failableRunnable, final FailableRunnable<? extends Throwable>... array) {
        tryWithResources(failableRunnable, (FailableConsumer<Throwable, ? extends Throwable>)null, array);
    }
    
    public static RuntimeException rethrow(final Throwable undeclaredThrowable) {
        if (undeclaredThrowable == null) {
            throw new NullPointerException("The Throwable must not be null.");
        }
        if (undeclaredThrowable instanceof RuntimeException) {
            throw (RuntimeException)undeclaredThrowable;
        }
        if (undeclaredThrowable instanceof Error) {
            throw (Error)undeclaredThrowable;
        }
        if (undeclaredThrowable instanceof IOException) {
            throw new UncheckedIOException((IOException)undeclaredThrowable);
        }
        throw new UndeclaredThrowableException(undeclaredThrowable);
    }
    
    @FunctionalInterface
    public interface FailableBiPredicate<O1, O2, T extends Throwable>
    {
        boolean test(final O1 p0, final O2 p1) throws T, Throwable;
    }
    
    @FunctionalInterface
    public interface FailablePredicate<O, T extends Throwable>
    {
        boolean test(final O p0) throws T, Throwable;
    }
    
    @FunctionalInterface
    public interface FailableBiFunction<I1, I2, O, T extends Throwable>
    {
        O apply(final I1 p0, final I2 p1) throws T, Throwable;
    }
    
    @FunctionalInterface
    public interface FailableFunction<I, O, T extends Throwable>
    {
        O apply(final I p0) throws T, Throwable;
    }
    
    @FunctionalInterface
    public interface FailableBiConsumer<O1, O2, T extends Throwable>
    {
        void accept(final O1 p0, final O2 p1) throws T, Throwable;
    }
    
    @FunctionalInterface
    public interface FailableConsumer<O, T extends Throwable>
    {
        void accept(final O p0) throws T, Throwable;
    }
    
    @FunctionalInterface
    public interface FailableCallable<O, T extends Throwable>
    {
        O call() throws T, Throwable;
    }
    
    @FunctionalInterface
    public interface FailableRunnable<T extends Throwable>
    {
        void run() throws T, Throwable;
    }
}

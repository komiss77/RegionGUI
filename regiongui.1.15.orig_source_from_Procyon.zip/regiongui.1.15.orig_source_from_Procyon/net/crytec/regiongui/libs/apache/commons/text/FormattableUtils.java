// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text;

import net.crytec.regiongui.libs.apache.commons.ObjectUtils;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.Formatter;
import java.util.Formattable;

@Deprecated
public class FormattableUtils
{
    private static final String SIMPLEST_FORMAT = "%s";
    
    public static String toString(final Formattable formattable) {
        return String.format("%s", formattable);
    }
    
    public static Formatter append(final CharSequence charSequence, final Formatter formatter, final int n, final int n2, final int n3) {
        return append(charSequence, formatter, n, n2, n3, ' ', null);
    }
    
    public static Formatter append(final CharSequence charSequence, final Formatter formatter, final int n, final int n2, final int n3, final char c) {
        return append(charSequence, formatter, n, n2, n3, c, null);
    }
    
    public static Formatter append(final CharSequence charSequence, final Formatter formatter, final int n, final int n2, final int n3, final CharSequence charSequence2) {
        return append(charSequence, formatter, n, n2, n3, ' ', charSequence2);
    }
    
    public static Formatter append(final CharSequence seq, final Formatter formatter, final int n, final int n2, final int i, final char c, final CharSequence charSequence) {
        Validate.isTrue(charSequence == null || i < 0 || charSequence.length() <= i, "Specified ellipsis '%1$s' exceeds precision of %2$s", charSequence, i);
        final StringBuilder sb = new StringBuilder(seq);
        if (i >= 0 && i < seq.length()) {
            final CharSequence charSequence2 = ObjectUtils.defaultIfNull(charSequence, "");
            sb.replace(i - charSequence2.length(), seq.length(), charSequence2.toString());
        }
        final boolean b = (n & 0x1) == 0x1;
        for (int j = sb.length(); j < n2; ++j) {
            sb.insert(b ? j : false, c);
        }
        formatter.format(sb.toString(), new Object[0]);
        return formatter;
    }
}

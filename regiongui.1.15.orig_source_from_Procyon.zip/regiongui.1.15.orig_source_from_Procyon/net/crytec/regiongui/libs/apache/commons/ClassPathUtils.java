// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

public class ClassPathUtils
{
    public static String toFullyQualifiedName(final Class<?> clazz, final String s) {
        Validate.notNull(clazz, "Parameter '%s' must not be null!", "context");
        Validate.notNull(s, "Parameter '%s' must not be null!", "resourceName");
        return toFullyQualifiedName(clazz.getPackage(), s);
    }
    
    public static String toFullyQualifiedName(final Package package1, final String str) {
        Validate.notNull(package1, "Parameter '%s' must not be null!", "context");
        Validate.notNull(str, "Parameter '%s' must not be null!", "resourceName");
        return package1.getName() + "." + str;
    }
    
    public static String toFullyQualifiedPath(final Class<?> clazz, final String s) {
        Validate.notNull(clazz, "Parameter '%s' must not be null!", "context");
        Validate.notNull(s, "Parameter '%s' must not be null!", "resourceName");
        return toFullyQualifiedPath(clazz.getPackage(), s);
    }
    
    public static String toFullyQualifiedPath(final Package package1, final String str) {
        Validate.notNull(package1, "Parameter '%s' must not be null!", "context");
        Validate.notNull(str, "Parameter '%s' must not be null!", "resourceName");
        return package1.getName().replace('.', '/') + "/" + str;
    }
}

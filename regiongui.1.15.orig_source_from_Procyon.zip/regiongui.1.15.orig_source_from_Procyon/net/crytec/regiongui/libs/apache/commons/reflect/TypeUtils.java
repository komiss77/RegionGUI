// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.reflect;

import net.crytec.regiongui.libs.apache.commons.builder.Builder;
import net.crytec.regiongui.libs.apache.commons.ObjectUtils;
import java.util.Objects;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;
import java.util.Collections;
import java.lang.reflect.Array;
import java.util.HashSet;
import java.util.List;
import java.util.Arrays;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.HashMap;
import java.util.Iterator;
import net.crytec.regiongui.libs.apache.commons.ClassUtils;
import java.lang.reflect.GenericArrayType;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.TypeVariable;
import java.util.Map;
import java.lang.reflect.Type;
import java.lang.reflect.WildcardType;

public class TypeUtils
{
    public static final WildcardType WILDCARD_ALL;
    
    public static boolean isAssignable(final Type type, final Type type2) {
        return isAssignable(type, type2, null);
    }
    
    private static boolean isAssignable(final Type type, final Type obj, final Map<TypeVariable<?>, Type> map) {
        if (obj == null || obj instanceof Class) {
            return isAssignable(type, (Class<?>)obj);
        }
        if (obj instanceof ParameterizedType) {
            return isAssignable(type, (ParameterizedType)obj, map);
        }
        if (obj instanceof GenericArrayType) {
            return isAssignable(type, (GenericArrayType)obj, map);
        }
        if (obj instanceof WildcardType) {
            return isAssignable(type, (WildcardType)obj, map);
        }
        if (obj instanceof TypeVariable) {
            return isAssignable(type, (TypeVariable<?>)obj, map);
        }
        throw new IllegalStateException("found an unhandled type: " + obj);
    }
    
    private static boolean isAssignable(final Type type, final Class<?> clazz) {
        if (type == null) {
            return clazz == null || !clazz.isPrimitive();
        }
        if (clazz == null) {
            return false;
        }
        if (clazz.equals(type)) {
            return true;
        }
        if (type instanceof Class) {
            return ClassUtils.isAssignable((Class<?>)type, clazz);
        }
        if (type instanceof ParameterizedType) {
            return isAssignable(getRawType((ParameterizedType)type), clazz);
        }
        if (type instanceof TypeVariable) {
            final Type[] bounds = ((TypeVariable)type).getBounds();
            for (int length = bounds.length, i = 0; i < length; ++i) {
                if (isAssignable(bounds[i], clazz)) {
                    return true;
                }
            }
            return false;
        }
        if (type instanceof GenericArrayType) {
            return clazz.equals(Object.class) || (clazz.isArray() && isAssignable(((GenericArrayType)type).getGenericComponentType(), clazz.getComponentType()));
        }
        if (type instanceof WildcardType) {
            return false;
        }
        throw new IllegalStateException("found an unhandled type: " + type);
    }
    
    private static boolean isAssignable(final Type obj, final ParameterizedType parameterizedType, final Map<TypeVariable<?>, Type> map) {
        if (obj == null) {
            return true;
        }
        if (parameterizedType == null) {
            return false;
        }
        if (parameterizedType.equals(obj)) {
            return true;
        }
        final Class<?> rawType = getRawType(parameterizedType);
        final Map<TypeVariable<?>, Type> typeArguments = getTypeArguments(obj, rawType, null);
        if (typeArguments == null) {
            return false;
        }
        if (typeArguments.isEmpty()) {
            return true;
        }
        final Map<TypeVariable<?>, Type> typeArguments2 = getTypeArguments(parameterizedType, rawType, map);
        for (final TypeVariable<?> typeVariable : typeArguments2.keySet()) {
            final Type unrollVariableAssignments = unrollVariableAssignments(typeVariable, typeArguments2);
            final Type unrollVariableAssignments2 = unrollVariableAssignments(typeVariable, typeArguments);
            if (unrollVariableAssignments == null && unrollVariableAssignments2 instanceof Class) {
                continue;
            }
            if (unrollVariableAssignments2 != null && !unrollVariableAssignments.equals(unrollVariableAssignments2) && (!(unrollVariableAssignments instanceof WildcardType) || !isAssignable(unrollVariableAssignments2, unrollVariableAssignments, map))) {
                return false;
            }
        }
        return true;
    }
    
    private static Type unrollVariableAssignments(TypeVariable<?> obj, final Map<TypeVariable<?>, Type> map) {
        Type type;
        while (true) {
            type = map.get(obj);
            if (!(type instanceof TypeVariable) || type.equals(obj)) {
                break;
            }
            obj = (TypeVariable<?>)type;
        }
        return type;
    }
    
    private static boolean isAssignable(final Type type, final GenericArrayType genericArrayType, final Map<TypeVariable<?>, Type> map) {
        if (type == null) {
            return true;
        }
        if (genericArrayType == null) {
            return false;
        }
        if (genericArrayType.equals(type)) {
            return true;
        }
        final Type genericComponentType = genericArrayType.getGenericComponentType();
        if (type instanceof Class) {
            final Class clazz = (Class)type;
            return clazz.isArray() && isAssignable(clazz.getComponentType(), genericComponentType, map);
        }
        if (type instanceof GenericArrayType) {
            return isAssignable(((GenericArrayType)type).getGenericComponentType(), genericComponentType, map);
        }
        if (type instanceof WildcardType) {
            final Type[] implicitUpperBounds = getImplicitUpperBounds((WildcardType)type);
            for (int length = implicitUpperBounds.length, i = 0; i < length; ++i) {
                if (isAssignable(implicitUpperBounds[i], genericArrayType)) {
                    return true;
                }
            }
            return false;
        }
        if (type instanceof TypeVariable) {
            final Type[] implicitBounds = getImplicitBounds((TypeVariable<?>)type);
            for (int length2 = implicitBounds.length, j = 0; j < length2; ++j) {
                if (isAssignable(implicitBounds[j], genericArrayType)) {
                    return true;
                }
            }
            return false;
        }
        if (type instanceof ParameterizedType) {
            return false;
        }
        throw new IllegalStateException("found an unhandled type: " + type);
    }
    
    private static boolean isAssignable(final Type obj, final WildcardType wildcardType, final Map<TypeVariable<?>, Type> map) {
        if (obj == null) {
            return true;
        }
        if (wildcardType == null) {
            return false;
        }
        if (wildcardType.equals(obj)) {
            return true;
        }
        final Type[] implicitUpperBounds = getImplicitUpperBounds(wildcardType);
        final Type[] implicitLowerBounds = getImplicitLowerBounds(wildcardType);
        if (obj instanceof WildcardType) {
            final WildcardType wildcardType2 = (WildcardType)obj;
            final Type[] implicitUpperBounds2 = getImplicitUpperBounds(wildcardType2);
            final Type[] implicitLowerBounds2 = getImplicitLowerBounds(wildcardType2);
            final Type[] array = implicitUpperBounds;
            for (int length = array.length, i = 0; i < length; ++i) {
                final Type substituteTypeVariables = substituteTypeVariables(array[i], map);
                final Type[] array2 = implicitUpperBounds2;
                for (int length2 = array2.length, j = 0; j < length2; ++j) {
                    if (!isAssignable(array2[j], substituteTypeVariables, map)) {
                        return false;
                    }
                }
            }
            final Type[] array3 = implicitLowerBounds;
            for (int length3 = array3.length, k = 0; k < length3; ++k) {
                final Type substituteTypeVariables2 = substituteTypeVariables(array3[k], map);
                final Type[] array4 = implicitLowerBounds2;
                for (int length4 = array4.length, l = 0; l < length4; ++l) {
                    if (!isAssignable(substituteTypeVariables2, array4[l], map)) {
                        return false;
                    }
                }
            }
            return true;
        }
        final Type[] array5 = implicitUpperBounds;
        for (int length5 = array5.length, n = 0; n < length5; ++n) {
            if (!isAssignable(obj, substituteTypeVariables(array5[n], map), map)) {
                return false;
            }
        }
        final Type[] array6 = implicitLowerBounds;
        for (int length6 = array6.length, n2 = 0; n2 < length6; ++n2) {
            if (!isAssignable(substituteTypeVariables(array6[n2], map), obj, map)) {
                return false;
            }
        }
        return true;
    }
    
    private static boolean isAssignable(final Type type, final TypeVariable<?> typeVariable, final Map<TypeVariable<?>, Type> map) {
        if (type == null) {
            return true;
        }
        if (typeVariable == null) {
            return false;
        }
        if (typeVariable.equals(type)) {
            return true;
        }
        if (type instanceof TypeVariable) {
            final Type[] implicitBounds = getImplicitBounds((TypeVariable<?>)type);
            for (int length = implicitBounds.length, i = 0; i < length; ++i) {
                if (isAssignable(implicitBounds[i], typeVariable, map)) {
                    return true;
                }
            }
        }
        if (type instanceof Class || type instanceof ParameterizedType || type instanceof GenericArrayType || type instanceof WildcardType) {
            return false;
        }
        throw new IllegalStateException("found an unhandled type: " + type);
    }
    
    private static Type substituteTypeVariables(final Type obj, final Map<TypeVariable<?>, Type> map) {
        if (!(obj instanceof TypeVariable) || map == null) {
            return obj;
        }
        final Type type = map.get(obj);
        if (type == null) {
            throw new IllegalArgumentException("missing assignment type for type variable " + obj);
        }
        return type;
    }
    
    public static Map<TypeVariable<?>, Type> getTypeArguments(final ParameterizedType parameterizedType) {
        return getTypeArguments(parameterizedType, getRawType(parameterizedType), null);
    }
    
    public static Map<TypeVariable<?>, Type> getTypeArguments(final Type type, final Class<?> clazz) {
        return getTypeArguments(type, clazz, null);
    }
    
    private static Map<TypeVariable<?>, Type> getTypeArguments(final Type obj, final Class<?> clazz, final Map<TypeVariable<?>, Type> map) {
        if (obj instanceof Class) {
            return getTypeArguments((Class<?>)obj, clazz, map);
        }
        if (obj instanceof ParameterizedType) {
            return getTypeArguments((ParameterizedType)obj, clazz, map);
        }
        if (obj instanceof GenericArrayType) {
            return getTypeArguments(((GenericArrayType)obj).getGenericComponentType(), clazz.isArray() ? clazz.getComponentType() : clazz, map);
        }
        if (obj instanceof WildcardType) {
            for (final Type type : getImplicitUpperBounds((WildcardType)obj)) {
                if (isAssignable(type, clazz)) {
                    return getTypeArguments(type, clazz, map);
                }
            }
            return null;
        }
        if (obj instanceof TypeVariable) {
            for (final Type type2 : getImplicitBounds((TypeVariable<?>)obj)) {
                if (isAssignable(type2, clazz)) {
                    return getTypeArguments(type2, clazz, map);
                }
            }
            return null;
        }
        throw new IllegalStateException("found an unhandled type: " + obj);
    }
    
    private static Map<TypeVariable<?>, Type> getTypeArguments(final ParameterizedType parameterizedType, final Class<?> clazz, final Map<TypeVariable<?>, Type> m) {
        final Class<?> rawType = getRawType(parameterizedType);
        if (!isAssignable(rawType, clazz)) {
            return null;
        }
        final Type ownerType = parameterizedType.getOwnerType();
        Map<TypeVariable<?>, Type> typeArguments;
        if (ownerType instanceof ParameterizedType) {
            final ParameterizedType parameterizedType2 = (ParameterizedType)ownerType;
            typeArguments = getTypeArguments(parameterizedType2, getRawType(parameterizedType2), m);
        }
        else {
            typeArguments = (Map<TypeVariable<?>, Type>)((m == null) ? new HashMap<TypeVariable<Class<?>>, Type>() : new HashMap<TypeVariable<Class<?>>, Type>((Map<? extends TypeVariable<Class<?>>, ? extends Type>)m));
        }
        final Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
        final TypeVariable<Class<?>>[] typeParameters = rawType.getTypeParameters();
        for (int i = 0; i < typeParameters.length; ++i) {
            final Type type = actualTypeArguments[i];
            typeArguments.put(typeParameters[i], typeArguments.containsKey(type) ? typeArguments.get(type) : type);
        }
        if (clazz.equals(rawType)) {
            return typeArguments;
        }
        return getTypeArguments(getClosestParentType(rawType, clazz), clazz, typeArguments);
    }
    
    private static Map<TypeVariable<?>, Type> getTypeArguments(Class<?> primitiveToWrapper, final Class<?> clazz, final Map<TypeVariable<?>, Type> m) {
        if (!isAssignable(primitiveToWrapper, clazz)) {
            return null;
        }
        if (primitiveToWrapper.isPrimitive()) {
            if (clazz.isPrimitive()) {
                return new HashMap<TypeVariable<?>, Type>();
            }
            primitiveToWrapper = ClassUtils.primitiveToWrapper(primitiveToWrapper);
        }
        final HashMap<TypeVariable<?>, Type> hashMap = (m == null) ? new HashMap<TypeVariable<?>, Type>() : new HashMap<TypeVariable<?>, Type>(m);
        if (clazz.equals(primitiveToWrapper)) {
            return hashMap;
        }
        return getTypeArguments(getClosestParentType(primitiveToWrapper, clazz), clazz, hashMap);
    }
    
    public static Map<TypeVariable<?>, Type> determineTypeArguments(final Class<?> clazz, final ParameterizedType parameterizedType) {
        Validate.notNull(clazz, "cls is null", new Object[0]);
        Validate.notNull(parameterizedType, "superType is null", new Object[0]);
        final Class<?> rawType = getRawType(parameterizedType);
        if (!isAssignable(clazz, rawType)) {
            return null;
        }
        if (clazz.equals(rawType)) {
            return getTypeArguments(parameterizedType, rawType, null);
        }
        final Type closestParentType = getClosestParentType(clazz, rawType);
        if (closestParentType instanceof Class) {
            return determineTypeArguments((Class<?>)closestParentType, parameterizedType);
        }
        final ParameterizedType parameterizedType2 = (ParameterizedType)closestParentType;
        final Map<TypeVariable<?>, Type> determineTypeArguments = determineTypeArguments(getRawType(parameterizedType2), parameterizedType);
        mapTypeVariablesToArguments(clazz, parameterizedType2, determineTypeArguments);
        return determineTypeArguments;
    }
    
    private static <T> void mapTypeVariablesToArguments(final Class<T> clazz, final ParameterizedType parameterizedType, final Map<TypeVariable<?>, Type> map) {
        final Type ownerType = parameterizedType.getOwnerType();
        if (ownerType instanceof ParameterizedType) {
            mapTypeVariablesToArguments((Class<Object>)clazz, (ParameterizedType)ownerType, map);
        }
        final Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
        final TypeVariable<Class<?>>[] typeParameters = getRawType(parameterizedType).getTypeParameters();
        final List<TypeVariable<Class<Object>>> list = Arrays.asList((TypeVariable<Class<Object>>[])clazz.getTypeParameters());
        for (int i = 0; i < actualTypeArguments.length; ++i) {
            final TypeVariable<Class<?>> typeVariable = typeParameters[i];
            final Type type = actualTypeArguments[i];
            if (list.contains(type) && map.containsKey(typeVariable)) {
                map.put((TypeVariable<?>)type, map.get(typeVariable));
            }
        }
    }
    
    private static Type getClosestParentType(final Class<?> clazz, final Class<?> clazz2) {
        if (clazz2.isInterface()) {
            final Type[] genericInterfaces = clazz.getGenericInterfaces();
            Type type = null;
            for (final Type obj : genericInterfaces) {
                Class<?> rawType;
                if (obj instanceof ParameterizedType) {
                    rawType = getRawType((ParameterizedType)obj);
                }
                else {
                    if (!(obj instanceof Class)) {
                        throw new IllegalStateException("Unexpected generic interface type found: " + obj);
                    }
                    rawType = (Class<?>)obj;
                }
                if (isAssignable(rawType, clazz2) && isAssignable(type, (Type)rawType)) {
                    type = obj;
                }
            }
            if (type != null) {
                return type;
            }
        }
        return clazz.getGenericSuperclass();
    }
    
    public static boolean isInstance(final Object o, final Type type) {
        return type != null && ((o == null) ? (!(type instanceof Class) || !((Class)type).isPrimitive()) : isAssignable(o.getClass(), type, null));
    }
    
    public static Type[] normalizeUpperBounds(final Type[] array) {
        Validate.notNull(array, "null value specified for bounds array", new Object[0]);
        if (array.length < 2) {
            return array;
        }
        final HashSet<Type> set = new HashSet<Type>(array.length);
        for (final Type type : array) {
            boolean b = false;
            for (final Type type2 : array) {
                if (type != type2 && isAssignable(type2, type, null)) {
                    b = true;
                    break;
                }
            }
            if (!b) {
                set.add(type);
            }
        }
        return set.toArray(new Type[set.size()]);
    }
    
    public static Type[] getImplicitBounds(final TypeVariable<?> typeVariable) {
        Validate.notNull(typeVariable, "typeVariable is null", new Object[0]);
        final Type[] bounds = typeVariable.getBounds();
        return (bounds.length == 0) ? new Type[] { Object.class } : normalizeUpperBounds(bounds);
    }
    
    public static Type[] getImplicitUpperBounds(final WildcardType wildcardType) {
        Validate.notNull(wildcardType, "wildcardType is null", new Object[0]);
        final Type[] upperBounds = wildcardType.getUpperBounds();
        return (upperBounds.length == 0) ? new Type[] { Object.class } : normalizeUpperBounds(upperBounds);
    }
    
    public static Type[] getImplicitLowerBounds(final WildcardType wildcardType) {
        Validate.notNull(wildcardType, "wildcardType is null", new Object[0]);
        final Type[] lowerBounds = wildcardType.getLowerBounds();
        return (lowerBounds.length == 0) ? new Type[] { null } : lowerBounds;
    }
    
    public static boolean typesSatisfyVariables(final Map<TypeVariable<?>, Type> map) {
        Validate.notNull(map, "typeVarAssigns is null", new Object[0]);
        for (final Map.Entry<TypeVariable<?>, Type> entry : map.entrySet()) {
            final TypeVariable<?> typeVariable = entry.getKey();
            final Type type = entry.getValue();
            final Type[] implicitBounds = getImplicitBounds(typeVariable);
            for (int length = implicitBounds.length, i = 0; i < length; ++i) {
                if (!isAssignable(type, substituteTypeVariables(implicitBounds[i], map), map)) {
                    return false;
                }
            }
        }
        return true;
    }
    
    private static Class<?> getRawType(final ParameterizedType parameterizedType) {
        final Type rawType = parameterizedType.getRawType();
        if (!(rawType instanceof Class)) {
            throw new IllegalStateException("Wait... What!? Type of rawType: " + rawType);
        }
        return (Class<?>)rawType;
    }
    
    public static Class<?> getRawType(final Type obj, final Type type) {
        if (obj instanceof Class) {
            return (Class<?>)obj;
        }
        if (obj instanceof ParameterizedType) {
            return getRawType((ParameterizedType)obj);
        }
        if (obj instanceof TypeVariable) {
            if (type == null) {
                return null;
            }
            final Class<?> genericDeclaration = ((TypeVariable)obj).getGenericDeclaration();
            if (!(genericDeclaration instanceof Class)) {
                return null;
            }
            final Map<TypeVariable<?>, Type> typeArguments = getTypeArguments(type, genericDeclaration);
            if (typeArguments == null) {
                return null;
            }
            final Type type2 = typeArguments.get(obj);
            if (type2 == null) {
                return null;
            }
            return getRawType(type2, type);
        }
        else {
            if (obj instanceof GenericArrayType) {
                return Array.newInstance(getRawType(((GenericArrayType)obj).getGenericComponentType(), type), 0).getClass();
            }
            if (obj instanceof WildcardType) {
                return null;
            }
            throw new IllegalArgumentException("unknown type: " + obj);
        }
    }
    
    public static boolean isArrayType(final Type type) {
        return type instanceof GenericArrayType || (type instanceof Class && ((Class)type).isArray());
    }
    
    public static Type getArrayComponentType(final Type type) {
        if (type instanceof Class) {
            final Class clazz = (Class)type;
            return clazz.isArray() ? clazz.getComponentType() : null;
        }
        if (type instanceof GenericArrayType) {
            return ((GenericArrayType)type).getGenericComponentType();
        }
        return null;
    }
    
    public static Type unrollVariables(Map<TypeVariable<?>, Type> emptyMap, final Type type) {
        if (emptyMap == null) {
            emptyMap = Collections.emptyMap();
        }
        if (containsTypeVariables(type)) {
            if (type instanceof TypeVariable) {
                return unrollVariables(emptyMap, emptyMap.get(type));
            }
            if (type instanceof ParameterizedType) {
                final ParameterizedType parameterizedType = (ParameterizedType)type;
                Map<TypeVariable<?>, Type> map;
                if (parameterizedType.getOwnerType() == null) {
                    map = emptyMap;
                }
                else {
                    map = new HashMap<TypeVariable<?>, Type>(emptyMap);
                    map.putAll(getTypeArguments(parameterizedType));
                }
                final Type[] actualTypeArguments = parameterizedType.getActualTypeArguments();
                for (int i = 0; i < actualTypeArguments.length; ++i) {
                    final Type unrollVariables = unrollVariables(map, actualTypeArguments[i]);
                    if (unrollVariables != null) {
                        actualTypeArguments[i] = unrollVariables;
                    }
                }
                return parameterizeWithOwner(parameterizedType.getOwnerType(), (Class<?>)parameterizedType.getRawType(), actualTypeArguments);
            }
            if (type instanceof WildcardType) {
                final WildcardType wildcardType = (WildcardType)type;
                return wildcardType().withUpperBounds(unrollBounds(emptyMap, wildcardType.getUpperBounds())).withLowerBounds(unrollBounds(emptyMap, wildcardType.getLowerBounds())).build();
            }
        }
        return type;
    }
    
    private static Type[] unrollBounds(final Map<TypeVariable<?>, Type> map, final Type[] array) {
        Type[] array2 = array;
        for (int i = 0; i < array2.length; ++i) {
            final Type unrollVariables = unrollVariables(map, array2[i]);
            if (unrollVariables == null) {
                array2 = ArrayUtils.remove(array2, i--);
            }
            else {
                array2[i] = unrollVariables;
            }
        }
        return array2;
    }
    
    public static boolean containsTypeVariables(final Type type) {
        if (type instanceof TypeVariable) {
            return true;
        }
        if (type instanceof Class) {
            return ((Class)type).getTypeParameters().length > 0;
        }
        if (type instanceof ParameterizedType) {
            final Type[] actualTypeArguments = ((ParameterizedType)type).getActualTypeArguments();
            for (int length = actualTypeArguments.length, i = 0; i < length; ++i) {
                if (containsTypeVariables(actualTypeArguments[i])) {
                    return true;
                }
            }
            return false;
        }
        if (type instanceof WildcardType) {
            final WildcardType wildcardType = (WildcardType)type;
            return containsTypeVariables(getImplicitLowerBounds(wildcardType)[0]) || containsTypeVariables(getImplicitUpperBounds(wildcardType)[0]);
        }
        return false;
    }
    
    public static final ParameterizedType parameterize(final Class<?> clazz, final Type... array) {
        return parameterizeWithOwner(null, clazz, array);
    }
    
    public static final ParameterizedType parameterize(final Class<?> clazz, final Map<TypeVariable<?>, Type> map) {
        Validate.notNull(clazz, "raw class is null", new Object[0]);
        Validate.notNull(map, "typeArgMappings is null", new Object[0]);
        return parameterizeWithOwner(null, clazz, extractTypeArgumentsFrom(map, clazz.getTypeParameters()));
    }
    
    public static final ParameterizedType parameterizeWithOwner(final Type type, final Class<?> clazz, final Type... array) {
        Validate.notNull(clazz, "raw class is null", new Object[0]);
        Type enclosingClass;
        if (clazz.getEnclosingClass() == null) {
            Validate.isTrue(type == null, "no owner allowed for top-level %s", clazz);
            enclosingClass = null;
        }
        else if (type == null) {
            enclosingClass = clazz.getEnclosingClass();
        }
        else {
            Validate.isTrue(isAssignable(type, clazz.getEnclosingClass()), "%s is invalid owner type for parameterized %s", type, clazz);
            enclosingClass = type;
        }
        Validate.noNullElements(array, "null type argument at index %s", new Object[0]);
        Validate.isTrue(clazz.getTypeParameters().length == array.length, "invalid number of type parameters specified: expected %d, got %d", clazz.getTypeParameters().length, array.length);
        return new ParameterizedTypeImpl((Class)clazz, enclosingClass, array);
    }
    
    public static final ParameterizedType parameterizeWithOwner(final Type type, final Class<?> clazz, final Map<TypeVariable<?>, Type> map) {
        Validate.notNull(clazz, "raw class is null", new Object[0]);
        Validate.notNull(map, "typeArgMappings is null", new Object[0]);
        return parameterizeWithOwner(type, clazz, extractTypeArgumentsFrom(map, clazz.getTypeParameters()));
    }
    
    private static Type[] extractTypeArgumentsFrom(final Map<TypeVariable<?>, Type> map, final TypeVariable<?>[] array) {
        final Type[] array2 = new Type[array.length];
        int n = 0;
        for (final TypeVariable<?> typeVariable : array) {
            Validate.isTrue(map.containsKey(typeVariable), "missing argument mapping for %s", toString((Type)typeVariable));
            array2[n++] = map.get(typeVariable);
        }
        return array2;
    }
    
    public static WildcardTypeBuilder wildcardType() {
        return new WildcardTypeBuilder();
    }
    
    public static GenericArrayType genericArrayType(final Type type) {
        return new GenericArrayTypeImpl((Type)Validate.notNull(type, "componentType is null", new Object[0]));
    }
    
    public static boolean equals(final Type a, final Type b) {
        if (Objects.equals(a, b)) {
            return true;
        }
        if (a instanceof ParameterizedType) {
            return equals((ParameterizedType)a, b);
        }
        if (a instanceof GenericArrayType) {
            return equals((GenericArrayType)a, b);
        }
        return a instanceof WildcardType && equals((WildcardType)a, b);
    }
    
    private static boolean equals(final ParameterizedType parameterizedType, final Type type) {
        if (type instanceof ParameterizedType) {
            final ParameterizedType parameterizedType2 = (ParameterizedType)type;
            if (equals(parameterizedType.getRawType(), parameterizedType2.getRawType()) && equals(parameterizedType.getOwnerType(), parameterizedType2.getOwnerType())) {
                return equals(parameterizedType.getActualTypeArguments(), parameterizedType2.getActualTypeArguments());
            }
        }
        return false;
    }
    
    private static boolean equals(final GenericArrayType genericArrayType, final Type type) {
        return type instanceof GenericArrayType && equals(genericArrayType.getGenericComponentType(), ((GenericArrayType)type).getGenericComponentType());
    }
    
    private static boolean equals(final WildcardType wildcardType, final Type type) {
        if (type instanceof WildcardType) {
            final WildcardType wildcardType2 = (WildcardType)type;
            return equals(getImplicitLowerBounds(wildcardType), getImplicitLowerBounds(wildcardType2)) && equals(getImplicitUpperBounds(wildcardType), getImplicitUpperBounds(wildcardType2));
        }
        return false;
    }
    
    private static boolean equals(final Type[] array, final Type[] array2) {
        if (array.length == array2.length) {
            for (int i = 0; i < array.length; ++i) {
                if (!equals(array[i], array2[i])) {
                    return false;
                }
            }
            return true;
        }
        return false;
    }
    
    public static String toString(final Type type) {
        Validate.notNull(type);
        if (type instanceof Class) {
            return classToString((Class<?>)type);
        }
        if (type instanceof ParameterizedType) {
            return parameterizedTypeToString((ParameterizedType)type);
        }
        if (type instanceof WildcardType) {
            return wildcardTypeToString((WildcardType)type);
        }
        if (type instanceof TypeVariable) {
            return typeVariableToString((TypeVariable<?>)type);
        }
        if (type instanceof GenericArrayType) {
            return genericArrayTypeToString((GenericArrayType)type);
        }
        throw new IllegalArgumentException(ObjectUtils.identityToString(type));
    }
    
    public static String toLongString(final TypeVariable<?> typeVariable) {
        Validate.notNull(typeVariable, "var is null", new Object[0]);
        final StringBuilder sb = new StringBuilder();
        final Object genericDeclaration = typeVariable.getGenericDeclaration();
        if (genericDeclaration instanceof Class) {
            Class<?> enclosingClass;
            for (enclosingClass = (Class<?>)genericDeclaration; enclosingClass.getEnclosingClass() != null; enclosingClass = enclosingClass.getEnclosingClass()) {
                sb.insert(0, enclosingClass.getSimpleName()).insert(0, '.');
            }
            sb.insert(0, enclosingClass.getName());
        }
        else if (genericDeclaration instanceof Type) {
            sb.append(toString((Type)genericDeclaration));
        }
        else {
            sb.append(genericDeclaration);
        }
        return sb.append(':').append(typeVariableToString(typeVariable)).toString();
    }
    
    public static <T> Typed<T> wrap(final Type type) {
        return new Typed<T>() {
            @Override
            public Type getType() {
                return type;
            }
        };
    }
    
    public static <T> Typed<T> wrap(final Class<T> clazz) {
        return wrap((Type)clazz);
    }
    
    private static String classToString(final Class<?> clazz) {
        if (clazz.isArray()) {
            return toString((Type)clazz.getComponentType()) + "[]";
        }
        final StringBuilder sb = new StringBuilder();
        if (clazz.getEnclosingClass() != null) {
            sb.append(classToString(clazz.getEnclosingClass())).append('.').append(clazz.getSimpleName());
        }
        else {
            sb.append(clazz.getName());
        }
        if (clazz.getTypeParameters().length > 0) {
            sb.append('<');
            appendAllTo(sb, ", ", clazz.getTypeParameters());
            sb.append('>');
        }
        return sb.toString();
    }
    
    private static String typeVariableToString(final TypeVariable<?> typeVariable) {
        final StringBuilder sb = new StringBuilder(typeVariable.getName());
        final Type[] bounds = typeVariable.getBounds();
        if (bounds.length > 0 && (bounds.length != 1 || !Object.class.equals(bounds[0]))) {
            sb.append(" extends ");
            appendAllTo(sb, " & ", typeVariable.getBounds());
        }
        return sb.toString();
    }
    
    private static String parameterizedTypeToString(final ParameterizedType parameterizedType) {
        final StringBuilder sb = new StringBuilder();
        final Type ownerType = parameterizedType.getOwnerType();
        final Class clazz = (Class)parameterizedType.getRawType();
        if (ownerType == null) {
            sb.append(clazz.getName());
        }
        else {
            if (ownerType instanceof Class) {
                sb.append(((Class)ownerType).getName());
            }
            else {
                sb.append(ownerType.toString());
            }
            sb.append('.').append(clazz.getSimpleName());
        }
        final int[] recursiveTypes = findRecursiveTypes(parameterizedType);
        if (recursiveTypes.length > 0) {
            appendRecursiveTypes(sb, recursiveTypes, parameterizedType.getActualTypeArguments());
        }
        else {
            appendAllTo(sb.append('<'), ", ", parameterizedType.getActualTypeArguments()).append('>');
        }
        return sb.toString();
    }
    
    private static void appendRecursiveTypes(final StringBuilder sb, final int[] array, final Type[] array2) {
        for (int i = 0; i < array.length; ++i) {
            appendAllTo(sb.append('<'), ", ", array2[i].toString()).append('>');
        }
        final Type[] array3 = ArrayUtils.removeAll(array2, array);
        if (array3.length > 0) {
            appendAllTo(sb.append('<'), ", ", array3).append('>');
        }
    }
    
    private static int[] findRecursiveTypes(final ParameterizedType parameterizedType) {
        final Type[] array = Arrays.copyOf(parameterizedType.getActualTypeArguments(), parameterizedType.getActualTypeArguments().length);
        int[] add = new int[0];
        for (int i = 0; i < array.length; ++i) {
            if (array[i] instanceof TypeVariable && containsVariableTypeSameParametrizedTypeBound((TypeVariable<?>)array[i], parameterizedType)) {
                add = ArrayUtils.add(add, i);
            }
        }
        return add;
    }
    
    private static boolean containsVariableTypeSameParametrizedTypeBound(final TypeVariable<?> typeVariable, final ParameterizedType parameterizedType) {
        return ArrayUtils.contains(typeVariable.getBounds(), parameterizedType);
    }
    
    private static String wildcardTypeToString(final WildcardType wildcardType) {
        final StringBuilder append = new StringBuilder().append('?');
        final Type[] lowerBounds = wildcardType.getLowerBounds();
        final Type[] upperBounds = wildcardType.getUpperBounds();
        if (lowerBounds.length > 1 || (lowerBounds.length == 1 && lowerBounds[0] != null)) {
            appendAllTo(append.append(" super "), " & ", lowerBounds);
        }
        else if (upperBounds.length > 1 || (upperBounds.length == 1 && !Object.class.equals(upperBounds[0]))) {
            appendAllTo(append.append(" extends "), " & ", upperBounds);
        }
        return append.toString();
    }
    
    private static String genericArrayTypeToString(final GenericArrayType genericArrayType) {
        return String.format("%s[]", toString(genericArrayType.getGenericComponentType()));
    }
    
    private static <T> StringBuilder appendAllTo(final StringBuilder sb, final String str, final T... array) {
        Validate.notEmpty(Validate.noNullElements(array));
        if (array.length > 0) {
            sb.append(toString(array[0]));
            for (int i = 1; i < array.length; ++i) {
                sb.append(str).append(toString(array[i]));
            }
        }
        return sb;
    }
    
    private static <T> String toString(final T t) {
        return (t instanceof Type) ? toString((Type)t) : t.toString();
    }
    
    static {
        WILDCARD_ALL = wildcardType().withUpperBounds(Object.class).build();
    }
    
    public static class WildcardTypeBuilder implements Builder<WildcardType>
    {
        private Type[] upperBounds;
        private Type[] lowerBounds;
        
        private WildcardTypeBuilder() {
        }
        
        public WildcardTypeBuilder withUpperBounds(final Type... upperBounds) {
            this.upperBounds = upperBounds;
            return this;
        }
        
        public WildcardTypeBuilder withLowerBounds(final Type... lowerBounds) {
            this.lowerBounds = lowerBounds;
            return this;
        }
        
        @Override
        public WildcardType build() {
            return new WildcardTypeImpl(this.upperBounds, this.lowerBounds);
        }
    }
    
    private static final class GenericArrayTypeImpl implements GenericArrayType
    {
        private final Type componentType;
        
        private GenericArrayTypeImpl(final Type componentType) {
            this.componentType = componentType;
        }
        
        @Override
        public Type getGenericComponentType() {
            return this.componentType;
        }
        
        @Override
        public String toString() {
            return TypeUtils.toString((Type)this);
        }
        
        @Override
        public boolean equals(final Object o) {
            return o == this || (o instanceof GenericArrayType && equals(this, (Type)o));
        }
        
        @Override
        public int hashCode() {
            return 0x430 | this.componentType.hashCode();
        }
    }
    
    private static final class ParameterizedTypeImpl implements ParameterizedType
    {
        private final Class<?> raw;
        private final Type useOwner;
        private final Type[] typeArguments;
        
        private ParameterizedTypeImpl(final Class<?> raw, final Type useOwner, final Type[] original) {
            this.raw = raw;
            this.useOwner = useOwner;
            this.typeArguments = Arrays.copyOf(original, original.length, (Class<? extends Type[]>)Type[].class);
        }
        
        @Override
        public Type getRawType() {
            return this.raw;
        }
        
        @Override
        public Type getOwnerType() {
            return this.useOwner;
        }
        
        @Override
        public Type[] getActualTypeArguments() {
            return this.typeArguments.clone();
        }
        
        @Override
        public String toString() {
            return TypeUtils.toString((Type)this);
        }
        
        @Override
        public boolean equals(final Object o) {
            return o == this || (o instanceof ParameterizedType && equals(this, (Type)o));
        }
        
        @Override
        public int hashCode() {
            return ((0x470 | this.raw.hashCode()) << 4 | Objects.hashCode(this.useOwner)) << 8 | Arrays.hashCode(this.typeArguments);
        }
    }
    
    private static final class WildcardTypeImpl implements WildcardType
    {
        private static final Type[] EMPTY_BOUNDS;
        private final Type[] upperBounds;
        private final Type[] lowerBounds;
        
        private WildcardTypeImpl(final Type[] array, final Type[] array2) {
            this.upperBounds = ObjectUtils.defaultIfNull(array, WildcardTypeImpl.EMPTY_BOUNDS);
            this.lowerBounds = ObjectUtils.defaultIfNull(array2, WildcardTypeImpl.EMPTY_BOUNDS);
        }
        
        @Override
        public Type[] getUpperBounds() {
            return this.upperBounds.clone();
        }
        
        @Override
        public Type[] getLowerBounds() {
            return this.lowerBounds.clone();
        }
        
        @Override
        public String toString() {
            return TypeUtils.toString((Type)this);
        }
        
        @Override
        public boolean equals(final Object o) {
            return o == this || (o instanceof WildcardType && equals(this, (Type)o));
        }
        
        @Override
        public int hashCode() {
            return (0x4900 | Arrays.hashCode(this.upperBounds)) << 8 | Arrays.hashCode(this.lowerBounds);
        }
        
        static {
            EMPTY_BOUNDS = new Type[0];
        }
    }
}

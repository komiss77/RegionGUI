// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.math;

import net.crytec.regiongui.libs.apache.commons.Validate;

public class IEEE754rUtils
{
    public static double min(final double... array) {
        Validate.isTrue(array != null, "The Array must not be null", new Object[0]);
        Validate.isTrue(array.length != 0, "Array cannot be empty.", new Object[0]);
        double min = array[0];
        for (int i = 1; i < array.length; ++i) {
            min = min(array[i], min);
        }
        return min;
    }
    
    public static float min(final float... array) {
        Validate.isTrue(array != null, "The Array must not be null", new Object[0]);
        Validate.isTrue(array.length != 0, "Array cannot be empty.", new Object[0]);
        float min = array[0];
        for (int i = 1; i < array.length; ++i) {
            min = min(array[i], min);
        }
        return min;
    }
    
    public static double min(final double n, final double n2, final double n3) {
        return min(min(n, n2), n3);
    }
    
    public static double min(final double n, final double n2) {
        if (Double.isNaN(n)) {
            return n2;
        }
        if (Double.isNaN(n2)) {
            return n;
        }
        return Math.min(n, n2);
    }
    
    public static float min(final float n, final float n2, final float n3) {
        return min(min(n, n2), n3);
    }
    
    public static float min(final float n, final float n2) {
        if (Float.isNaN(n)) {
            return n2;
        }
        if (Float.isNaN(n2)) {
            return n;
        }
        return Math.min(n, n2);
    }
    
    public static double max(final double... array) {
        Validate.isTrue(array != null, "The Array must not be null", new Object[0]);
        Validate.isTrue(array.length != 0, "Array cannot be empty.", new Object[0]);
        double max = array[0];
        for (int i = 1; i < array.length; ++i) {
            max = max(array[i], max);
        }
        return max;
    }
    
    public static float max(final float... array) {
        Validate.isTrue(array != null, "The Array must not be null", new Object[0]);
        Validate.isTrue(array.length != 0, "Array cannot be empty.", new Object[0]);
        float max = array[0];
        for (int i = 1; i < array.length; ++i) {
            max = max(array[i], max);
        }
        return max;
    }
    
    public static double max(final double n, final double n2, final double n3) {
        return max(max(n, n2), n3);
    }
    
    public static double max(final double n, final double n2) {
        if (Double.isNaN(n)) {
            return n2;
        }
        if (Double.isNaN(n2)) {
            return n;
        }
        return Math.max(n, n2);
    }
    
    public static float max(final float n, final float n2, final float n3) {
        return max(max(n, n2), n3);
    }
    
    public static float max(final float n, final float n2) {
        if (Float.isNaN(n)) {
            return n2;
        }
        if (Float.isNaN(n2)) {
            return n;
        }
        return Math.max(n, n2);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

public interface Computable<I, O>
{
    O compute(final I p0) throws InterruptedException;
}

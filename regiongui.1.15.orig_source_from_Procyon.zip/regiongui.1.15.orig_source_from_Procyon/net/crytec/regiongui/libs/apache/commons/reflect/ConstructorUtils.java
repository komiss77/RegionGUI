// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.reflect;

import java.lang.reflect.Modifier;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Member;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.lang.reflect.Constructor;
import net.crytec.regiongui.libs.apache.commons.ClassUtils;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;

public class ConstructorUtils
{
    public static <T> T invokeConstructor(final Class<T> clazz, Object... nullToEmpty) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        return invokeConstructor(clazz, nullToEmpty, ClassUtils.toClass(nullToEmpty));
    }
    
    public static <T> T invokeConstructor(final Class<T> clazz, Object[] initargs, final Class<?>[] array) {
        initargs = ArrayUtils.nullToEmpty(initargs);
        final Constructor<T> matchingAccessibleConstructor = getMatchingAccessibleConstructor(clazz, ArrayUtils.nullToEmpty(array));
        if (matchingAccessibleConstructor == null) {
            throw new NoSuchMethodException("No such accessible constructor on object: " + clazz.getName());
        }
        if (matchingAccessibleConstructor.isVarArgs()) {
            initargs = MethodUtils.getVarArgs(initargs, matchingAccessibleConstructor.getParameterTypes());
        }
        return matchingAccessibleConstructor.newInstance(initargs);
    }
    
    public static <T> T invokeExactConstructor(final Class<T> clazz, Object... nullToEmpty) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        return invokeExactConstructor(clazz, nullToEmpty, ClassUtils.toClass(nullToEmpty));
    }
    
    public static <T> T invokeExactConstructor(final Class<T> clazz, Object[] nullToEmpty, final Class<?>[] array) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        final Constructor<T> accessibleConstructor = getAccessibleConstructor(clazz, ArrayUtils.nullToEmpty(array));
        if (accessibleConstructor == null) {
            throw new NoSuchMethodException("No such accessible constructor on object: " + clazz.getName());
        }
        return accessibleConstructor.newInstance(nullToEmpty);
    }
    
    public static <T> Constructor<T> getAccessibleConstructor(final Class<T> clazz, final Class<?>... parameterTypes) {
        Validate.notNull(clazz, "class cannot be null", new Object[0]);
        try {
            return getAccessibleConstructor(clazz.getConstructor(parameterTypes));
        }
        catch (NoSuchMethodException ex) {
            return null;
        }
    }
    
    public static <T> Constructor<T> getAccessibleConstructor(final Constructor<T> constructor) {
        Validate.notNull(constructor, "constructor cannot be null", new Object[0]);
        return (MemberUtils.isAccessible(constructor) && isAccessible(constructor.getDeclaringClass())) ? constructor : null;
    }
    
    public static <T> Constructor<T> getMatchingAccessibleConstructor(final Class<T> clazz, final Class<?>... parameterTypes) {
        Validate.notNull(clazz, "class cannot be null", new Object[0]);
        try {
            final Constructor<T> constructor = clazz.getConstructor(parameterTypes);
            MemberUtils.setAccessibleWorkaround(constructor);
            return constructor;
        }
        catch (NoSuchMethodException ex) {
            Constructor<T> constructor2 = null;
            for (final Constructor constructor3 : clazz.getConstructors()) {
                if (MemberUtils.isMatchingConstructor(constructor3, parameterTypes)) {
                    final Constructor<T> accessibleConstructor = getAccessibleConstructor(constructor3);
                    if (accessibleConstructor != null) {
                        MemberUtils.setAccessibleWorkaround(accessibleConstructor);
                        if (constructor2 == null || MemberUtils.compareConstructorFit(accessibleConstructor, constructor2, parameterTypes) < 0) {
                            constructor2 = accessibleConstructor;
                        }
                    }
                }
            }
            return constructor2;
        }
    }
    
    private static boolean isAccessible(final Class<?> clazz) {
        for (Class<?> enclosingClass = clazz; enclosingClass != null; enclosingClass = enclosingClass.getEnclosingClass()) {
            if (!Modifier.isPublic(enclosingClass.getModifiers())) {
                return false;
            }
        }
        return true;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text.translate;

import java.io.Writer;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;

@Deprecated
public class AggregateTranslator extends CharSequenceTranslator
{
    private final CharSequenceTranslator[] translators;
    
    public AggregateTranslator(final CharSequenceTranslator... array) {
        this.translators = ArrayUtils.clone(array);
    }
    
    @Override
    public int translate(final CharSequence charSequence, final int n, final Writer writer) {
        final CharSequenceTranslator[] translators = this.translators;
        for (int length = translators.length, i = 0; i < length; ++i) {
            final int translate = translators[i].translate(charSequence, n, writer);
            if (translate != 0) {
                return translate;
            }
        }
        return 0;
    }
}

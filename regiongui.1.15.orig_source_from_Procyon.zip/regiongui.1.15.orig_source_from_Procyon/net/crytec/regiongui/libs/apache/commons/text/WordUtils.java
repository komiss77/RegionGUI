// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text;

import net.crytec.regiongui.libs.apache.commons.ArrayUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.crytec.regiongui.libs.apache.commons.StringUtils;

@Deprecated
public class WordUtils
{
    public static String wrap(final String s, final int n) {
        return wrap(s, n, null, false);
    }
    
    public static String wrap(final String s, final int n, final String s2, final boolean b) {
        return wrap(s, n, s2, b, " ");
    }
    
    public static String wrap(final String s, int n, String lineSeparator, final boolean b, String regex) {
        if (s == null) {
            return null;
        }
        if (lineSeparator == null) {
            lineSeparator = System.lineSeparator();
        }
        if (n < 1) {
            n = 1;
        }
        if (StringUtils.isBlank(regex)) {
            regex = " ";
        }
        final Pattern compile = Pattern.compile(regex);
        final int length = s.length();
        int i = 0;
        final StringBuilder sb = new StringBuilder(length + 32);
        while (i < length) {
            int n2 = -1;
            final Matcher matcher = compile.matcher(s.substring(i, Math.min((int)Math.min(2147483647L, i + n + 1L), length)));
            if (matcher.find()) {
                if (matcher.start() == 0) {
                    i += matcher.end();
                    continue;
                }
                n2 = matcher.start() + i;
            }
            if (length - i <= n) {
                break;
            }
            while (matcher.find()) {
                n2 = matcher.start() + i;
            }
            if (n2 >= i) {
                sb.append(s, i, n2);
                sb.append(lineSeparator);
                i = n2 + 1;
            }
            else if (b) {
                sb.append(s, i, n + i);
                sb.append(lineSeparator);
                i += n;
            }
            else {
                final Matcher matcher2 = compile.matcher(s.substring(i + n));
                if (matcher2.find()) {
                    n2 = matcher2.start() + i + n;
                }
                if (n2 >= 0) {
                    sb.append(s, i, n2);
                    sb.append(lineSeparator);
                    i = n2 + 1;
                }
                else {
                    sb.append(s, i, s.length());
                    i = length;
                }
            }
        }
        sb.append(s, i, s.length());
        return sb.toString();
    }
    
    public static String capitalize(final String s) {
        return capitalize(s, (char[])null);
    }
    
    public static String capitalize(final String s, final char... array) {
        final int n = (array == null) ? -1 : array.length;
        if (StringUtils.isEmpty(s) || n == 0) {
            return s;
        }
        final char[] charArray = s.toCharArray();
        int n2 = 1;
        for (int i = 0; i < charArray.length; ++i) {
            final char ch = charArray[i];
            if (isDelimiter(ch, array)) {
                n2 = 1;
            }
            else if (n2 != 0) {
                charArray[i] = Character.toTitleCase(ch);
                n2 = 0;
            }
        }
        return new String(charArray);
    }
    
    public static String capitalizeFully(final String s) {
        return capitalizeFully(s, (char[])null);
    }
    
    public static String capitalizeFully(String lowerCase, final char... array) {
        final int n = (array == null) ? -1 : array.length;
        if (StringUtils.isEmpty(lowerCase) || n == 0) {
            return lowerCase;
        }
        lowerCase = lowerCase.toLowerCase();
        return capitalize(lowerCase, array);
    }
    
    public static String uncapitalize(final String s) {
        return uncapitalize(s, (char[])null);
    }
    
    public static String uncapitalize(final String s, final char... array) {
        final int n = (array == null) ? -1 : array.length;
        if (StringUtils.isEmpty(s) || n == 0) {
            return s;
        }
        final char[] charArray = s.toCharArray();
        int n2 = 1;
        for (int i = 0; i < charArray.length; ++i) {
            final char ch = charArray[i];
            if (isDelimiter(ch, array)) {
                n2 = 1;
            }
            else if (n2 != 0) {
                charArray[i] = Character.toLowerCase(ch);
                n2 = 0;
            }
        }
        return new String(charArray);
    }
    
    public static String swapCase(final String s) {
        if (StringUtils.isEmpty(s)) {
            return s;
        }
        final char[] charArray = s.toCharArray();
        int whitespace = 1;
        for (int i = 0; i < charArray.length; ++i) {
            final char c = charArray[i];
            if (Character.isUpperCase(c)) {
                charArray[i] = Character.toLowerCase(c);
                whitespace = 0;
            }
            else if (Character.isTitleCase(c)) {
                charArray[i] = Character.toLowerCase(c);
                whitespace = 0;
            }
            else if (Character.isLowerCase(c)) {
                if (whitespace != 0) {
                    charArray[i] = Character.toTitleCase(c);
                    whitespace = 0;
                }
                else {
                    charArray[i] = Character.toUpperCase(c);
                }
            }
            else {
                whitespace = (Character.isWhitespace(c) ? 1 : 0);
            }
        }
        return new String(charArray);
    }
    
    public static String initials(final String s) {
        return initials(s, (char[])null);
    }
    
    public static String initials(final String s, final char... array) {
        if (StringUtils.isEmpty(s)) {
            return s;
        }
        if (array != null && array.length == 0) {
            return "";
        }
        final int length = s.length();
        final char[] value = new char[length / 2 + 1];
        int count = 0;
        int n = 1;
        for (int i = 0; i < length; ++i) {
            final char char1 = s.charAt(i);
            if (isDelimiter(char1, array)) {
                n = 1;
            }
            else if (n != 0) {
                value[count++] = char1;
                n = 0;
            }
        }
        return new String(value, 0, count);
    }
    
    public static boolean containsAllWords(final CharSequence input, final CharSequence... array) {
        if (StringUtils.isEmpty(input) || ArrayUtils.isEmpty(array)) {
            return false;
        }
        for (final CharSequence obj : array) {
            if (StringUtils.isBlank(obj)) {
                return false;
            }
            if (!Pattern.compile(".*\\b" + (Object)obj + "\\b.*").matcher(input).matches()) {
                return false;
            }
        }
        return true;
    }
    
    private static boolean isDelimiter(final char ch, final char[] array) {
        if (array == null) {
            return Character.isWhitespace(ch);
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (ch == array[i]) {
                return true;
            }
        }
        return false;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import java.util.concurrent.Executors;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.ExecutorService;

public abstract class BackgroundInitializer<T> implements ConcurrentInitializer<T>
{
    private ExecutorService externalExecutor;
    private ExecutorService executor;
    private Future<T> future;
    
    protected BackgroundInitializer() {
        this(null);
    }
    
    protected BackgroundInitializer(final ExecutorService externalExecutor) {
        this.setExternalExecutor(externalExecutor);
    }
    
    public final synchronized ExecutorService getExternalExecutor() {
        return this.externalExecutor;
    }
    
    public synchronized boolean isStarted() {
        return this.future != null;
    }
    
    public final synchronized void setExternalExecutor(final ExecutorService externalExecutor) {
        if (this.isStarted()) {
            throw new IllegalStateException("Cannot set ExecutorService after start()!");
        }
        this.externalExecutor = externalExecutor;
    }
    
    public synchronized boolean start() {
        if (!this.isStarted()) {
            this.executor = this.getExternalExecutor();
            ExecutorService executorService;
            if (this.executor == null) {
                executorService = (this.executor = this.createExecutor());
            }
            else {
                executorService = null;
            }
            this.future = this.executor.submit(this.createTask(executorService));
            return true;
        }
        return false;
    }
    
    @Override
    public T get() {
        try {
            return this.getFuture().get();
        }
        catch (ExecutionException ex) {
            ConcurrentUtils.handleCause(ex);
            return null;
        }
        catch (InterruptedException ex2) {
            Thread.currentThread().interrupt();
            throw new ConcurrentException(ex2);
        }
    }
    
    public synchronized Future<T> getFuture() {
        if (this.future == null) {
            throw new IllegalStateException("start() must be called first!");
        }
        return this.future;
    }
    
    protected final synchronized ExecutorService getActiveExecutor() {
        return this.executor;
    }
    
    protected int getTaskCount() {
        return 1;
    }
    
    protected abstract T initialize();
    
    private Callable<T> createTask(final ExecutorService executorService) {
        return new InitializationTask(executorService);
    }
    
    private ExecutorService createExecutor() {
        return Executors.newFixedThreadPool(this.getTaskCount());
    }
    
    private class InitializationTask implements Callable<T>
    {
        private final ExecutorService execFinally;
        
        InitializationTask(final ExecutorService execFinally) {
            this.execFinally = execFinally;
        }
        
        @Override
        public T call() {
            try {
                return BackgroundInitializer.this.initialize();
            }
            finally {
                if (this.execFinally != null) {
                    this.execFinally.shutdown();
                }
            }
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.builder;

import java.util.Iterator;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;
import java.util.Arrays;
import java.util.ArrayList;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.List;

public class DiffBuilder implements Builder<DiffResult>
{
    private final List<Diff<?>> diffs;
    private final boolean objectsTriviallyEqual;
    private final Object left;
    private final Object right;
    private final ToStringStyle style;
    
    public DiffBuilder(final Object left, final Object o, final ToStringStyle style, final boolean b) {
        Validate.isTrue(left != null, "lhs cannot be null", new Object[0]);
        Validate.isTrue(o != null, "rhs cannot be null", new Object[0]);
        this.diffs = new ArrayList<Diff<?>>();
        this.left = left;
        this.right = o;
        this.style = style;
        this.objectsTriviallyEqual = (b && (left == o || left.equals(o)));
    }
    
    public DiffBuilder(final Object o, final Object o2, final ToStringStyle toStringStyle) {
        this(o, o2, toStringStyle, true);
    }
    
    public DiffBuilder append(final String s, final boolean b, final boolean b2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (b != b2) {
            this.diffs.add(new Diff<Boolean>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Boolean getLeft() {
                    return b;
                }
                
                @Override
                public Boolean getRight() {
                    return b2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final boolean[] a, final boolean[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Boolean[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Boolean[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Boolean[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final byte b, final byte b2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (b != b2) {
            this.diffs.add(new Diff<Byte>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Byte getLeft() {
                    return b;
                }
                
                @Override
                public Byte getRight() {
                    return b2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final byte[] a, final byte[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Byte[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Byte[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Byte[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final char c, final char c2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (c != c2) {
            this.diffs.add(new Diff<Character>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Character getLeft() {
                    return c;
                }
                
                @Override
                public Character getRight() {
                    return c2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final char[] a, final char[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Character[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Character[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Character[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final double value, final double value2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (Double.doubleToLongBits(value) != Double.doubleToLongBits(value2)) {
            this.diffs.add(new Diff<Double>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Double getLeft() {
                    return value;
                }
                
                @Override
                public Double getRight() {
                    return value2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final double[] a, final double[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Double[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Double[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Double[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final float value, final float value2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (Float.floatToIntBits(value) != Float.floatToIntBits(value2)) {
            this.diffs.add(new Diff<Float>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Float getLeft() {
                    return value;
                }
                
                @Override
                public Float getRight() {
                    return value2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final float[] a, final float[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Float[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Float[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Float[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final int n, final int n2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (n != n2) {
            this.diffs.add(new Diff<Integer>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Integer getLeft() {
                    return n;
                }
                
                @Override
                public Integer getRight() {
                    return n2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final int[] a, final int[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Integer[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Integer[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Integer[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final long n, final long n2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (n != n2) {
            this.diffs.add(new Diff<Long>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Long getLeft() {
                    return n;
                }
                
                @Override
                public Long getRight() {
                    return n2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final long[] a, final long[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Long[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Long[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Long[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final short n, final short n2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (n != n2) {
            this.diffs.add(new Diff<Short>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Short getLeft() {
                    return n;
                }
                
                @Override
                public Short getRight() {
                    return n2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final short[] a, final short[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Short[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Short[] getLeft() {
                    return ArrayUtils.toObject(a);
                }
                
                @Override
                public Short[] getRight() {
                    return ArrayUtils.toObject(a2);
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String s, final Object o, final Object obj) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (o == obj) {
            return this;
        }
        Object o2;
        if (o != null) {
            o2 = o;
        }
        else {
            o2 = obj;
        }
        if (o2.getClass().isArray()) {
            if (o2 instanceof boolean[]) {
                return this.append(s, (boolean[])o, (boolean[])obj);
            }
            if (o2 instanceof byte[]) {
                return this.append(s, (byte[])o, (byte[])obj);
            }
            if (o2 instanceof char[]) {
                return this.append(s, (char[])o, (char[])obj);
            }
            if (o2 instanceof double[]) {
                return this.append(s, (double[])o, (double[])obj);
            }
            if (o2 instanceof float[]) {
                return this.append(s, (float[])o, (float[])obj);
            }
            if (o2 instanceof int[]) {
                return this.append(s, (int[])o, (int[])obj);
            }
            if (o2 instanceof long[]) {
                return this.append(s, (long[])o, (long[])obj);
            }
            if (o2 instanceof short[]) {
                return this.append(s, (short[])o, (short[])obj);
            }
            return this.append(s, (Object[])o, (Object[])obj);
        }
        else {
            if (o != null && o.equals(obj)) {
                return this;
            }
            this.diffs.add(new Diff<Object>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Object getLeft() {
                    return o;
                }
                
                @Override
                public Object getRight() {
                    return obj;
                }
            });
            return this;
        }
    }
    
    public DiffBuilder append(final String s, final Object[] a, final Object[] a2) {
        this.validateFieldNameNotNull(s);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        if (!Arrays.equals(a, a2)) {
            this.diffs.add(new Diff<Object[]>(s) {
                private static final long serialVersionUID = 1L;
                
                @Override
                public Object[] getLeft() {
                    return a;
                }
                
                @Override
                public Object[] getRight() {
                    return a2;
                }
            });
        }
        return this;
    }
    
    public DiffBuilder append(final String str, final DiffResult diffResult) {
        this.validateFieldNameNotNull(str);
        Validate.isTrue(diffResult != null, "Diff result cannot be null", new Object[0]);
        if (this.objectsTriviallyEqual) {
            return this;
        }
        for (final Diff<?> diff : diffResult.getDiffs()) {
            this.append(str + "." + diff.getFieldName(), diff.getLeft(), diff.getRight());
        }
        return this;
    }
    
    @Override
    public DiffResult build() {
        return new DiffResult(this.left, this.right, this.diffs, this.style);
    }
    
    private void validateFieldNameNotNull(final String s) {
        Validate.isTrue(s != null, "Field name cannot be null", new Object[0]);
    }
}

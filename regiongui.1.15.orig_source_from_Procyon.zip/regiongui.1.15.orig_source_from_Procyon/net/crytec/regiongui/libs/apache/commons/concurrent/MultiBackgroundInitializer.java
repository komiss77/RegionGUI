// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import java.util.NoSuchElementException;
import java.util.Collections;
import java.util.Set;
import java.util.Iterator;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.util.concurrent.ExecutorService;
import java.util.HashMap;
import java.util.Map;

public class MultiBackgroundInitializer extends BackgroundInitializer<MultiBackgroundInitializerResults>
{
    private final Map<String, BackgroundInitializer<?>> childInitializers;
    
    public MultiBackgroundInitializer() {
        this.childInitializers = new HashMap<String, BackgroundInitializer<?>>();
    }
    
    public MultiBackgroundInitializer(final ExecutorService executorService) {
        super(executorService);
        this.childInitializers = new HashMap<String, BackgroundInitializer<?>>();
    }
    
    public void addInitializer(final String s, final BackgroundInitializer<?> backgroundInitializer) {
        Validate.isTrue(s != null, "Name of child initializer must not be null!", new Object[0]);
        Validate.isTrue(backgroundInitializer != null, "Child initializer must not be null!", new Object[0]);
        synchronized (this) {
            if (this.isStarted()) {
                throw new IllegalStateException("addInitializer() must not be called after start()!");
            }
            this.childInitializers.put(s, backgroundInitializer);
        }
    }
    
    @Override
    protected int getTaskCount() {
        int n = 1;
        final Iterator<BackgroundInitializer<?>> iterator = this.childInitializers.values().iterator();
        while (iterator.hasNext()) {
            n += iterator.next().getTaskCount();
        }
        return n;
    }
    
    @Override
    protected MultiBackgroundInitializerResults initialize() {
        final HashMap<Object, BackgroundInitializer> hashMap;
        synchronized (this) {
            hashMap = new HashMap<Object, BackgroundInitializer>(this.childInitializers);
        }
        final ExecutorService activeExecutor = this.getActiveExecutor();
        for (final BackgroundInitializer backgroundInitializer : hashMap.values()) {
            if (backgroundInitializer.getExternalExecutor() == null) {
                backgroundInitializer.setExternalExecutor(activeExecutor);
            }
            backgroundInitializer.start();
        }
        final HashMap<String, Object> hashMap2 = new HashMap<String, Object>();
        final HashMap<String, ConcurrentException> hashMap3 = new HashMap<String, ConcurrentException>();
        for (final Map.Entry<Object, BackgroundInitializer> entry : hashMap.entrySet()) {
            try {
                hashMap2.put(entry.getKey(), entry.getValue().get());
            }
            catch (ConcurrentException ex) {
                hashMap3.put(entry.getKey(), ex);
            }
        }
        return new MultiBackgroundInitializerResults((Map)hashMap, (Map)hashMap2, (Map)hashMap3);
    }
    
    public static class MultiBackgroundInitializerResults
    {
        private final Map<String, BackgroundInitializer<?>> initializers;
        private final Map<String, Object> resultObjects;
        private final Map<String, ConcurrentException> exceptions;
        
        private MultiBackgroundInitializerResults(final Map<String, BackgroundInitializer<?>> initializers, final Map<String, Object> resultObjects, final Map<String, ConcurrentException> exceptions) {
            this.initializers = initializers;
            this.resultObjects = resultObjects;
            this.exceptions = exceptions;
        }
        
        public BackgroundInitializer<?> getInitializer(final String s) {
            return this.checkName(s);
        }
        
        public Object getResultObject(final String s) {
            this.checkName(s);
            return this.resultObjects.get(s);
        }
        
        public boolean isException(final String s) {
            this.checkName(s);
            return this.exceptions.containsKey(s);
        }
        
        public ConcurrentException getException(final String s) {
            this.checkName(s);
            return this.exceptions.get(s);
        }
        
        public Set<String> initializerNames() {
            return Collections.unmodifiableSet((Set<? extends String>)this.initializers.keySet());
        }
        
        public boolean isSuccessful() {
            return this.exceptions.isEmpty();
        }
        
        private BackgroundInitializer<?> checkName(final String str) {
            final BackgroundInitializer<?> backgroundInitializer = this.initializers.get(str);
            if (backgroundInitializer == null) {
                throw new NoSuchElementException("No child initializer with name " + str);
            }
            return backgroundInitializer;
        }
    }
}

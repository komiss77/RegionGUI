// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.builder;

import java.lang.reflect.Modifier;
import java.lang.reflect.Field;
import net.crytec.regiongui.libs.apache.commons.reflect.FieldUtils;

public class ReflectionDiffBuilder implements Builder<DiffResult>
{
    private final Object left;
    private final Object right;
    private final DiffBuilder diffBuilder;
    
    public <T> ReflectionDiffBuilder(final T left, final T right, final ToStringStyle toStringStyle) {
        this.left = left;
        this.right = right;
        this.diffBuilder = new DiffBuilder(left, right, toStringStyle);
    }
    
    @Override
    public DiffResult build() {
        if (this.left.equals(this.right)) {
            return this.diffBuilder.build();
        }
        this.appendFields(this.left.getClass());
        return this.diffBuilder.build();
    }
    
    private void appendFields(final Class<?> clazz) {
        for (final Field field : FieldUtils.getAllFields(clazz)) {
            if (this.accept(field)) {
                try {
                    this.diffBuilder.append(field.getName(), FieldUtils.readField(field, this.left, true), FieldUtils.readField(field, this.right, true));
                }
                catch (IllegalAccessException ex) {
                    throw new InternalError("Unexpected IllegalAccessException: " + ex.getMessage());
                }
            }
        }
    }
    
    private boolean accept(final Field field) {
        return field.getName().indexOf(36) == -1 && !Modifier.isTransient(field.getModifiers()) && !Modifier.isStatic(field.getModifiers());
    }
}

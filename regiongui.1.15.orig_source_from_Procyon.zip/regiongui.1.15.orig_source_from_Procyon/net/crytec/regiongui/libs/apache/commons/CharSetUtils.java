// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

public class CharSetUtils
{
    public static String squeeze(final String s, final String... array) {
        if (StringUtils.isEmpty(s) || deepEmpty(array)) {
            return s;
        }
        final CharSet instance = CharSet.getInstance(array);
        final StringBuilder sb = new StringBuilder(s.length());
        final char[] charArray = s.toCharArray();
        final int length = charArray.length;
        char c = charArray[0];
        Character value = null;
        Character value2 = null;
        sb.append(c);
        for (int i = 1; i < length; ++i) {
            final char c2 = charArray[i];
            if (c2 == c) {
                if (value != null && c2 == value) {
                    continue;
                }
                if (value2 == null || c2 != value2) {
                    if (instance.contains(c2)) {
                        value = c2;
                        continue;
                    }
                    value2 = c2;
                }
            }
            sb.append(c2);
            c = c2;
        }
        return sb.toString();
    }
    
    public static boolean containsAny(final String s, final String... array) {
        if (StringUtils.isEmpty(s) || deepEmpty(array)) {
            return false;
        }
        final CharSet instance = CharSet.getInstance(array);
        final char[] charArray = s.toCharArray();
        for (int length = charArray.length, i = 0; i < length; ++i) {
            if (instance.contains(charArray[i])) {
                return true;
            }
        }
        return false;
    }
    
    public static int count(final String s, final String... array) {
        if (StringUtils.isEmpty(s) || deepEmpty(array)) {
            return 0;
        }
        final CharSet instance = CharSet.getInstance(array);
        int n = 0;
        final char[] charArray = s.toCharArray();
        for (int length = charArray.length, i = 0; i < length; ++i) {
            if (instance.contains(charArray[i])) {
                ++n;
            }
        }
        return n;
    }
    
    public static String keep(final String s, final String... array) {
        if (s == null) {
            return null;
        }
        if (s.isEmpty() || deepEmpty(array)) {
            return "";
        }
        return modify(s, array, true);
    }
    
    public static String delete(final String s, final String... array) {
        if (StringUtils.isEmpty(s) || deepEmpty(array)) {
            return s;
        }
        return modify(s, array, false);
    }
    
    private static String modify(final String s, final String[] array, final boolean b) {
        final CharSet instance = CharSet.getInstance(array);
        final StringBuilder sb = new StringBuilder(s.length());
        for (final char c : s.toCharArray()) {
            if (instance.contains(c) == b) {
                sb.append(c);
            }
        }
        return sb.toString();
    }
    
    private static boolean deepEmpty(final String[] array) {
        if (array != null) {
            for (int length = array.length, i = 0; i < length; ++i) {
                if (StringUtils.isNotEmpty(array[i])) {
                    return false;
                }
            }
        }
        return true;
    }
}

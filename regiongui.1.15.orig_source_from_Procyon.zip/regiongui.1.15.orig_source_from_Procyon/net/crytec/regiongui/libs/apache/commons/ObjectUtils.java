// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import net.crytec.regiongui.libs.apache.commons.exception.CloneFailedException;
import java.util.Iterator;
import net.crytec.regiongui.libs.apache.commons.mutable.MutableInt;
import java.util.HashMap;
import java.util.Comparator;
import java.util.Collections;
import java.util.TreeSet;
import net.crytec.regiongui.libs.apache.commons.text.StrBuilder;
import java.util.Map;
import java.util.Collection;
import java.lang.reflect.Array;

public class ObjectUtils
{
    private static final char AT_SIGN = '@';
    public static final Null NULL;
    
    public static boolean isEmpty(final Object o) {
        if (o == null) {
            return true;
        }
        if (o instanceof CharSequence) {
            return ((CharSequence)o).length() == 0;
        }
        if (o.getClass().isArray()) {
            return Array.getLength(o) == 0;
        }
        if (o instanceof Collection) {
            return ((Collection)o).isEmpty();
        }
        return o instanceof Map && ((Map)o).isEmpty();
    }
    
    public static boolean isNotEmpty(final Object o) {
        return !isEmpty(o);
    }
    
    public static <T> T defaultIfNull(final T t, final T t2) {
        return (t != null) ? t : t2;
    }
    
    @SafeVarargs
    public static <T> T firstNonNull(final T... array) {
        if (array != null) {
            for (final T t : array) {
                if (t != null) {
                    return t;
                }
            }
        }
        return null;
    }
    
    public static boolean anyNotNull(final Object... array) {
        return firstNonNull(array) != null;
    }
    
    public static boolean allNotNull(final Object... array) {
        if (array == null) {
            return false;
        }
        for (int length = array.length, i = 0; i < length; ++i) {
            if (array[i] == null) {
                return false;
            }
        }
        return true;
    }
    
    @Deprecated
    public static boolean equals(final Object o, final Object obj) {
        return o == obj || (o != null && obj != null && o.equals(obj));
    }
    
    public static boolean notEqual(final Object o, final Object o2) {
        return !equals(o, o2);
    }
    
    @Deprecated
    public static int hashCode(final Object o) {
        return (o == null) ? 0 : o.hashCode();
    }
    
    @Deprecated
    public static int hashCodeMulti(final Object... array) {
        int n = 1;
        if (array != null) {
            for (int length = array.length, i = 0; i < length; ++i) {
                n = n * 31 + hashCode(array[i]);
            }
        }
        return n;
    }
    
    public static String identityToString(final Object o) {
        if (o == null) {
            return null;
        }
        final String name = o.getClass().getName();
        final String hexString = Integer.toHexString(System.identityHashCode(o));
        final StringBuilder sb = new StringBuilder(name.length() + 1 + hexString.length());
        sb.append(name).append('@').append(hexString);
        return sb.toString();
    }
    
    public static void identityToString(final Appendable appendable, final Object o) {
        Validate.notNull(o, "Cannot get the toString of a null object", new Object[0]);
        appendable.append(o.getClass().getName()).append('@').append(Integer.toHexString(System.identityHashCode(o)));
    }
    
    @Deprecated
    public static void identityToString(final StrBuilder strBuilder, final Object o) {
        Validate.notNull(o, "Cannot get the toString of a null object", new Object[0]);
        final String name = o.getClass().getName();
        final String hexString = Integer.toHexString(System.identityHashCode(o));
        strBuilder.ensureCapacity(strBuilder.length() + name.length() + 1 + hexString.length());
        strBuilder.append(name).append('@').append(hexString);
    }
    
    public static void identityToString(final StringBuffer sb, final Object o) {
        Validate.notNull(o, "Cannot get the toString of a null object", new Object[0]);
        final String name = o.getClass().getName();
        final String hexString = Integer.toHexString(System.identityHashCode(o));
        sb.ensureCapacity(sb.length() + name.length() + 1 + hexString.length());
        sb.append(name).append('@').append(hexString);
    }
    
    public static void identityToString(final StringBuilder sb, final Object o) {
        Validate.notNull(o, "Cannot get the toString of a null object", new Object[0]);
        final String name = o.getClass().getName();
        final String hexString = Integer.toHexString(System.identityHashCode(o));
        sb.ensureCapacity(sb.length() + name.length() + 1 + hexString.length());
        sb.append(name).append('@').append(hexString);
    }
    
    @Deprecated
    public static String toString(final Object o) {
        return (o == null) ? "" : o.toString();
    }
    
    @Deprecated
    public static String toString(final Object o, final String s) {
        return (o == null) ? s : o.toString();
    }
    
    @SafeVarargs
    public static <T extends Comparable<? super T>> T min(final T... array) {
        Comparable<? super T> comparable = null;
        if (array != null) {
            for (final Comparable<? super T> comparable2 : array) {
                if (compare(comparable2, comparable, true) < 0) {
                    comparable = comparable2;
                }
            }
        }
        return (T)comparable;
    }
    
    @SafeVarargs
    public static <T extends Comparable<? super T>> T max(final T... array) {
        Comparable<? super T> comparable = null;
        if (array != null) {
            for (final Comparable<? super T> comparable2 : array) {
                if (compare(comparable2, comparable, false) > 0) {
                    comparable = comparable2;
                }
            }
        }
        return (T)comparable;
    }
    
    public static <T extends Comparable<? super T>> int compare(final T t, final T t2) {
        return compare(t, t2, false);
    }
    
    public static <T extends Comparable<? super T>> int compare(final T t, final T t2, final boolean b) {
        if (t == t2) {
            return 0;
        }
        if (t == null) {
            return b ? 1 : -1;
        }
        if (t2 == null) {
            return b ? -1 : 1;
        }
        return t.compareTo((Object)t2);
    }
    
    @SafeVarargs
    public static <T extends Comparable<? super T>> T median(final T... elements) {
        Validate.notEmpty(elements);
        Validate.noNullElements(elements);
        final TreeSet<Object> c = new TreeSet<Object>();
        Collections.addAll(c, elements);
        return (T)c.toArray()[(c.size() - 1) / 2];
    }
    
    @SafeVarargs
    public static <T> T median(final Comparator<T> comparator, final T... elements) {
        Validate.notEmpty(elements, "null/empty items", new Object[0]);
        Validate.noNullElements(elements);
        Validate.notNull(comparator, "null comparator", new Object[0]);
        final TreeSet<Object> c = new TreeSet<Object>((Comparator<? super Object>)comparator);
        Collections.addAll(c, elements);
        return (T)c.toArray()[(c.size() - 1) / 2];
    }
    
    @SafeVarargs
    public static <T> T mode(final T... array) {
        if (ArrayUtils.isNotEmpty(array)) {
            final HashMap<T, MutableInt> hashMap = new HashMap<T, MutableInt>(array.length);
            for (final T t : array) {
                final MutableInt mutableInt = hashMap.get(t);
                if (mutableInt == null) {
                    hashMap.put(t, new MutableInt(1));
                }
                else {
                    mutableInt.increment();
                }
            }
            T key = null;
            int n = 0;
            for (final Map.Entry<T, MutableInt> entry : hashMap.entrySet()) {
                final int intValue = entry.getValue().intValue();
                if (intValue == n) {
                    key = null;
                }
                else {
                    if (intValue <= n) {
                        continue;
                    }
                    n = intValue;
                    key = entry.getKey();
                }
            }
            return key;
        }
        return null;
    }
    
    public static <T> T clone(final T obj) {
        if (obj instanceof Cloneable) {
            Object o;
            if (obj.getClass().isArray()) {
                final Class<?> componentType = obj.getClass().getComponentType();
                if (componentType.isPrimitive()) {
                    int length = Array.getLength(obj);
                    o = Array.newInstance(componentType, length);
                    while (length-- > 0) {
                        Array.set(o, length, Array.get(obj, length));
                    }
                }
                else {
                    o = ((Object[])(Object)obj).clone();
                }
            }
            else {
                try {
                    o = obj.getClass().getMethod("clone", (Class<?>[])new Class[0]).invoke(obj, new Object[0]);
                }
                catch (NoSuchMethodException ex) {
                    throw new CloneFailedException("Cloneable type " + obj.getClass().getName() + " has no clone method", ex);
                }
                catch (IllegalAccessException ex2) {
                    throw new CloneFailedException("Cannot clone Cloneable type " + obj.getClass().getName(), ex2);
                }
                catch (InvocationTargetException ex3) {
                    throw new CloneFailedException("Exception cloning Cloneable type " + obj.getClass().getName(), ex3.getCause());
                }
            }
            return (T)o;
        }
        return null;
    }
    
    public static <T> T cloneIfPossible(final T t) {
        final Object clone = clone((Object)t);
        return (T)((clone == null) ? t : clone);
    }
    
    public static boolean CONST(final boolean b) {
        return b;
    }
    
    public static byte CONST(final byte b) {
        return b;
    }
    
    public static byte CONST_BYTE(final int i) {
        if (i < -128 || i > 127) {
            throw new IllegalArgumentException("Supplied value must be a valid byte literal between -128 and 127: [" + i + "]");
        }
        return (byte)i;
    }
    
    public static char CONST(final char c) {
        return c;
    }
    
    public static short CONST(final short n) {
        return n;
    }
    
    public static short CONST_SHORT(final int i) {
        if (i < -32768 || i > 32767) {
            throw new IllegalArgumentException("Supplied value must be a valid byte literal between -32768 and 32767: [" + i + "]");
        }
        return (short)i;
    }
    
    public static int CONST(final int n) {
        return n;
    }
    
    public static long CONST(final long n) {
        return n;
    }
    
    public static float CONST(final float n) {
        return n;
    }
    
    public static double CONST(final double n) {
        return n;
    }
    
    public static <T> T CONST(final T t) {
        return t;
    }
    
    static {
        NULL = new Null();
    }
    
    public static class Null implements Serializable
    {
        private static final long serialVersionUID = 7092611880189329093L;
        
        Null() {
        }
        
        private Object readResolve() {
            return ObjectUtils.NULL;
        }
    }
}

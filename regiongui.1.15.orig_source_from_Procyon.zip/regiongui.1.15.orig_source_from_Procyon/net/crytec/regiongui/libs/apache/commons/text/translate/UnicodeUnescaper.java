// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text.translate;

import java.io.Writer;

@Deprecated
public class UnicodeUnescaper extends CharSequenceTranslator
{
    @Override
    public int translate(final CharSequence charSequence, final int n, final Writer writer) {
        if (charSequence.charAt(n) != '\\' || n + 1 >= charSequence.length() || charSequence.charAt(n + 1) != 'u') {
            return 0;
        }
        int n2;
        for (n2 = 2; n + n2 < charSequence.length() && charSequence.charAt(n + n2) == 'u'; ++n2) {}
        if (n + n2 < charSequence.length() && charSequence.charAt(n + n2) == '+') {
            ++n2;
        }
        if (n + n2 + 4 <= charSequence.length()) {
            final CharSequence subSequence = charSequence.subSequence(n + n2, n + n2 + 4);
            try {
                writer.write((char)Integer.parseInt(subSequence.toString(), 16));
            }
            catch (NumberFormatException cause) {
                throw new IllegalArgumentException("Unable to parse unicode value: " + (Object)subSequence, cause);
            }
            return n2 + 4;
        }
        throw new IllegalArgumentException("Less than 4 hex digits in unicode value: '" + (Object)charSequence.subSequence(n, charSequence.length()) + "' due to end of CharSequence");
    }
}

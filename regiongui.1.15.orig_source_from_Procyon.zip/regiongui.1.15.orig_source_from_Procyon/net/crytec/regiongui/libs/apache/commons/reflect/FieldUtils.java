// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.reflect;

import net.crytec.regiongui.libs.apache.commons.SystemUtils;
import net.crytec.regiongui.libs.apache.commons.JavaVersion;
import java.lang.annotation.Annotation;
import java.util.Collection;
import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Member;
import java.util.Iterator;
import net.crytec.regiongui.libs.apache.commons.ClassUtils;
import java.lang.reflect.Modifier;
import net.crytec.regiongui.libs.apache.commons.StringUtils;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Field;

public class FieldUtils
{
    public static Field getField(final Class<?> clazz, final String s) {
        final Field field = getField(clazz, s, false);
        MemberUtils.setAccessibleWorkaround(field);
        return field;
    }
    
    public static Field getField(final Class<?> clazz, final String s, final boolean b) {
        Validate.isTrue(clazz != null, "The class must not be null", new Object[0]);
        Validate.isTrue(StringUtils.isNotBlank(s), "The field name must not be blank/empty", new Object[0]);
        for (Class<?> superclass = clazz; superclass != null; superclass = superclass.getSuperclass()) {
            try {
                final Field declaredField = superclass.getDeclaredField(s);
                if (!Modifier.isPublic(declaredField.getModifiers())) {
                    if (!b) {
                        continue;
                    }
                    declaredField.setAccessible(true);
                }
                return declaredField;
            }
            catch (NoSuchFieldException ex) {}
        }
        Field field = null;
        for (final Class<?> clazz2 : ClassUtils.getAllInterfaces(clazz)) {
            try {
                final Field field2 = clazz2.getField(s);
                Validate.isTrue(field == null, "Reference to field %s is ambiguous relative to %s; a matching field exists on two or more implemented interfaces.", s, clazz);
                field = field2;
            }
            catch (NoSuchFieldException ex2) {}
        }
        return field;
    }
    
    public static Field getDeclaredField(final Class<?> clazz, final String s) {
        return getDeclaredField(clazz, s, false);
    }
    
    public static Field getDeclaredField(final Class<?> clazz, final String name, final boolean b) {
        Validate.isTrue(clazz != null, "The class must not be null", new Object[0]);
        Validate.isTrue(StringUtils.isNotBlank(name), "The field name must not be blank/empty", new Object[0]);
        try {
            final Field declaredField = clazz.getDeclaredField(name);
            if (!MemberUtils.isAccessible(declaredField)) {
                if (!b) {
                    return null;
                }
                declaredField.setAccessible(true);
            }
            return declaredField;
        }
        catch (NoSuchFieldException ex) {
            return null;
        }
    }
    
    public static Field[] getAllFields(final Class<?> clazz) {
        final List<Field> allFieldsList = getAllFieldsList(clazz);
        return allFieldsList.toArray(new Field[allFieldsList.size()]);
    }
    
    public static List<Field> getAllFieldsList(final Class<?> clazz) {
        Validate.isTrue(clazz != null, "The class must not be null", new Object[0]);
        final ArrayList<Object> c = new ArrayList<Object>();
        for (Class<?> superclass = clazz; superclass != null; superclass = superclass.getSuperclass()) {
            Collections.addAll(c, superclass.getDeclaredFields());
        }
        return (List<Field>)c;
    }
    
    public static Field[] getFieldsWithAnnotation(final Class<?> clazz, final Class<? extends Annotation> clazz2) {
        final List<Field> fieldsListWithAnnotation = getFieldsListWithAnnotation(clazz, clazz2);
        return fieldsListWithAnnotation.toArray(new Field[fieldsListWithAnnotation.size()]);
    }
    
    public static List<Field> getFieldsListWithAnnotation(final Class<?> clazz, final Class<? extends Annotation> annotationClass) {
        Validate.isTrue(annotationClass != null, "The annotation class must not be null", new Object[0]);
        final List<Field> allFieldsList = getAllFieldsList(clazz);
        final ArrayList<Field> list = new ArrayList<Field>();
        for (final Field field : allFieldsList) {
            if (field.getAnnotation(annotationClass) != null) {
                list.add(field);
            }
        }
        return list;
    }
    
    public static Object readStaticField(final Field field) {
        return readStaticField(field, false);
    }
    
    public static Object readStaticField(final Field field, final boolean b) {
        Validate.isTrue(field != null, "The field must not be null", new Object[0]);
        Validate.isTrue(Modifier.isStatic(field.getModifiers()), "The field '%s' is not static", field.getName());
        return readField(field, (Object)null, b);
    }
    
    public static Object readStaticField(final Class<?> clazz, final String s) {
        return readStaticField(clazz, s, false);
    }
    
    public static Object readStaticField(final Class<?> clazz, final String s, final boolean b) {
        final Field field = getField(clazz, s, b);
        Validate.isTrue(field != null, "Cannot locate field '%s' on %s", s, clazz);
        return readStaticField(field, false);
    }
    
    public static Object readDeclaredStaticField(final Class<?> clazz, final String s) {
        return readDeclaredStaticField(clazz, s, false);
    }
    
    public static Object readDeclaredStaticField(final Class<?> clazz, final String s, final boolean b) {
        final Field declaredField = getDeclaredField(clazz, s, b);
        Validate.isTrue(declaredField != null, "Cannot locate declared field %s.%s", clazz.getName(), s);
        return readStaticField(declaredField, false);
    }
    
    public static Object readField(final Field field, final Object o) {
        return readField(field, o, false);
    }
    
    public static Object readField(final Field accessibleWorkaround, final Object obj, final boolean b) {
        Validate.isTrue(accessibleWorkaround != null, "The field must not be null", new Object[0]);
        if (b && !accessibleWorkaround.isAccessible()) {
            accessibleWorkaround.setAccessible(true);
        }
        else {
            MemberUtils.setAccessibleWorkaround(accessibleWorkaround);
        }
        return accessibleWorkaround.get(obj);
    }
    
    public static Object readField(final Object o, final String s) {
        return readField(o, s, false);
    }
    
    public static Object readField(final Object o, final String s, final boolean b) {
        Validate.isTrue(o != null, "target object must not be null", new Object[0]);
        final Class<?> class1 = o.getClass();
        final Field field = getField(class1, s, b);
        Validate.isTrue(field != null, "Cannot locate field %s on %s", s, class1);
        return readField(field, o, false);
    }
    
    public static Object readDeclaredField(final Object o, final String s) {
        return readDeclaredField(o, s, false);
    }
    
    public static Object readDeclaredField(final Object o, final String s, final boolean b) {
        Validate.isTrue(o != null, "target object must not be null", new Object[0]);
        final Class<?> class1 = o.getClass();
        final Field declaredField = getDeclaredField(class1, s, b);
        Validate.isTrue(declaredField != null, "Cannot locate declared field %s.%s", class1, s);
        return readField(declaredField, o, false);
    }
    
    public static void writeStaticField(final Field field, final Object o) {
        writeStaticField(field, o, false);
    }
    
    public static void writeStaticField(final Field field, final Object o, final boolean b) {
        Validate.isTrue(field != null, "The field must not be null", new Object[0]);
        Validate.isTrue(Modifier.isStatic(field.getModifiers()), "The field %s.%s is not static", field.getDeclaringClass().getName(), field.getName());
        writeField(field, (Object)null, o, b);
    }
    
    public static void writeStaticField(final Class<?> clazz, final String s, final Object o) {
        writeStaticField(clazz, s, o, false);
    }
    
    public static void writeStaticField(final Class<?> clazz, final String s, final Object o, final boolean b) {
        final Field field = getField(clazz, s, b);
        Validate.isTrue(field != null, "Cannot locate field %s on %s", s, clazz);
        writeStaticField(field, o, false);
    }
    
    public static void writeDeclaredStaticField(final Class<?> clazz, final String s, final Object o) {
        writeDeclaredStaticField(clazz, s, o, false);
    }
    
    public static void writeDeclaredStaticField(final Class<?> clazz, final String s, final Object o, final boolean b) {
        final Field declaredField = getDeclaredField(clazz, s, b);
        Validate.isTrue(declaredField != null, "Cannot locate declared field %s.%s", clazz.getName(), s);
        writeField(declaredField, (Object)null, o, false);
    }
    
    public static void writeField(final Field field, final Object o, final Object o2) {
        writeField(field, o, o2, false);
    }
    
    public static void writeField(final Field accessibleWorkaround, final Object obj, final Object value, final boolean b) {
        Validate.isTrue(accessibleWorkaround != null, "The field must not be null", new Object[0]);
        if (b && !accessibleWorkaround.isAccessible()) {
            accessibleWorkaround.setAccessible(true);
        }
        else {
            MemberUtils.setAccessibleWorkaround(accessibleWorkaround);
        }
        accessibleWorkaround.set(obj, value);
    }
    
    public static void removeFinalModifier(final Field field) {
        removeFinalModifier(field, true);
    }
    
    @Deprecated
    public static void removeFinalModifier(final Field obj, final boolean b) {
        Validate.isTrue(obj != null, "The field must not be null", new Object[0]);
        try {
            if (Modifier.isFinal(obj.getModifiers())) {
                final Field declaredField = Field.class.getDeclaredField("modifiers");
                final boolean b2 = b && !declaredField.isAccessible();
                if (b2) {
                    declaredField.setAccessible(true);
                }
                try {
                    declaredField.setInt(obj, obj.getModifiers() & 0xFFFFFFEF);
                }
                finally {
                    if (b2) {
                        declaredField.setAccessible(false);
                    }
                }
            }
        }
        catch (NoSuchFieldException | IllegalAccessException ex2) {
            final IllegalAccessException ex;
            final IllegalAccessException cause = ex;
            if (SystemUtils.isJavaVersionAtLeast(JavaVersion.JAVA_12)) {
                throw new UnsupportedOperationException("In java 12+ final cannot be removed.", cause);
            }
        }
    }
    
    public static void writeField(final Object o, final String s, final Object o2) {
        writeField(o, s, o2, false);
    }
    
    public static void writeField(final Object o, final String s, final Object o2, final boolean b) {
        Validate.isTrue(o != null, "target object must not be null", new Object[0]);
        final Class<?> class1 = o.getClass();
        final Field field = getField(class1, s, b);
        Validate.isTrue(field != null, "Cannot locate declared field %s.%s", class1.getName(), s);
        writeField(field, o, o2, false);
    }
    
    public static void writeDeclaredField(final Object o, final String s, final Object o2) {
        writeDeclaredField(o, s, o2, false);
    }
    
    public static void writeDeclaredField(final Object o, final String s, final Object o2, final boolean b) {
        Validate.isTrue(o != null, "target object must not be null", new Object[0]);
        final Class<?> class1 = o.getClass();
        final Field declaredField = getDeclaredField(class1, s, b);
        Validate.isTrue(declaredField != null, "Cannot locate declared field %s.%s", class1.getName(), s);
        writeField(declaredField, o, o2, false);
    }
}

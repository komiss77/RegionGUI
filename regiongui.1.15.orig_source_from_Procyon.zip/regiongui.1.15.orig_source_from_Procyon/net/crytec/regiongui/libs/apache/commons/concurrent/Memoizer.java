// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.concurrent;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.CancellationException;
import java.util.concurrent.FutureTask;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Future;
import java.util.concurrent.ConcurrentMap;

public class Memoizer<I, O> implements Computable<I, O>
{
    private final ConcurrentMap<I, Future<O>> cache;
    private final Computable<I, O> computable;
    private final boolean recalculate;
    
    public Memoizer(final Computable<I, O> computable) {
        this(computable, false);
    }
    
    public Memoizer(final Computable<I, O> computable, final boolean recalculate) {
        this.cache = new ConcurrentHashMap<I, Future<O>>();
        this.computable = computable;
        this.recalculate = recalculate;
    }
    
    @Override
    public O compute(final I n) {
        while (true) {
            Future<?> future = this.cache.get(n);
            if (future == null) {
                final FutureTask<O> futureTask = new FutureTask<O>(new Callable<O>() {
                    @Override
                    public O call() {
                        return Memoizer.this.computable.compute(n);
                    }
                });
                future = this.cache.putIfAbsent(n, futureTask);
                if (future == null) {
                    future = futureTask;
                    futureTask.run();
                }
            }
            try {
                return (O)future.get();
            }
            catch (CancellationException ex2) {
                this.cache.remove(n, future);
            }
            catch (ExecutionException ex) {
                if (this.recalculate) {
                    this.cache.remove(n, future);
                }
                throw this.launderException(ex.getCause());
            }
        }
    }
    
    private RuntimeException launderException(final Throwable cause) {
        if (cause instanceof RuntimeException) {
            return (RuntimeException)cause;
        }
        if (cause instanceof Error) {
            throw (Error)cause;
        }
        throw new IllegalStateException("Unchecked exception", cause);
    }
}

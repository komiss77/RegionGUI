// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.time;

import java.util.Date;
import java.util.TimeZone;

class GmtTimeZone extends TimeZone
{
    private static final int MILLISECONDS_PER_MINUTE = 60000;
    private static final int MINUTES_PER_HOUR = 60;
    private static final int HOURS_PER_DAY = 24;
    static final long serialVersionUID = 1L;
    private final int offset;
    private final String zoneId;
    
    GmtTimeZone(final boolean b, final int i, final int j) {
        if (i >= 24) {
            throw new IllegalArgumentException(i + " hours out of range");
        }
        if (j >= 60) {
            throw new IllegalArgumentException(j + " minutes out of range");
        }
        final int n = (j + i * 60) * 60000;
        this.offset = (b ? (-n) : n);
        this.zoneId = twoDigits(twoDigits(new StringBuilder(9).append("GMT").append(b ? '-' : '+'), i).append(':'), j).toString();
    }
    
    private static StringBuilder twoDigits(final StringBuilder sb, final int n) {
        return sb.append((char)(48 + n / 10)).append((char)(48 + n % 10));
    }
    
    @Override
    public int getOffset(final int n, final int n2, final int n3, final int n4, final int n5, final int n6) {
        return this.offset;
    }
    
    @Override
    public void setRawOffset(final int n) {
        throw new UnsupportedOperationException();
    }
    
    @Override
    public int getRawOffset() {
        return this.offset;
    }
    
    @Override
    public String getID() {
        return this.zoneId;
    }
    
    @Override
    public boolean useDaylightTime() {
        return false;
    }
    
    @Override
    public boolean inDaylightTime(final Date date) {
        return false;
    }
    
    @Override
    public String toString() {
        return "[GmtTimeZone id=\"" + this.zoneId + "\",offset=" + this.offset + ']';
    }
    
    @Override
    public int hashCode() {
        return this.offset;
    }
    
    @Override
    public boolean equals(final Object o) {
        return o instanceof GmtTimeZone && this.zoneId == ((GmtTimeZone)o).zoneId;
    }
}

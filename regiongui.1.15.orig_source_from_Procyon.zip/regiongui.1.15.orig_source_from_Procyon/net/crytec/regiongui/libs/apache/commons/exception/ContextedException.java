// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.exception;

import java.util.Set;
import net.crytec.regiongui.libs.apache.commons.tuple.Pair;
import java.util.List;

public class ContextedException extends Exception implements ExceptionContext
{
    private static final long serialVersionUID = 20110706L;
    private final ExceptionContext exceptionContext;
    
    public ContextedException() {
        this.exceptionContext = new DefaultExceptionContext();
    }
    
    public ContextedException(final String message) {
        super(message);
        this.exceptionContext = new DefaultExceptionContext();
    }
    
    public ContextedException(final Throwable cause) {
        super(cause);
        this.exceptionContext = new DefaultExceptionContext();
    }
    
    public ContextedException(final String message, final Throwable cause) {
        super(message, cause);
        this.exceptionContext = new DefaultExceptionContext();
    }
    
    public ContextedException(final String message, final Throwable cause, ExceptionContext exceptionContext) {
        super(message, cause);
        if (exceptionContext == null) {
            exceptionContext = new DefaultExceptionContext();
        }
        this.exceptionContext = exceptionContext;
    }
    
    @Override
    public ContextedException addContextValue(final String s, final Object o) {
        this.exceptionContext.addContextValue(s, o);
        return this;
    }
    
    @Override
    public ContextedException setContextValue(final String s, final Object o) {
        this.exceptionContext.setContextValue(s, o);
        return this;
    }
    
    @Override
    public List<Object> getContextValues(final String s) {
        return this.exceptionContext.getContextValues(s);
    }
    
    @Override
    public Object getFirstContextValue(final String s) {
        return this.exceptionContext.getFirstContextValue(s);
    }
    
    @Override
    public List<Pair<String, Object>> getContextEntries() {
        return this.exceptionContext.getContextEntries();
    }
    
    @Override
    public Set<String> getContextLabels() {
        return this.exceptionContext.getContextLabels();
    }
    
    @Override
    public String getMessage() {
        return this.getFormattedExceptionMessage(super.getMessage());
    }
    
    public String getRawMessage() {
        return super.getMessage();
    }
    
    @Override
    public String getFormattedExceptionMessage(final String s) {
        return this.exceptionContext.getFormattedExceptionMessage(s);
    }
}

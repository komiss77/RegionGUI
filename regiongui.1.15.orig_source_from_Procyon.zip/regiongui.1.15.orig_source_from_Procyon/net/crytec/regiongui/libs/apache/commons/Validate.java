// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons;

import java.util.regex.Pattern;
import java.util.Iterator;
import java.util.Map;
import java.util.Collection;

public class Validate
{
    private static final String DEFAULT_NOT_NAN_EX_MESSAGE = "The validated value is not a number";
    private static final String DEFAULT_FINITE_EX_MESSAGE = "The value is invalid: %f";
    private static final String DEFAULT_EXCLUSIVE_BETWEEN_EX_MESSAGE = "The value %s is not in the specified exclusive range of %s to %s";
    private static final String DEFAULT_INCLUSIVE_BETWEEN_EX_MESSAGE = "The value %s is not in the specified inclusive range of %s to %s";
    private static final String DEFAULT_MATCHES_PATTERN_EX = "The string %s does not match the pattern %s";
    private static final String DEFAULT_IS_NULL_EX_MESSAGE = "The validated object is null";
    private static final String DEFAULT_IS_TRUE_EX_MESSAGE = "The validated expression is false";
    private static final String DEFAULT_NO_NULL_ELEMENTS_ARRAY_EX_MESSAGE = "The validated array contains null element at index: %d";
    private static final String DEFAULT_NO_NULL_ELEMENTS_COLLECTION_EX_MESSAGE = "The validated collection contains null element at index: %d";
    private static final String DEFAULT_NOT_BLANK_EX_MESSAGE = "The validated character sequence is blank";
    private static final String DEFAULT_NOT_EMPTY_ARRAY_EX_MESSAGE = "The validated array is empty";
    private static final String DEFAULT_NOT_EMPTY_CHAR_SEQUENCE_EX_MESSAGE = "The validated character sequence is empty";
    private static final String DEFAULT_NOT_EMPTY_COLLECTION_EX_MESSAGE = "The validated collection is empty";
    private static final String DEFAULT_NOT_EMPTY_MAP_EX_MESSAGE = "The validated map is empty";
    private static final String DEFAULT_VALID_INDEX_ARRAY_EX_MESSAGE = "The validated array index is invalid: %d";
    private static final String DEFAULT_VALID_INDEX_CHAR_SEQUENCE_EX_MESSAGE = "The validated character sequence index is invalid: %d";
    private static final String DEFAULT_VALID_INDEX_COLLECTION_EX_MESSAGE = "The validated collection index is invalid: %d";
    private static final String DEFAULT_VALID_STATE_EX_MESSAGE = "The validated state is false";
    private static final String DEFAULT_IS_ASSIGNABLE_EX_MESSAGE = "Cannot assign a %s to a %s";
    private static final String DEFAULT_IS_INSTANCE_OF_EX_MESSAGE = "Expected type: %s, actual: %s";
    
    public static void isTrue(final boolean b, final String format, final long l) {
        if (!b) {
            throw new IllegalArgumentException(String.format(format, l));
        }
    }
    
    public static void isTrue(final boolean b, final String format, final double d) {
        if (!b) {
            throw new IllegalArgumentException(String.format(format, d));
        }
    }
    
    public static void isTrue(final boolean b, final String format, final Object... args) {
        if (!b) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
    
    public static void isTrue(final boolean b) {
        if (!b) {
            throw new IllegalArgumentException("The validated expression is false");
        }
    }
    
    public static <T> T notNull(final T t) {
        return notNull(t, "The validated object is null", new Object[0]);
    }
    
    public static <T> T notNull(final T t, final String format, final Object... args) {
        if (t == null) {
            throw new NullPointerException(String.format(format, args));
        }
        return t;
    }
    
    public static <T> T[] notEmpty(final T[] array, final String s, final Object... array2) {
        if (array == null) {
            throw new NullPointerException(String.format(s, array2));
        }
        if (array.length == 0) {
            throw new IllegalArgumentException(String.format(s, array2));
        }
        return array;
    }
    
    public static <T> T[] notEmpty(final T[] array) {
        return notEmpty(array, "The validated array is empty", new Object[0]);
    }
    
    public static <T extends Collection<?>> T notEmpty(final T t, final String s, final Object... array) {
        if (t == null) {
            throw new NullPointerException(String.format(s, array));
        }
        if (t.isEmpty()) {
            throw new IllegalArgumentException(String.format(s, array));
        }
        return t;
    }
    
    public static <T extends Collection<?>> T notEmpty(final T t) {
        return notEmpty(t, "The validated collection is empty", new Object[0]);
    }
    
    public static <T extends Map<?, ?>> T notEmpty(final T t, final String s, final Object... array) {
        if (t == null) {
            throw new NullPointerException(String.format(s, array));
        }
        if (t.isEmpty()) {
            throw new IllegalArgumentException(String.format(s, array));
        }
        return t;
    }
    
    public static <T extends Map<?, ?>> T notEmpty(final T t) {
        return notEmpty(t, "The validated map is empty", new Object[0]);
    }
    
    public static <T extends CharSequence> T notEmpty(final T t, final String s, final Object... array) {
        if (t == null) {
            throw new NullPointerException(String.format(s, array));
        }
        if (t.length() == 0) {
            throw new IllegalArgumentException(String.format(s, array));
        }
        return t;
    }
    
    public static <T extends CharSequence> T notEmpty(final T t) {
        return notEmpty(t, "The validated character sequence is empty", new Object[0]);
    }
    
    public static <T extends CharSequence> T notBlank(final T t, final String s, final Object... array) {
        if (t == null) {
            throw new NullPointerException(String.format(s, array));
        }
        if (StringUtils.isBlank(t)) {
            throw new IllegalArgumentException(String.format(s, array));
        }
        return t;
    }
    
    public static <T extends CharSequence> T notBlank(final T t) {
        return notBlank(t, "The validated character sequence is blank", new Object[0]);
    }
    
    public static <T> T[] noNullElements(final T[] array, final String format, final Object... array2) {
        notNull(array);
        for (int i = 0; i < array.length; ++i) {
            if (array[i] == null) {
                throw new IllegalArgumentException(String.format(format, ArrayUtils.add(array2, i)));
            }
        }
        return array;
    }
    
    public static <T> T[] noNullElements(final T[] array) {
        return noNullElements(array, "The validated array contains null element at index: %d", new Object[0]);
    }
    
    public static <T extends Iterable<?>> T noNullElements(final T t, final String format, final Object... array) {
        notNull(t);
        int i = 0;
        final Iterator<?> iterator = t.iterator();
        while (iterator.hasNext()) {
            if (iterator.next() == null) {
                throw new IllegalArgumentException(String.format(format, ArrayUtils.addAll(array, i)));
            }
            ++i;
        }
        return t;
    }
    
    public static <T extends Iterable<?>> T noNullElements(final T t) {
        return noNullElements(t, "The validated collection contains null element at index: %d", new Object[0]);
    }
    
    public static <T> T[] validIndex(final T[] array, final int n, final String format, final Object... args) {
        notNull(array);
        if (n < 0 || n >= array.length) {
            throw new IndexOutOfBoundsException(String.format(format, args));
        }
        return array;
    }
    
    public static <T> T[] validIndex(final T[] array, final int i) {
        return validIndex(array, i, "The validated array index is invalid: %d", new Object[] { i });
    }
    
    public static <T extends Collection<?>> T validIndex(final T t, final int n, final String format, final Object... args) {
        notNull(t);
        if (n < 0 || n >= t.size()) {
            throw new IndexOutOfBoundsException(String.format(format, args));
        }
        return t;
    }
    
    public static <T extends Collection<?>> T validIndex(final T t, final int i) {
        return validIndex(t, i, "The validated collection index is invalid: %d", new Object[] { i });
    }
    
    public static <T extends CharSequence> T validIndex(final T t, final int n, final String format, final Object... args) {
        notNull(t);
        if (n < 0 || n >= t.length()) {
            throw new IndexOutOfBoundsException(String.format(format, args));
        }
        return t;
    }
    
    public static <T extends CharSequence> T validIndex(final T t, final int i) {
        return validIndex(t, i, "The validated character sequence index is invalid: %d", new Object[] { i });
    }
    
    public static void validState(final boolean b) {
        if (!b) {
            throw new IllegalStateException("The validated state is false");
        }
    }
    
    public static void validState(final boolean b, final String format, final Object... args) {
        if (!b) {
            throw new IllegalStateException(String.format(format, args));
        }
    }
    
    public static void matchesPattern(final CharSequence input, final String regex) {
        if (!Pattern.matches(regex, input)) {
            throw new IllegalArgumentException(String.format("The string %s does not match the pattern %s", input, regex));
        }
    }
    
    public static void matchesPattern(final CharSequence input, final String regex, final String format, final Object... args) {
        if (!Pattern.matches(regex, input)) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
    
    public static void notNaN(final double n) {
        notNaN(n, "The validated value is not a number", new Object[0]);
    }
    
    public static void notNaN(final double v, final String format, final Object... args) {
        if (Double.isNaN(v)) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
    
    public static void finite(final double d) {
        finite(d, "The value is invalid: %f", d);
    }
    
    public static void finite(final double n, final String format, final Object... args) {
        if (Double.isNaN(n) || Double.isInfinite(n)) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
    
    public static <T> void inclusiveBetween(final T t, final T t2, final Comparable<T> comparable) {
        if (comparable.compareTo(t) < 0 || comparable.compareTo(t2) > 0) {
            throw new IllegalArgumentException(String.format("The value %s is not in the specified inclusive range of %s to %s", comparable, t, t2));
        }
    }
    
    public static <T> void inclusiveBetween(final T t, final T t2, final Comparable<T> comparable, final String format, final Object... args) {
        if (comparable.compareTo(t) < 0 || comparable.compareTo(t2) > 0) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
    
    public static void inclusiveBetween(final long l, final long i, final long j) {
        if (j < l || j > i) {
            throw new IllegalArgumentException(String.format("The value %s is not in the specified inclusive range of %s to %s", j, l, i));
        }
    }
    
    public static void inclusiveBetween(final long n, final long n2, final long n3, final String s) {
        if (n3 < n || n3 > n2) {
            throw new IllegalArgumentException(s);
        }
    }
    
    public static void inclusiveBetween(final double d, final double d2, final double d3) {
        if (d3 < d || d3 > d2) {
            throw new IllegalArgumentException(String.format("The value %s is not in the specified inclusive range of %s to %s", d3, d, d2));
        }
    }
    
    public static void inclusiveBetween(final double n, final double n2, final double n3, final String s) {
        if (n3 < n || n3 > n2) {
            throw new IllegalArgumentException(s);
        }
    }
    
    public static <T> void exclusiveBetween(final T t, final T t2, final Comparable<T> comparable) {
        if (comparable.compareTo(t) <= 0 || comparable.compareTo(t2) >= 0) {
            throw new IllegalArgumentException(String.format("The value %s is not in the specified exclusive range of %s to %s", comparable, t, t2));
        }
    }
    
    public static <T> void exclusiveBetween(final T t, final T t2, final Comparable<T> comparable, final String format, final Object... args) {
        if (comparable.compareTo(t) <= 0 || comparable.compareTo(t2) >= 0) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
    
    public static void exclusiveBetween(final long l, final long i, final long j) {
        if (j <= l || j >= i) {
            throw new IllegalArgumentException(String.format("The value %s is not in the specified exclusive range of %s to %s", j, l, i));
        }
    }
    
    public static void exclusiveBetween(final long n, final long n2, final long n3, final String s) {
        if (n3 <= n || n3 >= n2) {
            throw new IllegalArgumentException(s);
        }
    }
    
    public static void exclusiveBetween(final double d, final double d2, final double d3) {
        if (d3 <= d || d3 >= d2) {
            throw new IllegalArgumentException(String.format("The value %s is not in the specified exclusive range of %s to %s", d3, d, d2));
        }
    }
    
    public static void exclusiveBetween(final double n, final double n2, final double n3, final String s) {
        if (n3 <= n || n3 >= n2) {
            throw new IllegalArgumentException(s);
        }
    }
    
    public static void isInstanceOf(final Class<?> clazz, final Object o) {
        if (!clazz.isInstance(o)) {
            throw new IllegalArgumentException(String.format("Expected type: %s, actual: %s", clazz.getName(), (o == null) ? "null" : o.getClass().getName()));
        }
    }
    
    public static void isInstanceOf(final Class<?> clazz, final Object o, final String format, final Object... args) {
        if (!clazz.isInstance(o)) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
    
    public static void isAssignableFrom(final Class<?> clazz, final Class<?> clazz2) {
        if (!clazz.isAssignableFrom(clazz2)) {
            throw new IllegalArgumentException(String.format("Cannot assign a %s to a %s", (clazz2 == null) ? "null" : clazz2.getName(), clazz.getName()));
        }
    }
    
    public static void isAssignableFrom(final Class<?> clazz, final Class<?> clazz2, final String format, final Object... args) {
        if (!clazz.isAssignableFrom(clazz2)) {
            throw new IllegalArgumentException(String.format(format, args));
        }
    }
}

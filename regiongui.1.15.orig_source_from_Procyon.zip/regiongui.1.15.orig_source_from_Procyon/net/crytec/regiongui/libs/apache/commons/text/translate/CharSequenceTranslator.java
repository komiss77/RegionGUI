// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.text.translate;

import java.util.Locale;
import java.io.IOException;
import java.io.StringWriter;
import java.io.Writer;

@Deprecated
public abstract class CharSequenceTranslator
{
    static final char[] HEX_DIGITS;
    
    public abstract int translate(final CharSequence p0, final int p1, final Writer p2);
    
    public final String translate(final CharSequence charSequence) {
        if (charSequence == null) {
            return null;
        }
        try {
            final StringWriter stringWriter = new StringWriter(charSequence.length() * 2);
            this.translate(charSequence, stringWriter);
            return stringWriter.toString();
        }
        catch (IOException cause) {
            throw new RuntimeException(cause);
        }
    }
    
    public final void translate(final CharSequence seq, final Writer writer) {
        if (writer == null) {
            throw new IllegalArgumentException("The Writer must not be null");
        }
        if (seq == null) {
            return;
        }
        int i = 0;
        final int length = seq.length();
        while (i < length) {
            final int translate = this.translate(seq, i, writer);
            if (translate == 0) {
                final char char1 = seq.charAt(i);
                writer.write(char1);
                ++i;
                if (!Character.isHighSurrogate(char1) || i >= length) {
                    continue;
                }
                final char char2 = seq.charAt(i);
                if (!Character.isLowSurrogate(char2)) {
                    continue;
                }
                writer.write(char2);
                ++i;
            }
            else {
                for (int j = 0; j < translate; ++j) {
                    i += Character.charCount(Character.codePointAt(seq, i));
                }
            }
        }
    }
    
    public final CharSequenceTranslator with(final CharSequenceTranslator... array) {
        final CharSequenceTranslator[] array2 = new CharSequenceTranslator[array.length + 1];
        array2[0] = this;
        System.arraycopy(array, 0, array2, 1, array.length);
        return new AggregateTranslator(array2);
    }
    
    public static String hex(final int i) {
        return Integer.toHexString(i).toUpperCase(Locale.ENGLISH);
    }
    
    static {
        HEX_DIGITS = new char[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    }
}

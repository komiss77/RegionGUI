// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.apache.commons.reflect;

import java.util.ArrayList;
import java.util.List;
import java.lang.annotation.Annotation;
import java.lang.reflect.TypeVariable;
import java.util.Map;
import java.lang.reflect.Type;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.Iterator;
import java.util.Objects;
import net.crytec.regiongui.libs.apache.commons.Validate;
import java.lang.reflect.AccessibleObject;
import java.lang.reflect.Modifier;
import java.lang.reflect.Member;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import net.crytec.regiongui.libs.apache.commons.ClassUtils;
import net.crytec.regiongui.libs.apache.commons.ArrayUtils;

public class MethodUtils
{
    public static Object invokeMethod(final Object o, final String s) {
        return invokeMethod(o, s, ArrayUtils.EMPTY_OBJECT_ARRAY, null);
    }
    
    public static Object invokeMethod(final Object o, final boolean b, final String s) {
        return invokeMethod(o, b, s, ArrayUtils.EMPTY_OBJECT_ARRAY, null);
    }
    
    public static Object invokeMethod(final Object o, final String s, Object... nullToEmpty) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        return invokeMethod(o, s, nullToEmpty, ClassUtils.toClass(nullToEmpty));
    }
    
    public static Object invokeMethod(final Object o, final boolean b, final String s, Object... nullToEmpty) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        return invokeMethod(o, b, s, nullToEmpty, ClassUtils.toClass(nullToEmpty));
    }
    
    public static Object invokeMethod(final Object obj, final boolean b, final String str, Object[] args, final Class<?>[] array) {
        final Class<?>[] nullToEmpty = ArrayUtils.nullToEmpty(array);
        args = ArrayUtils.nullToEmpty(args);
        String str2;
        Method method;
        if (b) {
            str2 = "No such method: ";
            method = getMatchingMethod(obj.getClass(), str, nullToEmpty);
            if (method != null && !method.isAccessible()) {
                method.setAccessible(true);
            }
        }
        else {
            str2 = "No such accessible method: ";
            method = getMatchingAccessibleMethod(obj.getClass(), str, nullToEmpty);
        }
        if (method == null) {
            throw new NoSuchMethodException(str2 + str + "() on object: " + obj.getClass().getName());
        }
        args = toVarArgs(method, args);
        return method.invoke(obj, args);
    }
    
    public static Object invokeMethod(final Object o, final String s, final Object[] array, final Class<?>[] array2) {
        return invokeMethod(o, false, s, array, array2);
    }
    
    public static Object invokeExactMethod(final Object o, final String s) {
        return invokeExactMethod(o, s, ArrayUtils.EMPTY_OBJECT_ARRAY, null);
    }
    
    public static Object invokeExactMethod(final Object o, final String s, Object... nullToEmpty) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        return invokeExactMethod(o, s, nullToEmpty, ClassUtils.toClass(nullToEmpty));
    }
    
    public static Object invokeExactMethod(final Object obj, final String str, Object[] nullToEmpty, final Class<?>[] array) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        final Method accessibleMethod = getAccessibleMethod(obj.getClass(), str, ArrayUtils.nullToEmpty(array));
        if (accessibleMethod == null) {
            throw new NoSuchMethodException("No such accessible method: " + str + "() on object: " + obj.getClass().getName());
        }
        return accessibleMethod.invoke(obj, nullToEmpty);
    }
    
    public static Object invokeExactStaticMethod(final Class<?> clazz, final String str, Object[] nullToEmpty, final Class<?>[] array) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        final Method accessibleMethod = getAccessibleMethod(clazz, str, ArrayUtils.nullToEmpty(array));
        if (accessibleMethod == null) {
            throw new NoSuchMethodException("No such accessible method: " + str + "() on class: " + clazz.getName());
        }
        return accessibleMethod.invoke(null, nullToEmpty);
    }
    
    public static Object invokeStaticMethod(final Class<?> clazz, final String s, Object... nullToEmpty) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        return invokeStaticMethod(clazz, s, nullToEmpty, ClassUtils.toClass(nullToEmpty));
    }
    
    public static Object invokeStaticMethod(final Class<?> clazz, final String str, Object[] args, final Class<?>[] array) {
        args = ArrayUtils.nullToEmpty(args);
        final Method matchingAccessibleMethod = getMatchingAccessibleMethod(clazz, str, ArrayUtils.nullToEmpty(array));
        if (matchingAccessibleMethod == null) {
            throw new NoSuchMethodException("No such accessible method: " + str + "() on class: " + clazz.getName());
        }
        args = toVarArgs(matchingAccessibleMethod, args);
        return matchingAccessibleMethod.invoke(null, args);
    }
    
    private static Object[] toVarArgs(final Method method, Object[] varArgs) {
        if (method.isVarArgs()) {
            varArgs = getVarArgs(varArgs, method.getParameterTypes());
        }
        return varArgs;
    }
    
    static Object[] getVarArgs(final Object[] array, final Class<?>[] array2) {
        if (array.length == array2.length && array[array.length - 1].getClass().equals(array2[array2.length - 1])) {
            return array;
        }
        final Object[] array3 = new Object[array2.length];
        System.arraycopy(array, 0, array3, 0, array2.length - 1);
        final Class<?> componentType = array2[array2.length - 1].getComponentType();
        final int length = array.length - array2.length + 1;
        Object o = Array.newInstance(ClassUtils.primitiveToWrapper(componentType), length);
        System.arraycopy(array, array2.length - 1, o, 0, length);
        if (componentType.isPrimitive()) {
            o = ArrayUtils.toPrimitive(o);
        }
        array3[array2.length - 1] = o;
        return array3;
    }
    
    public static Object invokeExactStaticMethod(final Class<?> clazz, final String s, Object... nullToEmpty) {
        nullToEmpty = ArrayUtils.nullToEmpty(nullToEmpty);
        return invokeExactStaticMethod(clazz, s, nullToEmpty, ClassUtils.toClass(nullToEmpty));
    }
    
    public static Method getAccessibleMethod(final Class<?> clazz, final String name, final Class<?>... parameterTypes) {
        try {
            return getAccessibleMethod(clazz.getMethod(name, (Class[])parameterTypes));
        }
        catch (NoSuchMethodException ex) {
            return null;
        }
    }
    
    public static Method getAccessibleMethod(Method method) {
        if (!MemberUtils.isAccessible(method)) {
            return null;
        }
        final Class<?> declaringClass = method.getDeclaringClass();
        if (Modifier.isPublic(declaringClass.getModifiers())) {
            return method;
        }
        final String name = method.getName();
        final Class<?>[] parameterTypes = method.getParameterTypes();
        method = getAccessibleMethodFromInterfaceNest(declaringClass, name, parameterTypes);
        if (method == null) {
            method = getAccessibleMethodFromSuperclass(declaringClass, name, parameterTypes);
        }
        return method;
    }
    
    private static Method getAccessibleMethodFromSuperclass(final Class<?> clazz, final String name, final Class<?>... parameterTypes) {
        for (Class<?> clazz2 = clazz.getSuperclass(); clazz2 != null; clazz2 = clazz2.getSuperclass()) {
            if (Modifier.isPublic(clazz2.getModifiers())) {
                try {
                    return clazz2.getMethod(name, parameterTypes);
                }
                catch (NoSuchMethodException ex) {
                    return null;
                }
            }
        }
        return null;
    }
    
    private static Method getAccessibleMethodFromInterfaceNest(Class<?> superclass, final String name, final Class<?>... parameterTypes) {
        while (superclass != null) {
            for (final Class clazz : superclass.getInterfaces()) {
                if (Modifier.isPublic(clazz.getModifiers())) {
                    try {
                        return clazz.getDeclaredMethod(name, (Class[])parameterTypes);
                    }
                    catch (NoSuchMethodException ex) {
                        final Method accessibleMethodFromInterfaceNest = getAccessibleMethodFromInterfaceNest(clazz, name, parameterTypes);
                        if (accessibleMethodFromInterfaceNest != null) {
                            return accessibleMethodFromInterfaceNest;
                        }
                    }
                }
            }
            superclass = superclass.getSuperclass();
        }
        return null;
    }
    
    public static Method getMatchingAccessibleMethod(final Class<?> clazz, final String s, final Class<?>... parameterTypes) {
        try {
            final Method method = clazz.getMethod(s, (Class[])parameterTypes);
            MemberUtils.setAccessibleWorkaround(method);
            return method;
        }
        catch (NoSuchMethodException ex) {
            Method accessibleWorkaround = null;
            for (final Method method2 : clazz.getMethods()) {
                if (method2.getName().equals(s) && MemberUtils.isMatchingMethod(method2, parameterTypes)) {
                    final Method accessibleMethod = getAccessibleMethod(method2);
                    if (accessibleMethod != null && (accessibleWorkaround == null || MemberUtils.compareMethodFit(accessibleMethod, accessibleWorkaround, parameterTypes) < 0)) {
                        accessibleWorkaround = accessibleMethod;
                    }
                }
            }
            if (accessibleWorkaround != null) {
                MemberUtils.setAccessibleWorkaround(accessibleWorkaround);
            }
            if (accessibleWorkaround != null && accessibleWorkaround.isVarArgs() && accessibleWorkaround.getParameterTypes().length > 0 && parameterTypes.length > 0) {
                final Class<?>[] parameterTypes2 = accessibleWorkaround.getParameterTypes();
                final String name = ClassUtils.primitiveToWrapper(parameterTypes2[parameterTypes2.length - 1].getComponentType()).getName();
                final String name2 = parameterTypes[parameterTypes.length - 1].getName();
                final String name3 = parameterTypes[parameterTypes.length - 1].getSuperclass().getName();
                if (!name.equals(name2) && !name.equals(name3)) {
                    return null;
                }
            }
            return accessibleWorkaround;
        }
    }
    
    public static Method getMatchingMethod(final Class<?> clazz, final String s, final Class<?>... a) {
        Validate.notNull(clazz, "Null class not allowed.", new Object[0]);
        Validate.notEmpty(s, "Null or blank methodName not allowed.", new Object[0]);
        Method[] declaredMethods = clazz.getDeclaredMethods();
        final Iterator<Class<?>> iterator = ClassUtils.getAllSuperclasses(clazz).iterator();
        while (iterator.hasNext()) {
            declaredMethods = ArrayUtils.addAll(declaredMethods, iterator.next().getDeclaredMethods());
        }
        Method method = null;
        for (final Method method2 : declaredMethods) {
            if (s.equals(method2.getName()) && Objects.deepEquals(a, method2.getParameterTypes())) {
                return method2;
            }
            if (s.equals(method2.getName()) && ClassUtils.isAssignable(a, method2.getParameterTypes(), true)) {
                if (method == null) {
                    method = method2;
                }
                else if (distance(a, method2.getParameterTypes()) < distance(a, method.getParameterTypes())) {
                    method = method2;
                }
            }
        }
        return method;
    }
    
    private static int distance(final Class<?>[] array, final Class<?>[] array2) {
        int n = 0;
        if (!ClassUtils.isAssignable(array, array2, true)) {
            return -1;
        }
        for (int i = 0; i < array.length; ++i) {
            if (!array[i].equals(array2[i])) {
                if (ClassUtils.isAssignable(array[i], array2[i], true) && !ClassUtils.isAssignable(array[i], array2[i], false)) {
                    ++n;
                }
                else {
                    n += 2;
                }
            }
        }
        return n;
    }
    
    public static Set<Method> getOverrideHierarchy(final Method method, final ClassUtils.Interfaces interfaces) {
        Validate.notNull(method);
        final LinkedHashSet<Method> set = new LinkedHashSet<Method>();
        set.add(method);
        final Class<?>[] parameterTypes = method.getParameterTypes();
        final Class<?> declaringClass = method.getDeclaringClass();
        final Iterator<Class<?>> iterator = ClassUtils.hierarchy(declaringClass, interfaces).iterator();
        iterator.next();
    Label_0053:
        while (iterator.hasNext()) {
            final Method matchingAccessibleMethod = getMatchingAccessibleMethod(iterator.next(), method.getName(), parameterTypes);
            if (matchingAccessibleMethod == null) {
                continue;
            }
            if (Arrays.equals(matchingAccessibleMethod.getParameterTypes(), parameterTypes)) {
                set.add(matchingAccessibleMethod);
            }
            else {
                final Map<TypeVariable<?>, Type> typeArguments = TypeUtils.getTypeArguments(declaringClass, matchingAccessibleMethod.getDeclaringClass());
                for (int i = 0; i < parameterTypes.length; ++i) {
                    if (!TypeUtils.equals(TypeUtils.unrollVariables(typeArguments, method.getGenericParameterTypes()[i]), TypeUtils.unrollVariables(typeArguments, matchingAccessibleMethod.getGenericParameterTypes()[i]))) {
                        continue Label_0053;
                    }
                }
                set.add(matchingAccessibleMethod);
            }
        }
        return set;
    }
    
    public static Method[] getMethodsWithAnnotation(final Class<?> clazz, final Class<? extends Annotation> clazz2) {
        return getMethodsWithAnnotation(clazz, clazz2, false, false);
    }
    
    public static List<Method> getMethodsListWithAnnotation(final Class<?> clazz, final Class<? extends Annotation> clazz2) {
        return getMethodsListWithAnnotation(clazz, clazz2, false, false);
    }
    
    public static Method[] getMethodsWithAnnotation(final Class<?> clazz, final Class<? extends Annotation> clazz2, final boolean b, final boolean b2) {
        final List<Method> methodsListWithAnnotation = getMethodsListWithAnnotation(clazz, clazz2, b, b2);
        return methodsListWithAnnotation.toArray(new Method[methodsListWithAnnotation.size()]);
    }
    
    public static List<Method> getMethodsListWithAnnotation(final Class<?> clazz, final Class<? extends Annotation> annotationClass, final boolean b, final boolean b2) {
        Validate.isTrue(clazz != null, "The class must not be null", new Object[0]);
        Validate.isTrue(annotationClass != null, "The annotation class must not be null", new Object[0]);
        final List<Class<?>> list = b ? getAllSuperclassesAndInterfaces(clazz) : new ArrayList<Class<?>>();
        list.add(0, clazz);
        final ArrayList<Method> list2 = new ArrayList<Method>();
        for (final Class<?> clazz2 : list) {
            for (final Method method : b2 ? clazz2.getDeclaredMethods() : clazz2.getMethods()) {
                if (method.getAnnotation(annotationClass) != null) {
                    list2.add(method);
                }
            }
        }
        return list2;
    }
    
    public static <A extends Annotation> A getAnnotation(final Method method, final Class<A> clazz, final boolean b, final boolean b2) {
        Validate.isTrue(method != null, "The method must not be null", new Object[0]);
        Validate.isTrue(clazz != null, "The annotation class must not be null", new Object[0]);
        if (!b2 && !MemberUtils.isAccessible(method)) {
            return null;
        }
        Annotation annotation = method.getAnnotation(clazz);
        if (annotation == null && b) {
            for (final Class<?> clazz2 : getAllSuperclassesAndInterfaces(method.getDeclaringClass())) {
                Method method2;
                try {
                    method2 = (b2 ? clazz2.getDeclaredMethod(method.getName(), method.getParameterTypes()) : clazz2.getMethod(method.getName(), method.getParameterTypes()));
                }
                catch (NoSuchMethodException ex) {
                    continue;
                }
                annotation = method2.getAnnotation(clazz);
                if (annotation != null) {
                    break;
                }
            }
        }
        return (A)annotation;
    }
    
    private static List<Class<?>> getAllSuperclassesAndInterfaces(final Class<?> clazz) {
        if (clazz == null) {
            return null;
        }
        final ArrayList<Class<?>> list = new ArrayList<Class<?>>();
        final List<Class<?>> allSuperclasses = ClassUtils.getAllSuperclasses(clazz);
        int n = 0;
        final List<Class<?>> allInterfaces = ClassUtils.getAllInterfaces(clazz);
        int n2 = 0;
        while (n2 < allInterfaces.size() || n < allSuperclasses.size()) {
            Class<?> clazz2;
            if (n2 >= allInterfaces.size()) {
                clazz2 = allSuperclasses.get(n++);
            }
            else if (n >= allSuperclasses.size()) {
                clazz2 = allInterfaces.get(n2++);
            }
            else if (n2 < n) {
                clazz2 = allInterfaces.get(n2++);
            }
            else if (n < n2) {
                clazz2 = allSuperclasses.get(n++);
            }
            else {
                clazz2 = allInterfaces.get(n2++);
            }
            list.add(clazz2);
        }
        return list;
    }
}

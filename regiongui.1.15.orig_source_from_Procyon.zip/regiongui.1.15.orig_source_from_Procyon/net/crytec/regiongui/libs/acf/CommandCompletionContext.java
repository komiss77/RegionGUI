// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CommandCompletionContext<I extends CommandIssuer>
{
    private final RegisteredCommand command;
    protected final I issuer;
    private final String input;
    private final String config;
    private final Map<String, String> configs;
    private final List<String> args;
    
    CommandCompletionContext(final RegisteredCommand command, final I issuer, final String input, final String config, final String[] args) {
        this.configs = new HashMap<String, String>();
        this.command = command;
        this.issuer = issuer;
        this.input = input;
        if (config != null) {
            final String[] split;
            final String[] array = split = ACFPatterns.COMMA.split(config);
            for (int length = split.length, i = 0; i < length; ++i) {
                final String[] split2 = ACFPatterns.EQUALS.split(split[i], 2);
                this.configs.put(split2[0].toLowerCase(), (split2.length > 1) ? split2[1] : null);
            }
            this.config = array[0];
        }
        else {
            this.config = null;
        }
        this.args = Arrays.asList(args);
    }
    
    public Map<String, String> getConfigs() {
        return this.configs;
    }
    
    public String getConfig(final String key) {
        return this.getConfig(key, null);
    }
    
    public String getConfig(final String key, final String def) {
        return this.configs.getOrDefault(key.toLowerCase(), def);
    }
    
    public boolean hasConfig(final String key) {
        return this.configs.containsKey(key.toLowerCase());
    }
    
    public <T> T getContextValue(final Class<? extends T> clazz) {
        return this.getContextValue(clazz, (Integer)null);
    }
    
    public <T> T getContextValue(final Class<? extends T> clazz, Integer paramIdx) {
        Object o = null;
        if (paramIdx != null) {
            if (paramIdx >= this.command.parameters.length) {
                throw new IllegalArgumentException("Param index is higher than number of parameters");
            }
            final CommandParameter<CEC> commandParameter = this.command.parameters[paramIdx];
            final Class<?> type = commandParameter.getType();
            if (!clazz.isAssignableFrom(type)) {
                throw new IllegalArgumentException(commandParameter.getName() + ":" + type.getName() + " can not satisfy " + clazz.getName());
            }
            o = commandParameter.getName();
        }
        else {
            final CommandParameter<CEC>[] parameters = this.command.parameters;
            for (int i = 0; i < parameters.length; ++i) {
                final CommandParameter<CEC> commandParameter2 = parameters[i];
                if (clazz.isAssignableFrom(commandParameter2.getType())) {
                    paramIdx = i;
                    o = commandParameter2.getName();
                    break;
                }
            }
            if (paramIdx == null) {
                throw new IllegalStateException("Can not find any parameter that can satisfy " + clazz.getName());
            }
        }
        final Map resolveContexts = this.command.resolveContexts(this.issuer, this.args, this.args.size() - 1);
        if (resolveContexts == null || paramIdx > resolveContexts.size()) {
            ACFUtil.sneaky(new CommandCompletionTextLookupException());
        }
        return resolveContexts.get(o);
    }
    
    public CommandIssuer getIssuer() {
        return this.issuer;
    }
    
    public String getInput() {
        return this.input;
    }
    
    public String getConfig() {
        return this.config;
    }
    
    public boolean isAsync() {
        return CommandManager.getCurrentCommandOperationContext().isAsync();
    }
}

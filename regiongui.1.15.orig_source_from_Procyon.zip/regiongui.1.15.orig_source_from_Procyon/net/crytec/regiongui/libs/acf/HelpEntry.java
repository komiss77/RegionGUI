// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

public class HelpEntry
{
    private final CommandHelp commandHelp;
    private final RegisteredCommand command;
    private int searchScore;
    
    HelpEntry(final CommandHelp commandHelp, final RegisteredCommand command) {
        this.searchScore = 1;
        this.commandHelp = commandHelp;
        this.command = command;
    }
    
    RegisteredCommand getRegisteredCommand() {
        return this.command;
    }
    
    public String getCommand() {
        return this.command.command;
    }
    
    public String getCommandPrefix() {
        return this.commandHelp.getCommandPrefix();
    }
    
    public String getParameterSyntax() {
        return (this.command.syntaxText != null) ? this.command.syntaxText : "";
    }
    
    public String getDescription() {
        return this.command.getHelpText();
    }
    
    public void setSearchScore(final int searchScore) {
        this.searchScore = searchScore;
    }
    
    public boolean shouldShow() {
        return this.searchScore > 0;
    }
    
    public int getSearchScore() {
        return this.searchScore;
    }
    
    public String getSearchTags() {
        return this.command.helpSearchTags;
    }
    
    public CommandParameter[] getParameters() {
        return this.command.parameters;
    }
}

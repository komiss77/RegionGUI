// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Collection;
import org.bukkit.command.CommandSender;
import java.util.List;
import org.bukkit.Bukkit;
import java.util.ArrayList;
import org.bukkit.command.Command;
import org.bukkit.help.GenericCommandHelpTopic;

public class ACFBukkitHelpTopic extends GenericCommandHelpTopic
{
    public ACFBukkitHelpTopic(final BukkitCommandManager manager, final BukkitRootCommand command) {
        super((Command)command);
        final ArrayList<String> list = new ArrayList<String>();
        final BukkitCommandIssuer bukkitCommandIssuer = new BukkitCommandIssuer(manager, Bukkit.getConsoleSender()) {
            @Override
            public void sendMessageInternal(final String message) {
                list.add(message);
            }
        };
        manager.generateCommandHelp(bukkitCommandIssuer, command).showHelp(bukkitCommandIssuer);
        this.fullText = ACFUtil.join(list, "\n");
    }
}

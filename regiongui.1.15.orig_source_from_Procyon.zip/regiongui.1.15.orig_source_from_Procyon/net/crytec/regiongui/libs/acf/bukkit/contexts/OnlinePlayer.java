// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf.bukkit.contexts;

import java.util.Objects;
import org.bukkit.entity.Player;

public class OnlinePlayer
{
    public final Player player;
    
    public OnlinePlayer(final Player player) {
        this.player = player;
    }
    
    public Player getPlayer() {
        return this.player;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o || (o != null && this.getClass() == o.getClass() && Objects.equals(this.player, ((OnlinePlayer)o).player));
    }
    
    @Override
    public int hashCode() {
        return Objects.hash(this.player);
    }
    
    @Override
    public String toString() {
        return "OnlinePlayer{player=" + this.player + '}';
    }
}

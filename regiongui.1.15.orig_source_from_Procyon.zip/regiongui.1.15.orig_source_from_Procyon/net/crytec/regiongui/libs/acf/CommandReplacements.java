// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.regex.Matcher;
import java.util.Iterator;
import org.jetbrains.annotations.Nullable;
import java.util.AbstractMap;
import java.util.LinkedHashMap;
import java.util.regex.Pattern;
import java.util.Map;

public class CommandReplacements
{
    private final CommandManager manager;
    private final Map<String, Map.Entry<Pattern, String>> replacements;
    
    CommandReplacements(final CommandManager manager) {
        this.replacements = new LinkedHashMap<String, Map.Entry<Pattern, String>>();
        this.manager = manager;
        this.addReplacement0("truthy", "true|false|yes|no|1|0|on|off|t|f");
    }
    
    public void addReplacements(final String... replacements) {
        if (replacements.length == 0 || replacements.length % 2 != 0) {
            throw new IllegalArgumentException("Must pass a number of arguments divisible by 2.");
        }
        for (int i = 0; i < replacements.length; i += 2) {
            this.addReplacement(replacements[i], replacements[i + 1]);
        }
    }
    
    public String addReplacement(final String key, final String val) {
        return this.addReplacement0(key, val);
    }
    
    @Nullable
    private String addReplacement0(String key, final String val) {
        key = ACFPatterns.PERCENTAGE.matcher(key.toLowerCase()).replaceAll("");
        final AbstractMap.SimpleImmutableEntry<Pattern, String> simpleImmutableEntry = this.replacements.put(key, new AbstractMap.SimpleImmutableEntry<Pattern, String>(Pattern.compile("%" + Pattern.quote(key) + "\\b", 2), val));
        if (simpleImmutableEntry != null) {
            return simpleImmutableEntry.getValue();
        }
        return null;
    }
    
    public String replace(String text) {
        if (text == null) {
            return null;
        }
        for (final Map.Entry<Pattern, String> entry : this.replacements.values()) {
            text = entry.getKey().matcher(text).replaceAll(entry.getValue());
        }
        final Matcher matcher = Pattern.compile("%.[^\\s]*").matcher(text);
        while (matcher.find()) {
            this.manager.log(LogLevel.ERROR, "Found unregistered replacement: " + matcher.group());
        }
        return text;
    }
}

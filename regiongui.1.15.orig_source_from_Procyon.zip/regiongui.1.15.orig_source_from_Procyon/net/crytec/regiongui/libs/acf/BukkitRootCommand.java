// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.command.CommandSender;
import java.util.ArrayList;
import com.google.common.collect.HashMultimap;
import java.util.List;
import com.google.common.collect.SetMultimap;
import org.bukkit.command.Command;

public class BukkitRootCommand extends Command implements RootCommand
{
    private final BukkitCommandManager manager;
    private final String name;
    private BaseCommand defCommand;
    private SetMultimap<String, RegisteredCommand> subCommands;
    private List<BaseCommand> children;
    boolean isRegistered;
    
    BukkitRootCommand(final BukkitCommandManager manager, final String name) {
        super(name);
        this.subCommands = (SetMultimap<String, RegisteredCommand>)HashMultimap.create();
        this.children = new ArrayList<BaseCommand>();
        this.isRegistered = false;
        this.manager = manager;
        this.name = name;
    }
    
    public String getDescription() {
        final RegisteredCommand defaultRegisteredCommand = this.getDefaultRegisteredCommand();
        if (defaultRegisteredCommand != null && !defaultRegisteredCommand.getHelpText().isEmpty()) {
            return defaultRegisteredCommand.getHelpText();
        }
        if (defaultRegisteredCommand != null && defaultRegisteredCommand.scope.description != null) {
            return defaultRegisteredCommand.scope.description;
        }
        if (this.defCommand.description != null) {
            return this.defCommand.description;
        }
        return super.getDescription();
    }
    
    public String getCommandName() {
        return this.name;
    }
    
    public List<String> tabComplete(final CommandSender sender, String commandLabel, final String[] args) {
        if (commandLabel.contains(":")) {
            commandLabel = ACFPatterns.COLON.split(commandLabel, 2)[1];
        }
        return this.getTabCompletions(this.manager.getCommandIssuer(sender), commandLabel, args);
    }
    
    public boolean execute(final CommandSender sender, String commandLabel, final String[] args) {
        if (commandLabel.contains(":")) {
            commandLabel = ACFPatterns.COLON.split(commandLabel, 2)[1];
        }
        this.execute(this.manager.getCommandIssuer(sender), commandLabel, args);
        return true;
    }
    
    public boolean testPermissionSilent(final CommandSender target) {
        return this.hasAnyPermission(this.manager.getCommandIssuer(target));
    }
    
    public void addChild(final BaseCommand command) {
        if (this.defCommand == null || !command.subCommands.get((Object)"__default").isEmpty()) {
            this.defCommand = command;
        }
        this.addChildShared(this.children, this.subCommands, command);
        this.setPermission(this.getUniquePermission());
    }
    
    public CommandManager getManager() {
        return this.manager;
    }
    
    public SetMultimap<String, RegisteredCommand> getSubCommands() {
        return this.subCommands;
    }
    
    public List<BaseCommand> getChildren() {
        return this.children;
    }
    
    public BaseCommand getDefCommand() {
        return this.defCommand;
    }
}

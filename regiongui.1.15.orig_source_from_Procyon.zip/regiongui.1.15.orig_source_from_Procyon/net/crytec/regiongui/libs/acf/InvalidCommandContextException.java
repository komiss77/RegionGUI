// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

public class InvalidCommandContextException extends RuntimeException
{
    InvalidCommandContextException(final String message) {
        super(message);
    }
}

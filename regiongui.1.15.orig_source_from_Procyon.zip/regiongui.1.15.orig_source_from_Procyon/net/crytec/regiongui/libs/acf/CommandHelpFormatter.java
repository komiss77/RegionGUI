// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.jetbrains.annotations.NotNull;
import co.aikar.locales.MessageKeyProvider;
import java.util.Iterator;
import java.util.List;

public class CommandHelpFormatter
{
    private final CommandManager manager;
    
    public CommandHelpFormatter(final CommandManager manager) {
        this.manager = manager;
    }
    
    public void showAllResults(final CommandHelp commandHelp, final List<HelpEntry> entries) {
        final CommandIssuer issuer = commandHelp.getIssuer();
        this.printHelpHeader(commandHelp, issuer);
        final Iterator<HelpEntry> iterator = entries.iterator();
        while (iterator.hasNext()) {
            this.printHelpCommand(commandHelp, issuer, iterator.next());
        }
        this.printHelpFooter(commandHelp, issuer);
    }
    
    public void showSearchResults(final CommandHelp commandHelp, final List<HelpEntry> entries) {
        final CommandIssuer issuer = commandHelp.getIssuer();
        this.printSearchHeader(commandHelp, issuer);
        final Iterator<HelpEntry> iterator = entries.iterator();
        while (iterator.hasNext()) {
            this.printSearchEntry(commandHelp, issuer, iterator.next());
        }
        this.printSearchFooter(commandHelp, issuer);
    }
    
    public void showDetailedHelp(final CommandHelp commandHelp, final HelpEntry entry) {
        final CommandIssuer issuer = commandHelp.getIssuer();
        this.printDetailedHelpCommand(commandHelp, issuer, entry);
        for (final CommandParameter param : entry.getParameters()) {
            final String description = param.getDescription();
            if (description != null && !description.isEmpty()) {
                this.printDetailedParameter(commandHelp, issuer, entry, param);
            }
        }
    }
    
    public void printHelpHeader(final CommandHelp help, final CommandIssuer issuer) {
        issuer.sendMessage(MessageType.HELP, MessageKeys.HELP_HEADER, this.getHeaderFooterFormatReplacements(help));
    }
    
    public void printHelpCommand(final CommandHelp help, final CommandIssuer issuer, final HelpEntry entry) {
        final String[] split = ACFPatterns.NEWLINE.split(this.manager.formatMessage(issuer, MessageType.HELP, MessageKeys.HELP_FORMAT, this.getEntryFormatReplacements(help, entry)));
        for (int length = split.length, i = 0; i < length; ++i) {
            issuer.sendMessageInternal(ACFUtil.rtrim(split[i]));
        }
    }
    
    public void printHelpFooter(final CommandHelp help, final CommandIssuer issuer) {
        if (help.isOnlyPage()) {
            return;
        }
        issuer.sendMessage(MessageType.HELP, MessageKeys.HELP_PAGE_INFORMATION, this.getHeaderFooterFormatReplacements(help));
    }
    
    public void printSearchHeader(final CommandHelp help, final CommandIssuer issuer) {
        issuer.sendMessage(MessageType.HELP, MessageKeys.HELP_SEARCH_HEADER, this.getHeaderFooterFormatReplacements(help));
    }
    
    public void printSearchEntry(final CommandHelp help, final CommandIssuer issuer, final HelpEntry page) {
        final String[] split = ACFPatterns.NEWLINE.split(this.manager.formatMessage(issuer, MessageType.HELP, MessageKeys.HELP_FORMAT, this.getEntryFormatReplacements(help, page)));
        for (int length = split.length, i = 0; i < length; ++i) {
            issuer.sendMessageInternal(ACFUtil.rtrim(split[i]));
        }
    }
    
    public void printSearchFooter(final CommandHelp help, final CommandIssuer issuer) {
        if (help.isOnlyPage()) {
            return;
        }
        issuer.sendMessage(MessageType.HELP, MessageKeys.HELP_PAGE_INFORMATION, this.getHeaderFooterFormatReplacements(help));
    }
    
    public void printDetailedHelpHeader(final CommandHelp help, final CommandIssuer issuer, final HelpEntry entry) {
        issuer.sendMessage(MessageType.HELP, MessageKeys.HELP_DETAILED_HEADER, "{command}", entry.getCommand(), "{commandprefix}", help.getCommandPrefix());
    }
    
    public void printDetailedHelpCommand(final CommandHelp help, final CommandIssuer issuer, final HelpEntry entry) {
        final String[] split = ACFPatterns.NEWLINE.split(this.manager.formatMessage(issuer, MessageType.HELP, MessageKeys.HELP_DETAILED_COMMAND_FORMAT, this.getEntryFormatReplacements(help, entry)));
        for (int length = split.length, i = 0; i < length; ++i) {
            issuer.sendMessageInternal(ACFUtil.rtrim(split[i]));
        }
    }
    
    public void printDetailedParameter(final CommandHelp help, final CommandIssuer issuer, final HelpEntry entry, final CommandParameter param) {
        final String[] split = ACFPatterns.NEWLINE.split(this.manager.formatMessage(issuer, MessageType.HELP, MessageKeys.HELP_DETAILED_PARAMETER_FORMAT, this.getParameterFormatReplacements(help, param, entry)));
        for (int length = split.length, i = 0; i < length; ++i) {
            issuer.sendMessageInternal(ACFUtil.rtrim(split[i]));
        }
    }
    
    public void printDetailedHelpFooter(final CommandHelp help, final CommandIssuer issuer, final HelpEntry entry) {
    }
    
    public String[] getHeaderFooterFormatReplacements(final CommandHelp help) {
        return new String[] { "{search}", (help.search != null) ? String.join(" ", help.search) : "", "{command}", help.getCommandName(), "{commandprefix}", help.getCommandPrefix(), "{rootcommand}", help.getCommandName(), "{page}", "" + help.getPage(), "{totalpages}", "" + help.getTotalPages(), "{results}", "" + help.getTotalResults() };
    }
    
    public String[] getEntryFormatReplacements(final CommandHelp help, final HelpEntry entry) {
        return new String[] { "{command}", entry.getCommand(), "{commandprefix}", help.getCommandPrefix(), "{parameters}", entry.getParameterSyntax(), "{separator}", entry.getDescription().isEmpty() ? "" : "-", "{description}", entry.getDescription() };
    }
    
    @NotNull
    public String[] getParameterFormatReplacements(final CommandHelp help, final CommandParameter param, final HelpEntry entry) {
        return new String[] { "{name}", param.getName(), "{syntaxorname}", ACFUtil.nullDefault(param.getSyntax(), param.getName()), "{syntax}", ACFUtil.nullDefault(param.getSyntax(), ""), "{description}", ACFUtil.nullDefault(param.getDescription(), ""), "{command}", help.getCommandName(), "{fullcommand}", entry.getCommand(), "{commandprefix}", help.getCommandPrefix() };
    }
}

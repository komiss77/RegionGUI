// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.lang.reflect.Method;
import net.crytec.regiongui.libs.timings.lib.MCTiming;

public class BukkitRegisteredCommand extends RegisteredCommand<BukkitCommandExecutionContext>
{
    private final MCTiming timing;
    
    BukkitRegisteredCommand(final BaseCommand scope, final String command, final Method method, final String prefSubCommand) {
        super(scope, command, method, prefSubCommand);
        final BukkitCommandManager bukkitCommandManager = (BukkitCommandManager)scope.manager;
        this.timing = bukkitCommandManager.getTimings().of("Command: " + this.command, bukkitCommandManager.commandTiming);
    }
    
    @Override
    public void preCommand() {
        this.timing.startTiming();
        super.preCommand();
    }
    
    @Override
    public void postCommand() {
        super.postCommand();
        this.timing.stopTiming();
    }
}

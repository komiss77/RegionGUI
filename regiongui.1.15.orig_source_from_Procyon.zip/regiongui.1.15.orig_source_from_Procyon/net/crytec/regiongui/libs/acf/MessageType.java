// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.concurrent.atomic.AtomicInteger;

public class MessageType
{
    private static final AtomicInteger counter;
    public static final MessageType INFO;
    public static final MessageType SYNTAX;
    public static final MessageType ERROR;
    public static final MessageType HELP;
    private final int id;
    
    public MessageType() {
        this.id = MessageType.counter.getAndIncrement();
    }
    
    @Override
    public int hashCode() {
        return this.id;
    }
    
    @Override
    public boolean equals(final Object o) {
        return this == o;
    }
    
    static {
        counter = new AtomicInteger(1);
        INFO = new MessageType();
        SYNTAX = new MessageType();
        ERROR = new MessageType();
        HELP = new MessageType();
    }
}

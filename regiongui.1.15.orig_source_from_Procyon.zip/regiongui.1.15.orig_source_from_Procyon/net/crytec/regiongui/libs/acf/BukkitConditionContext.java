// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class BukkitConditionContext extends ConditionContext<BukkitCommandIssuer>
{
    BukkitConditionContext(final BukkitCommandIssuer issuer, final String config) {
        super(issuer, config);
    }
    
    public CommandSender getSender() {
        return this.getIssuer().getIssuer();
    }
    
    public Player getPlayer() {
        return this.getIssuer().getPlayer();
    }
}

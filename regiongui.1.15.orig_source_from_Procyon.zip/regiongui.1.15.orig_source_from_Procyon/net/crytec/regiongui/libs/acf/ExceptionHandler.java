// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.List;

@FunctionalInterface
public interface ExceptionHandler
{
    boolean execute(final BaseCommand command, final RegisteredCommand registeredCommand, final CommandIssuer sender, final List<String> args, final Throwable t);
}

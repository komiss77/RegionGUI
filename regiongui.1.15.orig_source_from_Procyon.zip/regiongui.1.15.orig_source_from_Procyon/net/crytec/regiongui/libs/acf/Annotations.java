// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.AnnotatedElement;
import java.util.IdentityHashMap;
import java.lang.reflect.Method;
import java.lang.annotation.Annotation;
import java.util.Map;

class Annotations<M extends CommandManager> extends AnnotationLookups
{
    public static final int NOTHING = 0;
    public static final int REPLACEMENTS = 1;
    public static final int LOWERCASE = 2;
    public static final int UPPERCASE = 4;
    public static final int NO_EMPTY = 8;
    public static final int DEFAULT_EMPTY = 16;
    private final M manager;
    private final Map<Class<? extends Annotation>, Method> valueMethods;
    private final Map<Class<? extends Annotation>, Void> noValueAnnotations;
    
    Annotations(final M manager) {
        this.valueMethods = new IdentityHashMap<Class<? extends Annotation>, Method>();
        this.noValueAnnotations = new IdentityHashMap<Class<? extends Annotation>, Void>();
        this.manager = manager;
    }
    
    @Override
    String getAnnotationValue(final AnnotatedElement object, final Class<? extends Annotation> annoClass, final int options) {
        final Annotation annotation = object.getAnnotation(annoClass);
        String text = null;
        if (annotation != null) {
            Method method = this.valueMethods.get(annoClass);
            if (this.noValueAnnotations.containsKey(annoClass)) {
                text = "";
            }
            else {
                try {
                    if (method == null) {
                        method = annoClass.getMethod("value", (Class[])new Class[0]);
                        method.setAccessible(true);
                        this.valueMethods.put(annoClass, method);
                    }
                    text = (String)method.invoke(annotation, new Object[0]);
                }
                catch (NoSuchMethodException | IllegalAccessException | InvocationTargetException ex2) {
                    final InvocationTargetException ex;
                    final InvocationTargetException throwable = ex;
                    if (!(throwable instanceof NoSuchMethodException)) {
                        this.manager.log(LogLevel.ERROR, "Error getting annotation value", throwable);
                    }
                    this.noValueAnnotations.put(annoClass, null);
                    text = "";
                }
            }
        }
        if (text == null) {
            if (!hasOption(options, 16)) {
                return null;
            }
            text = "";
        }
        if (hasOption(options, 1)) {
            text = this.manager.getCommandReplacements().replace(text);
        }
        if (hasOption(options, 2)) {
            text = text.toLowerCase(this.manager.getLocales().getDefaultLocale());
        }
        else if (hasOption(options, 4)) {
            text = text.toUpperCase(this.manager.getLocales().getDefaultLocale());
        }
        if (text.isEmpty() && hasOption(options, 8)) {
            text = null;
        }
        return text;
    }
    
    private static boolean hasOption(final int options, final int option) {
        return (options & option) == option;
    }
}

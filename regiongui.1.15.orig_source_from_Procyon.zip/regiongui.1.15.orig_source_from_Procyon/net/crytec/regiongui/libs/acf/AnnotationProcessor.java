// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.lang.reflect.Parameter;
import org.jetbrains.annotations.Nullable;
import java.util.Set;
import java.lang.annotation.Annotation;

@Deprecated
public interface AnnotationProcessor<T extends Annotation>
{
    @Nullable
    default Set<Class<?>> getApplicableParameters() {
        return null;
    }
    
    default void onBaseCommandRegister(final BaseCommand command, final T annotation) {
    }
    
    default void onCommandRegistered(final RegisteredCommand command, final T annotation) {
    }
    
    default void onParameterRegistered(final RegisteredCommand command, final int parameterIndex, final Parameter p, final T annotation) {
    }
    
    default void onPreComand(final CommandOperationContext context) {
    }
    
    default void onPostComand(final CommandOperationContext context) {
    }
    
    default void onPreContextResolution(final CommandExecutionContext context) {
    }
    
    default void onPostContextResolution(final CommandExecutionContext context, final Object resolvedValue) {
    }
}

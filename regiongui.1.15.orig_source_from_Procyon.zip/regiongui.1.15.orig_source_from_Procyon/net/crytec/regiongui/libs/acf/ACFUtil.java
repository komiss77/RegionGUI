// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.function.Consumer;
import java.util.ArrayList;
import java.util.Iterator;
import org.jetbrains.annotations.Nullable;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.stream.Stream;
import java.text.Normalizer;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.math.BigDecimal;
import java.util.Collection;
import net.crytec.regiongui.libs.acf.apachecommonslang.ApacheCommonsLangUtil;
import java.text.NumberFormat;
import java.util.Random;

public final class ACFUtil
{
    public static final Random RANDOM;
    
    private ACFUtil() {
    }
    
    public static String padRight(final String s, final int n) {
        return String.format("%1$-" + n + "s", s);
    }
    
    public static String padLeft(final String s, final int n) {
        return String.format("%1$" + n + "s", s);
    }
    
    public static String formatNumber(final Integer balance) {
        return NumberFormat.getInstance().format(balance);
    }
    
    public static <T extends Enum> T getEnumFromName(final T[] types, final String name) {
        return getEnumFromName(types, name, null);
    }
    
    public static <T extends Enum> T getEnumFromName(final T[] types, final String name, final T def) {
        for (final Enum enum1 : types) {
            if (enum1.name().equalsIgnoreCase(name)) {
                return (T)enum1;
            }
        }
        return def;
    }
    
    public static <T extends Enum> T getEnumFromOrdinal(final T[] types, final int ordinal) {
        for (final Enum enum1 : types) {
            if (enum1.ordinal() == ordinal) {
                return (T)enum1;
            }
        }
        return null;
    }
    
    public static String ucfirst(final String str) {
        return ApacheCommonsLangUtil.capitalizeFully(str);
    }
    
    public static Double parseDouble(final String var) {
        return parseDouble(var, null);
    }
    
    public static Double parseDouble(final String var, final Double def) {
        if (var == null) {
            return def;
        }
        try {
            return Double.parseDouble(var);
        }
        catch (NumberFormatException ex) {
            return def;
        }
    }
    
    public static Float parseFloat(final String var) {
        return parseFloat(var, null);
    }
    
    public static Float parseFloat(final String var, final Float def) {
        if (var == null) {
            return def;
        }
        try {
            return Float.parseFloat(var);
        }
        catch (NumberFormatException ex) {
            return def;
        }
    }
    
    public static Long parseLong(final String var) {
        return parseLong(var, null);
    }
    
    public static Long parseLong(final String var, final Long def) {
        if (var == null) {
            return def;
        }
        try {
            return Long.parseLong(var);
        }
        catch (NumberFormatException ex) {
            return def;
        }
    }
    
    public static Integer parseInt(final String var) {
        return parseInt(var, null);
    }
    
    public static Integer parseInt(final String var, final Integer def) {
        if (var == null) {
            return def;
        }
        try {
            return Integer.parseInt(var);
        }
        catch (NumberFormatException ex) {
            return def;
        }
    }
    
    public static boolean randBool() {
        return ACFUtil.RANDOM.nextBoolean();
    }
    
    public static <T> T nullDefault(final Object val, final Object def) {
        return (T)((val != null) ? val : def);
    }
    
    public static String join(final Collection<String> args) {
        return ApacheCommonsLangUtil.join(args, " ");
    }
    
    public static String join(final Collection<String> args, final String sep) {
        return ApacheCommonsLangUtil.join(args, sep);
    }
    
    public static String join(final String[] args) {
        return join(args, 0, ' ');
    }
    
    public static String join(final String[] args, final String sep) {
        return ApacheCommonsLangUtil.join((Object[])args, sep);
    }
    
    public static String join(final String[] args, final char sep) {
        return join(args, 0, sep);
    }
    
    public static String join(final String[] args, final int index) {
        return join(args, index, ' ');
    }
    
    public static String join(final String[] args, final int index, final char sep) {
        return ApacheCommonsLangUtil.join((Object[])args, sep, index, args.length);
    }
    
    public static String simplifyString(final String str) {
        if (str == null) {
            return null;
        }
        return ACFPatterns.NON_ALPHA_NUMERIC.matcher(str.toLowerCase()).replaceAll("");
    }
    
    public static double round(final double x, final int scale) {
        try {
            return new BigDecimal(Double.toString(x)).setScale(scale, 4).doubleValue();
        }
        catch (NumberFormatException ex) {
            if (Double.isInfinite(x)) {
                return x;
            }
            return Double.NaN;
        }
    }
    
    public static int roundUp(final int num, final int multiple) {
        if (multiple == 0) {
            return num;
        }
        final int n = num % multiple;
        if (n == 0) {
            return num;
        }
        return num + multiple - n;
    }
    
    public static String limit(final String str, final int limit) {
        return (str.length() > limit) ? str.substring(0, limit) : str;
    }
    
    public static String replace(final String string, final Pattern pattern, final String repl) {
        return pattern.matcher(string).replaceAll(Matcher.quoteReplacement(repl));
    }
    
    public static String replacePattern(final String string, final Pattern pattern, final String repl) {
        return pattern.matcher(string).replaceAll(repl);
    }
    
    public static String replace(final String string, final String pattern, final String repl) {
        return replace(string, ACFPatterns.getPattern(Pattern.quote(pattern)), repl);
    }
    
    public static String replacePattern(final String string, final String pattern, final String repl) {
        return replace(string, ACFPatterns.getPattern(pattern), repl);
    }
    
    public static String replacePatternMatch(final String string, final Pattern pattern, final String repl) {
        return pattern.matcher(string).replaceAll(repl);
    }
    
    public static String replacePatternMatch(final String string, final String pattern, final String repl) {
        return replacePatternMatch(string, ACFPatterns.getPattern(pattern), repl);
    }
    
    public static String replaceStrings(String string, final String... replacements) {
        if (replacements.length < 2 || replacements.length % 2 != 0) {
            throw new IllegalArgumentException("Invalid Replacements");
        }
        for (int i = 0; i < replacements.length; i += 2) {
            final String pattern = replacements[i];
            String repl = replacements[i + 1];
            if (repl == null) {
                repl = "";
            }
            string = replace(string, pattern, repl);
        }
        return string;
    }
    
    public static String replacePatterns(String string, final String... replacements) {
        if (replacements.length < 2 || replacements.length % 2 != 0) {
            throw new IllegalArgumentException("Invalid Replacements");
        }
        for (int i = 0; i < replacements.length; i += 2) {
            final String pattern = replacements[i];
            String repl = replacements[i + 1];
            if (repl == null) {
                repl = "";
            }
            string = replacePattern(string, pattern, repl);
        }
        return string;
    }
    
    public static String capitalize(final String str, final char[] delimiters) {
        return ApacheCommonsLangUtil.capitalize(str, delimiters);
    }
    
    private static boolean isDelimiter(final char ch, final char[] delimiters) {
        return ApacheCommonsLangUtil.isDelimiter(ch, delimiters);
    }
    
    public static <T> T random(final List<T> arr) {
        if (arr == null || arr.isEmpty()) {
            return null;
        }
        return arr.get(ACFUtil.RANDOM.nextInt(arr.size()));
    }
    
    public static <T> T random(final T[] arr) {
        if (arr == null || arr.length == 0) {
            return null;
        }
        return arr[ACFUtil.RANDOM.nextInt(arr.length)];
    }
    
    @Deprecated
    public static <T extends Enum<?>> T random(final Class<? extends T> enm) {
        return random((T[])enm.getEnumConstants());
    }
    
    public static String normalize(final String s) {
        if (s == null) {
            return null;
        }
        return ACFPatterns.NON_PRINTABLE_CHARACTERS.matcher(Normalizer.normalize(s, Normalizer.Form.NFD)).replaceAll("");
    }
    
    public static int indexOf(final String arg, final String[] split) {
        for (int i = 0; i < split.length; ++i) {
            if (arg == null) {
                if (split[i] == null) {
                    return i;
                }
            }
            else if (arg.equals(split[i])) {
                return i;
            }
        }
        return -1;
    }
    
    public static String capitalizeFirst(final String name) {
        return capitalizeFirst(name, '_');
    }
    
    public static String capitalizeFirst(String name, final char separator) {
        name = name.toLowerCase();
        final String[] split = name.split(Character.toString(separator));
        final StringBuilder sb = new StringBuilder(3);
        for (final String s : split) {
            sb.append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }
    
    public static String ltrim(final String s) {
        int n;
        for (n = 0; n < s.length() && Character.isWhitespace(s.charAt(n)); ++n) {}
        return s.substring(n);
    }
    
    public static String rtrim(final String s) {
        int index;
        for (index = s.length() - 1; index >= 0 && Character.isWhitespace(s.charAt(index)); --index) {}
        return s.substring(0, index + 1);
    }
    
    public static List<String> enumNames(final Enum<?>[] values) {
        return Stream.of(values).map((Function<? super Enum<?>, ?>)Enum::name).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
    }
    
    public static List<String> enumNames(final Class<? extends Enum<?>> cls) {
        return enumNames((Enum<?>[])cls.getEnumConstants());
    }
    
    public static String combine(final String[] args) {
        return combine(args, 0);
    }
    
    public static String combine(final String[] args, final int start) {
        int capacity = 0;
        for (int i = start; i < args.length; ++i) {
            capacity += args[i].length();
        }
        final StringBuilder sb = new StringBuilder(capacity);
        for (int j = start; j < args.length; ++j) {
            sb.append(args[j]);
        }
        return sb.toString();
    }
    
    @Nullable
    public static <E extends Enum<E>> E simpleMatch(final Class<? extends Enum<?>> list, String item) {
        if (item == null) {
            return null;
        }
        item = simplifyString(item);
        for (final Enum enum1 : (Enum[])list.getEnumConstants()) {
            if (item.equals(simplifyString(enum1.name()))) {
                return (E)enum1;
            }
        }
        return null;
    }
    
    public static boolean isTruthy(final String test) {
        switch (test) {
            case "t":
            case "true":
            case "on":
            case "y":
            case "yes":
            case "1": {
                return true;
            }
            default: {
                return false;
            }
        }
    }
    
    public static Number parseNumber(String num, final boolean suffixes) {
        final ApplyModifierToNumber invoke = new ApplyModifierToNumber(num, suffixes).invoke();
        num = invoke.getNum();
        return Double.parseDouble(num) * invoke.getMod();
    }
    
    public static BigDecimal parseBigNumber(String num, final boolean suffixes) {
        final ApplyModifierToNumber invoke = new ApplyModifierToNumber(num, suffixes).invoke();
        num = invoke.getNum();
        final double mod = invoke.getMod();
        final BigDecimal bigDecimal = new BigDecimal(num);
        return (mod == 1.0) ? bigDecimal : bigDecimal.multiply(new BigDecimal(mod));
    }
    
    public static <T> boolean hasIntersection(final Collection<T> list1, final Collection<T> list2) {
        final Iterator<T> iterator = list1.iterator();
        while (iterator.hasNext()) {
            if (list2.contains(iterator.next())) {
                return true;
            }
        }
        return false;
    }
    
    public static <T> Collection<T> intersection(final Collection<T> list1, final Collection<T> list2) {
        final ArrayList<T> list3 = new ArrayList<T>();
        for (final T next : list1) {
            if (list2.contains(next)) {
                list3.add(next);
            }
        }
        return list3;
    }
    
    public static int rand(final int min, final int max) {
        return min + ACFUtil.RANDOM.nextInt(max - min + 1);
    }
    
    public static int rand(final int min1, final int max1, final int min2, final int max2) {
        return randBool() ? rand(min1, max1) : rand(min2, max2);
    }
    
    public static double rand(final double min, final double max) {
        return ACFUtil.RANDOM.nextDouble() * (max - min) + min;
    }
    
    public static boolean isNumber(final String str) {
        return ApacheCommonsLangUtil.isNumeric(str);
    }
    
    public static String intToRoman(final int integer) {
        if (integer == 1) {
            return "I";
        }
        if (integer == 2) {
            return "II";
        }
        if (integer == 3) {
            return "III";
        }
        if (integer == 4) {
            return "IV";
        }
        if (integer == 5) {
            return "V";
        }
        if (integer == 6) {
            return "VI";
        }
        if (integer == 7) {
            return "VII";
        }
        if (integer == 8) {
            return "VIII";
        }
        if (integer == 9) {
            return "IX";
        }
        if (integer == 10) {
            return "X";
        }
        return null;
    }
    
    public static boolean isInteger(final String string) {
        return ACFPatterns.INTEGER.matcher(string).matches();
    }
    
    public static boolean isFloat(final String string) {
        try {
            Float.parseFloat(string);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    public static boolean isDouble(final String string) {
        try {
            Double.parseDouble(string);
            return true;
        }
        catch (Exception ex) {
            return false;
        }
    }
    
    public static boolean isBetween(final float num, final double min, final double max) {
        return num >= min && num <= max;
    }
    
    public static double precision(final double x, final int p) {
        final double pow = Math.pow(10.0, p);
        return Math.round(x * pow) / pow;
    }
    
    public static void sneaky(final Throwable t) {
        throw (RuntimeException)superSneaky(t);
    }
    
    private static <T extends Throwable> T superSneaky(final Throwable t) throws T {
        throw t;
    }
    
    public static <T> List<T> preformOnImmutable(List<T> var_0_13, final Consumer<List<T>> action) {
        try {
            action.accept(var_0_13);
        }
        catch (UnsupportedOperationException ex) {
            var_0_13 = new ArrayList<T>((Collection<? extends T>)var_0_13);
            action.accept(var_0_13);
        }
        return var_0_13;
    }
    
    public static <T> T getFirstElement(final Iterable<T> iterable) {
        if (iterable == null) {
            return null;
        }
        final Iterator<T> iterator = iterable.iterator();
        if (iterator.hasNext()) {
            return iterator.next();
        }
        return null;
    }
    
    static {
        RANDOM = new Random();
    }
    
    private static class ApplyModifierToNumber
    {
        private String num;
        private boolean suffixes;
        private double mod;
        
        public ApplyModifierToNumber(final String num, final boolean suffixes) {
            this.num = num;
            this.suffixes = suffixes;
        }
        
        public String getNum() {
            return this.num;
        }
        
        public double getMod() {
            return this.mod;
        }
        
        public ApplyModifierToNumber invoke() {
            this.mod = 1.0;
            if (this.suffixes) {
                switch (this.num.charAt(this.num.length() - 1)) {
                    case 'M':
                    case 'm': {
                        this.mod = 1000000.0;
                        this.num = this.num.substring(0, this.num.length() - 1);
                        break;
                    }
                    case 'K':
                    case 'k': {
                        this.mod = 1000.0;
                        this.num = this.num.substring(0, this.num.length() - 1);
                        break;
                    }
                }
            }
            return this;
        }
    }
}

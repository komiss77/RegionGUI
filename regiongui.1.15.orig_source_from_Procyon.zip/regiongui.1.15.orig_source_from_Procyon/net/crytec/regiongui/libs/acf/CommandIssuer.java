// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import co.aikar.locales.MessageKey;
import org.jetbrains.annotations.NotNull;
import java.util.UUID;
import co.aikar.locales.MessageKeyProvider;

public interface CommandIssuer
{
     <T> T getIssuer();
    
    CommandManager getManager();
    
    boolean isPlayer();
    
    default void sendMessage(final String message) {
        this.getManager().sendMessage(this, MessageType.INFO, MessageKeys.INFO_MESSAGE, "{message}", message);
    }
    
    @NotNull
    UUID getUniqueId();
    
    boolean hasPermission(final String permission);
    
    default void sendError(final MessageKeyProvider key, final String... replacements) {
        this.sendMessage(MessageType.ERROR, key.getMessageKey(), replacements);
    }
    
    default void sendSyntax(final MessageKeyProvider key, final String... replacements) {
        this.sendMessage(MessageType.SYNTAX, key.getMessageKey(), replacements);
    }
    
    default void sendInfo(final MessageKeyProvider key, final String... replacements) {
        this.sendMessage(MessageType.INFO, key.getMessageKey(), replacements);
    }
    
    default void sendError(final MessageKey key, final String... replacements) {
        this.sendMessage(MessageType.ERROR, key, replacements);
    }
    
    default void sendSyntax(final MessageKey key, final String... replacements) {
        this.sendMessage(MessageType.SYNTAX, key, replacements);
    }
    
    default void sendInfo(final MessageKey key, final String... replacements) {
        this.sendMessage(MessageType.INFO, key, replacements);
    }
    
    default void sendMessage(final MessageType type, final MessageKeyProvider key, final String... replacements) {
        this.sendMessage(type, key.getMessageKey(), replacements);
    }
    
    default void sendMessage(final MessageType type, final MessageKey key, final String... replacements) {
        this.getManager().sendMessage(this, type, key, replacements);
    }
    
    @Deprecated
    void sendMessageInternal(final String message);
}

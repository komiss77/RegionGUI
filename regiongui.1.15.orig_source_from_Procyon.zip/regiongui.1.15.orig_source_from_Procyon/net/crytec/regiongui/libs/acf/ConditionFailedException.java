// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import co.aikar.locales.MessageKey;
import co.aikar.locales.MessageKeyProvider;

public class ConditionFailedException extends InvalidCommandArgument
{
    public ConditionFailedException() {
        super(false);
    }
    
    public ConditionFailedException(final MessageKeyProvider key, final String... replacements) {
        super(key, false, replacements);
    }
    
    public ConditionFailedException(final MessageKey key, final String... replacements) {
        super(key, false, replacements);
    }
    
    public ConditionFailedException(final String message) {
        super(message, false);
    }
}

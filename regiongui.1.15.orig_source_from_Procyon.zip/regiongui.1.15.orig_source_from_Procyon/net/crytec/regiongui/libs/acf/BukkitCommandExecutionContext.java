// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;
import java.util.Map;
import java.util.List;

public class BukkitCommandExecutionContext extends CommandExecutionContext<BukkitCommandExecutionContext, BukkitCommandIssuer>
{
    BukkitCommandExecutionContext(final RegisteredCommand cmd, final CommandParameter param, final BukkitCommandIssuer sender, final List<String> args, final int index, final Map<String, Object> passedArgs) {
        super(cmd, param, sender, args, index, passedArgs);
    }
    
    public CommandSender getSender() {
        return ((BukkitCommandIssuer)this.issuer).getIssuer();
    }
    
    public Player getPlayer() {
        return ((BukkitCommandIssuer)this.issuer).getPlayer();
    }
}

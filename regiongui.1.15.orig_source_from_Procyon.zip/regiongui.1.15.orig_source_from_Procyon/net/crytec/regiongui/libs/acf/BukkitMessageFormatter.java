// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.ChatColor;

public class BukkitMessageFormatter extends MessageFormatter<ChatColor>
{
    public BukkitMessageFormatter(final ChatColor... colors) {
        super(colors);
    }
    
    @Override
    String format(final ChatColor color, final String message) {
        return color + message;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

enum LogLevel
{
    INFO, 
    ERROR;
    
    static final String LOG_PREFIX = "[ACF] ";
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Map;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import com.google.common.collect.SetMultimap;

public interface RootCommand
{
    void addChild(final BaseCommand command);
    
    CommandManager getManager();
    
    SetMultimap<String, RegisteredCommand> getSubCommands();
    
    List<BaseCommand> getChildren();
    
    String getCommandName();
    
    default void addChildShared(final List<BaseCommand> children, final SetMultimap<String, RegisteredCommand> subCommands, final BaseCommand command) {
        command.subCommands.entries().forEach(e -> subCommands.put(e.getKey(), (Object)e.getValue()));
        children.add(command);
    }
    
    default String getUniquePermission() {
        final Set<String> permissions = new HashSet<String>();
        for (final BaseCommand child : this.getChildren()) {
            for (final RegisteredCommand<?> value : child.subCommands.values()) {
                final Set<String> requiredPermissions = value.getRequiredPermissions();
                if (requiredPermissions.isEmpty()) {
                    return null;
                }
                permissions.addAll(requiredPermissions);
            }
        }
        return (permissions.size() == 1) ? permissions.iterator().next() : null;
    }
    
    default boolean hasAnyPermission(final CommandIssuer issuer) {
        final List<BaseCommand> children = this.getChildren();
        if (children.isEmpty()) {
            return true;
        }
        for (final BaseCommand child : children) {
            if (!child.hasPermission(issuer)) {
                continue;
            }
            for (final RegisteredCommand value : child.getRegisteredCommands()) {
                if (value.hasPermission(issuer)) {
                    return true;
                }
            }
        }
        return false;
    }
    
    default BaseCommand execute(final CommandIssuer sender, final String commandLabel, final String[] args) {
        final CommandRouter router = this.getManager().getRouter();
        final CommandRouter.RouteSearch search = router.routeCommand(this, commandLabel, args, false);
        BaseCommand defCommand = this.getDefCommand();
        if (search != null) {
            final CommandRouter.CommandRouteResult result = router.matchCommand(search, false);
            if (result != null) {
                final BaseCommand scope = result.cmd.scope;
                scope.execute(sender, result);
                return scope;
            }
            final RegisteredCommand firstElement = ACFUtil.getFirstElement(search.commands);
            if (firstElement != null) {
                defCommand = firstElement.scope;
            }
        }
        defCommand.help(sender, args);
        return defCommand;
    }
    
    default List<String> getTabCompletions(final CommandIssuer sender, final String alias, final String[] args) {
        return this.getTabCompletions(sender, alias, args, false);
    }
    
    default List<String> getTabCompletions(final CommandIssuer sender, final String alias, final String[] args, final boolean commandsOnly) {
        return this.getTabCompletions(sender, alias, args, commandsOnly, false);
    }
    
    default List<String> getTabCompletions(final CommandIssuer sender, final String alias, final String[] args, final boolean commandsOnly, final boolean isAsync) {
        final Set<String> completions = new HashSet<String>();
        final Set set;
        this.getChildren().forEach(child -> {
            if (!commandsOnly) {
                set.addAll(child.tabComplete(sender, this, args, isAsync));
            }
            set.addAll(child.getCommandsForCompletion(sender, args));
            return;
        });
        return new ArrayList<String>(completions);
    }
    
    default RegisteredCommand getDefaultRegisteredCommand() {
        final BaseCommand defCommand = this.getDefCommand();
        if (defCommand != null) {
            return defCommand.getDefaultRegisteredCommand();
        }
        return null;
    }
    
    default BaseCommand getDefCommand() {
        return null;
    }
    
    default String getDescription() {
        final RegisteredCommand cmd = this.getDefaultRegisteredCommand();
        if (cmd != null) {
            return cmd.getHelpText();
        }
        final BaseCommand defCommand = this.getDefCommand();
        if (defCommand != null && defCommand.description != null) {
            return defCommand.description;
        }
        return "";
    }
    
    default String getUsage() {
        final RegisteredCommand cmd = this.getDefaultRegisteredCommand();
        if (cmd != null) {
            return (cmd.syntaxText != null) ? cmd.syntaxText : "";
        }
        return "";
    }
}

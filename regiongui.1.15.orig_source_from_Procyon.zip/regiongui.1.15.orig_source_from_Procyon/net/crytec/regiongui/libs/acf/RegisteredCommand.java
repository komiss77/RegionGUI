// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.lang.annotation.Annotation;
import java.util.Arrays;
import net.crytec.regiongui.libs.acf.contexts.ContextResolver;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Function;
import java.util.LinkedHashMap;
import org.jetbrains.annotations.Nullable;
import java.util.Collection;
import co.aikar.locales.MessageKeyProvider;
import java.lang.reflect.InvocationTargetException;
import java.util.concurrent.ExecutionException;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.lang.reflect.Parameter;
import net.crytec.regiongui.libs.acf.annotation.Syntax;
import net.crytec.regiongui.libs.acf.annotation.Private;
import net.crytec.regiongui.libs.acf.annotation.HelpSearchTags;
import net.crytec.regiongui.libs.acf.annotation.Conditions;
import net.crytec.regiongui.libs.acf.annotation.Description;
import net.crytec.regiongui.libs.acf.annotation.CommandCompletion;
import net.crytec.regiongui.libs.acf.annotation.CommandPermission;
import java.lang.reflect.AnnotatedElement;
import net.crytec.regiongui.libs.acf.annotation.CommandAlias;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;
import java.lang.reflect.Method;

public class RegisteredCommand<CEC extends CommandExecutionContext<CEC, ? extends CommandIssuer>>
{
    final BaseCommand scope;
    final Method method;
    final CommandParameter<CEC>[] parameters;
    final CommandManager manager;
    final List<String> registeredSubcommands;
    String command;
    String prefSubCommand;
    String syntaxText;
    String helpText;
    String permission;
    String complete;
    String conditions;
    public String helpSearchTags;
    boolean isPrivate;
    final int requiredResolvers;
    final int consumeInputResolvers;
    final int doesNotConsumeInputResolvers;
    final int optionalResolvers;
    final Set<String> permissions;
    
    RegisteredCommand(final BaseCommand scope, String command, final Method method, String prefSubCommand) {
        this.registeredSubcommands = new ArrayList<String>();
        this.permissions = new HashSet<String>();
        this.scope = scope;
        this.manager = this.scope.manager;
        final Annotations annotations = this.manager.getAnnotations();
        if ("__catchunknown".equals(prefSubCommand) || "__default".equals(prefSubCommand)) {
            prefSubCommand = "";
            command = command.trim();
        }
        this.command = command + ((!annotations.hasAnnotation(method, CommandAlias.class, false) && !prefSubCommand.isEmpty()) ? prefSubCommand : "");
        this.method = method;
        this.prefSubCommand = prefSubCommand;
        this.permission = annotations.getAnnotationValue(method, CommandPermission.class, 9);
        this.complete = annotations.getAnnotationValue(method, CommandCompletion.class, 16);
        this.helpText = annotations.getAnnotationValue(method, Description.class, 17);
        this.conditions = annotations.getAnnotationValue(method, Conditions.class, 9);
        this.helpSearchTags = annotations.getAnnotationValue(method, HelpSearchTags.class, 9);
        final Parameter[] parameters = method.getParameters();
        this.parameters = (CommandParameter<CEC>[])new CommandParameter[parameters.length];
        this.isPrivate = (annotations.hasAnnotation(method, Private.class) || annotations.getAnnotationFromClass(scope.getClass(), Private.class) != null);
        int requiredResolvers = 0;
        int consumeInputResolvers = 0;
        int doesNotConsumeInputResolvers = 0;
        int optionalResolvers = 0;
        final StringBuilder sb = new StringBuilder(64);
        for (int i = 0; i < parameters.length; ++i) {
            final CommandParameter<CEC>[] parameters2 = this.parameters;
            final int n = i;
            final CommandParameter<CEC> commandParameter = new CommandParameter<CEC>(this, parameters[i], i, i == parameters.length - 1);
            parameters2[n] = commandParameter;
            final CommandParameter<CEC> commandParameter2 = commandParameter;
            if (!commandParameter2.isCommandIssuer()) {
                if (!commandParameter2.requiresInput()) {
                    ++optionalResolvers;
                }
                else {
                    ++requiredResolvers;
                }
                if (commandParameter2.canConsumeInput()) {
                    ++consumeInputResolvers;
                }
                else {
                    ++doesNotConsumeInputResolvers;
                }
            }
            if (commandParameter2.getSyntax() != null) {
                if (sb.length() > 0) {
                    sb.append(' ');
                }
                sb.append(commandParameter2.getSyntax());
            }
        }
        final String trim = sb.toString().trim();
        final String annotationValue = annotations.getAnnotationValue(method, Syntax.class);
        this.syntaxText = ((annotationValue != null) ? ACFUtil.replace(annotationValue, "@syntax", trim) : trim);
        this.requiredResolvers = requiredResolvers;
        this.consumeInputResolvers = consumeInputResolvers;
        this.doesNotConsumeInputResolvers = doesNotConsumeInputResolvers;
        this.optionalResolvers = optionalResolvers;
        this.computePermissions();
    }
    
    void invoke(final CommandIssuer sender, final List<String> args, final CommandOperationContext context) {
        if (!this.scope.canExecute(sender, this)) {
            return;
        }
        this.preCommand();
        try {
            this.manager.getCommandConditions().validateConditions(context);
            final Map<String, Object> resolveContexts = this.resolveContexts(sender, args);
            if (resolveContexts == null) {
                return;
            }
            final Object invoke = this.method.invoke(this.scope, resolveContexts.values().toArray());
            if (invoke instanceof CompletableFuture) {
                ((CompletableFuture)invoke).exceptionally(t -> {
                    this.handleException(sender, args, t);
                    return null;
                });
            }
        }
        catch (Exception e) {
            this.handleException(sender, args, e);
        }
        finally {
            this.postCommand();
        }
    }
    
    public void preCommand() {
    }
    
    public void postCommand() {
    }
    
    void handleException(final CommandIssuer sender, final List<String> args, Throwable e) {
        while (e instanceof ExecutionException) {
            e = e.getCause();
        }
        if (e instanceof InvocationTargetException && e.getCause() instanceof InvalidCommandArgument) {
            e = e.getCause();
        }
        if (e instanceof ShowCommandHelp) {
            final ShowCommandHelp showCommandHelp = (ShowCommandHelp)e;
            final CommandHelp generateCommandHelp = this.manager.generateCommandHelp();
            if (showCommandHelp.search) {
                generateCommandHelp.setSearch((showCommandHelp.searchArgs == null) ? args : showCommandHelp.searchArgs);
            }
            generateCommandHelp.showHelp(sender);
        }
        else if (e instanceof InvalidCommandArgument) {
            final InvalidCommandArgument invalidCommandArgument = (InvalidCommandArgument)e;
            if (invalidCommandArgument.key != null) {
                sender.sendMessage(MessageType.ERROR, invalidCommandArgument.key, invalidCommandArgument.replacements);
            }
            else if (e.getMessage() != null && !e.getMessage().isEmpty()) {
                sender.sendMessage(MessageType.ERROR, MessageKeys.ERROR_PREFIX, "{message}", e.getMessage());
            }
            if (invalidCommandArgument.showSyntax) {
                this.scope.showSyntax(sender, this);
            }
        }
        else {
            try {
                if (!this.manager.handleUncaughtException(this.scope, this, sender, args, e)) {
                    sender.sendMessage(MessageType.ERROR, MessageKeys.ERROR_PERFORMING_COMMAND, new String[0]);
                }
                if ((this.manager.defaultExceptionHandler == null && this.scope.getExceptionHandler() == null) || this.manager.logUnhandledExceptions) {
                    this.manager.log(LogLevel.ERROR, "Exception in command: " + this.command + " " + ACFUtil.join(args), e);
                }
            }
            catch (Exception throwable) {
                this.manager.log(LogLevel.ERROR, "Exception in handleException for command: " + this.command + " " + ACFUtil.join(args), e);
                this.manager.log(LogLevel.ERROR, "Exception triggered by exception handler:", throwable);
            }
        }
    }
    
    @Nullable
    Map<String, Object> resolveContexts(final CommandIssuer sender, final List<String> args) {
        return this.resolveContexts(sender, args, this.parameters.length);
    }
    
    @Nullable
    Map<String, Object> resolveContexts(final CommandIssuer sender, final List<String> args, int argLimit) {
        final ArrayList<String> args2 = new ArrayList<String>(args);
        final String[] array = args2.toArray(new String[args2.size()]);
        final LinkedHashMap<String, Object> passedArgs = new LinkedHashMap<String, Object>();
        int requiredResolvers = this.requiredResolvers;
        final CommandOperationContext currentCommandOperationContext = CommandManager.getCurrentCommandOperationContext();
        for (int i = 0; i < this.parameters.length && i < argLimit; ++i) {
            final boolean b = i == this.parameters.length - 1;
            final boolean b2 = requiredResolvers == 0;
            final CommandParameter<CEC> parameter = this.parameters[i];
            if (!parameter.canConsumeInput()) {
                ++argLimit;
            }
            final String name = parameter.getName();
            final Class<?> type = parameter.getType();
            final ContextResolver<?, CEC> resolver = parameter.getResolver();
            final CommandExecutionContext commandContext = this.manager.createCommandContext(this, parameter, sender, args2, i, passedArgs);
            final boolean requiresInput = parameter.requiresInput();
            if (requiresInput && requiredResolvers > 0) {
                --requiredResolvers;
            }
            final Set<String> requiredPermissions = parameter.getRequiredPermissions();
            if (args2.isEmpty() && (!b || type != String[].class)) {
                if (b2 && parameter.getDefaultValue() != null) {
                    args2.add(parameter.getDefaultValue());
                }
                else if (b2 && parameter.isOptional()) {
                    Object context;
                    if (!parameter.isOptionalResolver() || !this.manager.hasPermission(sender, requiredPermissions)) {
                        context = null;
                    }
                    else {
                        context = resolver.getContext((CEC)commandContext);
                    }
                    if (context == null && parameter.getClass().isPrimitive()) {
                        throw new IllegalStateException("Parameter " + parameter.getName() + " is primitive and does not support Optional.");
                    }
                    this.manager.getCommandConditions().validateConditions((CEC)commandContext, context);
                    passedArgs.put(name, context);
                    continue;
                }
                else if (requiresInput) {
                    this.scope.showSyntax(sender, this);
                    return null;
                }
            }
            else if (!this.manager.hasPermission(sender, requiredPermissions)) {
                sender.sendMessage(MessageType.ERROR, MessageKeys.PERMISSION_DENIED_PARAMETER, "{param}", name);
                throw new InvalidCommandArgument(false);
            }
            if (parameter.getValues() != null) {
                final String s = args2.isEmpty() ? "" : args2.get(0);
                final HashSet<String> args3 = new HashSet<String>();
                final CommandCompletions commandCompletions = this.manager.getCommandCompletions();
                for (String defaultCompletion : parameter.getValues()) {
                    if ("*".equals(defaultCompletion) || "@completions".equals(defaultCompletion)) {
                        defaultCompletion = commandCompletions.findDefaultCompletion(this, array);
                    }
                    final List completionValues = commandCompletions.getCompletionValues(this, sender, defaultCompletion, array, currentCommandOperationContext.isAsync());
                    if (!completionValues.isEmpty()) {
                        args3.addAll((Collection<?>)completionValues.stream().map((Function<? super Object, ?>)String::toLowerCase).collect((Collector<? super Object, ?, List<Object>>)Collectors.toList()));
                    }
                    else {
                        args3.add(defaultCompletion.toLowerCase());
                    }
                }
                if (!args3.contains(s.toLowerCase())) {
                    throw new InvalidCommandArgument(MessageKeys.PLEASE_SPECIFY_ONE_OF, new String[] { "{valid}", ACFUtil.join(args3, ", ") });
                }
            }
            final Object context2 = resolver.getContext((CEC)commandContext);
            this.manager.getCommandConditions().validateConditions((CEC)commandContext, context2);
            passedArgs.put(name, context2);
        }
        return passedArgs;
    }
    
    boolean hasPermission(final CommandIssuer issuer) {
        return this.manager.hasPermission(issuer, this.getRequiredPermissions());
    }
    
    @Deprecated
    public String getPermission() {
        if (this.permission == null || this.permission.isEmpty()) {
            return null;
        }
        return ACFPatterns.COMMA.split(this.permission)[0];
    }
    
    void computePermissions() {
        this.permissions.clear();
        this.permissions.addAll(this.scope.getRequiredPermissions());
        if (this.permission != null && !this.permission.isEmpty()) {
            this.permissions.addAll(Arrays.asList(ACFPatterns.COMMA.split(this.permission)));
        }
    }
    
    public Set<String> getRequiredPermissions() {
        return this.permissions;
    }
    
    public boolean requiresPermission(final String permission) {
        return this.getRequiredPermissions().contains(permission);
    }
    
    public String getPrefSubCommand() {
        return this.prefSubCommand;
    }
    
    public String getSyntaxText() {
        return this.syntaxText;
    }
    
    public String getHelpText() {
        return (this.helpText != null) ? this.helpText : "";
    }
    
    public boolean isPrivate() {
        return this.isPrivate;
    }
    
    public String getCommand() {
        return this.command;
    }
    
    public void addSubcommand(final String cmd) {
        this.registeredSubcommands.add(cmd);
    }
    
    public void addSubcommands(final Collection<String> cmd) {
        this.registeredSubcommands.addAll(cmd);
    }
    
    public <T extends Annotation> T getAnnotation(final Class<T> annotation) {
        return this.method.getAnnotation(annotation);
    }
}

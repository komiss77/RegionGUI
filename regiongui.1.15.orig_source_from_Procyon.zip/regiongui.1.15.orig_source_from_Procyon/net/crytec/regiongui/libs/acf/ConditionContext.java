// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.HashMap;
import java.util.Map;

public class ConditionContext<I extends CommandIssuer>
{
    private final I issuer;
    private final String config;
    private final Map<String, String> configs;
    
    ConditionContext(final I issuer, final String config) {
        this.issuer = issuer;
        this.config = config;
        this.configs = new HashMap<String, String>();
        if (config != null) {
            final String[] split = ACFPatterns.COMMA.split(config);
            for (int length = split.length, i = 0; i < length; ++i) {
                final String[] split2 = ACFPatterns.EQUALS.split(split[i], 2);
                this.configs.put(split2[0], (split2.length > 1) ? split2[1] : null);
            }
        }
    }
    
    public I getIssuer() {
        return this.issuer;
    }
    
    public String getConfig() {
        return this.config;
    }
    
    public boolean hasConfig(final String flag) {
        return this.configs.containsKey(flag);
    }
    
    public String getConfigValue(final String flag, final String def) {
        return this.configs.getOrDefault(flag, def);
    }
    
    public Integer getConfigValue(final String flag, final Integer def) {
        return ACFUtil.parseInt(this.configs.get(flag), def);
    }
}

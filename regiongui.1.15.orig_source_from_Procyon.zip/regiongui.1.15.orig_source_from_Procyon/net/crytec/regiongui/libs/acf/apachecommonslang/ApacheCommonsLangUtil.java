// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf.apachecommonslang;

import java.util.Iterator;
import java.lang.reflect.Array;

public class ApacheCommonsLangUtil
{
    public static final String EMPTY = "";
    public static final int INDEX_NOT_FOUND = -1;
    
    public static <T> T[] clone(final T[] array) {
        if (array == null) {
            return null;
        }
        return array.clone();
    }
    
    public static <T> T[] addAll(final T[] array1, final T... array2) {
        if (array1 == null) {
            return clone(array2);
        }
        if (array2 == null) {
            return clone(array1);
        }
        final Class<?> componentType = array1.getClass().getComponentType();
        final Object[] array3 = (Object[])Array.newInstance(componentType, array1.length + array2.length);
        System.arraycopy(array1, 0, array3, 0, array1.length);
        try {
            System.arraycopy(array2, 0, array3, array1.length, array2.length);
        }
        catch (ArrayStoreException cause) {
            final Class<?> componentType2 = array2.getClass().getComponentType();
            if (!componentType.isAssignableFrom(componentType2)) {
                throw new IllegalArgumentException("Cannot store " + componentType2.getName() + " in an array of " + componentType.getName(), cause);
            }
            throw cause;
        }
        return (T[])array3;
    }
    
    public static String capitalizeFully(final String str) {
        return capitalizeFully(str, (char[])null);
    }
    
    public static String capitalizeFully(String str, final char... delimiters) {
        final int n = (delimiters == null) ? -1 : delimiters.length;
        if (str == null || str.isEmpty() || n == 0) {
            return str;
        }
        str = str.toLowerCase();
        return capitalize(str, delimiters);
    }
    
    public static String capitalize(final String str) {
        return capitalize(str, (char[])null);
    }
    
    public static String capitalize(final String str, final char... delimiters) {
        final int n = (delimiters == null) ? -1 : delimiters.length;
        if (str == null || str.isEmpty() || n == 0) {
            return str;
        }
        final char[] charArray = str.toCharArray();
        int n2 = 1;
        for (int i = 0; i < charArray.length; ++i) {
            final char c = charArray[i];
            if (isDelimiter(c, delimiters)) {
                n2 = 1;
            }
            else if (n2 != 0) {
                charArray[i] = Character.toTitleCase(c);
                n2 = 0;
            }
        }
        return new String(charArray);
    }
    
    public static boolean isDelimiter(final char ch, final char[] delimiters) {
        if (delimiters == null) {
            return Character.isWhitespace(ch);
        }
        for (int length = delimiters.length, i = 0; i < length; ++i) {
            if (ch == delimiters[i]) {
                return true;
            }
        }
        return false;
    }
    
    @SafeVarargs
    public static <T> String join(final T... elements) {
        return join((Object[])elements, null);
    }
    
    public static String join(final Object[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final long[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final int[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final short[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final byte[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final char[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final float[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final double[] array, final char separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final Object[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            if (array[i] != null) {
                sb.append(array[i]);
            }
        }
        return sb.toString();
    }
    
    public static String join(final long[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            sb.append(array[i]);
        }
        return sb.toString();
    }
    
    public static String join(final int[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            sb.append(array[i]);
        }
        return sb.toString();
    }
    
    public static String join(final byte[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            sb.append(array[i]);
        }
        return sb.toString();
    }
    
    public static String join(final short[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            sb.append(array[i]);
        }
        return sb.toString();
    }
    
    public static String join(final char[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            sb.append(array[i]);
        }
        return sb.toString();
    }
    
    public static String join(final double[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            sb.append(array[i]);
        }
        return sb.toString();
    }
    
    public static String join(final float[] array, final char separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            sb.append(array[i]);
        }
        return sb.toString();
    }
    
    public static String join(final Object[] array, final String separator) {
        if (array == null) {
            return null;
        }
        return join(array, separator, 0, array.length);
    }
    
    public static String join(final Object[] array, String separator, final int startIndex, final int endIndex) {
        if (array == null) {
            return null;
        }
        if (separator == null) {
            separator = "";
        }
        final int n = endIndex - startIndex;
        if (n <= 0) {
            return "";
        }
        final StringBuilder sb = new StringBuilder(n * 16);
        for (int i = startIndex; i < endIndex; ++i) {
            if (i > startIndex) {
                sb.append(separator);
            }
            if (array[i] != null) {
                sb.append(array[i]);
            }
        }
        return sb.toString();
    }
    
    public static String join(final Iterator<?> iterator, final char separator) {
        if (iterator == null) {
            return null;
        }
        if (!iterator.hasNext()) {
            return "";
        }
        final Object next = iterator.next();
        if (!iterator.hasNext()) {
            return (next != null) ? next.toString() : "";
        }
        final StringBuilder sb = new StringBuilder(256);
        if (next != null) {
            sb.append(next);
        }
        while (iterator.hasNext()) {
            sb.append(separator);
            final Object next2 = iterator.next();
            if (next2 != null) {
                sb.append(next2);
            }
        }
        return sb.toString();
    }
    
    public static String join(final Iterator<?> iterator, final String separator) {
        if (iterator == null) {
            return null;
        }
        if (!iterator.hasNext()) {
            return "";
        }
        final Object next = iterator.next();
        if (!iterator.hasNext()) {
            return (next != null) ? next.toString() : "";
        }
        final StringBuilder sb = new StringBuilder(256);
        if (next != null) {
            sb.append(next);
        }
        while (iterator.hasNext()) {
            if (separator != null) {
                sb.append(separator);
            }
            final Object next2 = iterator.next();
            if (next2 != null) {
                sb.append(next2);
            }
        }
        return sb.toString();
    }
    
    public static String join(final Iterable<?> iterable, final char separator) {
        if (iterable == null) {
            return null;
        }
        return join(iterable.iterator(), separator);
    }
    
    public static String join(final Iterable<?> iterable, final String separator) {
        if (iterable == null) {
            return null;
        }
        return join(iterable.iterator(), separator);
    }
    
    public static boolean isNumeric(final CharSequence cs) {
        if (cs == null || cs.length() == 0) {
            return false;
        }
        for (int length = cs.length(), i = 0; i < length; ++i) {
            if (!Character.isDigit(cs.charAt(i))) {
                return false;
            }
        }
        return true;
    }
    
    public static boolean startsWith(final CharSequence str, final CharSequence prefix) {
        return startsWith(str, prefix, false);
    }
    
    public static boolean startsWithIgnoreCase(final CharSequence str, final CharSequence prefix) {
        return startsWith(str, prefix, true);
    }
    
    private static boolean startsWith(final CharSequence str, final CharSequence prefix, final boolean ignoreCase) {
        if (str == null || prefix == null) {
            return str == null && prefix == null;
        }
        return prefix.length() <= str.length() && regionMatches(str, ignoreCase, 0, prefix, 0, prefix.length());
    }
    
    static boolean regionMatches(final CharSequence cs, final boolean ignoreCase, final int thisStart, final CharSequence substring, final int start, final int length) {
        if (cs instanceof String && substring instanceof String) {
            return ((String)cs).regionMatches(ignoreCase, thisStart, (String)substring, start, length);
        }
        int n = thisStart;
        int n2 = start;
        int n3 = length;
        final int n4 = cs.length() - thisStart;
        final int n5 = substring.length() - start;
        if (thisStart < 0 || start < 0 || length < 0) {
            return false;
        }
        if (n4 < length || n5 < length) {
            return false;
        }
        while (n3-- > 0) {
            final char char1 = cs.charAt(n++);
            final char char2 = substring.charAt(n2++);
            if (char1 == char2) {
                continue;
            }
            if (!ignoreCase) {
                return false;
            }
            if (Character.toUpperCase(char1) != Character.toUpperCase(char2) && Character.toLowerCase(char1) != Character.toLowerCase(char2)) {
                return false;
            }
        }
        return true;
    }
    
    public static int indexOf(final Object[] array, final Object objectToFind) {
        return indexOf(array, objectToFind, 0);
    }
    
    public static int indexOf(final Object[] array, final Object objectToFind, int startIndex) {
        if (array == null) {
            return -1;
        }
        if (startIndex < 0) {
            startIndex = 0;
        }
        if (objectToFind == null) {
            for (int i = startIndex; i < array.length; ++i) {
                if (array[i] == null) {
                    return i;
                }
            }
        }
        else {
            for (int j = startIndex; j < array.length; ++j) {
                if (objectToFind.equals(array[j])) {
                    return j;
                }
            }
        }
        return -1;
    }
}

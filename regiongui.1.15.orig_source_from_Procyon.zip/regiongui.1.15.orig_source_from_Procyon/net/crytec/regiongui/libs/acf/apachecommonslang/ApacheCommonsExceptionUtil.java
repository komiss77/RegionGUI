// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf.apachecommonslang;

import java.io.PrintStream;
import java.util.StringTokenizer;
import java.io.Writer;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.reflect.Field;
import java.sql.SQLException;
import java.util.Collection;
import java.util.Arrays;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;
import java.lang.reflect.Method;

public class ApacheCommonsExceptionUtil
{
    private static final String LINE_SEPARATOR;
    static final String WRAPPED_MARKER = " [wrapped] ";
    private static String[] CAUSE_METHOD_NAMES;
    private static final Method THROWABLE_CAUSE_METHOD;
    private static final Method THROWABLE_INITCAUSE_METHOD;
    
    public static void addCauseMethodName(final String methodName) {
        if (methodName != null && !methodName.isEmpty() && !isCauseMethodName(methodName)) {
            final ArrayList causeMethodNameList = getCauseMethodNameList();
            if (causeMethodNameList.add(methodName)) {
                ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES = toArray(causeMethodNameList);
            }
        }
    }
    
    public static void removeCauseMethodName(final String methodName) {
        if (methodName != null && !methodName.isEmpty()) {
            final ArrayList causeMethodNameList = getCauseMethodNameList();
            if (causeMethodNameList.remove(methodName)) {
                ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES = toArray(causeMethodNameList);
            }
        }
    }
    
    public static boolean setCause(final Throwable target, final Throwable cause) {
        if (target == null) {
            throw new IllegalArgumentException("target");
        }
        final Object[] array = { cause };
        boolean b = false;
        if (ApacheCommonsExceptionUtil.THROWABLE_INITCAUSE_METHOD != null) {
            try {
                ApacheCommonsExceptionUtil.THROWABLE_INITCAUSE_METHOD.invoke(target, array);
                b = true;
            }
            catch (IllegalAccessException ex) {}
            catch (InvocationTargetException ex2) {}
        }
        try {
            target.getClass().getMethod("setCause", Throwable.class).invoke(target, array);
            b = true;
        }
        catch (NoSuchMethodException ex3) {}
        catch (IllegalAccessException ex4) {}
        catch (InvocationTargetException ex5) {}
        return b;
    }
    
    private static String[] toArray(final List list) {
        return list.toArray(new String[list.size()]);
    }
    
    private static ArrayList getCauseMethodNameList() {
        return new ArrayList((Collection<? extends E>)Arrays.asList(ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES));
    }
    
    public static boolean isCauseMethodName(final String methodName) {
        return ApacheCommonsLangUtil.indexOf(ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES, methodName) >= 0;
    }
    
    public static Throwable getCause(final Throwable throwable) {
        return getCause(throwable, ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES);
    }
    
    public static Throwable getCause(final Throwable throwable, String[] methodNames) {
        if (throwable == null) {
            return null;
        }
        Throwable t = getCauseUsingWellKnownTypes(throwable);
        if (t == null) {
            if (methodNames == null) {
                methodNames = ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES;
            }
            for (int i = 0; i < methodNames.length; ++i) {
                final String methodName = methodNames[i];
                if (methodName != null) {
                    t = getCauseUsingMethodName(throwable, methodName);
                    if (t != null) {
                        break;
                    }
                }
            }
            if (t == null) {
                t = getCauseUsingFieldName(throwable, "detail");
            }
        }
        return t;
    }
    
    public static Throwable getRootCause(final Throwable throwable) {
        final List throwableList = getThrowableList(throwable);
        return (throwableList.size() < 2) ? null : throwableList.get(throwableList.size() - 1);
    }
    
    private static Throwable getCauseUsingWellKnownTypes(final Throwable throwable) {
        if (throwable instanceof Nestable) {
            return throwable.getCause();
        }
        if (throwable instanceof SQLException) {
            return ((SQLException)throwable).getNextException();
        }
        if (throwable instanceof InvocationTargetException) {
            return ((InvocationTargetException)throwable).getTargetException();
        }
        return null;
    }
    
    private static Throwable getCauseUsingMethodName(final Throwable throwable, final String methodName) {
        Method method = null;
        try {
            method = throwable.getClass().getMethod(methodName, (Class<?>[])null);
        }
        catch (NoSuchMethodException ex) {}
        catch (SecurityException ex2) {}
        if (method != null && Throwable.class.isAssignableFrom(method.getReturnType())) {
            try {
                return (Throwable)method.invoke(throwable, new Object[0]);
            }
            catch (IllegalAccessException ex3) {}
            catch (IllegalArgumentException ex4) {}
            catch (InvocationTargetException ex5) {}
        }
        return null;
    }
    
    private static Throwable getCauseUsingFieldName(final Throwable throwable, final String fieldName) {
        Field field = null;
        try {
            field = throwable.getClass().getField(fieldName);
        }
        catch (NoSuchFieldException ex) {}
        catch (SecurityException ex2) {}
        if (field != null && Throwable.class.isAssignableFrom(field.getType())) {
            try {
                return (Throwable)field.get(throwable);
            }
            catch (IllegalAccessException ex3) {}
            catch (IllegalArgumentException ex4) {}
        }
        return null;
    }
    
    public static boolean isThrowableNested() {
        return ApacheCommonsExceptionUtil.THROWABLE_CAUSE_METHOD != null;
    }
    
    public static boolean isNestedThrowable(final Throwable throwable) {
        if (throwable == null) {
            return false;
        }
        if (throwable instanceof Nestable) {
            return true;
        }
        if (throwable instanceof SQLException) {
            return true;
        }
        if (throwable instanceof InvocationTargetException) {
            return true;
        }
        if (isThrowableNested()) {
            return true;
        }
        final Class<? extends Throwable> class1 = throwable.getClass();
        for (int i = 0; i < ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES.length; ++i) {
            try {
                final Method method = class1.getMethod(ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES[i], (Class<?>[])null);
                if (method != null && Throwable.class.isAssignableFrom(method.getReturnType())) {
                    return true;
                }
            }
            catch (NoSuchMethodException ex) {}
            catch (SecurityException ex2) {}
        }
        try {
            if (class1.getField("detail") != null) {
                return true;
            }
        }
        catch (NoSuchFieldException ex3) {}
        catch (SecurityException ex4) {}
        return false;
    }
    
    public static int getThrowableCount(final Throwable throwable) {
        return getThrowableList(throwable).size();
    }
    
    public static Throwable[] getThrowables(final Throwable throwable) {
        final List throwableList = getThrowableList(throwable);
        return throwableList.toArray(new Throwable[throwableList.size()]);
    }
    
    public static List getThrowableList(Throwable throwable) {
        ArrayList<Throwable> list;
        for (list = new ArrayList<Throwable>(); throwable != null && !list.contains(throwable); throwable = getCause(throwable)) {
            list.add(throwable);
        }
        return list;
    }
    
    public static int indexOfThrowable(final Throwable throwable, final Class clazz) {
        return indexOf(throwable, clazz, 0, false);
    }
    
    public static int indexOfThrowable(final Throwable throwable, final Class clazz, final int fromIndex) {
        return indexOf(throwable, clazz, fromIndex, false);
    }
    
    public static int indexOfType(final Throwable throwable, final Class type) {
        return indexOf(throwable, type, 0, true);
    }
    
    public static int indexOfType(final Throwable throwable, final Class type, final int fromIndex) {
        return indexOf(throwable, type, fromIndex, true);
    }
    
    private static int indexOf(final Throwable throwable, final Class type, int fromIndex, final boolean subclass) {
        if (throwable == null || type == null) {
            return -1;
        }
        if (fromIndex < 0) {
            fromIndex = 0;
        }
        final Throwable[] throwables = getThrowables(throwable);
        if (fromIndex >= throwables.length) {
            return -1;
        }
        if (subclass) {
            for (int i = fromIndex; i < throwables.length; ++i) {
                if (type.isAssignableFrom(throwables[i].getClass())) {
                    return i;
                }
            }
        }
        else {
            for (int j = fromIndex; j < throwables.length; ++j) {
                if (type.equals(throwables[j].getClass())) {
                    return j;
                }
            }
        }
        return -1;
    }
    
    public static void removeCommonFrames(final List causeFrames, final List wrapperFrames) {
        if (causeFrames == null || wrapperFrames == null) {
            throw new IllegalArgumentException("The List must not be null");
        }
        for (int n = causeFrames.size() - 1, n2 = wrapperFrames.size() - 1; n >= 0 && n2 >= 0; --n, --n2) {
            if (causeFrames.get(n).equals(wrapperFrames.get(n2))) {
                causeFrames.remove(n);
            }
        }
    }
    
    public static String getFullStackTrace(final Throwable throwable) {
        final StringWriter out = new StringWriter();
        final PrintWriter s = new PrintWriter(out, true);
        final Throwable[] throwables = getThrowables(throwable);
        for (int i = 0; i < throwables.length; ++i) {
            throwables[i].printStackTrace(s);
            if (isNestedThrowable(throwables[i])) {
                break;
            }
        }
        return out.getBuffer().toString();
    }
    
    public static String getStackTrace(final Throwable throwable) {
        final StringWriter out = new StringWriter();
        throwable.printStackTrace(new PrintWriter(out, true));
        return out.getBuffer().toString();
    }
    
    static List getStackFrameList(final Throwable t) {
        final StringTokenizer stringTokenizer = new StringTokenizer(getStackTrace(t), ApacheCommonsExceptionUtil.LINE_SEPARATOR);
        final ArrayList<String> list = new ArrayList<String>();
        boolean b = false;
        while (stringTokenizer.hasMoreTokens()) {
            final String nextToken = stringTokenizer.nextToken();
            final int index = nextToken.indexOf("at");
            if (index != -1 && nextToken.substring(0, index).trim().length() == 0) {
                b = true;
                list.add(nextToken);
            }
            else {
                if (b) {
                    break;
                }
                continue;
            }
        }
        return list;
    }
    
    static {
        LINE_SEPARATOR = System.getProperty("line.separator");
        ApacheCommonsExceptionUtil.CAUSE_METHOD_NAMES = new String[] { "getCause", "getNextException", "getTargetException", "getException", "getSourceException", "getRootCause", "getCausedByException", "getNested", "getLinkedException", "getNestedException", "getLinkedCause", "getThrowable" };
        Method method;
        try {
            method = Throwable.class.getMethod("getCause", (Class<?>[])null);
        }
        catch (Exception ex) {
            method = null;
        }
        THROWABLE_CAUSE_METHOD = method;
        Method method2;
        try {
            method2 = Throwable.class.getMethod("initCause", Throwable.class);
        }
        catch (Exception ex2) {
            method2 = null;
        }
        THROWABLE_INITCAUSE_METHOD = method2;
    }
    
    public interface Nestable
    {
        Throwable getCause();
        
        String getMessage();
        
        String getMessage(final int index);
        
        String[] getMessages();
        
        Throwable getThrowable(final int index);
        
        int getThrowableCount();
        
        Throwable[] getThrowables();
        
        int indexOfThrowable(final Class type);
        
        int indexOfThrowable(final Class type, final int fromIndex);
        
        void printStackTrace(final PrintWriter out);
        
        void printStackTrace(final PrintStream out);
        
        void printPartialStackTrace(final PrintWriter out);
    }
}

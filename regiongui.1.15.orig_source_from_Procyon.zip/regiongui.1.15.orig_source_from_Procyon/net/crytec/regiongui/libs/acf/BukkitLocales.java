// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.configuration.ConfigurationSection;
import java.util.Iterator;
import co.aikar.locales.MessageKeyProvider;
import co.aikar.locales.MessageKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.util.Locale;
import java.io.File;

public class BukkitLocales extends Locales
{
    private final BukkitCommandManager manager;
    
    public BukkitLocales(final BukkitCommandManager manager) {
        super(manager);
        this.manager = manager;
        this.addBundleClassLoader(this.manager.getPlugin().getClass().getClassLoader());
    }
    
    @Override
    public void loadLanguages() {
        super.loadLanguages();
        final String string = "acf-" + this.manager.plugin.getDescription().getName();
        this.addMessageBundles("acf-minecraft", string, string.toLowerCase());
    }
    
    public boolean loadYamlLanguageFile(final File file, final Locale locale) {
        final YamlConfiguration config = new YamlConfiguration();
        config.load(file);
        return this.loadLanguage((FileConfiguration)config, locale);
    }
    
    public boolean loadYamlLanguageFile(final String file, final Locale locale) {
        final YamlConfiguration config = new YamlConfiguration();
        config.load(new File(this.manager.plugin.getDataFolder(), file));
        return this.loadLanguage((FileConfiguration)config, locale);
    }
    
    public boolean loadLanguage(final FileConfiguration config, final Locale locale) {
        boolean b = false;
        for (final String str : config.getKeys(false)) {
            final ConfigurationSection configurationSection = config.getConfigurationSection(str);
            if (configurationSection == null) {
                continue;
            }
            for (final String str2 : configurationSection.getKeys(false)) {
                final String string = configurationSection.getString(str2);
                if (string != null && !string.isEmpty()) {
                    this.addMessage(locale, MessageKey.of(str + "." + str2), string);
                    b = true;
                }
            }
        }
        return b;
    }
}

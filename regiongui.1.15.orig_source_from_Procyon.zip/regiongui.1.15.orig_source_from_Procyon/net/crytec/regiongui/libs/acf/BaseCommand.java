// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import co.aikar.locales.MessageKeyProvider;
import java.util.Stack;
import net.crytec.regiongui.libs.acf.apachecommonslang.ApacheCommonsLangUtil;
import java.util.List;
import java.util.ArrayList;
import net.crytec.regiongui.libs.acf.annotation.Subcommand;
import java.util.function.Consumer;
import java.util.Arrays;
import java.util.Objects;
import net.crytec.regiongui.libs.acf.annotation.UnknownHandler;
import net.crytec.regiongui.libs.acf.annotation.CatchAll;
import net.crytec.regiongui.libs.acf.annotation.CatchUnknown;
import net.crytec.regiongui.libs.acf.annotation.PreCommand;
import net.crytec.regiongui.libs.acf.annotation.Default;
import net.crytec.regiongui.libs.acf.annotation.HelpCommand;
import java.util.LinkedHashSet;
import java.lang.reflect.Parameter;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import com.google.common.collect.Multimap;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.Iterator;
import java.util.Collection;
import java.util.Collections;
import net.crytec.regiongui.libs.acf.annotation.Conditions;
import net.crytec.regiongui.libs.acf.annotation.Description;
import net.crytec.regiongui.libs.acf.annotation.CommandPermission;
import java.lang.reflect.AnnotatedElement;
import net.crytec.regiongui.libs.acf.annotation.CommandAlias;
import java.util.HashMap;
import java.util.HashSet;
import com.google.common.collect.HashMultimap;
import org.jetbrains.annotations.Nullable;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.Set;
import com.google.common.collect.SetMultimap;

public abstract class BaseCommand
{
    static final String CATCHUNKNOWN = "__catchunknown";
    static final String DEFAULT = "__default";
    final SetMultimap<String, RegisteredCommand> subCommands;
    final Set<BaseCommand> subScopes;
    final Map<Class<?>, String> contextFlags;
    @Nullable
    private Method preCommandHandler;
    private String execLabel;
    private String execSubcommand;
    private String[] origArgs;
    CommandManager<?, ?, ?, ?, ?, ?> manager;
    BaseCommand parentCommand;
    Map<String, RootCommand> registeredCommands;
    @Nullable
    String description;
    @Nullable
    String commandName;
    @Nullable
    String permission;
    @Nullable
    String conditions;
    boolean hasHelpCommand;
    private ExceptionHandler exceptionHandler;
    private final ThreadLocal<CommandOperationContext> lastCommandOperationContext;
    @Nullable
    private String parentSubcommand;
    private final Set<String> permissions;
    
    public BaseCommand() {
        this.subCommands = (SetMultimap<String, RegisteredCommand>)HashMultimap.create();
        this.subScopes = new HashSet<BaseCommand>();
        this.contextFlags = new HashMap<Class<?>, String>();
        this.manager = null;
        this.registeredCommands = new HashMap<String, RootCommand>();
        this.exceptionHandler = null;
        this.lastCommandOperationContext = new ThreadLocal<CommandOperationContext>();
        this.permissions = new HashSet<String>();
    }
    
    @Deprecated
    public BaseCommand(@Nullable final String cmd) {
        this.subCommands = (SetMultimap<String, RegisteredCommand>)HashMultimap.create();
        this.subScopes = new HashSet<BaseCommand>();
        this.contextFlags = new HashMap<Class<?>, String>();
        this.manager = null;
        this.registeredCommands = new HashMap<String, RootCommand>();
        this.exceptionHandler = null;
        this.lastCommandOperationContext = new ThreadLocal<CommandOperationContext>();
        this.permissions = new HashSet<String>();
        this.commandName = cmd;
    }
    
    public CommandOperationContext getLastCommandOperationContext() {
        return this.lastCommandOperationContext.get();
    }
    
    public String getExecCommandLabel() {
        return this.execLabel;
    }
    
    public String getExecSubcommand() {
        return this.execSubcommand;
    }
    
    public String[] getOrigArgs() {
        return this.origArgs;
    }
    
    void onRegister(final CommandManager manager) {
        this.onRegister(manager, this.commandName);
    }
    
    private void onRegister(final CommandManager manager, String cmd) {
        manager.injectDependencies(this);
        this.manager = (CommandManager<?, ?, ?, ?, ?, ?>)manager;
        final Annotations annotations = manager.getAnnotations();
        final Class<? extends BaseCommand> class1 = this.getClass();
        final String[] annotationValues = annotations.getAnnotationValues(class1, CommandAlias.class, 11);
        if (cmd == null && annotationValues != null) {
            cmd = annotationValues[0];
        }
        this.commandName = ((cmd != null) ? cmd : class1.getSimpleName().toLowerCase());
        this.permission = annotations.getAnnotationValue(class1, CommandPermission.class, 1);
        this.description = annotations.getAnnotationValue(class1, Description.class, 9);
        this.parentSubcommand = this.getParentSubcommand(class1);
        this.conditions = annotations.getAnnotationValue(class1, Conditions.class, 9);
        this.computePermissions();
        this.registerSubcommands();
        this.registerSubclasses(cmd);
        if (annotationValues != null) {
            final HashSet<Object> c = new HashSet<Object>();
            Collections.addAll(c, annotationValues);
            c.remove(cmd);
            final Iterator<String> iterator = c.iterator();
            while (iterator.hasNext()) {
                this.register(iterator.next(), this);
            }
        }
        if (cmd != null) {
            this.register(cmd, this);
        }
    }
    
    private void registerSubclasses(final String cmd) {
        for (final Class<?> clazz : this.getClass().getDeclaredClasses()) {
            if (BaseCommand.class.isAssignableFrom(clazz)) {
                try {
                    BaseCommand baseCommand = null;
                    for (final Constructor constructor : clazz.getDeclaredConstructors()) {
                        constructor.setAccessible(true);
                        final Parameter[] parameters = constructor.getParameters();
                        if (parameters.length == 1) {
                            baseCommand = constructor.newInstance(this);
                        }
                        else {
                            this.manager.log(LogLevel.INFO, "Found unusable constructor: " + constructor.getName() + "(" + Stream.of(parameters).map(p -> p.getType().getSimpleName() + " " + p.getName()).collect((Collector<? super Object, ?, String>)Collectors.joining("<c2>,</c2> ")) + ")");
                        }
                    }
                    if (baseCommand != null) {
                        baseCommand.parentCommand = this;
                        this.subScopes.add(baseCommand);
                        baseCommand.onRegister(this.manager, cmd);
                        this.subCommands.putAll((Multimap)baseCommand.subCommands);
                        this.registeredCommands.putAll(baseCommand.registeredCommands);
                    }
                    else {
                        this.manager.log(LogLevel.ERROR, "Could not find a subcommand ctor for " + clazz.getName());
                    }
                }
                catch (InstantiationException | IllegalAccessException | InvocationTargetException ex) {
                    final Throwable throwable;
                    this.manager.log(LogLevel.ERROR, "Error registering subclass", throwable);
                }
            }
        }
    }
    
    private void registerSubcommands() {
        final Annotations annotations = this.manager.getAnnotations();
        int n = 0;
        final boolean b = this.parentSubcommand == null || this.parentSubcommand.isEmpty();
        final LinkedHashSet<Object> set = new LinkedHashSet<Object>();
        Collections.addAll(set, this.getClass().getDeclaredMethods());
        Collections.addAll(set, this.getClass().getMethods());
        for (final Method method : set) {
            method.setAccessible(true);
            String subCommand = null;
            String s = this.getSubcommandValue(method);
            final String annotationValue = annotations.getAnnotationValue(method, HelpCommand.class, 0);
            final String annotationValue2 = annotations.getAnnotationValue(method, CommandAlias.class, 0);
            if (annotations.hasAnnotation(method, Default.class)) {
                if (!b) {
                    s = this.parentSubcommand;
                }
                else {
                    this.registerSubcommand(method, "__default");
                }
            }
            if (s != null) {
                subCommand = s;
            }
            else if (annotationValue2 != null) {
                subCommand = annotationValue2;
            }
            else if (annotationValue != null) {
                subCommand = annotationValue;
                this.hasHelpCommand = true;
            }
            final boolean hasAnnotation = annotations.hasAnnotation(method, PreCommand.class);
            final boolean b2 = annotations.hasAnnotation(method, CatchUnknown.class) || annotations.hasAnnotation(method, CatchAll.class) || annotations.hasAnnotation(method, UnknownHandler.class);
            if (b2 || (n == 0 && annotationValue != null)) {
                if (n == 0) {
                    if (b2) {
                        this.subCommands.get((Object)"__catchunknown").clear();
                        n = 1;
                    }
                    this.registerSubcommand(method, "__catchunknown");
                }
                else {
                    ACFUtil.sneaky(new IllegalStateException("Multiple @CatchUnknown/@HelpCommand commands, duplicate on " + method.getDeclaringClass().getName() + "#" + method.getName()));
                }
            }
            else if (hasAnnotation) {
                if (this.preCommandHandler == null) {
                    this.preCommandHandler = method;
                }
                else {
                    ACFUtil.sneaky(new IllegalStateException("Multiple @PreCommand commands, duplicate on " + method.getDeclaringClass().getName() + "#" + method.getName()));
                }
            }
            if (Objects.equals(method.getDeclaringClass(), this.getClass()) && subCommand != null) {
                this.registerSubcommand(method, subCommand);
            }
        }
    }
    
    private void computePermissions() {
        this.permissions.clear();
        if (this.permission != null && !this.permission.isEmpty()) {
            this.permissions.addAll(Arrays.asList(ACFPatterns.COMMA.split(this.permission)));
        }
        if (this.parentCommand != null) {
            this.permissions.addAll(this.parentCommand.getRequiredPermissions());
        }
        this.subCommands.values().forEach(RegisteredCommand::computePermissions);
        this.subScopes.forEach(BaseCommand::computePermissions);
    }
    
    private String getSubcommandValue(final Method method) {
        final String annotationValue = this.manager.getAnnotations().getAnnotationValue(method, Subcommand.class, 0);
        if (annotationValue == null) {
            return null;
        }
        final String parentSubcommand = this.getParentSubcommand(method.getDeclaringClass());
        return (parentSubcommand == null || parentSubcommand.isEmpty()) ? annotationValue : (parentSubcommand + " " + annotationValue);
    }
    
    private String getParentSubcommand(Class<?> var_1_2C) {
        final ArrayList<String> list = new ArrayList<String>();
        while (var_1_2C != null) {
            final String annotationValue = this.manager.getAnnotations().getAnnotationValue(var_1_2C, Subcommand.class, 0);
            if (annotationValue != null) {
                list.add(annotationValue);
            }
            var_1_2C = var_1_2C.getEnclosingClass();
        }
        Collections.reverse(list);
        return ACFUtil.join(list, " ");
    }
    
    private void register(final String name, final BaseCommand cmd) {
        final String lowerCase = name.toLowerCase();
        final RootCommand obtainRootCommand = this.manager.obtainRootCommand(lowerCase);
        obtainRootCommand.addChild(cmd);
        this.registeredCommands.put(lowerCase, obtainRootCommand);
    }
    
    private void registerSubcommand(final Method method, String subCommand) {
        subCommand = this.manager.getCommandReplacements().replace(subCommand.toLowerCase());
        final String[] split = ACFPatterns.SPACE.split(subCommand);
        final Set<String> subCommandPossibilityList = getSubCommandPossibilityList(split);
        for (int i = 0; i < split.length; ++i) {
            final String[] split2 = ACFPatterns.PIPE.split(split[i]);
            if (split2.length == 0 || split2[0].isEmpty()) {
                throw new IllegalArgumentException("Invalid @Subcommand configuration for " + method.getName() + " - parts can not start with | or be empty");
            }
            split[i] = split2[0];
        }
        final String join = ApacheCommonsLangUtil.join((Object[])split, " ");
        final String[] annotationValues = this.manager.getAnnotations().getAnnotationValues(method, CommandAlias.class, 3);
        final RegisteredCommand registeredCommand = this.manager.createRegisteredCommand(this, (annotationValues != null) ? annotationValues[0] : (this.commandName + " "), method, join);
        final Iterator<String> iterator = subCommandPossibilityList.iterator();
        while (iterator.hasNext()) {
            this.subCommands.put((Object)iterator.next(), (Object)registeredCommand);
        }
        registeredCommand.addSubcommands(subCommandPossibilityList);
        if (annotationValues != null) {
            final String[] array = annotationValues;
            for (int length = array.length, j = 0; j < length; ++j) {
                this.register(array[j], new ForwardingCommand(this, registeredCommand, split));
            }
        }
    }
    
    private static Set<String> getSubCommandPossibilityList(final String[] subCommandParts) {
        int n = 0;
        Collection<Object> collection = null;
        HashSet<Object> set;
        while (true) {
            set = new HashSet<Object>();
            if (n < subCommandParts.length) {
                for (final String str : ACFPatterns.PIPE.split(subCommandParts[n])) {
                    if (collection != null) {
                        set.addAll(collection.stream().map(s -> s + " " + str).collect((Collector<? super Object, ?, List<Object>>)Collectors.toList()));
                    }
                    else {
                        set.add(str);
                    }
                }
            }
            if (n + 1 >= subCommandParts.length) {
                break;
            }
            collection = set;
            ++n;
        }
        return (Set<String>)set;
    }
    
    void execute(final CommandIssuer issuer, final CommandRouter.CommandRouteResult command) {
        try {
            final CommandOperationContext preCommandOperation = this.preCommandOperation(issuer, command.commandLabel, command.args, false);
            this.execSubcommand = command.subcommand;
            this.executeCommand(preCommandOperation, issuer, command.args, command.cmd);
        }
        finally {
            this.postCommandOperation();
        }
    }
    
    private void postCommandOperation() {
        CommandManager.commandOperationContext.get().pop();
        this.execSubcommand = null;
        this.execLabel = null;
        this.origArgs = new String[0];
    }
    
    private CommandOperationContext preCommandOperation(final CommandIssuer issuer, final String commandLabel, final String[] args, final boolean isAsync) {
        final Stack<CommandOperationContext> stack = CommandManager.commandOperationContext.get();
        final CommandOperationContext<?> commandOperationContext = this.manager.createCommandOperationContext(this, issuer, commandLabel, args, isAsync);
        stack.push(commandOperationContext);
        this.lastCommandOperationContext.set(commandOperationContext);
        this.execSubcommand = null;
        this.execLabel = commandLabel;
        this.origArgs = args;
        return commandOperationContext;
    }
    
    public CommandIssuer getCurrentCommandIssuer() {
        return CommandManager.getCurrentCommandIssuer();
    }
    
    public CommandManager getCurrentCommandManager() {
        return CommandManager.getCurrentCommandManager();
    }
    
    private void executeCommand(final CommandOperationContext commandOperationContext, final CommandIssuer issuer, final String[] args, final RegisteredCommand cmd) {
        if (cmd.hasPermission(issuer)) {
            commandOperationContext.setRegisteredCommand(cmd);
            if (this.checkPrecommand(commandOperationContext, cmd, issuer, args)) {
                return;
            }
            cmd.invoke(issuer, Arrays.asList(args), commandOperationContext);
        }
        else {
            issuer.sendMessage(MessageType.ERROR, MessageKeys.PERMISSION_DENIED, new String[0]);
        }
    }
    
    @Deprecated
    public boolean canExecute(final CommandIssuer issuer, final RegisteredCommand<?> cmd) {
        return true;
    }
    
    public List<String> tabComplete(final CommandIssuer issuer, final String commandLabel, final String[] args) {
        return this.tabComplete(issuer, commandLabel, args, false);
    }
    
    public List<String> tabComplete(final CommandIssuer issuer, final String commandLabel, final String[] args, final boolean isAsync) {
        return this.tabComplete(issuer, this.manager.getRootCommand(commandLabel.toLowerCase()), args, isAsync);
    }
    
    List<String> tabComplete(final CommandIssuer issuer, final RootCommand rootCommand, String[] args, final boolean isAsync) {
        if (args.length == 0) {
            args = new String[] { "" };
        }
        final String commandName = rootCommand.getCommandName();
        try {
            final CommandRouter router = this.manager.getRouter();
            this.preCommandOperation(issuer, commandName, args, isAsync);
            final CommandRouter.RouteSearch routeCommand = router.routeCommand(rootCommand, commandName, args, true);
            final ArrayList<String> cmds = new ArrayList<String>();
            if (routeCommand != null) {
                final CommandRouter.CommandRouteResult matchCommand = router.matchCommand(routeCommand, true);
                if (matchCommand != null) {
                    cmds.addAll((Collection<?>)this.completeCommand(issuer, matchCommand.cmd, matchCommand.args, commandName, isAsync));
                }
            }
            return filterTabComplete(args[args.length - 1], cmds);
        }
        finally {
            this.postCommandOperation();
        }
    }
    
    List<String> getCommandsForCompletion(final CommandIssuer issuer, final String[] args) {
        final HashSet<String> c = new HashSet<String>();
        final int max = Math.max(0, args.length - 1);
        final String lowerCase = ApacheCommonsLangUtil.join((Object[])args, " ").toLowerCase();
        for (final Map.Entry<String, V> entry : this.subCommands.entries()) {
            final String s = entry.getKey();
            if (s.startsWith(lowerCase) && !"__catchunknown".equals(s) && !"__default".equals(s)) {
                final RegisteredCommand registeredCommand = (RegisteredCommand)entry.getValue();
                if (!registeredCommand.hasPermission(issuer)) {
                    continue;
                }
                if (registeredCommand.isPrivate) {
                    continue;
                }
                c.add(ACFPatterns.SPACE.split(registeredCommand.prefSubCommand)[max]);
            }
        }
        return new ArrayList<String>(c);
    }
    
    private List<String> completeCommand(final CommandIssuer issuer, final RegisteredCommand cmd, final String[] args, final String commandLabel, final boolean isAsync) {
        if (!cmd.hasPermission(issuer) || args.length == 0 || cmd.parameters.length == 0) {
            return Collections.emptyList();
        }
        if (!cmd.parameters[cmd.parameters.length - 1].consumesRest && args.length > cmd.consumeInputResolvers) {
            return Collections.emptyList();
        }
        return filterTabComplete(args[args.length - 1], this.manager.getCommandCompletions().of(cmd, issuer, args, isAsync));
    }
    
    private static List<String> filterTabComplete(final String arg, final List<String> cmds) {
        return cmds.stream().distinct().filter(cmd -> cmd != null && (arg.isEmpty() || ApacheCommonsLangUtil.startsWithIgnoreCase(cmd, arg))).collect((Collector<? super Object, ?, List<String>>)Collectors.toList());
    }
    
    private boolean checkPrecommand(final CommandOperationContext commandOperationContext, final RegisteredCommand cmd, final CommandIssuer issuer, final String[] args) {
        final Method preCommandHandler = this.preCommandHandler;
        if (preCommandHandler != null) {
            try {
                final Class<?>[] parameterTypes = preCommandHandler.getParameterTypes();
                final Object[] args2 = new Object[preCommandHandler.getParameterCount()];
                for (int i = 0; i < args2.length; ++i) {
                    final Class<?> type = parameterTypes[i];
                    final Object issuer2 = issuer.getIssuer();
                    if (this.manager.isCommandIssuer(type) && type.isAssignableFrom(issuer2.getClass())) {
                        args2[i] = issuer2;
                    }
                    else if (CommandIssuer.class.isAssignableFrom(type)) {
                        args2[i] = issuer;
                    }
                    else if (RegisteredCommand.class.isAssignableFrom(type)) {
                        args2[i] = cmd;
                    }
                    else if (String[].class.isAssignableFrom(type)) {
                        args2[i] = args;
                    }
                    else {
                        args2[i] = null;
                    }
                }
                return (boolean)preCommandHandler.invoke(this, args2);
            }
            catch (IllegalAccessException | InvocationTargetException ex) {
                final Throwable throwable;
                this.manager.log(LogLevel.ERROR, "Exception encountered while command pre-processing", throwable);
            }
        }
        return false;
    }
    
    @Deprecated
    @UnstableAPI
    public CommandHelp getCommandHelp() {
        return this.manager.generateCommandHelp();
    }
    
    @Deprecated
    @UnstableAPI
    public void showCommandHelp() {
        this.getCommandHelp().showHelp();
    }
    
    public void help(final Object issuer, final String[] args) {
        this.help((CommandIssuer)this.manager.getCommandIssuer(issuer), args);
    }
    
    public void help(final CommandIssuer issuer, final String[] args) {
        issuer.sendMessage(MessageType.ERROR, MessageKeys.UNKNOWN_COMMAND, new String[0]);
    }
    
    public void doHelp(final Object issuer, final String... args) {
        this.doHelp((CommandIssuer)this.manager.getCommandIssuer(issuer), args);
    }
    
    public void doHelp(final CommandIssuer issuer, final String... args) {
        this.help(issuer, args);
    }
    
    public void showSyntax(final CommandIssuer issuer, final RegisteredCommand<?> cmd) {
        issuer.sendMessage(MessageType.SYNTAX, MessageKeys.INVALID_SYNTAX, "{command}", this.manager.getCommandPrefix(issuer) + cmd.command, "{syntax}", cmd.syntaxText);
    }
    
    public boolean hasPermission(final Object issuer) {
        return this.hasPermission((CommandIssuer)this.manager.getCommandIssuer(issuer));
    }
    
    public boolean hasPermission(final CommandIssuer issuer) {
        return this.manager.hasPermission(issuer, this.getRequiredPermissions());
    }
    
    public Set<String> getRequiredPermissions() {
        return this.permissions;
    }
    
    public boolean requiresPermission(final String permission) {
        return this.getRequiredPermissions().contains(permission);
    }
    
    public String getName() {
        return this.commandName;
    }
    
    public ExceptionHandler getExceptionHandler() {
        return this.exceptionHandler;
    }
    
    public BaseCommand setExceptionHandler(final ExceptionHandler exceptionHandler) {
        this.exceptionHandler = exceptionHandler;
        return this;
    }
    
    public RegisteredCommand getDefaultRegisteredCommand() {
        return ACFUtil.getFirstElement((Iterable<RegisteredCommand>)this.subCommands.get((Object)"__default"));
    }
    
    public String setContextFlags(final Class<?> cls, final String flags) {
        return this.contextFlags.put(cls, flags);
    }
    
    public String getContextFlags(final Class<?> cls) {
        return this.contextFlags.get(cls);
    }
    
    public List<RegisteredCommand> getRegisteredCommands() {
        final ArrayList<Object> list = (ArrayList<Object>)new ArrayList<RegisteredCommand>();
        list.addAll(this.subCommands.values());
        return (List<RegisteredCommand>)list;
    }
}

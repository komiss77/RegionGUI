// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Locale;

public interface IssuerLocaleChangedCallback<I extends CommandIssuer>
{
    void onIssuerLocaleChange(final I issuer, final Locale oldLocale, final Locale newLocale);
}

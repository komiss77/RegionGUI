// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf.processors;

import net.crytec.regiongui.libs.acf.CommandExecutionContext;
import net.crytec.regiongui.libs.acf.CommandOperationContext;
import net.crytec.regiongui.libs.acf.annotation.Conditions;
import net.crytec.regiongui.libs.acf.AnnotationProcessor;

@Deprecated
public class ConditionsProcessor implements AnnotationProcessor<Conditions>
{
    @Override
    public void onPreComand(final CommandOperationContext context) {
    }
    
    @Override
    public void onPostContextResolution(final CommandExecutionContext context, final Object resolvedValue) {
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.help.GenericCommandHelpTopic;
import org.bukkit.help.HelpTopic;
import org.bukkit.command.CommandException;
import net.crytec.regiongui.libs.acf.apachecommonslang.ApacheCommonsExceptionUtil;
import java.util.logging.Level;
import java.util.List;
import java.util.Collections;
import java.util.Objects;
import java.util.Locale;
import java.io.Serializable;
import org.bukkit.entity.Player;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import org.bukkit.command.PluginIdentifiableCommand;
import org.jetbrains.annotations.NotNull;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.bukkit.command.SimpleCommandMap;
import java.util.regex.Matcher;
import org.bukkit.inventory.ItemFactory;
import org.bukkit.scoreboard.ScoreboardManager;
import org.bukkit.scheduler.BukkitScheduler;
import org.bukkit.Server;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import java.util.function.Consumer;
import org.bukkit.event.Listener;
import org.bukkit.Bukkit;
import java.util.regex.Pattern;
import java.util.HashMap;
import net.crytec.regiongui.libs.timings.lib.MCTiming;
import org.bukkit.command.Command;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.scheduler.BukkitTask;
import net.crytec.regiongui.libs.timings.lib.TimingManager;
import org.bukkit.command.CommandMap;
import org.bukkit.plugin.Plugin;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

public class BukkitCommandManager extends CommandManager<CommandSender, BukkitCommandIssuer, ChatColor, BukkitMessageFormatter, BukkitCommandExecutionContext, BukkitConditionContext>
{
    protected final Plugin plugin;
    private final CommandMap commandMap;
    private final TimingManager timingManager;
    private final BukkitTask localeTask;
    private final Logger logger;
    public final Integer mcMinorVersion;
    public final Integer mcPatchVersion;
    protected Map<String, Command> knownCommands;
    protected Map<String, BukkitRootCommand> registeredCommands;
    protected BukkitCommandContexts contexts;
    protected BukkitCommandCompletions completions;
    MCTiming commandTiming;
    protected BukkitLocales locales;
    private boolean cantReadLocale;
    protected boolean autoDetectFromClient;
    
    public BukkitCommandManager(final Plugin plugin) {
        this.knownCommands = new HashMap<String, Command>();
        this.registeredCommands = new HashMap<String, BukkitRootCommand>();
        this.cantReadLocale = false;
        this.autoDetectFromClient = true;
        this.plugin = plugin;
        this.logger = Logger.getLogger(this.plugin.getName());
        this.timingManager = TimingManager.of(plugin);
        this.commandTiming = this.timingManager.of("Commands");
        this.commandMap = this.hookCommandMap();
        this.formatters.put(MessageType.ERROR, this.defaultFormatter = (MF)new BukkitMessageFormatter(new ChatColor[] { ChatColor.RED, ChatColor.YELLOW, ChatColor.RED }));
        this.formatters.put(MessageType.SYNTAX, (MF)new BukkitMessageFormatter(new ChatColor[] { ChatColor.YELLOW, ChatColor.GREEN, ChatColor.WHITE }));
        this.formatters.put(MessageType.INFO, (MF)new BukkitMessageFormatter(new ChatColor[] { ChatColor.BLUE, ChatColor.DARK_GREEN, ChatColor.GREEN }));
        this.formatters.put(MessageType.HELP, (MF)new BukkitMessageFormatter(new ChatColor[] { ChatColor.AQUA, ChatColor.GREEN, ChatColor.YELLOW }));
        final Matcher matcher = Pattern.compile("\\(MC: (\\d)\\.(\\d+)\\.?(\\d+?)?\\)").matcher(Bukkit.getVersion());
        if (matcher.find()) {
            this.mcMinorVersion = ACFUtil.parseInt(matcher.toMatchResult().group(2), 0);
            this.mcPatchVersion = ACFUtil.parseInt(matcher.toMatchResult().group(3), 0);
        }
        else {
            this.mcMinorVersion = -1;
            this.mcPatchVersion = -1;
        }
        Bukkit.getHelpMap().registerHelpTopicFactory((Class)BukkitRootCommand.class, command -> {
            if (this.hasUnstableAPI("help")) {
                return (HelpTopic)new ACFBukkitHelpTopic(this, (BukkitRootCommand)command);
            }
            return (HelpTopic)new GenericCommandHelpTopic(command);
        });
        Bukkit.getPluginManager().registerEvents((Listener)new ACFBukkitListener(this, plugin), plugin);
        this.getLocales();
        this.localeTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            if (this.cantReadLocale || !this.autoDetectFromClient) {
                return;
            }
            else {
                Bukkit.getOnlinePlayers().forEach(this::readPlayerLocale);
                return;
            }
        }, 5L, 5L);
        this.registerDependency(plugin.getClass(), plugin);
        this.registerDependency(Logger.class, plugin.getLogger());
        this.registerDependency(FileConfiguration.class, plugin.getConfig());
        this.registerDependency(FileConfiguration.class, "config", plugin.getConfig());
        this.registerDependency(Plugin.class, plugin);
        this.registerDependency((Class<? extends Plugin>)JavaPlugin.class, plugin);
        this.registerDependency(PluginManager.class, Bukkit.getPluginManager());
        this.registerDependency(Server.class, Bukkit.getServer());
        this.registerDependency(BukkitScheduler.class, Bukkit.getScheduler());
        this.registerDependency(ScoreboardManager.class, Bukkit.getScoreboardManager());
        this.registerDependency(ItemFactory.class, Bukkit.getItemFactory());
    }
    
    @NotNull
    private CommandMap hookCommandMap() {
        Object obj = null;
        try {
            final Server server = Bukkit.getServer();
            final Method declaredMethod = server.getClass().getDeclaredMethod("getCommandMap", (Class<?>[])new Class[0]);
            declaredMethod.setAccessible(true);
            obj = declaredMethod.invoke(server, new Object[0]);
            if (!SimpleCommandMap.class.isAssignableFrom(((CommandMap)obj).getClass())) {
                this.log(LogLevel.ERROR, "ERROR: CommandMap has been hijacked! Offending command map is located at: " + ((CommandMap)obj).getClass().getName());
                this.log(LogLevel.ERROR, "We are going to try to hijack it back and resolve this, but you are now in dangerous territory.");
                this.log(LogLevel.ERROR, "We can not guarantee things are going to work.");
                final Field declaredField = server.getClass().getDeclaredField("commandMap");
                obj = new ProxyCommandMap(this, (CommandMap)obj);
                declaredField.set(server, obj);
                this.log(LogLevel.INFO, "Injected Proxy Command Map... good luck...");
            }
            final Field declaredField2 = SimpleCommandMap.class.getDeclaredField("knownCommands");
            declaredField2.setAccessible(true);
            this.knownCommands = (Map<String, Command>)declaredField2.get(obj);
        }
        catch (Exception t) {
            this.log(LogLevel.ERROR, "Failed to get Command Map. ACF will not function.");
            ACFUtil.sneaky(t);
        }
        return (CommandMap)obj;
    }
    
    public Plugin getPlugin() {
        return this.plugin;
    }
    
    @Override
    public boolean isCommandIssuer(final Class<?> type) {
        return CommandSender.class.isAssignableFrom(type);
    }
    
    @Override
    public synchronized CommandContexts<BukkitCommandExecutionContext> getCommandContexts() {
        if (this.contexts == null) {
            this.contexts = new BukkitCommandContexts(this);
        }
        return this.contexts;
    }
    
    @Override
    public synchronized CommandCompletions<BukkitCommandCompletionContext> getCommandCompletions() {
        if (this.completions == null) {
            this.completions = new BukkitCommandCompletions(this);
        }
        return this.completions;
    }
    
    @Override
    public BukkitLocales getLocales() {
        if (this.locales == null) {
            (this.locales = new BukkitLocales(this)).loadLanguages();
        }
        return this.locales;
    }
    
    @Override
    public boolean hasRegisteredCommands() {
        return !this.registeredCommands.isEmpty();
    }
    
    public void registerCommand(final BaseCommand command, final boolean force) {
        final String lowerCase = this.plugin.getName().toLowerCase();
        command.onRegister(this);
        for (final Map.Entry<String, RootCommand> entry : command.registeredCommands.entrySet()) {
            final String lowerCase2 = entry.getKey().toLowerCase();
            final BukkitRootCommand bukkitRootCommand = entry.getValue();
            if (!bukkitRootCommand.isRegistered) {
                final Command command2 = this.commandMap.getCommand(lowerCase2);
                if (command2 instanceof PluginIdentifiableCommand && ((PluginIdentifiableCommand)command2).getPlugin() == this.plugin) {
                    this.knownCommands.remove(lowerCase2);
                    command2.unregister(this.commandMap);
                }
                else if (command2 != null && force) {
                    this.knownCommands.remove(lowerCase2);
                    for (final Map.Entry<String, Command> entry2 : this.knownCommands.entrySet()) {
                        final String input = entry2.getKey();
                        final Command obj = entry2.getValue();
                        if (input.contains(":") && command2.equals(obj)) {
                            final String[] split = ACFPatterns.COLON.split(input, 2);
                            if (split.length <= 1) {
                                continue;
                            }
                            command2.unregister(this.commandMap);
                            command2.setLabel(split[0] + ":" + command.getName());
                            command2.register(this.commandMap);
                        }
                    }
                }
                this.commandMap.register(lowerCase2, lowerCase, (Command)bukkitRootCommand);
            }
            bukkitRootCommand.isRegistered = true;
            this.registeredCommands.put(lowerCase2, bukkitRootCommand);
        }
    }
    
    @Override
    public void registerCommand(final BaseCommand command) {
        this.registerCommand(command, false);
    }
    
    public void unregisterCommand(final BaseCommand command) {
        for (final BukkitRootCommand command2 : command.registeredCommands.values()) {
            command2.getSubCommands().values().removeAll(command.subCommands.values());
            if (command2.isRegistered && command2.getSubCommands().isEmpty()) {
                this.unregisterCommand(command2);
                command2.isRegistered = false;
            }
        }
    }
    
    @Deprecated
    public void unregisterCommand(final BukkitRootCommand command) {
        final String lowerCase = this.plugin.getName().toLowerCase();
        command.unregister(this.commandMap);
        final String name = command.getName();
        if (command.equals(this.knownCommands.get(name))) {
            this.knownCommands.remove(name);
        }
        this.knownCommands.remove(lowerCase + ":" + name);
        this.registeredCommands.remove(name);
    }
    
    public void unregisterCommands() {
        final Iterator<String> iterator = new HashSet<String>(this.registeredCommands.keySet()).iterator();
        while (iterator.hasNext()) {
            this.unregisterCommand(this.registeredCommands.get(iterator.next()));
        }
    }
    
    private Field getEntityField(final Player player) {
        for (Serializable s = player.getClass(); s != Object.class; s = ((Class<Object>)s).getSuperclass()) {
            if (((Class)s).getName().endsWith("CraftEntity")) {
                final Field declaredField = ((Class)s).getDeclaredField("entity");
                declaredField.setAccessible(true);
                return declaredField;
            }
        }
        return null;
    }
    
    public Locale setPlayerLocale(final Player player, final Locale locale) {
        return ((CommandManager<CommandSender, I, FT, MF, CEC, CC>)this).setIssuerLocale((CommandSender)player, locale);
    }
    
    void readPlayerLocale(final Player player) {
        if (!player.isOnline() || this.cantReadLocale) {
            return;
        }
        try {
            final Field entityField = this.getEntityField(player);
            if (entityField == null) {
                return;
            }
            final Object value = entityField.get(player);
            if (value != null) {
                final Field declaredField = value.getClass().getDeclaredField("locale");
                declaredField.setAccessible(true);
                final Object value2 = declaredField.get(value);
                if (value2 instanceof String) {
                    final String[] split = ACFPatterns.UNDERSCORE.split((CharSequence)value2);
                    final Locale locale = (split.length > 1) ? new Locale(split[0], split[1]) : new Locale(split[0]);
                    final Locale locale2 = this.issuersLocale.put(player.getUniqueId(), locale);
                    if (!Objects.equals(locale, locale2)) {
                        ((CommandManager<IT, BukkitCommandIssuer, FT, MF, CEC, CC>)this).notifyLocaleChange(this.getCommandIssuer(player), locale2, locale);
                    }
                }
            }
        }
        catch (Exception throwable) {
            this.cantReadLocale = true;
            this.localeTask.cancel();
            this.log(LogLevel.INFO, "Can't read players locale, you will be unable to automatically detect players language. Only Bukkit 1.7+ is supported for this.", throwable);
        }
    }
    
    public TimingManager getTimings() {
        return this.timingManager;
    }
    
    @Override
    public RootCommand createRootCommand(final String cmd) {
        return new BukkitRootCommand(this, cmd);
    }
    
    @Override
    public Collection<RootCommand> getRegisteredRootCommands() {
        return Collections.unmodifiableCollection((Collection<? extends RootCommand>)this.registeredCommands.values());
    }
    
    @Override
    public BukkitCommandIssuer getCommandIssuer(final Object issuer) {
        if (!(issuer instanceof CommandSender)) {
            throw new IllegalArgumentException(issuer.getClass().getName() + " is not a Command Issuer.");
        }
        return new BukkitCommandIssuer(this, (CommandSender)issuer);
    }
    
    @Override
    public BukkitCommandExecutionContext createCommandContext(final RegisteredCommand command, final CommandParameter parameter, final CommandIssuer sender, final List<String> args, final int i, final Map<String, Object> passedArgs) {
        return new BukkitCommandExecutionContext(command, parameter, (BukkitCommandIssuer)sender, args, i, passedArgs);
    }
    
    @Override
    public BukkitCommandCompletionContext createCompletionContext(final RegisteredCommand command, final CommandIssuer sender, final String input, final String config, final String[] args) {
        return new BukkitCommandCompletionContext(command, (BukkitCommandIssuer)sender, input, config, args);
    }
    
    @Override
    public RegisteredCommand createRegisteredCommand(final BaseCommand command, final String cmdName, final Method method, final String prefSubCommand) {
        return new BukkitRegisteredCommand(command, cmdName, method, prefSubCommand);
    }
    
    @Override
    public BukkitConditionContext createConditionContext(final CommandIssuer issuer, final String config) {
        return new BukkitConditionContext((BukkitCommandIssuer)issuer, config);
    }
    
    @Override
    public void log(final LogLevel level, final String message, final Throwable throwable) {
        final Level level2 = (level == LogLevel.INFO) ? Level.INFO : Level.SEVERE;
        this.logger.log(level2, "[ACF] " + message);
        if (throwable != null) {
            final String[] split = ACFPatterns.NEWLINE.split(ApacheCommonsExceptionUtil.getFullStackTrace(throwable));
            for (int length = split.length, i = 0; i < length; ++i) {
                this.logger.log(level2, "[ACF] " + split[i]);
            }
        }
    }
    
    public boolean usePerIssuerLocale(final boolean usePerIssuerLocale, final boolean autoDetectFromClient) {
        final boolean usePerIssuerLocale2 = this.usePerIssuerLocale;
        this.usePerIssuerLocale = usePerIssuerLocale;
        this.autoDetectFromClient = autoDetectFromClient;
        return usePerIssuerLocale2;
    }
    
    @Override
    public String getCommandPrefix(final CommandIssuer issuer) {
        return issuer.isPlayer() ? "/" : "";
    }
    
    @Override
    protected boolean handleUncaughtException(final BaseCommand scope, final RegisteredCommand registeredCommand, final CommandIssuer sender, final List<String> args, Throwable t) {
        if (t instanceof CommandException && t.getCause() != null && t.getMessage().startsWith("Unhandled exception")) {
            t = t.getCause();
        }
        return super.handleUncaughtException(scope, registeredCommand, sender, args, t);
    }
}

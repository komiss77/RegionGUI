// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Iterator;
import com.google.common.collect.SetMultimap;
import java.util.HashSet;
import java.util.Arrays;
import net.crytec.regiongui.libs.acf.apachecommonslang.ApacheCommonsLangUtil;
import java.util.Optional;
import java.util.Set;

class CommandRouter
{
    private final CommandManager manager;
    
    CommandRouter(final CommandManager manager) {
        this.manager = manager;
    }
    
    CommandRouteResult matchCommand(final RouteSearch search, final boolean completion) {
        final Set<RegisteredCommand> commands = search.commands;
        final String[] args = search.args;
        if (!commands.isEmpty()) {
            if (commands.size() == 1) {
                return new CommandRouteResult(ACFUtil.getFirstElement(commands), search);
            }
            final int consumeInputResolvers;
            final int consumeInputResolvers2;
            final Optional<RegisteredCommand> min = commands.stream().filter(c -> this.isProbableMatch(c, args, completion)).min((c1, c2) -> {
                consumeInputResolvers = c1.consumeInputResolvers;
                consumeInputResolvers2 = c2.consumeInputResolvers;
                if (consumeInputResolvers == consumeInputResolvers2) {
                    return 0;
                }
                else {
                    return (consumeInputResolvers < consumeInputResolvers2) ? 1 : -1;
                }
            });
            if (min.isPresent()) {
                return new CommandRouteResult(min.get(), search);
            }
        }
        return null;
    }
    
    private boolean isProbableMatch(final RegisteredCommand c, final String[] args, final boolean completion) {
        final int requiredResolvers = c.requiredResolvers;
        return args.length <= requiredResolvers + c.optionalResolvers && (completion || args.length >= requiredResolvers);
    }
    
    RouteSearch routeCommand(final RootCommand command, final String commandLabel, final String[] args, final boolean completion) {
        final SetMultimap<String, RegisteredCommand> subCommands = command.getSubCommands();
        int i;
        int to;
        for (to = (i = args.length); i >= 0; --i) {
            final String lowerCase = ApacheCommonsLangUtil.join((Object[])args, " ", 0, i).toLowerCase();
            final Set value = subCommands.get((Object)lowerCase);
            if (!value.isEmpty()) {
                return new RouteSearch(value, Arrays.copyOfRange(args, i, to), commandLabel, lowerCase, completion);
            }
        }
        final Set value2 = subCommands.get((Object)"__default");
        final Set value3 = subCommands.get((Object)"__catchunknown");
        if (!value2.isEmpty()) {
            final HashSet commands = new HashSet<RegisteredCommand>();
            for (final RegisteredCommand registeredCommand : value2) {
                final int requiredResolvers = registeredCommand.requiredResolvers;
                final int optionalResolvers = registeredCommand.optionalResolvers;
                final CommandParameter<CEC> commandParameter = (registeredCommand.parameters.length > 0) ? registeredCommand.parameters[registeredCommand.parameters.length - 1] : null;
                if (to <= requiredResolvers + optionalResolvers || (commandParameter != null && (commandParameter.getType() == String[].class || (to >= requiredResolvers && commandParameter.consumesRest)))) {
                    commands.add(registeredCommand);
                }
            }
            if (!commands.isEmpty()) {
                return new RouteSearch(commands, args, commandLabel, null, completion);
            }
        }
        if (!value3.isEmpty()) {
            return new RouteSearch(value3, args, commandLabel, null, completion);
        }
        return null;
    }
    
    static class CommandRouteResult
    {
        final RegisteredCommand cmd;
        final String[] args;
        final String commandLabel;
        final String subcommand;
        
        CommandRouteResult(final RegisteredCommand cmd, final RouteSearch search) {
            this(cmd, search.args, search.subcommand, search.commandLabel);
        }
        
        CommandRouteResult(final RegisteredCommand cmd, final String[] args, final String subcommand, final String commandLabel) {
            this.cmd = cmd;
            this.args = args;
            this.commandLabel = commandLabel;
            this.subcommand = subcommand;
        }
    }
    
    static class RouteSearch
    {
        final String[] args;
        final Set<RegisteredCommand> commands;
        final String commandLabel;
        final String subcommand;
        
        RouteSearch(final Set<RegisteredCommand> commands, final String[] args, final String commandLabel, final String subcommand, final boolean completion) {
            this.commands = commands;
            this.args = args;
            this.commandLabel = commandLabel.toLowerCase();
            this.subcommand = subcommand;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.entity.Player;
import org.bukkit.command.CommandSender;

public class BukkitCommandCompletionContext extends CommandCompletionContext<BukkitCommandIssuer>
{
    BukkitCommandCompletionContext(final RegisteredCommand command, final BukkitCommandIssuer issuer, final String input, final String config, final String[] args) {
        super(command, issuer, input, config, args);
    }
    
    public CommandSender getSender() {
        return this.getIssuer().getIssuer();
    }
    
    public Player getPlayer() {
        return ((BukkitCommandIssuer)this.issuer).getPlayer();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.entity.Player;
import java.util.Locale;
import org.bukkit.command.CommandSender;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.event.Listener;

class ACFBukkitListener implements Listener
{
    private BukkitCommandManager manager;
    private final Plugin plugin;
    
    public ACFBukkitListener(final BukkitCommandManager manager, final Plugin plugin) {
        this.manager = manager;
        this.plugin = plugin;
    }
    
    @EventHandler
    public void onPluginDisable(final PluginDisableEvent event) {
        if (!this.plugin.getName().equalsIgnoreCase(event.getPlugin().getName())) {
            return;
        }
        this.manager.unregisterCommands();
    }
    
    @EventHandler
    public void onPlayerJoin(final PlayerJoinEvent event) {
        final Player player = event.getPlayer();
        if (this.manager.autoDetectFromClient) {
            this.manager.readPlayerLocale(player);
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> this.manager.readPlayerLocale(player), 20L);
        }
        else {
            ((CommandManager<CommandSender, I, FT, MF, CEC, CC>)this.manager).setIssuerLocale((CommandSender)player, this.manager.getLocales().getDefaultLocale());
            ((CommandManager<IT, BukkitCommandIssuer, FT, MF, CEC, CC>)this.manager).notifyLocaleChange(this.manager.getCommandIssuer(player), null, this.manager.getLocales().getDefaultLocale());
        }
    }
    
    @EventHandler
    public void onPlayerQuit(final PlayerQuitEvent quitEvent) {
        this.manager.issuersLocale.remove(quitEvent.getPlayer().getUniqueId());
    }
}

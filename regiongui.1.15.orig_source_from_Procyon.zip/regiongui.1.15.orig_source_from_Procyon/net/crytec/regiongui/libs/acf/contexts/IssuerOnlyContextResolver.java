// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf.contexts;

import net.crytec.regiongui.libs.acf.CommandIssuer;
import net.crytec.regiongui.libs.acf.CommandExecutionContext;

public interface IssuerOnlyContextResolver<T, C extends CommandExecutionContext<?, ? extends CommandIssuer>> extends ContextResolver<T, C>
{
}

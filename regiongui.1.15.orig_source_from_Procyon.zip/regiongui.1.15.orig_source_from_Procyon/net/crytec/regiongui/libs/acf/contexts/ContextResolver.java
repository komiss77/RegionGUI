// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf.contexts;

import net.crytec.regiongui.libs.acf.InvalidCommandArgument;
import net.crytec.regiongui.libs.acf.CommandIssuer;
import net.crytec.regiongui.libs.acf.CommandExecutionContext;

@FunctionalInterface
public interface ContextResolver<T, C extends CommandExecutionContext<?, ? extends CommandIssuer>>
{
    T getContext(final C c) throws InvalidCommandArgument;
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf.contexts;

import org.bukkit.entity.Player;

@Deprecated
public class OnlinePlayer extends net.crytec.regiongui.libs.acf.bukkit.contexts.OnlinePlayer
{
    public OnlinePlayer(final Player player) {
        super(player);
    }
}

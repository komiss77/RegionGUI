// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import co.aikar.locales.MessageKeyProvider;
import co.aikar.locales.MessageKey;

public class InvalidCommandArgument extends RuntimeException
{
    final boolean showSyntax;
    final MessageKey key;
    final String[] replacements;
    
    public InvalidCommandArgument() {
        this(null, true);
    }
    
    public InvalidCommandArgument(final boolean showSyntax) {
        this(null, showSyntax);
    }
    
    public InvalidCommandArgument(final MessageKeyProvider key, final String... replacements) {
        this(key.getMessageKey(), replacements);
    }
    
    public InvalidCommandArgument(final MessageKey key, final String... replacements) {
        this(key, true, replacements);
    }
    
    public InvalidCommandArgument(final MessageKeyProvider key, final boolean showSyntax, final String... replacements) {
        this(key.getMessageKey(), showSyntax, replacements);
    }
    
    public InvalidCommandArgument(final MessageKey key, final boolean showSyntax, final String... replacements) {
        super(key.getKey(), null, false, false);
        this.showSyntax = showSyntax;
        this.key = key;
        this.replacements = replacements;
    }
    
    public InvalidCommandArgument(final String message) {
        this(message, true);
    }
    
    public InvalidCommandArgument(final String message, final boolean showSyntax) {
        super(message, null, false, false);
        this.showSyntax = showSyntax;
        this.replacements = null;
        this.key = null;
    }
}

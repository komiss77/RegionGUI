// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.math.BigDecimal;
import java.math.BigInteger;
import net.crytec.regiongui.libs.acf.annotation.Values;
import net.crytec.regiongui.libs.acf.annotation.Split;
import net.crytec.regiongui.libs.acf.annotation.Single;
import java.util.Collection;
import java.util.List;
import net.crytec.regiongui.libs.acf.contexts.OptionalContextResolver;
import net.crytec.regiongui.libs.acf.contexts.IssuerOnlyContextResolver;
import net.crytec.regiongui.libs.acf.contexts.IssuerAwareContextResolver;
import co.aikar.locales.MessageKeyProvider;
import org.jetbrains.annotations.NotNull;
import net.crytec.regiongui.libs.acf.contexts.ContextResolver;
import java.util.Map;

public class CommandContexts<R extends CommandExecutionContext<?, ? extends CommandIssuer>>
{
    protected final Map<Class<?>, ContextResolver<?, R>> contextMap;
    protected final CommandManager manager;
    
    CommandContexts(final CommandManager manager) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     4: aload_0        
        //     5: new             Ljava/util/HashMap;
        //     8: dup            
        //     9: invokespecial   java/util/HashMap.<init>:()V
        //    12: putfield        net/crytec/regiongui/libs/acf/CommandContexts.contextMap:Ljava/util/Map;
        //    15: aload_0        
        //    16: aload_1        
        //    17: putfield        net/crytec/regiongui/libs/acf/CommandContexts.manager:Lnet/crytec/regiongui/libs/acf/CommandManager;
        //    20: aload_0        
        //    21: ldc             Lnet/crytec/regiongui/libs/acf/CommandIssuer;.class
        //    23: invokedynamic   BootstrapMethod #0, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/IssuerOnlyContextResolver;
        //    28: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerIssuerOnlyContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/IssuerOnlyContextResolver;)V
        //    31: aload_0        
        //    32: ldc             Ljava/lang/Short;.class
        //    34: aload_0        
        //    35: invokedynamic   BootstrapMethod #1, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    40: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    43: aload_0        
        //    44: getstatic       java/lang/Short.TYPE:Ljava/lang/Class;
        //    47: aload_0        
        //    48: invokedynamic   BootstrapMethod #2, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    53: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    56: aload_0        
        //    57: ldc             Ljava/lang/Integer;.class
        //    59: aload_0        
        //    60: invokedynamic   BootstrapMethod #3, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    65: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    68: aload_0        
        //    69: getstatic       java/lang/Integer.TYPE:Ljava/lang/Class;
        //    72: aload_0        
        //    73: invokedynamic   BootstrapMethod #4, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    78: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    81: aload_0        
        //    82: ldc             Ljava/lang/Long;.class
        //    84: aload_0        
        //    85: invokedynamic   BootstrapMethod #5, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    90: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    93: aload_0        
        //    94: getstatic       java/lang/Long.TYPE:Ljava/lang/Class;
        //    97: aload_0        
        //    98: invokedynamic   BootstrapMethod #6, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   103: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   106: aload_0        
        //   107: ldc             Ljava/lang/Float;.class
        //   109: aload_0        
        //   110: invokedynamic   BootstrapMethod #7, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   115: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   118: aload_0        
        //   119: getstatic       java/lang/Float.TYPE:Ljava/lang/Class;
        //   122: aload_0        
        //   123: invokedynamic   BootstrapMethod #8, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   128: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   131: aload_0        
        //   132: ldc             Ljava/lang/Double;.class
        //   134: aload_0        
        //   135: invokedynamic   BootstrapMethod #9, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   140: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   143: aload_0        
        //   144: getstatic       java/lang/Double.TYPE:Ljava/lang/Class;
        //   147: aload_0        
        //   148: invokedynamic   BootstrapMethod #10, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   153: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   156: aload_0        
        //   157: ldc             Ljava/lang/Number;.class
        //   159: aload_0        
        //   160: invokedynamic   BootstrapMethod #11, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   165: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   168: aload_0        
        //   169: ldc             Ljava/math/BigDecimal;.class
        //   171: aload_0        
        //   172: invokedynamic   BootstrapMethod #12, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   177: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   180: aload_0        
        //   181: ldc             Ljava/math/BigInteger;.class
        //   183: aload_0        
        //   184: invokedynamic   BootstrapMethod #13, getContext:(Lnet/crytec/regiongui/libs/acf/CommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   189: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   192: aload_0        
        //   193: ldc             Ljava/lang/Boolean;.class
        //   195: invokedynamic   BootstrapMethod #14, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   200: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   203: aload_0        
        //   204: getstatic       java/lang/Boolean.TYPE:Ljava/lang/Class;
        //   207: invokedynamic   BootstrapMethod #15, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   212: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   215: aload_0        
        //   216: getstatic       java/lang/Character.TYPE:Ljava/lang/Class;
        //   219: invokedynamic   BootstrapMethod #16, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   224: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   227: aload_0        
        //   228: ldc             Ljava/lang/String;.class
        //   230: invokedynamic   BootstrapMethod #17, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   235: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   238: aload_0        
        //   239: ldc             [Ljava/lang/String;.class
        //   241: invokedynamic   BootstrapMethod #18, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   246: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   249: aload_0        
        //   250: ldc             Ljava/lang/Enum;.class
        //   252: invokedynamic   BootstrapMethod #19, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   257: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   260: aload_0        
        //   261: ldc             Lnet/crytec/regiongui/libs/acf/CommandHelp;.class
        //   263: aload_1        
        //   264: invokedynamic   BootstrapMethod #20, getContext:(Lnet/crytec/regiongui/libs/acf/CommandManager;)Lnet/crytec/regiongui/libs/acf/contexts/OptionalContextResolver;
        //   269: invokevirtual   net/crytec/regiongui/libs/acf/CommandContexts.registerOptionalContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/OptionalContextResolver;)V
        //   272: return         
        //    MethodParameters:
        //  Name     Flags  
        //  -------  -----
        //  manager  
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @NotNull
    private Number parseAndValidateNumber(final String number, final R c, final Number minValue, final Number maxValue) {
        final Number number2 = ACFUtil.parseNumber(number, c.hasFlag("suffixes"));
        this.validateMinMax(c, number2, minValue, maxValue);
        return number2;
    }
    
    private void validateMinMax(final R c, final Number val) {
        this.validateMinMax(c, val, null, null);
    }
    
    private void validateMinMax(final R c, final Number val, final Number minValue, final Number maxValue) {
        final Double flagValue = c.getFlagValue("min", minValue);
        final Double flagValue2 = c.getFlagValue("max", maxValue);
        if (flagValue2 != null && val.doubleValue() > flagValue2.doubleValue()) {
            throw new InvalidCommandArgument(MessageKeys.PLEASE_SPECIFY_AT_MOST, new String[] { "{max}", String.valueOf(flagValue2) });
        }
        if (flagValue != null && val.doubleValue() < flagValue.doubleValue()) {
            throw new InvalidCommandArgument(MessageKeys.PLEASE_SPECIFY_AT_LEAST, new String[] { "{min}", String.valueOf(flagValue) });
        }
    }
    
    @Deprecated
    public <T> void registerSenderAwareContext(final Class<T> context, final IssuerAwareContextResolver<T, R> supplier) {
        this.contextMap.put(context, supplier);
    }
    
    public <T> void registerIssuerAwareContext(final Class<T> context, final IssuerAwareContextResolver<T, R> supplier) {
        this.contextMap.put(context, supplier);
    }
    
    public <T> void registerIssuerOnlyContext(final Class<T> context, final IssuerOnlyContextResolver<T, R> supplier) {
        this.contextMap.put(context, supplier);
    }
    
    public <T> void registerOptionalContext(final Class<T> context, final OptionalContextResolver<T, R> supplier) {
        this.contextMap.put(context, supplier);
    }
    
    public <T> void registerContext(final Class<T> context, final ContextResolver<T, R> supplier) {
        this.contextMap.put(context, supplier);
    }
    
    public ContextResolver<?, R> getResolver(Class<?> var_1_24) {
        final Class<? super Object> clazz = var_1_24;
        while (true) {
            while (var_1_24 != Object.class) {
                final ContextResolver<?, R> contextResolver = this.contextMap.get(var_1_24);
                if (contextResolver != null) {
                    return contextResolver;
                }
                if ((var_1_24 = var_1_24.getSuperclass()) == null) {
                    this.manager.log(LogLevel.ERROR, "Could not find context resolver", new IllegalStateException("No context resolver defined for " + clazz.getName()));
                    return null;
                }
            }
            continue;
        }
    }
}

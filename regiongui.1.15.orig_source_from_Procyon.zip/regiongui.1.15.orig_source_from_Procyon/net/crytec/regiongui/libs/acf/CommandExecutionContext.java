// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Collection;
import java.lang.reflect.Parameter;
import java.lang.reflect.AnnotatedElement;
import java.lang.annotation.Annotation;
import java.util.Set;
import java.util.Iterator;
import java.util.Map;
import java.util.List;

public class CommandExecutionContext<CEC extends CommandExecutionContext, I extends CommandIssuer>
{
    private final RegisteredCommand cmd;
    private final CommandParameter param;
    protected final I issuer;
    private final List<String> args;
    private final int index;
    private final Map<String, Object> passedArgs;
    private final Map<String, String> flags;
    private final CommandManager manager;
    
    CommandExecutionContext(final RegisteredCommand cmd, final CommandParameter param, final I sender, final List<String> args, final int index, final Map<String, Object> passedArgs) {
        this.cmd = cmd;
        this.manager = cmd.scope.manager;
        this.param = param;
        this.issuer = sender;
        this.args = args;
        this.index = index;
        this.passedArgs = passedArgs;
        this.flags = (Map<String, String>)param.getFlags();
    }
    
    public String popFirstArg() {
        return this.args.isEmpty() ? null : this.args.remove(0);
    }
    
    public String popLastArg() {
        return this.args.isEmpty() ? null : this.args.remove(this.args.size() - 1);
    }
    
    public String getFirstArg() {
        return this.args.isEmpty() ? null : this.args.get(0);
    }
    
    public String getLastArg() {
        return this.args.isEmpty() ? null : this.args.get(this.args.size() - 1);
    }
    
    public boolean isLastArg() {
        return this.cmd.parameters.length - 1 == this.index;
    }
    
    public int getNumParams() {
        return this.cmd.parameters.length;
    }
    
    public boolean canOverridePlayerContext() {
        return this.cmd.requiredResolvers >= this.args.size();
    }
    
    public Object getResolvedArg(final String arg) {
        return this.passedArgs.get(arg);
    }
    
    public Object getResolvedArg(final Class<?>... classes) {
        for (final Class<?> clazz : classes) {
            for (final Object next : this.passedArgs.values()) {
                if (clazz.isInstance(next)) {
                    return next;
                }
            }
        }
        return null;
    }
    
    public <T> T getResolvedArg(final String key, final Class<?>... classes) {
        final Object value = this.passedArgs.get(key);
        for (int length = classes.length, i = 0; i < length; ++i) {
            if (classes[i].isInstance(value)) {
                return (T)value;
            }
        }
        return null;
    }
    
    public Set<String> getParameterPermissions() {
        return (Set<String>)this.param.getRequiredPermissions();
    }
    
    public boolean isOptional() {
        return this.param.isOptional();
    }
    
    public boolean hasFlag(final String flag) {
        return this.flags.containsKey(flag);
    }
    
    public String getFlagValue(final String flag, final String def) {
        return this.flags.getOrDefault(flag, def);
    }
    
    public Integer getFlagValue(final String flag, final Integer def) {
        return ACFUtil.parseInt(this.flags.get(flag), def);
    }
    
    public Long getFlagValue(final String flag, final Long def) {
        return ACFUtil.parseLong(this.flags.get(flag), def);
    }
    
    public Float getFlagValue(final String flag, final Float def) {
        return ACFUtil.parseFloat(this.flags.get(flag), def);
    }
    
    public Double getFlagValue(final String flag, final Double def) {
        return ACFUtil.parseDouble(this.flags.get(flag), def);
    }
    
    public Integer getIntFlagValue(final String flag, final Number def) {
        return ACFUtil.parseInt(this.flags.get(flag), (def != null) ? Integer.valueOf(def.intValue()) : null);
    }
    
    public Long getLongFlagValue(final String flag, final Number def) {
        return ACFUtil.parseLong(this.flags.get(flag), (def != null) ? Long.valueOf(def.longValue()) : null);
    }
    
    public Float getFloatFlagValue(final String flag, final Number def) {
        return ACFUtil.parseFloat(this.flags.get(flag), (def != null) ? Float.valueOf(def.floatValue()) : null);
    }
    
    public Double getDoubleFlagValue(final String flag, final Number def) {
        return ACFUtil.parseDouble(this.flags.get(flag), (def != null) ? Double.valueOf(def.doubleValue()) : null);
    }
    
    public Boolean getBooleanFlagValue(final String flag) {
        return this.getBooleanFlagValue(flag, false);
    }
    
    public Boolean getBooleanFlagValue(final String flag, final Boolean def) {
        final String test = this.flags.get(flag);
        if (test == null) {
            return def;
        }
        return ACFUtil.isTruthy(test);
    }
    
    public Double getFlagValue(final String flag, final Number def) {
        return ACFUtil.parseDouble(this.flags.get(flag), (def != null) ? Double.valueOf(def.doubleValue()) : null);
    }
    
    @Deprecated
    public <T extends Annotation> T getAnnotation(final Class<T> cls) {
        return this.param.getParameter().getAnnotation(cls);
    }
    
    public <T extends Annotation> String getAnnotationValue(final Class<T> cls) {
        return this.manager.getAnnotations().getAnnotationValue(this.param.getParameter(), cls);
    }
    
    public <T extends Annotation> String getAnnotationValue(final Class<T> cls, final int options) {
        return this.manager.getAnnotations().getAnnotationValue(this.param.getParameter(), cls, options);
    }
    
    public <T extends Annotation> boolean hasAnnotation(final Class<T> cls) {
        return this.manager.getAnnotations().hasAnnotation(this.param.getParameter(), cls);
    }
    
    public RegisteredCommand getCmd() {
        return this.cmd;
    }
    
    @UnstableAPI
    CommandParameter getCommandParameter() {
        return this.param;
    }
    
    @Deprecated
    public Parameter getParam() {
        return this.param.getParameter();
    }
    
    public I getIssuer() {
        return this.issuer;
    }
    
    public List<String> getArgs() {
        return this.args;
    }
    
    public int getIndex() {
        return this.index;
    }
    
    public Map<String, Object> getPassedArgs() {
        return this.passedArgs;
    }
    
    public Map<String, String> getFlags() {
        return this.flags;
    }
    
    public String joinArgs() {
        return ACFUtil.join(this.args, " ");
    }
    
    public String joinArgs(final String sep) {
        return ACFUtil.join(this.args, sep);
    }
}

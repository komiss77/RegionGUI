// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.lang.reflect.Field;
import java.io.Serializable;
import java.lang.reflect.AnnotatedElement;
import net.crytec.regiongui.libs.acf.annotation.Dependency;
import java.util.Objects;
import co.aikar.locales.MessageKeyProvider;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.function.Function;
import java.util.Iterator;
import org.jetbrains.annotations.NotNull;
import java.util.concurrent.ConcurrentHashMap;
import java.util.IdentityHashMap;
import java.util.Collection;
import java.util.HashSet;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;
import java.util.Locale;
import java.util.Set;
import java.util.List;
import co.aikar.util.Table;
import java.util.Map;
import java.util.Stack;

public abstract class CommandManager<IT, I extends CommandIssuer, FT, MF extends MessageFormatter<FT>, CEC extends CommandExecutionContext<CEC, I>, CC extends ConditionContext<I>>
{
    static ThreadLocal<Stack<CommandOperationContext>> commandOperationContext;
    protected Map<String, RootCommand> rootCommands;
    protected final CommandReplacements replacements;
    protected final CommandConditions<I, CEC, CC> conditions;
    protected ExceptionHandler defaultExceptionHandler;
    boolean logUnhandledExceptions;
    protected Table<Class<?>, String, Object> dependencies;
    protected CommandHelpFormatter helpFormatter;
    protected boolean usePerIssuerLocale;
    protected List<IssuerLocaleChangedCallback<I>> localeChangedCallbacks;
    protected Set<Locale> supportedLanguages;
    protected Map<MessageType, MF> formatters;
    protected MF defaultFormatter;
    protected int defaultHelpPerPage;
    protected Map<UUID, Locale> issuersLocale;
    private Set<String> unstableAPIs;
    private Annotations annotations;
    private CommandRouter router;
    
    public CommandManager() {
        this.rootCommands = new HashMap<String, RootCommand>();
        this.replacements = new CommandReplacements(this);
        this.conditions = new CommandConditions<I, CEC, CC>(this);
        this.defaultExceptionHandler = null;
        this.logUnhandledExceptions = true;
        this.dependencies = new Table<Class<?>, String, Object>();
        this.helpFormatter = new CommandHelpFormatter(this);
        this.usePerIssuerLocale = false;
        this.localeChangedCallbacks = new ArrayList<IssuerLocaleChangedCallback<I>>();
        this.supportedLanguages = new HashSet<Locale>(Arrays.asList(Locales.ENGLISH, Locales.GERMAN, Locales.SPANISH, Locales.FRENCH, Locales.CZECH, Locales.PORTUGUESE, Locales.SWEDISH, Locales.NORWEGIAN_BOKMAAL, Locales.NORWEGIAN_NYNORSK, Locales.RUSSIAN, Locales.BULGARIAN, Locales.HUNGARIAN));
        this.formatters = new IdentityHashMap<MessageType, MF>();
        this.defaultHelpPerPage = 10;
        this.issuersLocale = new ConcurrentHashMap<UUID, Locale>();
        this.unstableAPIs = new HashSet<String>();
        this.annotations = new Annotations((M)this);
        this.router = new CommandRouter(this);
    }
    
    public static CommandOperationContext getCurrentCommandOperationContext() {
        return CommandManager.commandOperationContext.get().peek();
    }
    
    public static CommandIssuer getCurrentCommandIssuer() {
        final CommandOperationContext<CommandIssuer> commandOperationContext = CommandManager.commandOperationContext.get().peek();
        return (commandOperationContext != null) ? commandOperationContext.getCommandIssuer() : null;
    }
    
    public static CommandManager getCurrentCommandManager() {
        final CommandOperationContext commandOperationContext = CommandManager.commandOperationContext.get().peek();
        return (commandOperationContext != null) ? commandOperationContext.getCommandManager() : null;
    }
    
    public MF setFormat(final MessageType type, final MF formatter) {
        return this.formatters.put(type, formatter);
    }
    
    public MF getFormat(final MessageType type) {
        return this.formatters.getOrDefault(type, this.defaultFormatter);
    }
    
    public void setFormat(final MessageType type, final FT... colors) {
        final MessageFormatter<FT> format = this.getFormat(type);
        for (int i = 1; i <= colors.length; ++i) {
            format.setColor(i, colors[i - 1]);
        }
    }
    
    public void setFormat(final MessageType type, final int i, final FT color) {
        this.getFormat(type).setColor(i, color);
    }
    
    public MF getDefaultFormatter() {
        return this.defaultFormatter;
    }
    
    public void setDefaultFormatter(final MF defaultFormatter) {
        this.defaultFormatter = defaultFormatter;
    }
    
    public CommandConditions<I, CEC, CC> getCommandConditions() {
        return this.conditions;
    }
    
    public abstract CommandContexts<?> getCommandContexts();
    
    public abstract CommandCompletions<?> getCommandCompletions();
    
    @Deprecated
    @UnstableAPI
    public CommandHelp generateCommandHelp(@NotNull final String command) {
        this.verifyUnstableAPI("help");
        final CommandOperationContext currentCommandOperationContext = getCurrentCommandOperationContext();
        if (currentCommandOperationContext == null) {
            throw new IllegalStateException("This method can only be called as part of a command execution.");
        }
        return this.generateCommandHelp(currentCommandOperationContext.getCommandIssuer(), command);
    }
    
    @Deprecated
    @UnstableAPI
    public CommandHelp generateCommandHelp(final CommandIssuer issuer, @NotNull final String command) {
        this.verifyUnstableAPI("help");
        return this.generateCommandHelp(issuer, this.obtainRootCommand(command));
    }
    
    @Deprecated
    @UnstableAPI
    public CommandHelp generateCommandHelp() {
        this.verifyUnstableAPI("help");
        final CommandOperationContext currentCommandOperationContext = getCurrentCommandOperationContext();
        if (currentCommandOperationContext == null) {
            throw new IllegalStateException("This method can only be called as part of a command execution.");
        }
        return this.generateCommandHelp(currentCommandOperationContext.getCommandIssuer(), this.obtainRootCommand(currentCommandOperationContext.getCommandLabel()));
    }
    
    @Deprecated
    @UnstableAPI
    public CommandHelp generateCommandHelp(final CommandIssuer issuer, final RootCommand rootCommand) {
        this.verifyUnstableAPI("help");
        return new CommandHelp(this, rootCommand, issuer);
    }
    
    @Deprecated
    @UnstableAPI
    public int getDefaultHelpPerPage() {
        this.verifyUnstableAPI("help");
        return this.defaultHelpPerPage;
    }
    
    @Deprecated
    @UnstableAPI
    public void setDefaultHelpPerPage(final int defaultHelpPerPage) {
        this.verifyUnstableAPI("help");
        this.defaultHelpPerPage = defaultHelpPerPage;
    }
    
    @Deprecated
    @UnstableAPI
    public void setHelpFormatter(final CommandHelpFormatter helpFormatter) {
        this.helpFormatter = helpFormatter;
    }
    
    @Deprecated
    @UnstableAPI
    public CommandHelpFormatter getHelpFormatter() {
        return this.helpFormatter;
    }
    
    CommandRouter getRouter() {
        return this.router;
    }
    
    public abstract void registerCommand(final BaseCommand command);
    
    public abstract boolean hasRegisteredCommands();
    
    public abstract boolean isCommandIssuer(final Class<?> type);
    
    public abstract I getCommandIssuer(final Object issuer);
    
    public abstract RootCommand createRootCommand(final String cmd);
    
    public abstract Locales getLocales();
    
    public boolean usingPerIssuerLocale() {
        return this.usePerIssuerLocale;
    }
    
    public boolean usePerIssuerLocale(final boolean setting) {
        final boolean usePerIssuerLocale = this.usePerIssuerLocale;
        this.usePerIssuerLocale = setting;
        return usePerIssuerLocale;
    }
    
    public ConditionContext createConditionContext(final CommandIssuer issuer, final String config) {
        return new ConditionContext((I)issuer, config);
    }
    
    public abstract CommandExecutionContext createCommandContext(final RegisteredCommand command, final CommandParameter parameter, final CommandIssuer sender, final List<String> args, final int i, final Map<String, Object> passedArgs);
    
    public abstract CommandCompletionContext createCompletionContext(final RegisteredCommand command, final CommandIssuer sender, final String input, final String config, final String[] args);
    
    public abstract void log(final LogLevel level, final String message, final Throwable throwable);
    
    public void log(final LogLevel level, final String message) {
        this.log(level, message, null);
    }
    
    public CommandReplacements getCommandReplacements() {
        return this.replacements;
    }
    
    public boolean hasPermission(final CommandIssuer issuer, final Set<String> permissions) {
        final Iterator<String> iterator = permissions.iterator();
        while (iterator.hasNext()) {
            if (!this.hasPermission(issuer, iterator.next())) {
                return false;
            }
        }
        return true;
    }
    
    public boolean hasPermission(final CommandIssuer issuer, final String permission) {
        if (permission == null || permission.isEmpty()) {
            return true;
        }
        for (final String permission2 : ACFPatterns.COMMA.split(permission)) {
            if (!permission2.isEmpty() && !issuer.hasPermission(permission2)) {
                return false;
            }
        }
        return true;
    }
    
    public synchronized RootCommand getRootCommand(@NotNull final String cmd) {
        return this.rootCommands.get(ACFPatterns.SPACE.split(cmd.toLowerCase(), 2)[0]);
    }
    
    public synchronized RootCommand obtainRootCommand(@NotNull final String cmd) {
        return this.rootCommands.computeIfAbsent(ACFPatterns.SPACE.split(cmd.toLowerCase(), 2)[0], this::createRootCommand);
    }
    
    public abstract Collection<RootCommand> getRegisteredRootCommands();
    
    public RegisteredCommand createRegisteredCommand(final BaseCommand command, final String cmdName, final Method method, final String prefSubCommand) {
        return new RegisteredCommand(command, cmdName, method, prefSubCommand);
    }
    
    public void setDefaultExceptionHandler(final ExceptionHandler exceptionHandler) {
        if (exceptionHandler == null && !this.logUnhandledExceptions) {
            throw new IllegalArgumentException("You may not disable the default exception handler and have logging of unhandled exceptions disabled");
        }
        this.defaultExceptionHandler = exceptionHandler;
    }
    
    public void setDefaultExceptionHandler(final ExceptionHandler exceptionHandler, final boolean logExceptions) {
        if (exceptionHandler == null && !logExceptions) {
            throw new IllegalArgumentException("You may not disable the default exception handler and have logging of unhandled exceptions disabled");
        }
        this.logUnhandledExceptions = logExceptions;
        this.defaultExceptionHandler = exceptionHandler;
    }
    
    public boolean isLoggingUnhandledExceptions() {
        return this.logUnhandledExceptions;
    }
    
    public ExceptionHandler getDefaultExceptionHandler() {
        return this.defaultExceptionHandler;
    }
    
    protected boolean handleUncaughtException(final BaseCommand scope, final RegisteredCommand registeredCommand, final CommandIssuer sender, final List<String> args, Throwable t) {
        if (t instanceof InvocationTargetException && t.getCause() != null) {
            t = t.getCause();
        }
        boolean b = false;
        if (scope.getExceptionHandler() != null) {
            b = scope.getExceptionHandler().execute(scope, registeredCommand, sender, args, t);
        }
        else if (this.defaultExceptionHandler != null) {
            b = this.defaultExceptionHandler.execute(scope, registeredCommand, sender, args, t);
        }
        return b;
    }
    
    public void sendMessage(final IT issuerArg, final MessageType type, final MessageKeyProvider key, final String... replacements) {
        this.sendMessage(this.getCommandIssuer(issuerArg), type, key, replacements);
    }
    
    public void sendMessage(final CommandIssuer issuer, final MessageType type, final MessageKeyProvider key, final String... replacements) {
        final String[] split = ACFPatterns.NEWLINE.split(this.formatMessage(issuer, type, key, replacements));
        for (int length = split.length, i = 0; i < length; ++i) {
            issuer.sendMessageInternal(ACFUtil.rtrim(split[i]));
        }
    }
    
    public String formatMessage(final CommandIssuer issuer, final MessageType type, final MessageKeyProvider key, final String... replacements) {
        String s = this.getLocales().getMessage(issuer, key.getMessageKey());
        if (replacements.length > 0) {
            s = ACFUtil.replaceStrings(s, replacements);
        }
        String message = this.getLocales().replaceI18NStrings(this.getCommandReplacements().replace(s));
        final MessageFormatter<FT> messageFormatter = this.formatters.getOrDefault(type, this.defaultFormatter);
        if (messageFormatter != null) {
            message = messageFormatter.format(message);
        }
        return message;
    }
    
    public void onLocaleChange(final IssuerLocaleChangedCallback<I> onChange) {
        this.localeChangedCallbacks.add(onChange);
    }
    
    public void notifyLocaleChange(final I issuer, final Locale oldLocale, final Locale newLocale) {
        this.localeChangedCallbacks.forEach(cb -> {
            try {
                cb.onIssuerLocaleChange(issuer, oldLocale, newLocale);
            }
            catch (Exception throwable) {
                this.log(LogLevel.ERROR, "Error in notifyLocaleChange", throwable);
            }
        });
    }
    
    public Locale setIssuerLocale(final IT issuer, final Locale locale) {
        final CommandIssuer commandIssuer = this.getCommandIssuer(issuer);
        final Locale locale2 = this.issuersLocale.put(commandIssuer.getUniqueId(), locale);
        if (!Objects.equals(locale2, locale)) {
            this.notifyLocaleChange((I)commandIssuer, locale2, locale);
        }
        return locale2;
    }
    
    public Locale getIssuerLocale(final CommandIssuer issuer) {
        if (this.usingPerIssuerLocale() && issuer != null) {
            final Locale locale = this.issuersLocale.get(issuer.getUniqueId());
            if (locale != null) {
                return locale;
            }
        }
        return this.getLocales().getDefaultLocale();
    }
    
    CommandOperationContext<I> createCommandOperationContext(final BaseCommand command, final CommandIssuer issuer, final String commandLabel, final String[] args, final boolean isAsync) {
        return new CommandOperationContext<I>(this, (I)issuer, command, commandLabel, args, isAsync);
    }
    
    public Set<Locale> getSupportedLanguages() {
        return this.supportedLanguages;
    }
    
    public void addSupportedLanguage(final Locale locale) {
        this.supportedLanguages.add(locale);
        this.getLocales().loadMissingBundles();
    }
    
    public <T> void registerDependency(final Class<? extends T> clazz, final T instance) {
        this.registerDependency(clazz, clazz.getName(), instance);
    }
    
    public <T> void registerDependency(final Class<? extends T> clazz, final String key, final T instance) {
        if (this.dependencies.containsKey(clazz, key)) {
            throw new IllegalStateException("There is already an instance of " + clazz.getName() + " with the key " + key + " registered!");
        }
        this.dependencies.put(clazz, key, instance);
    }
    
    void injectDependencies(final BaseCommand baseCommand) {
        Serializable s = baseCommand.getClass();
        do {
            for (final Field field : ((Class)s).getDeclaredFields()) {
                if (this.annotations.hasAnnotation(field, Dependency.class)) {
                    final String annotationValue;
                    final String str = (annotationValue = this.annotations.getAnnotationValue(field, Dependency.class)).isEmpty() ? field.getType().getName() : annotationValue;
                    final Object value = this.dependencies.row(field.getType()).get(str);
                    if (value == null) {
                        throw new UnresolvedDependencyException("Could not find a registered instance of " + field.getType().getName() + " with key " + str + " for field " + field.getName() + " in class " + baseCommand.getClass().getName());
                    }
                    try {
                        final boolean accessible = field.isAccessible();
                        if (!accessible) {
                            field.setAccessible(true);
                        }
                        field.set(baseCommand, value);
                        field.setAccessible(accessible);
                    }
                    catch (IllegalAccessException ex) {
                        ex.printStackTrace();
                    }
                }
            }
            s = ((Class<? extends BaseCommand>)s).getSuperclass();
        } while (!s.equals(BaseCommand.class));
    }
    
    @Deprecated
    public void enableUnstableAPI(final String api) {
        this.unstableAPIs.add(api);
    }
    
    void verifyUnstableAPI(final String api) {
        if (!this.unstableAPIs.contains(api)) {
            throw new IllegalStateException("Using an unstable API that has not been enabled ( " + api + "). See https://acfunstable.emc.gs");
        }
    }
    
    boolean hasUnstableAPI(final String api) {
        return this.unstableAPIs.contains(api);
    }
    
    Annotations getAnnotations() {
        return this.annotations;
    }
    
    public String getCommandPrefix(final CommandIssuer issuer) {
        return "";
    }
    
    static {
        CommandManager.commandOperationContext = ThreadLocal.withInitial(() -> new Stack<CommandOperationContext>() {
            @Override
            public synchronized CommandOperationContext peek() {
                return (super.size() == 0) ? null : super.peek();
            }
        });
    }
}

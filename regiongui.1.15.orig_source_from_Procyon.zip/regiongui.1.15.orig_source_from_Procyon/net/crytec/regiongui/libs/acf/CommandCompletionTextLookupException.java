// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

class CommandCompletionTextLookupException extends Throwable
{
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.regex.Pattern;
import java.util.HashSet;
import org.bukkit.entity.Entity;
import org.bukkit.inventory.PlayerInventory;
import java.util.UUID;
import org.bukkit.OfflinePlayer;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.Bukkit;
import co.aikar.locales.MessageKeyProvider;
import org.bukkit.command.BlockCommandSender;
import org.bukkit.Location;
import org.jetbrains.annotations.Nullable;
import org.bukkit.entity.Player;
import net.crytec.regiongui.libs.acf.bukkit.contexts.OnlinePlayer;

public class BukkitCommandContexts extends CommandContexts<BukkitCommandExecutionContext>
{
    public BukkitCommandContexts(final BukkitCommandManager manager) {
        // 
        // This method could not be decompiled.
        // 
        // Original Bytecode:
        // 
        //     1: aload_1        
        //     2: invokespecial   net/crytec/regiongui/libs/acf/CommandContexts.<init>:(Lnet/crytec/regiongui/libs/acf/CommandManager;)V
        //     5: aload_0        
        //     6: ldc             Lnet/crytec/regiongui/libs/acf/bukkit/contexts/OnlinePlayer;.class
        //     8: aload_0        
        //     9: invokedynamic   BootstrapMethod #0, getContext:(Lnet/crytec/regiongui/libs/acf/BukkitCommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    14: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    17: aload_0        
        //    18: ldc             Lnet/crytec/regiongui/libs/acf/contexts/OnlinePlayer;.class
        //    20: aload_0        
        //    21: invokedynamic   BootstrapMethod #1, getContext:(Lnet/crytec/regiongui/libs/acf/BukkitCommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    26: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    29: aload_0        
        //    30: ldc             [Lnet/crytec/regiongui/libs/acf/bukkit/contexts/OnlinePlayer;.class
        //    32: aload_0        
        //    33: invokedynamic   BootstrapMethod #2, getContext:(Lnet/crytec/regiongui/libs/acf/BukkitCommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    38: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    41: aload_0        
        //    42: ldc             Lorg/bukkit/World;.class
        //    44: invokedynamic   BootstrapMethod #3, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/IssuerAwareContextResolver;
        //    49: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerIssuerAwareContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/IssuerAwareContextResolver;)V
        //    52: aload_0        
        //    53: ldc             Lorg/bukkit/command/CommandSender;.class
        //    55: invokedynamic   BootstrapMethod #4, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/IssuerAwareContextResolver;
        //    60: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerIssuerAwareContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/IssuerAwareContextResolver;)V
        //    63: aload_0        
        //    64: ldc             Lorg/bukkit/entity/Player;.class
        //    66: aload_0        
        //    67: invokedynamic   BootstrapMethod #5, getContext:(Lnet/crytec/regiongui/libs/acf/BukkitCommandContexts;)Lnet/crytec/regiongui/libs/acf/contexts/IssuerAwareContextResolver;
        //    72: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerIssuerAwareContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/IssuerAwareContextResolver;)V
        //    75: aload_0        
        //    76: ldc             Lorg/bukkit/OfflinePlayer;.class
        //    78: invokedynamic   BootstrapMethod #6, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    83: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    86: aload_0        
        //    87: ldc             Lorg/bukkit/ChatColor;.class
        //    89: invokedynamic   BootstrapMethod #7, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //    94: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //    97: aload_0        
        //    98: ldc             Lorg/bukkit/Location;.class
        //   100: invokedynamic   BootstrapMethod #8, getContext:()Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;
        //   105: invokevirtual   net/crytec/regiongui/libs/acf/BukkitCommandContexts.registerContext:(Ljava/lang/Class;Lnet/crytec/regiongui/libs/acf/contexts/ContextResolver;)V
        //   108: aload_1        
        //   109: getfield        net/crytec/regiongui/libs/acf/BukkitCommandManager.mcMinorVersion:Ljava/lang/Integer;
        //   112: invokevirtual   java/lang/Integer.intValue:()I
        //   115: bipush          12
        //   117: if_icmplt       124
        //   120: aload_0        
        //   121: invokestatic    net/crytec/regiongui/libs/acf/BukkitCommandContexts_1_12.register:(Lnet/crytec/regiongui/libs/acf/BukkitCommandContexts;)V
        //   124: return         
        //    MethodParameters:
        //  Name     Flags  
        //  -------  -----
        //  manager  
        //    StackMapTable: 00 01 FF 00 7C 00 02 07 00 02 07 00 81 00 00
        // 
        // The error that occurred was:
        // 
        // java.lang.IllegalStateException: Could not infer any expression.
        //     at com.strobel.decompiler.ast.TypeAnalysis.runInference(TypeAnalysis.java:374)
        //     at com.strobel.decompiler.ast.TypeAnalysis.run(TypeAnalysis.java:96)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:344)
        //     at com.strobel.decompiler.ast.AstOptimizer.optimize(AstOptimizer.java:42)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:214)
        //     at com.strobel.decompiler.languages.java.ast.AstMethodBodyBuilder.createMethodBody(AstMethodBodyBuilder.java:99)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createMethodBody(AstBuilder.java:782)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createConstructor(AstBuilder.java:713)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addTypeMembers(AstBuilder.java:549)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeCore(AstBuilder.java:519)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createTypeNoCache(AstBuilder.java:161)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.createType(AstBuilder.java:150)
        //     at com.strobel.decompiler.languages.java.ast.AstBuilder.addType(AstBuilder.java:125)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.buildAst(JavaLanguage.java:71)
        //     at com.strobel.decompiler.languages.java.JavaLanguage.decompileType(JavaLanguage.java:59)
        //     at com.strobel.decompiler.DecompilerDriver.decompileType(DecompilerDriver.java:330)
        //     at com.strobel.decompiler.DecompilerDriver.decompileJar(DecompilerDriver.java:251)
        //     at com.strobel.decompiler.DecompilerDriver.main(DecompilerDriver.java:126)
        // 
        throw new IllegalStateException("An error occurred while decompiling this method.");
    }
    
    @Nullable
    OnlinePlayer getOnlinePlayer(final BukkitCommandIssuer issuer, final String lookup, final boolean allowMissing) {
        final Player playerSmart = ACFBukkitUtil.findPlayerSmart(issuer, lookup);
        if (playerSmart != null) {
            return new OnlinePlayer(playerSmart);
        }
        if (allowMissing) {
            return null;
        }
        throw new InvalidCommandArgument(false);
    }
}

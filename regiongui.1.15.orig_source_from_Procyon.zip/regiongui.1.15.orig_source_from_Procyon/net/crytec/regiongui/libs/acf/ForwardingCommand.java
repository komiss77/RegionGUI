// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Set;
import java.util.Collections;
import java.util.List;

public class ForwardingCommand extends BaseCommand
{
    private final BaseCommand command;
    private final String[] baseArgs;
    private final RegisteredCommand regCommand;
    
    ForwardingCommand(final BaseCommand baseCommand, final RegisteredCommand regCommand, final String[] baseArgs) {
        this.regCommand = regCommand;
        this.commandName = baseCommand.commandName;
        this.command = baseCommand;
        this.baseArgs = baseArgs;
        this.manager = baseCommand.manager;
        this.subCommands.put((Object)"__default", (Object)regCommand);
    }
    
    @Override
    public List<RegisteredCommand> getRegisteredCommands() {
        return (List<RegisteredCommand>)Collections.singletonList(this.regCommand);
    }
    
    @Override
    public CommandOperationContext getLastCommandOperationContext() {
        return this.command.getLastCommandOperationContext();
    }
    
    @Override
    public Set<String> getRequiredPermissions() {
        return this.command.getRequiredPermissions();
    }
    
    @Override
    public boolean hasPermission(final Object issuer) {
        return this.command.hasPermission(issuer);
    }
    
    @Override
    public boolean requiresPermission(final String permission) {
        return this.command.requiresPermission(permission);
    }
    
    @Override
    public boolean hasPermission(final CommandIssuer sender) {
        return this.command.hasPermission(sender);
    }
    
    public List<String> tabComplete(final CommandIssuer issuer, final RootCommand rootCommand, final String[] args, final boolean isAsync) {
        return this.command.tabComplete(issuer, rootCommand, args, isAsync);
    }
    
    public void execute(final CommandIssuer issuer, CommandRouter.CommandRouteResult result) {
        result = new CommandRouter.CommandRouteResult(this.regCommand, result.args, ACFUtil.join(this.baseArgs), result.commandLabel);
        this.command.execute(issuer, result);
    }
    
    BaseCommand getCommand() {
        return this.command;
    }
}

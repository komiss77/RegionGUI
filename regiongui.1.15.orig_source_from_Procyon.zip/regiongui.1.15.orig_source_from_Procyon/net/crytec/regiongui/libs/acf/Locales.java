// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.regex.Matcher;
import java.util.LinkedHashMap;
import co.aikar.locales.MessageKeyProvider;
import co.aikar.locales.MessageKey;
import org.jetbrains.annotations.NotNull;
import com.google.common.collect.HashMultimap;
import java.util.Iterator;
import java.util.Collection;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.google.common.collect.SetMultimap;
import java.util.Map;
import co.aikar.locales.LocaleManager;
import java.util.Locale;

public class Locales
{
    public static final Locale ENGLISH;
    public static final Locale GERMAN;
    public static final Locale FRENCH;
    public static final Locale JAPANESE;
    public static final Locale ITALIAN;
    public static final Locale KOREAN;
    public static final Locale CHINESE;
    public static final Locale SIMPLIFIED_CHINESE;
    public static final Locale TRADITIONAL_CHINESE;
    public static final Locale SPANISH;
    public static final Locale DUTCH;
    public static final Locale DANISH;
    public static final Locale CZECH;
    public static final Locale GREEK;
    public static final Locale LATIN;
    public static final Locale BULGARIAN;
    public static final Locale AFRIKAANS;
    public static final Locale HINDI;
    public static final Locale HEBREW;
    public static final Locale POLISH;
    public static final Locale PORTUGUESE;
    public static final Locale FINNISH;
    public static final Locale SWEDISH;
    public static final Locale RUSSIAN;
    public static final Locale ROMANIAN;
    public static final Locale VIETNAMESE;
    public static final Locale THAI;
    public static final Locale TURKISH;
    public static final Locale UKRANIAN;
    public static final Locale ARABIC;
    public static final Locale WELSH;
    public static final Locale NORWEGIAN_BOKMAAL;
    public static final Locale NORWEGIAN_NYNORSK;
    public static final Locale HUNGARIAN;
    private final CommandManager manager;
    private final LocaleManager<CommandIssuer> localeManager;
    private final Map<ClassLoader, SetMultimap<String, Locale>> loadedBundles;
    private final List<ClassLoader> registeredClassLoaders;
    
    public Locales(final CommandManager manager) {
        this.loadedBundles = new HashMap<ClassLoader, SetMultimap<String, Locale>>();
        this.registeredClassLoaders = new ArrayList<ClassLoader>();
        this.manager = manager;
        this.localeManager = LocaleManager.create(manager::getIssuerLocale);
        this.addBundleClassLoader(this.getClass().getClassLoader());
    }
    
    public void loadLanguages() {
        this.addMessageBundles("acf-core");
    }
    
    public Locale getDefaultLocale() {
        return this.localeManager.getDefaultLocale();
    }
    
    public Locale setDefaultLocale(final Locale locale) {
        return this.localeManager.setDefaultLocale(locale);
    }
    
    public void loadMissingBundles() {
        for (final Locale locale : this.manager.getSupportedLanguages()) {
            final Iterator<SetMultimap<String, Locale>> iterator2 = this.loadedBundles.values().iterator();
            while (iterator2.hasNext()) {
                final Iterator<String> iterator3 = new HashSet<String>((Collection<? extends String>)iterator2.next().keys()).iterator();
                while (iterator3.hasNext()) {
                    this.addMessageBundle(iterator3.next(), locale);
                }
            }
        }
    }
    
    public void addMessageBundles(final String... bundleNames) {
        for (final String bundleName : bundleNames) {
            final Iterator iterator = this.manager.getSupportedLanguages().iterator();
            while (iterator.hasNext()) {
                this.addMessageBundle(bundleName, iterator.next());
            }
        }
    }
    
    public boolean addMessageBundle(final String bundleName, final Locale locale) {
        boolean b = false;
        final Iterator<ClassLoader> iterator = this.registeredClassLoaders.iterator();
        while (iterator.hasNext()) {
            if (this.addMessageBundle(iterator.next(), bundleName, locale)) {
                b = true;
            }
        }
        return b;
    }
    
    public boolean addMessageBundle(final ClassLoader classLoader, final String bundleName, final Locale locale) {
        final SetMultimap<String, Locale> setMultimap = this.loadedBundles.getOrDefault(classLoader, (SetMultimap<String, Locale>)HashMultimap.create());
        if (!setMultimap.containsEntry((Object)bundleName, (Object)locale) && this.localeManager.addMessageBundle(classLoader, bundleName, locale)) {
            setMultimap.put((Object)bundleName, (Object)locale);
            this.loadedBundles.put(classLoader, setMultimap);
            return true;
        }
        return false;
    }
    
    public void addMessageStrings(final Locale locale, @NotNull final Map<String, String> messages) {
        final HashMap messages2 = new HashMap(messages.size());
        final String s;
        messages.forEach((key, value) -> s = messages2.put(MessageKey.of(key), value));
        this.localeManager.addMessages(locale, messages2);
    }
    
    public void addMessages(final Locale locale, @NotNull final Map<? extends MessageKeyProvider, String> messages) {
        final LinkedHashMap<MessageKey, String> messages2 = new LinkedHashMap<MessageKey, String>();
        for (final Map.Entry<? extends MessageKeyProvider, String> entry : messages.entrySet()) {
            messages2.put(((MessageKeyProvider)entry.getKey()).getMessageKey(), (V)entry.getValue());
        }
        this.localeManager.addMessages(locale, messages2);
    }
    
    public String addMessage(final Locale locale, final MessageKeyProvider key, final String message) {
        return this.localeManager.addMessage(locale, key.getMessageKey(), message);
    }
    
    public String getMessage(final CommandIssuer issuer, final MessageKeyProvider key) {
        final MessageKey messageKey = key.getMessageKey();
        String s = this.localeManager.getMessage(issuer, messageKey);
        if (s == null) {
            this.manager.log(LogLevel.ERROR, "Missing Language Key: " + messageKey.getKey());
            s = "<MISSING_LANGUAGE_KEY:" + messageKey.getKey() + ">";
        }
        return s;
    }
    
    public String replaceI18NStrings(final String message) {
        if (message == null) {
            return null;
        }
        final Matcher matcher = ACFPatterns.I18N_STRING.matcher(message);
        if (!matcher.find()) {
            return message;
        }
        final CommandIssuer currentCommandIssuer = CommandManager.getCurrentCommandIssuer();
        matcher.reset();
        final StringBuffer sb = new StringBuffer(message.length());
        while (matcher.find()) {
            matcher.appendReplacement(sb, Matcher.quoteReplacement(this.getMessage(currentCommandIssuer, MessageKey.of(matcher.group("key")))));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }
    
    public boolean addBundleClassLoader(final ClassLoader classLoader) {
        return !this.registeredClassLoaders.contains(classLoader) && this.registeredClassLoaders.add(classLoader);
    }
    
    static {
        ENGLISH = Locale.ENGLISH;
        GERMAN = Locale.GERMAN;
        FRENCH = Locale.FRENCH;
        JAPANESE = Locale.JAPANESE;
        ITALIAN = Locale.ITALIAN;
        KOREAN = Locale.KOREAN;
        CHINESE = Locale.CHINESE;
        SIMPLIFIED_CHINESE = Locale.SIMPLIFIED_CHINESE;
        TRADITIONAL_CHINESE = Locale.TRADITIONAL_CHINESE;
        SPANISH = new Locale("es");
        DUTCH = new Locale("nl");
        DANISH = new Locale("da");
        CZECH = new Locale("cs");
        GREEK = new Locale("el");
        LATIN = new Locale("la");
        BULGARIAN = new Locale("bg");
        AFRIKAANS = new Locale("af");
        HINDI = new Locale("hi");
        HEBREW = new Locale("he");
        POLISH = new Locale("pl");
        PORTUGUESE = new Locale("pt");
        FINNISH = new Locale("fi");
        SWEDISH = new Locale("sv");
        RUSSIAN = new Locale("ru");
        ROMANIAN = new Locale("ro");
        VIETNAMESE = new Locale("vi");
        THAI = new Locale("th");
        TURKISH = new Locale("tr");
        UKRANIAN = new Locale("uk");
        ARABIC = new Locale("ar");
        WELSH = new Locale("cy");
        NORWEGIAN_BOKMAAL = new Locale("nb");
        NORWEGIAN_NYNORSK = new Locale("nn");
        HUNGARIAN = new Locale("hu");
    }
}

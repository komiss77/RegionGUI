// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import java.util.Iterator;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.function.Function;
import org.bukkit.OfflinePlayer;
import java.util.List;
import java.util.ArrayList;
import co.aikar.locales.MessageKeyProvider;
import java.util.regex.Pattern;
import java.util.Set;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.bukkit.entity.Entity;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.ChatColor;
import org.bukkit.Location;

public class ACFBukkitUtil
{
    public static String formatLocation(final Location loc) {
        if (loc == null) {
            return null;
        }
        return loc.getWorld().getName() + ":" + loc.getBlockX() + "," + loc.getBlockY() + "," + loc.getBlockZ();
    }
    
    public static String color(final String message) {
        return ChatColor.translateAlternateColorCodes('&', message);
    }
    
    @Deprecated
    public static void sendMsg(final CommandSender player, String message) {
        message = color(message);
        final String[] split = ACFPatterns.NEWLINE.split(message);
        for (int length = split.length, i = 0; i < length; ++i) {
            player.sendMessage(split[i]);
        }
    }
    
    public static Location stringToLocation(final String storedLoc) {
        return stringToLocation(storedLoc, null);
    }
    
    public static Location stringToLocation(final String storedLoc, final World forcedWorld) {
        if (storedLoc == null) {
            return null;
        }
        final String[] split = ACFPatterns.COLON.split(storedLoc);
        if (split.length >= 4 || (split.length == 3 && forcedWorld != null)) {
            final String s = (forcedWorld != null) ? forcedWorld.getName() : split[0];
            final int n = (split.length != 3) ? 1 : 0;
            final Location location = new Location(Bukkit.getWorld(s), Double.parseDouble(split[n]), Double.parseDouble(split[n + 1]), Double.parseDouble(split[n + 2]));
            if (split.length >= 6) {
                location.setPitch(Float.parseFloat(split[4]));
                location.setYaw(Float.parseFloat(split[5]));
            }
            return location;
        }
        if (split.length == 2) {
            final String[] split2 = ACFPatterns.COMMA.split(split[1]);
            if (split2.length == 3) {
                return new Location(Bukkit.getWorld((forcedWorld != null) ? forcedWorld.getName() : split[0]), Double.parseDouble(split2[0]), Double.parseDouble(split2[1]), Double.parseDouble(split2[2]));
            }
        }
        return null;
    }
    
    public static String fullLocationToString(final Location loc) {
        if (loc == null) {
            return null;
        }
        return new StringBuilder(64).append(loc.getWorld().getName()).append(':').append(ACFUtil.precision(loc.getX(), 4)).append(':').append(ACFUtil.precision(loc.getY(), 4)).append(':').append(ACFUtil.precision(loc.getZ(), 4)).append(':').append(ACFUtil.precision(loc.getPitch(), 4)).append(':').append(ACFUtil.precision(loc.getYaw(), 4)).toString();
    }
    
    public static String fullBlockLocationToString(final Location loc) {
        if (loc == null) {
            return null;
        }
        return new StringBuilder(64).append(loc.getWorld().getName()).append(':').append(loc.getBlockX()).append(':').append(loc.getBlockY()).append(':').append(loc.getBlockZ()).append(':').append(ACFUtil.precision(loc.getPitch(), 4)).append(':').append(ACFUtil.precision(loc.getYaw(), 4)).toString();
    }
    
    public static String blockLocationToString(final Location loc) {
        if (loc == null) {
            return null;
        }
        return new StringBuilder(32).append(loc.getWorld().getName()).append(':').append(loc.getBlockX()).append(':').append(loc.getBlockY()).append(':').append(loc.getBlockZ()).toString();
    }
    
    public static double distance(@NotNull final Entity e1, @NotNull final Entity e2) {
        return distance(e1.getLocation(), e2.getLocation());
    }
    
    public static double distance2d(@NotNull final Entity e1, @NotNull final Entity e2) {
        return distance2d(e1.getLocation(), e2.getLocation());
    }
    
    public static double distance2d(@NotNull Location loc1, @NotNull final Location loc2) {
        loc1 = loc1.clone();
        loc1.setY(loc2.getY());
        return distance(loc1, loc2);
    }
    
    public static double distance(@NotNull final Location loc1, @NotNull final Location loc2) {
        if (loc1.getWorld() != loc2.getWorld()) {
            return 0.0;
        }
        return loc1.distance(loc2);
    }
    
    public static Location getTargetLoc(final Player player) {
        return getTargetLoc(player, 128);
    }
    
    public static Location getTargetLoc(final Player player, final int maxDist) {
        return getTargetLoc(player, maxDist, 1.5);
    }
    
    public static Location getTargetLoc(final Player player, final int maxDist, final double addY) {
        try {
            final Location location = player.getTargetBlock((Set)null, maxDist).getLocation();
            location.setY(location.getY() + addY);
            return location;
        }
        catch (Exception ex) {
            return null;
        }
    }
    
    public static Location getRandLoc(final Location loc, final int radius) {
        return getRandLoc(loc, radius, radius, radius);
    }
    
    public static Location getRandLoc(final Location loc, final int xzRadius, final int yRadius) {
        return getRandLoc(loc, xzRadius, yRadius, xzRadius);
    }
    
    @NotNull
    public static Location getRandLoc(final Location loc, final int xRadius, final int yRadius, final int zRadius) {
        final Location clone = loc.clone();
        clone.setX(ACFUtil.rand(loc.getX() - xRadius, loc.getX() + xRadius));
        clone.setY(ACFUtil.rand(loc.getY() - yRadius, loc.getY() + yRadius));
        clone.setZ(ACFUtil.rand(loc.getZ() - zRadius, loc.getZ() + zRadius));
        return clone;
    }
    
    public static String removeColors(final String msg) {
        return ChatColor.stripColor(color(msg));
    }
    
    public static String replaceChatString(final String message, final String replace, final String with) {
        return replaceChatString(message, Pattern.compile(Pattern.quote(replace), 2), with);
    }
    
    public static String replaceChatString(String message, final Pattern replace, final String with) {
        final String[] split = replace.split(message + "1");
        if (split.length < 2) {
            return replace.matcher(message).replaceAll(with);
        }
        message = split[0];
        for (int i = 1; i < split.length; ++i) {
            message = message + with + ChatColor.getLastColors(message) + split[i];
        }
        return message.substring(0, message.length() - 1);
    }
    
    public static boolean isWithinDistance(@NotNull final Player p1, @NotNull final Player p2, final int dist) {
        return isWithinDistance(p1.getLocation(), p2.getLocation(), dist);
    }
    
    public static boolean isWithinDistance(@NotNull final Location loc1, @NotNull final Location loc2, final int dist) {
        return loc1.getWorld() == loc2.getWorld() && loc1.distance(loc2) <= dist;
    }
    
    @Deprecated
    public static Player findPlayerSmart(final CommandSender requester, final String search) {
        final CommandManager<Object, CommandIssuer, Object, MessageFormatter, CommandExecutionContext, ConditionContext> currentCommandManager = CommandManager.getCurrentCommandManager();
        if (currentCommandManager != null) {
            return findPlayerSmart(currentCommandManager.getCommandIssuer(requester), search);
        }
        throw new IllegalStateException("You may not use the ACFBukkitUtil#findPlayerSmart(CommandSender) async to the command execution.");
    }
    
    public static Player findPlayerSmart(final CommandIssuer issuer, final String search) {
        final CommandSender requester = issuer.getIssuer();
        if (search == null) {
            return null;
        }
        final String replace = ACFUtil.replace(search, ":confirm", "");
        if (!isValidName(replace)) {
            issuer.sendError(MinecraftMessageKeys.IS_NOT_A_VALID_NAME, "{name}", replace);
            return null;
        }
        final List matchPlayer = Bukkit.getServer().matchPlayer(replace);
        final ArrayList<Player> list = new ArrayList<Player>();
        findMatches(search, requester, matchPlayer, list);
        if (matchPlayer.size() > 1 || list.size() > 1) {
            issuer.sendError(MinecraftMessageKeys.MULTIPLE_PLAYERS_MATCH, "{search}", replace, "{all}", matchPlayer.stream().map((Function<? super Object, ?>)OfflinePlayer::getName).collect((Collector<? super Object, ?, String>)Collectors.joining(", ")));
            return null;
        }
        if (!matchPlayer.isEmpty()) {
            return matchPlayer.get(0);
        }
        final Player player = ACFUtil.getFirstElement(list);
        if (player == null) {
            issuer.sendError(MinecraftMessageKeys.NO_PLAYER_FOUND_SERVER, "{search}", replace);
            return null;
        }
        issuer.sendInfo(MinecraftMessageKeys.PLAYER_IS_VANISHED_CONFIRM, "{vanished}", player.getName());
        return null;
    }
    
    private static void findMatches(final String search, final CommandSender requester, final List<Player> matches, final List<Player> confirmList) {
        final Iterator<Player> iterator = matches.iterator();
        while (iterator.hasNext()) {
            final Player player = iterator.next();
            if (requester instanceof Player && !((Player)requester).canSee(player)) {
                if (requester.hasPermission("acf.seevanish")) {
                    if (search.endsWith(":confirm")) {
                        continue;
                    }
                    confirmList.add(player);
                    iterator.remove();
                }
                else {
                    iterator.remove();
                }
            }
        }
    }
    
    public static boolean isValidName(final String name) {
        return name != null && !name.isEmpty() && ACFPatterns.VALID_NAME_PATTERN.matcher(name).matches();
    }
    
    static boolean isValidItem(final ItemStack item) {
        return item != null && item.getType() != Material.AIR && item.getAmount() > 0;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.lang.reflect.AnnotatedElement;
import java.lang.annotation.Annotation;
import java.util.List;

public class CommandOperationContext<I extends CommandIssuer>
{
    private final CommandManager manager;
    private final I issuer;
    private final BaseCommand command;
    private final String commandLabel;
    private final String[] args;
    private final boolean isAsync;
    private RegisteredCommand registeredCommand;
    List<String> enumCompletionValues;
    
    CommandOperationContext(final CommandManager manager, final I issuer, final BaseCommand command, final String commandLabel, final String[] args, final boolean isAsync) {
        this.manager = manager;
        this.issuer = issuer;
        this.command = command;
        this.commandLabel = commandLabel;
        this.args = args;
        this.isAsync = isAsync;
    }
    
    public CommandManager getCommandManager() {
        return this.manager;
    }
    
    public I getCommandIssuer() {
        return this.issuer;
    }
    
    public BaseCommand getCommand() {
        return this.command;
    }
    
    public String getCommandLabel() {
        return this.commandLabel;
    }
    
    public String[] getArgs() {
        return this.args;
    }
    
    public boolean isAsync() {
        return this.isAsync;
    }
    
    public void setRegisteredCommand(final RegisteredCommand registeredCommand) {
        this.registeredCommand = registeredCommand;
    }
    
    public RegisteredCommand getRegisteredCommand() {
        return this.registeredCommand;
    }
    
    @Deprecated
    public <T extends Annotation> T getAnnotation(final Class<T> anno) {
        return this.registeredCommand.method.getAnnotation(anno);
    }
    
    public <T extends Annotation> String getAnnotationValue(final Class<T> cls) {
        return this.manager.getAnnotations().getAnnotationValue(this.registeredCommand.method, cls);
    }
    
    public <T extends Annotation> String getAnnotationValue(final Class<T> cls, final int options) {
        return this.manager.getAnnotations().getAnnotationValue(this.registeredCommand.method, cls, options);
    }
    
    public boolean hasAnnotation(final Class<? extends Annotation> anno) {
        return this.getAnnotation(anno) != null;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.NamespacedKey;

class BukkitCommandContexts_1_12
{
    static void register(final BukkitCommandContexts contexts) {
        final String[] array;
        final String s;
        contexts.registerContext(NamespacedKey.class, c -> {
            ACFPatterns.COLON.split(c.popFirstArg(), 2);
            if (array.length == 1) {
                c.getFlagValue("namespace", (String)null);
                if (s == null) {
                    return NamespacedKey.minecraft(array[0]);
                }
                else {
                    return new NamespacedKey(s, array[0]);
                }
            }
            else {
                return new NamespacedKey(array[0], array[1]);
            }
        });
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

public class UnresolvedDependencyException extends RuntimeException
{
    UnresolvedDependencyException(final String message) {
        super(message);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.bukkit.command.CommandSender;
import java.util.Locale;
import org.bukkit.command.Command;
import java.util.List;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandMap;
import org.bukkit.command.SimpleCommandMap;

class ProxyCommandMap extends SimpleCommandMap
{
    private BukkitCommandManager manager;
    CommandMap proxied;
    
    ProxyCommandMap(final BukkitCommandManager manager, final CommandMap proxied) {
        super(Bukkit.getServer());
        this.manager = manager;
        this.proxied = proxied;
    }
    
    public void registerAll(final String fallbackPrefix, final List<Command> commands) {
        this.proxied.registerAll(fallbackPrefix, (List)commands);
    }
    
    public boolean register(final String label, final String fallbackPrefix, final Command command) {
        if (this.isOurCommand(command)) {
            return super.register(label, fallbackPrefix, command);
        }
        return this.proxied.register(label, fallbackPrefix, command);
    }
    
    boolean isOurCommand(final String cmdLine) {
        final String[] split = ACFPatterns.SPACE.split(cmdLine);
        return split.length != 0 && this.isOurCommand((Command)this.knownCommands.get(split[0].toLowerCase(Locale.ENGLISH)));
    }
    
    boolean isOurCommand(final Command command) {
        return command instanceof RootCommand && ((RootCommand)command).getManager() == this.manager;
    }
    
    public boolean register(final String fallbackPrefix, final Command command) {
        if (this.isOurCommand(command)) {
            return super.register(fallbackPrefix, command);
        }
        return this.proxied.register(fallbackPrefix, command);
    }
    
    public boolean dispatch(final CommandSender sender, final String cmdLine) {
        if (this.isOurCommand(cmdLine)) {
            return super.dispatch(sender, cmdLine);
        }
        return this.proxied.dispatch(sender, cmdLine);
    }
    
    public void clearCommands() {
        super.clearCommands();
        this.proxied.clearCommands();
    }
    
    public Command getCommand(final String name) {
        if (this.isOurCommand(name)) {
            return super.getCommand(name);
        }
        return this.proxied.getCommand(name);
    }
    
    public List<String> tabComplete(final CommandSender sender, final String cmdLine) {
        if (this.isOurCommand(cmdLine)) {
            return (List<String>)super.tabComplete(sender, cmdLine);
        }
        return (List<String>)this.proxied.tabComplete(sender, cmdLine);
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import net.jodah.expiringmap.ExpirationPolicy;
import java.util.concurrent.TimeUnit;
import net.jodah.expiringmap.ExpiringMap;
import java.util.Map;
import java.util.regex.Pattern;

final class ACFPatterns
{
    public static final Pattern COMMA;
    public static final Pattern PERCENTAGE;
    public static final Pattern NEWLINE;
    public static final Pattern DASH;
    public static final Pattern UNDERSCORE;
    public static final Pattern SPACE;
    public static final Pattern SEMICOLON;
    public static final Pattern COLON;
    public static final Pattern COLONEQUALS;
    public static final Pattern PIPE;
    public static final Pattern NON_ALPHA_NUMERIC;
    public static final Pattern INTEGER;
    public static final Pattern VALID_NAME_PATTERN;
    public static final Pattern NON_PRINTABLE_CHARACTERS;
    public static final Pattern EQUALS;
    public static final Pattern FORMATTER;
    public static final Pattern I18N_STRING;
    static final Map<String, Pattern> patternCache;
    
    private ACFPatterns() {
    }
    
    public static Pattern getPattern(final String pattern) {
        return ACFPatterns.patternCache.computeIfAbsent(pattern, s -> Pattern.compile(pattern));
    }
    
    static {
        COMMA = Pattern.compile(",");
        PERCENTAGE = Pattern.compile("%", 16);
        NEWLINE = Pattern.compile("\n");
        DASH = Pattern.compile("-");
        UNDERSCORE = Pattern.compile("_");
        SPACE = Pattern.compile(" ");
        SEMICOLON = Pattern.compile(";");
        COLON = Pattern.compile(":");
        COLONEQUALS = Pattern.compile("([:=])");
        PIPE = Pattern.compile("\\|");
        NON_ALPHA_NUMERIC = Pattern.compile("[^a-zA-Z0-9]");
        INTEGER = Pattern.compile("^[0-9]+$");
        VALID_NAME_PATTERN = Pattern.compile("^[a-zA-Z0-9_$]{1,16}$");
        NON_PRINTABLE_CHARACTERS = Pattern.compile("[^\\x20-\\x7F]");
        EQUALS = Pattern.compile("=");
        FORMATTER = Pattern.compile("<c(?<color>\\d+)>(?<msg>.*?)</c\\1>", 2);
        I18N_STRING = Pattern.compile("\\{@@(?<key>.+?)}", 2);
        patternCache = ExpiringMap.builder().maxSize(200).expiration(1L, TimeUnit.HOURS).expirationPolicy(ExpirationPolicy.ACCESSED).build();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import net.crytec.regiongui.libs.acf.contexts.OptionalContextResolver;
import net.crytec.regiongui.libs.acf.contexts.IssuerAwareContextResolver;
import java.util.Collection;
import java.util.Arrays;
import net.crytec.regiongui.libs.acf.annotation.Flags;
import java.util.HashMap;
import net.crytec.regiongui.libs.acf.annotation.Syntax;
import net.crytec.regiongui.libs.acf.annotation.Values;
import net.crytec.regiongui.libs.acf.annotation.Single;
import net.crytec.regiongui.libs.acf.contexts.IssuerOnlyContextResolver;
import net.crytec.regiongui.libs.acf.annotation.CommandPermission;
import net.crytec.regiongui.libs.acf.annotation.Optional;
import net.crytec.regiongui.libs.acf.annotation.Conditions;
import net.crytec.regiongui.libs.acf.annotation.Description;
import java.lang.reflect.AnnotatedElement;
import net.crytec.regiongui.libs.acf.annotation.Default;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.crytec.regiongui.libs.acf.contexts.ContextResolver;
import java.lang.reflect.Parameter;

public class CommandParameter<CEC extends CommandExecutionContext<CEC, ? extends CommandIssuer>>
{
    private final Parameter parameter;
    private final Class<?> type;
    private final String name;
    private final CommandManager manager;
    private final int paramIndex;
    private ContextResolver<?, CEC> resolver;
    private boolean optional;
    private Set<String> permissions;
    private String permission;
    private String description;
    private String defaultValue;
    private String syntax;
    private String conditions;
    private boolean requiresInput;
    private boolean commandIssuer;
    private String[] values;
    private Map<String, String> flags;
    private boolean canConsumeInput;
    private boolean optionalResolver;
    boolean consumesRest;
    
    public CommandParameter(final RegisteredCommand<CEC> command, final Parameter param, final int paramIndex, final boolean isLast) {
        this.permissions = new HashSet<String>();
        this.parameter = param;
        this.type = param.getType();
        this.name = param.getName();
        this.manager = command.manager;
        this.paramIndex = paramIndex;
        final Annotations annotations = this.manager.getAnnotations();
        this.defaultValue = annotations.getAnnotationValue(param, Default.class, 0x1 | ((this.type != String.class) ? 8 : 0));
        this.description = annotations.getAnnotationValue(param, Description.class, 17);
        this.conditions = annotations.getAnnotationValue(param, Conditions.class, 9);
        this.resolver = (ContextResolver<?, CEC>)this.manager.getCommandContexts().getResolver(this.type);
        if (this.resolver == null) {
            ACFUtil.sneaky(new InvalidCommandContextException("Parameter " + this.type.getSimpleName() + " of " + command + " has no applicable context resolver"));
        }
        this.optional = (annotations.hasAnnotation(param, Optional.class) || this.defaultValue != null || (isLast && this.type == String[].class));
        this.permission = annotations.getAnnotationValue(param, CommandPermission.class, 9);
        this.optionalResolver = this.isOptionalResolver(this.resolver);
        this.requiresInput = (!this.optional && !this.optionalResolver);
        this.commandIssuer = (paramIndex == 0 && this.manager.isCommandIssuer(this.type));
        this.canConsumeInput = (!this.commandIssuer && !(this.resolver instanceof IssuerOnlyContextResolver));
        this.consumesRest = ((this.type == String.class && !annotations.hasAnnotation(param, Single.class)) || (isLast && this.type == String[].class));
        this.values = annotations.getAnnotationValues(param, Values.class, 9);
        this.syntax = null;
        if (!this.commandIssuer) {
            this.syntax = annotations.getAnnotationValue(param, Syntax.class);
            if (this.syntax == null) {
                if (!this.requiresInput && this.canConsumeInput) {
                    this.syntax = "[" + this.name + "]";
                }
                else if (this.requiresInput) {
                    this.syntax = "<" + this.name + ">";
                }
            }
        }
        this.flags = new HashMap<String, String>();
        final String annotationValue = annotations.getAnnotationValue(param, Flags.class, 9);
        if (annotationValue != null) {
            this.parseFlags(annotationValue);
        }
        this.inheritContextFlags(command.scope);
        this.computePermissions();
    }
    
    private void inheritContextFlags(final BaseCommand scope) {
        if (!scope.contextFlags.isEmpty()) {
            Class<?> clazz = this.type;
            do {
                this.parseFlags(scope.contextFlags.get(clazz));
            } while ((clazz = clazz.getSuperclass()) != null);
        }
        if (scope.parentCommand != null) {
            this.inheritContextFlags(scope.parentCommand);
        }
    }
    
    private void parseFlags(final String flags) {
        if (flags != null) {
            final String[] split = ACFPatterns.COMMA.split(this.manager.getCommandReplacements().replace(flags));
            for (int length = split.length, i = 0; i < length; ++i) {
                final String[] split2 = ACFPatterns.EQUALS.split(split[i], 2);
                if (!this.flags.containsKey(split2[0])) {
                    this.flags.put(split2[0], (split2.length > 1) ? split2[1] : null);
                }
            }
        }
    }
    
    private void computePermissions() {
        this.permissions.clear();
        if (this.permission != null && !this.permission.isEmpty()) {
            this.permissions.addAll(Arrays.asList(ACFPatterns.COMMA.split(this.permission)));
        }
    }
    
    private boolean isOptionalResolver(final ContextResolver<?, CEC> resolver) {
        return resolver instanceof IssuerAwareContextResolver || resolver instanceof IssuerOnlyContextResolver || resolver instanceof OptionalContextResolver;
    }
    
    public Parameter getParameter() {
        return this.parameter;
    }
    
    public Class<?> getType() {
        return this.type;
    }
    
    public String getName() {
        return this.name;
    }
    
    public CommandManager getManager() {
        return this.manager;
    }
    
    public int getParamIndex() {
        return this.paramIndex;
    }
    
    public ContextResolver<?, CEC> getResolver() {
        return this.resolver;
    }
    
    public void setResolver(final ContextResolver<?, CEC> resolver) {
        this.resolver = resolver;
    }
    
    public boolean isOptional() {
        return this.optional;
    }
    
    public void setOptional(final boolean optional) {
        this.optional = optional;
    }
    
    public String getDescription() {
        return this.description;
    }
    
    public void setDescription(final String description) {
        this.description = description;
    }
    
    public String getDefaultValue() {
        return this.defaultValue;
    }
    
    public void setDefaultValue(final String defaultValue) {
        this.defaultValue = defaultValue;
    }
    
    public boolean isCommandIssuer() {
        return this.commandIssuer;
    }
    
    public void setCommandIssuer(final boolean commandIssuer) {
        this.commandIssuer = commandIssuer;
    }
    
    public String[] getValues() {
        return this.values;
    }
    
    public void setValues(final String[] values) {
        this.values = values;
    }
    
    public Map<String, String> getFlags() {
        return this.flags;
    }
    
    public void setFlags(final Map<String, String> flags) {
        this.flags = flags;
    }
    
    public boolean canConsumeInput() {
        return this.canConsumeInput;
    }
    
    public void setCanConsumeInput(final boolean canConsumeInput) {
        this.canConsumeInput = canConsumeInput;
    }
    
    public void setOptionalResolver(final boolean optionalResolver) {
        this.optionalResolver = optionalResolver;
    }
    
    public boolean isOptionalResolver() {
        return this.optionalResolver;
    }
    
    public boolean requiresInput() {
        return this.requiresInput;
    }
    
    public void setRequiresInput(final boolean requiresInput) {
        this.requiresInput = requiresInput;
    }
    
    public String getSyntax() {
        return this.syntax;
    }
    
    public void setSyntax(final String syntax) {
        this.syntax = syntax;
    }
    
    public String getConditions() {
        return this.conditions;
    }
    
    public void setConditions(final String conditions) {
        this.conditions = conditions;
    }
    
    public Set<String> getRequiredPermissions() {
        return this.permissions;
    }
}

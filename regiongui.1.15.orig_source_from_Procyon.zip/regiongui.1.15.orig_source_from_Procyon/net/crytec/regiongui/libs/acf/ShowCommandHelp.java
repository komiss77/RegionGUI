// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

public class ShowCommandHelp extends InvalidCommandArgument
{
    List<String> searchArgs;
    boolean search;
    
    ShowCommandHelp() {
        this.searchArgs = null;
        this.search = false;
    }
    
    ShowCommandHelp(final boolean search) {
        this.searchArgs = null;
        this.search = false;
        this.search = search;
    }
    
    ShowCommandHelp(final List<String> args) {
        this(true);
        this.searchArgs = new ArrayList<String>(args);
    }
}

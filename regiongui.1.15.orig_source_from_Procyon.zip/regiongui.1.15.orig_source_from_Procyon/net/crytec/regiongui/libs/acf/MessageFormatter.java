// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.regex.Matcher;
import java.util.Collections;
import java.util.Collection;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public abstract class MessageFormatter<FT>
{
    private final List<FT> colors;
    
    @SafeVarargs
    public MessageFormatter(final FT... colors) {
        (this.colors = new ArrayList<FT>()).addAll((Collection<? extends FT>)Arrays.asList(colors));
    }
    
    public FT setColor(int index, final FT color) {
        if (index > 0) {
            --index;
        }
        else {
            index = 0;
        }
        if (this.colors.size() <= index) {
            final int n = index - this.colors.size();
            if (n > 0) {
                this.colors.addAll((Collection<? extends FT>)Collections.nCopies(n, (Object)null));
            }
            this.colors.add(color);
            return null;
        }
        return this.colors.set(index, color);
    }
    
    public FT getColor(int index) {
        if (index > 0) {
            --index;
        }
        else {
            index = 0;
        }
        FT ft = this.colors.get(index);
        if (ft == null) {
            ft = this.getDefaultColor();
        }
        return ft;
    }
    
    public FT getDefaultColor() {
        return this.getColor(1);
    }
    
    abstract String format(final FT color, final String message);
    
    public String format(final int index, final String message) {
        return this.format(this.getColor(index), message);
    }
    
    public String format(final String message) {
        final String format = this.format(1, "");
        final Matcher matcher = ACFPatterns.FORMATTER.matcher(message);
        final StringBuffer sb = new StringBuffer(message.length());
        while (matcher.find()) {
            matcher.appendReplacement(sb, Matcher.quoteReplacement(this.format(ACFUtil.parseInt(matcher.group("color"), 1), matcher.group("msg")) + format));
        }
        matcher.appendTail(sb);
        return format + sb.toString();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.regex.Pattern;
import java.lang.annotation.Annotation;
import java.lang.reflect.AnnotatedElement;

abstract class AnnotationLookups
{
    boolean hasAnnotation(final AnnotatedElement object, final Class<? extends Annotation> annoClass) {
        return this.getAnnotationValue(object, annoClass, 0) != null;
    }
    
    boolean hasAnnotation(final AnnotatedElement object, final Class<? extends Annotation> annoClass, final boolean allowEmpty) {
        return this.getAnnotationValue(object, annoClass, 0x0 | (allowEmpty ? 0 : 8)) != null;
    }
    
    String[] getAnnotationValues(final AnnotatedElement object, final Class<? extends Annotation> annoClass) {
        return this.getAnnotationValues(object, annoClass, ACFPatterns.PIPE, 1);
    }
    
    String[] getAnnotationValues(final AnnotatedElement object, final Class<? extends Annotation> annoClass, final Pattern pattern) {
        return this.getAnnotationValues(object, annoClass, pattern, 1);
    }
    
    String[] getAnnotationValues(final AnnotatedElement object, final Class<? extends Annotation> annoClass, final int options) {
        return this.getAnnotationValues(object, annoClass, ACFPatterns.PIPE, options);
    }
    
    String[] getAnnotationValues(final AnnotatedElement object, final Class<? extends Annotation> annoClass, final Pattern pattern, final int options) {
        final String annotationValue = this.getAnnotationValue(object, annoClass, options);
        if (annotationValue == null) {
            return null;
        }
        return pattern.split(annotationValue);
    }
    
    String getAnnotationValue(final AnnotatedElement object, final Class<? extends Annotation> annoClass) {
        return this.getAnnotationValue(object, annoClass, 1);
    }
    
    abstract String getAnnotationValue(final AnnotatedElement object, final Class<? extends Annotation> annoClass, final int options);
    
     <T extends Annotation> T getAnnotationFromClass(Class<?> var_1_49, final Class<T> annoClass) {
        while (var_1_49 != null && BaseCommand.class.isAssignableFrom(var_1_49)) {
            final Annotation annotation = var_1_49.getAnnotation(annoClass);
            if (annotation != null) {
                return (T)annotation;
            }
            for (Class<?> clazz = var_1_49.getSuperclass(); clazz != null && BaseCommand.class.isAssignableFrom(clazz); clazz = clazz.getSuperclass()) {
                final Annotation annotation2 = clazz.getAnnotation(annoClass);
                if (annotation2 != null) {
                    return (T)annotation2;
                }
            }
            var_1_49 = (Class<?>)var_1_49.getEnclosingClass();
        }
        return null;
    }
}

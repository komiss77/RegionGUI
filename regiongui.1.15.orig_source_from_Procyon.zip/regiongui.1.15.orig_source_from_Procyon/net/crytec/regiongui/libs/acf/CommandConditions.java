// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import org.jetbrains.annotations.NotNull;
import java.util.HashMap;
import co.aikar.util.Table;
import java.util.Map;

public class CommandConditions<I extends CommandIssuer, CEC extends CommandExecutionContext<CEC, I>, CC extends ConditionContext<I>>
{
    private CommandManager manager;
    private Map<String, Condition<I>> conditions;
    private Table<Class<?>, String, ParameterCondition<?, ?, ?>> paramConditions;
    
    CommandConditions(final CommandManager manager) {
        this.conditions = new HashMap<String, Condition<I>>();
        this.paramConditions = new Table<Class<?>, String, ParameterCondition<?, ?, ?>>();
        this.manager = manager;
    }
    
    public Condition<I> addCondition(@NotNull final String id, @NotNull final Condition<I> handler) {
        return this.conditions.put(id.toLowerCase(), handler);
    }
    
    public <P> ParameterCondition addCondition(final Class<P> clazz, @NotNull final String id, @NotNull final ParameterCondition<P, CEC, I> handler) {
        return this.paramConditions.put(clazz, id.toLowerCase(), handler);
    }
    
    void validateConditions(final CommandOperationContext context) {
        final RegisteredCommand registeredCommand = context.getRegisteredCommand();
        this.validateConditions(registeredCommand.conditions, context);
        this.validateConditions(registeredCommand.scope, context);
    }
    
    private void validateConditions(final BaseCommand scope, final CommandOperationContext operationContext) {
        this.validateConditions(scope.conditions, operationContext);
        if (scope.parentCommand != null) {
            this.validateConditions(scope.parentCommand, operationContext);
        }
    }
    
    private void validateConditions(String conditions, final CommandOperationContext context) {
        if (conditions == null) {
            return;
        }
        conditions = this.manager.getCommandReplacements().replace(conditions);
        final CommandIssuer commandIssuer = context.getCommandIssuer();
        final String[] split = ACFPatterns.PIPE.split(conditions);
        for (int length = split.length, i = 0; i < length; ++i) {
            final String[] split2 = ACFPatterns.COLON.split(split[i], 2);
            final String lowerCase = split2[0].toLowerCase();
            final Condition<I> condition = this.conditions.get(lowerCase);
            if (condition == null) {
                this.manager.log(LogLevel.ERROR, "Could not find command condition " + lowerCase + " for " + context.getRegisteredCommand().method.getName());
            }
            else {
                condition.validateCondition(this.manager.createConditionContext(commandIssuer, (split2.length == 2) ? split2[1] : null));
            }
        }
    }
    
    void validateConditions(final CEC execContext, final Object value) {
        final String conditions = execContext.getCommandParameter().getConditions();
        if (conditions == null) {
            return;
        }
        final String replace = this.manager.getCommandReplacements().replace(conditions);
        final CommandIssuer issuer = ((CommandExecutionContext<CEC, CommandIssuer>)execContext).getIssuer();
        final String[] split = ACFPatterns.PIPE.split(replace);
        for (int length = split.length, i = 0; i < length; ++i) {
            final String[] split2 = ACFPatterns.COLON.split(split[i], 2);
            Class<?> clazz = execContext.getParam().getType();
            final String lowerCase = split2[0].toLowerCase();
            ParameterCondition<?, ?, ?> parameterCondition;
            do {
                parameterCondition = this.paramConditions.get(clazz, lowerCase);
                if (parameterCondition != null || clazz.getSuperclass() == null || clazz.getSuperclass() == Object.class) {
                    break;
                }
                clazz = clazz.getSuperclass();
            } while (clazz != null);
            if (parameterCondition == null) {
                this.manager.log(LogLevel.ERROR, "Could not find command condition " + lowerCase + " for " + execContext.getCmd().method.getName() + "::" + execContext.getParam().getName());
            }
            else {
                parameterCondition.validateCondition(this.manager.createConditionContext(issuer, (split2.length == 2) ? split2[1] : null), execContext, value);
            }
        }
    }
    
    public interface ParameterCondition<P, CEC extends CommandExecutionContext, I extends CommandIssuer>
    {
        void validateCondition(final ConditionContext<I> context, final CEC execContext, final P value) throws InvalidCommandArgument;
    }
    
    public interface Condition<I extends CommandIssuer>
    {
        void validateCondition(final ConditionContext<I> context) throws InvalidCommandArgument;
    }
}

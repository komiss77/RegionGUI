// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.acf;

import java.util.Map;
import java.util.function.Consumer;
import co.aikar.locales.MessageKeyProvider;
import java.util.Collection;
import java.util.Comparator;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Iterator;
import java.util.regex.Pattern;
import com.google.common.collect.SetMultimap;
import java.util.HashSet;
import java.util.ArrayList;
import java.util.Set;
import java.util.List;

public class CommandHelp
{
    private final CommandManager manager;
    private final CommandIssuer issuer;
    private final List<HelpEntry> helpEntries;
    private final String commandName;
    final String commandPrefix;
    private int page;
    private int perPage;
    List<String> search;
    private Set<HelpEntry> selectedEntry;
    private int totalResults;
    private int totalPages;
    private boolean lastPage;
    
    public CommandHelp(final CommandManager manager, final RootCommand rootCommand, final CommandIssuer issuer) {
        this.helpEntries = new ArrayList<HelpEntry>();
        this.page = 1;
        this.selectedEntry = new HashSet<HelpEntry>();
        this.manager = manager;
        this.issuer = issuer;
        this.perPage = manager.defaultHelpPerPage;
        this.commandPrefix = manager.getCommandPrefix(issuer);
        this.commandName = rootCommand.getCommandName();
        final SetMultimap<String, RegisteredCommand> subCommands = rootCommand.getSubCommands();
        final HashSet<RegisteredCommand> set = new HashSet<RegisteredCommand>();
        if (!rootCommand.getDefCommand().hasHelpCommand) {
            final RegisteredCommand defaultRegisteredCommand = rootCommand.getDefaultRegisteredCommand();
            if (defaultRegisteredCommand != null) {
                this.helpEntries.add(new HelpEntry(this, defaultRegisteredCommand));
                set.add(defaultRegisteredCommand);
            }
        }
        final String s;
        RegisteredCommand command;
        final Set<RegisteredCommand> set2;
        subCommands.entries().forEach(e -> {
            s = e.getKey();
            if (!s.equals("__default") && !s.equals("__catchunknown")) {
                command = (RegisteredCommand)e.getValue();
                if (!command.isPrivate && command.hasPermission(issuer) && !set2.contains(command)) {
                    this.helpEntries.add(new HelpEntry(this, command));
                    set2.add(command);
                }
            }
        });
    }
    
    @UnstableAPI
    protected void updateSearchScore(final HelpEntry help) {
        if (this.search == null || this.search.isEmpty()) {
            help.setSearchScore(1);
            return;
        }
        final RegisteredCommand registeredCommand = help.getRegisteredCommand();
        int searchScore = 0;
        for (final String s : this.search) {
            final Pattern compile = Pattern.compile(".*" + Pattern.quote(s) + ".*", 2);
            for (final String s2 : registeredCommand.registeredSubcommands) {
                final Pattern compile2 = Pattern.compile(".*" + Pattern.quote(s2) + ".*", 2);
                if (compile.matcher(s2).matches()) {
                    searchScore += 3;
                }
                else {
                    if (!compile2.matcher(s).matches()) {
                        continue;
                    }
                    ++searchScore;
                }
            }
            if (compile.matcher(help.getDescription()).matches()) {
                searchScore += 2;
            }
            if (compile.matcher(help.getParameterSyntax()).matches()) {
                ++searchScore;
            }
            if (help.getSearchTags() != null && compile.matcher(help.getSearchTags()).matches()) {
                searchScore += 2;
            }
        }
        help.setSearchScore(searchScore);
    }
    
    public CommandManager getManager() {
        return this.manager;
    }
    
    public boolean testExactMatch(final String command) {
        this.selectedEntry.clear();
        for (final HelpEntry helpEntry : this.helpEntries) {
            if (helpEntry.getCommand().endsWith(" " + command)) {
                this.selectedEntry.add(helpEntry);
            }
        }
        return !this.selectedEntry.isEmpty();
    }
    
    public void showHelp() {
        this.showHelp(this.issuer);
    }
    
    public void showHelp(final CommandIssuer issuer) {
        final CommandHelpFormatter helpFormatter = this.manager.getHelpFormatter();
        if (!this.selectedEntry.isEmpty()) {
            final HelpEntry helpEntry2 = ACFUtil.getFirstElement(this.selectedEntry);
            helpFormatter.printDetailedHelpHeader(this, issuer, helpEntry2);
            final Iterator<HelpEntry> iterator = this.selectedEntry.iterator();
            while (iterator.hasNext()) {
                helpFormatter.showDetailedHelp(this, iterator.next());
            }
            helpFormatter.printDetailedHelpFooter(this, issuer, helpEntry2);
            return;
        }
        Object helpEntries = this.getHelpEntries().stream().filter(HelpEntry::shouldShow).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList());
        Object o = ((Collection<Object>)helpEntries).stream().sorted(Comparator.comparingInt(helpEntry -> helpEntry.getSearchScore() * -1)).iterator();
        if (!((Iterator)o).hasNext()) {
            issuer.sendMessage(MessageType.ERROR, MessageKeys.NO_COMMAND_MATCHED_SEARCH, "{search}", ACFUtil.join(this.search, " "));
            helpEntries = this.getHelpEntries();
            o = ((List<HelpEntry>)helpEntries).iterator();
        }
        this.totalResults = ((List)helpEntries).size();
        final int n = (this.page - 1) * this.perPage;
        final int n2 = n + this.perPage;
        this.totalPages = (int)Math.ceil(this.totalResults / (float)this.perPage);
        int n3 = 0;
        if (n >= this.totalResults) {
            issuer.sendMessage(MessageType.HELP, MessageKeys.HELP_NO_RESULTS, new String[0]);
            return;
        }
        final ArrayList<HelpEntry> list = new ArrayList<HelpEntry>();
        while (((Iterator)o).hasNext()) {
            final HelpEntry helpEntry3 = ((Iterator<HelpEntry>)o).next();
            if (n3 >= n2) {
                break;
            }
            if (n3++ < n) {
                continue;
            }
            list.add(helpEntry3);
        }
        this.lastPage = (n2 >= this.totalResults);
        if (this.search == null) {
            helpFormatter.showAllResults(this, list);
        }
        else {
            helpFormatter.showSearchResults(this, list);
        }
    }
    
    public List<HelpEntry> getHelpEntries() {
        return this.helpEntries;
    }
    
    public void setPerPage(final int perPage) {
        this.perPage = perPage;
    }
    
    public void setPage(final int page) {
        this.page = page;
    }
    
    public void setPage(final int page, final int perPage) {
        this.setPage(page);
        this.setPerPage(perPage);
    }
    
    public void setSearch(final List<String> search) {
        this.search = search;
        this.getHelpEntries().forEach(this::updateSearchScore);
    }
    
    public CommandIssuer getIssuer() {
        return this.issuer;
    }
    
    public String getCommandName() {
        return this.commandName;
    }
    
    public String getCommandPrefix() {
        return this.commandPrefix;
    }
    
    public int getPage() {
        return this.page;
    }
    
    public int getPerPage() {
        return this.perPage;
    }
    
    public List<String> getSearch() {
        return this.search;
    }
    
    public Set<HelpEntry> getSelectedEntry() {
        return this.selectedEntry;
    }
    
    public int getTotalResults() {
        return this.totalResults;
    }
    
    public int getTotalPages() {
        return this.totalPages;
    }
    
    public boolean isOnlyPage() {
        return this.page == 1 && this.lastPage;
    }
    
    public boolean isLastPage() {
        return this.lastPage;
    }
}

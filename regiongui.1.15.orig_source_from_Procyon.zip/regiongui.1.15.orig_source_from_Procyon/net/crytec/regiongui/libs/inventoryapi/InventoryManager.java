// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi;

import java.util.ArrayList;
import com.google.common.collect.Lists;
import java.util.List;
import net.crytec.regiongui.libs.inventoryapi.api.opener.InventoryOpener;
import java.util.Optional;
import org.bukkit.event.inventory.InventoryType;
import com.google.common.base.Preconditions;
import com.google.common.collect.Maps;
import net.crytec.regiongui.libs.inventoryapi.api.opener.SpecialInventoryOpener;
import net.crytec.regiongui.libs.inventoryapi.api.opener.ChestInventoryOpener;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.entity.Player;
import java.util.Map;

public class InventoryManager
{
    private static InventoryManager instance;
    private final Map<Player, SmartInventory> inventories;
    private final Map<Player, InventoryContent> contents;
    private final ChestInventoryOpener chestOpener;
    private final SpecialInventoryOpener otherOpener;
    
    protected InventoryManager() {
        InventoryManager.instance = this;
        this.inventories = (Map<Player, SmartInventory>)Maps.newHashMap();
        this.contents = (Map<Player, InventoryContent>)Maps.newHashMap();
        this.chestOpener = new ChestInventoryOpener();
        this.otherOpener = new SpecialInventoryOpener();
    }
    
    public static InventoryManager get() {
        Preconditions.checkNotNull((Object)InventoryManager.instance, (Object)"Unable to retrieve InventoryManager instance - Variable not initialized");
        return InventoryManager.instance;
    }
    
    public Optional<InventoryOpener> findOpener(final InventoryType type) {
        if (type == InventoryType.CHEST && this.chestOpener.supports(type)) {
            return (Optional<InventoryOpener>)Optional.of(this.chestOpener);
        }
        if (this.otherOpener.supports(type)) {
            return (Optional<InventoryOpener>)Optional.of(this.otherOpener);
        }
        return Optional.empty();
    }
    
    public List<Player> getOpenedPlayers(final SmartInventory inv) {
        final ArrayList arrayList = Lists.newArrayList();
        final List<Player> list;
        this.inventories.forEach((player, obj) -> {
            if (inv.equals(obj)) {
                list.add(player);
            }
            return;
        });
        return (List<Player>)arrayList;
    }
    
    public Optional<SmartInventory> getInventory(final Player p) {
        return Optional.ofNullable(this.inventories.get(p));
    }
    
    protected void setInventory(final Player p, final SmartInventory inv) {
        if (inv == null) {
            this.inventories.remove(p);
        }
        else {
            this.inventories.put(p, inv);
        }
    }
    
    public Optional<InventoryContent> getContents(final Player p) {
        return Optional.ofNullable(this.contents.get(p));
    }
    
    protected void setContents(final Player p, final InventoryContent contents) {
        if (contents == null) {
            this.contents.remove(p);
        }
        else {
            this.contents.put(p, contents);
        }
    }
    
    public Map<Player, SmartInventory> getInventories() {
        return this.inventories;
    }
    
    public Map<Player, InventoryContent> getContents() {
        return this.contents;
    }
}

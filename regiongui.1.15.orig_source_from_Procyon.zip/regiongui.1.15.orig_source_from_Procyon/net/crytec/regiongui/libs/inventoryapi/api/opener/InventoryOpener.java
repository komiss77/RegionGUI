// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi.api.opener;

import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.entity.Player;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;

public interface InventoryOpener
{
    Inventory open(final SmartInventory inv, final Player player);
    
    boolean supports(final InventoryType type);
    
    default void fill(final Inventory handle, final InventoryContent contents) {
        final ClickableItem[][] items = contents.all();
        for (int row = 0; row < items.length; ++row) {
            for (int column = 0; column < items[row].length; ++column) {
                if (items[row][column] != null) {
                    handle.setItem(9 * row + column, items[row][column].getItem());
                }
            }
        }
    }
}

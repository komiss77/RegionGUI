// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi.api.buttons;

import org.bukkit.event.inventory.ClickType;
import org.bukkit.entity.Player;
import net.crytec.regiongui.libs.inventoryapi.anvil.AnvilGUI;
import org.bukkit.inventory.ItemStack;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import java.util.function.Consumer;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;

public class InputButton extends ClickableItem
{
    private Consumer<InventoryClickEvent> onRightClick;
    
    public InputButton(final Consumer<String> result) {
        this(new ItemStack(Material.BOOK), "Input", result);
    }
    
    public InputButton(final ItemStack icon, final String text, final Consumer<String> result) {
        this(icon, inventoryClickEvent -> new AnvilGUI((Player)inventoryClickEvent.getWhoClicked(), text, (p1, s) -> {
            result.accept(s);
            return null;
        }));
    }
    
    public InputButton onRightClick(final Consumer<InventoryClickEvent> consumer) {
        this.onRightClick = consumer;
        return this;
    }
    
    private InputButton(final ItemStack item, final Consumer<InventoryClickEvent> consumer) {
        super(item, consumer);
    }
    
    @Override
    public void run(final InventoryClickEvent e) {
        if (this.onRightClick != null && e.getClick() == ClickType.RIGHT) {
            this.onRightClick.accept(e);
            return;
        }
        super.run(e);
    }
}

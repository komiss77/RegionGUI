// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi.api.opener;

import com.google.common.collect.ImmutableList;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import net.crytec.regiongui.libs.inventoryapi.InventoryManager;
import org.bukkit.inventory.Inventory;
import org.bukkit.entity.Player;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import org.bukkit.event.inventory.InventoryType;
import java.util.List;

public class SpecialInventoryOpener implements InventoryOpener
{
    private static final List<InventoryType> SUPPORTED;
    
    @Override
    public Inventory open(final SmartInventory inv, final Player player) {
        final InventoryManager value = InventoryManager.get();
        final Inventory inventory = value.getContents(player).get().getInventory();
        this.fill(inventory, value.getContents(player).get());
        player.openInventory(inventory);
        return inventory;
    }
    
    @Override
    public boolean supports(final InventoryType type) {
        return SpecialInventoryOpener.SUPPORTED.contains(type);
    }
    
    static {
        SUPPORTED = (List)ImmutableList.of((Object)InventoryType.FURNACE, (Object)InventoryType.WORKBENCH, (Object)InventoryType.DISPENSER, (Object)InventoryType.DROPPER, (Object)InventoryType.ENCHANTING, (Object)InventoryType.BREWING, (Object)InventoryType.ANVIL, (Object)InventoryType.BEACON, (Object)InventoryType.HOPPER);
    }
}

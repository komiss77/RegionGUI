// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi.api;

import org.bukkit.event.inventory.InventoryClickEvent;
import java.util.function.Consumer;
import org.bukkit.inventory.ItemStack;

public class ClickableItem
{
    private ItemStack item;
    private Consumer<InventoryClickEvent> consumer;
    
    public ClickableItem(final ItemStack item, final Consumer<InventoryClickEvent> consumer) {
        this.item = item;
        this.consumer = consumer;
    }
    
    public static ClickableItem empty(final ItemStack item) {
        return of(item, p0 -> {});
    }
    
    public static ClickableItem of(final ItemStack item, final Consumer<InventoryClickEvent> consumer) {
        return new ClickableItem(item, consumer);
    }
    
    public void run(final InventoryClickEvent e) {
        this.consumer.accept(e);
    }
    
    public ItemStack getItem() {
        return this.item;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi;

import net.crytec.regiongui.libs.inventoryapi.anvil.AnvilListener;
import org.bukkit.plugin.Plugin;
import org.bukkit.event.Listener;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class InventoryAPI
{
    private static InventoryAPI api;
    private final JavaPlugin host;
    private final InventoryManager manager;
    
    public InventoryAPI(final JavaPlugin host) {
        this(host, true);
    }
    
    public InventoryAPI(final JavaPlugin host, final boolean useAnvilAPI) {
        InventoryAPI.api = this;
        this.host = host;
        this.manager = new InventoryManager();
        Bukkit.getPluginManager().registerEvents((Listener)new InventoryAPIListener(this.manager, host), (Plugin)host);
        if (useAnvilAPI) {
            Bukkit.getPluginManager().registerEvents((Listener)new AnvilListener(), (Plugin)host);
        }
    }
    
    public static InventoryAPI get() {
        return InventoryAPI.api;
    }
    
    public InventoryManager getManager() {
        return this.manager;
    }
    
    public JavaPlugin getHost() {
        return this.host;
    }
}

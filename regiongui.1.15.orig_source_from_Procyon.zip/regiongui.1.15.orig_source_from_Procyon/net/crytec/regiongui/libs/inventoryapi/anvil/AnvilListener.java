// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi.anvil;

import com.google.common.collect.Maps;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.EventHandler;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.Inventory;
import org.bukkit.Material;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.entity.Player;
import java.util.Map;
import org.bukkit.event.Listener;

public class AnvilListener implements Listener
{
    private static final Map<Player, AnvilGUI> openInventories;
    
    public void add(final Player player, final AnvilGUI gui) {
        AnvilListener.openInventories.put(player, gui);
    }
    
    public void remove(final Player player) {
        AnvilListener.openInventories.remove(player);
    }
    
    @EventHandler
    public void onInventoryClick(final InventoryClickEvent e) {
        final Player player = (Player)e.getWhoClicked();
        if (!AnvilListener.openInventories.containsKey(player)) {
            return;
        }
        final Inventory inventory = AnvilListener.openInventories.get(player).getInventory();
        if (!e.getInventory().equals(inventory)) {
            return;
        }
        e.setCancelled(true);
        if (e.getRawSlot() != 2) {
            return;
        }
        final ItemStack item = inventory.getItem(e.getRawSlot());
        final AnvilGUI anvilGUI = AnvilListener.openInventories.get(player);
        if (item == null || item.getType() == Material.AIR) {
            return;
        }
        final String displayName = anvilGUI.getBiFunction().apply(player, item.hasItemMeta() ? item.getItemMeta().getDisplayName() : item.getType().toString());
        if (displayName != null) {
            final ItemMeta itemMeta = item.getItemMeta();
            itemMeta.setDisplayName(displayName);
            item.setItemMeta(itemMeta);
            inventory.setItem(e.getRawSlot(), item);
        }
        else {
            anvilGUI.closeInventory();
        }
    }
    
    @EventHandler
    public void onInventoryClose(final InventoryCloseEvent e) {
        if (!AnvilListener.openInventories.containsKey(e.getPlayer())) {
            return;
        }
        final AnvilGUI anvilGUI = AnvilListener.openInventories.get(e.getPlayer());
        if (anvilGUI.isOpen() && e.getInventory().equals(anvilGUI.getInventory())) {
            anvilGUI.closeInventory();
            AnvilListener.openInventories.remove(e.getPlayer());
        }
    }
    
    static {
        openInventories = Maps.newHashMap();
    }
}

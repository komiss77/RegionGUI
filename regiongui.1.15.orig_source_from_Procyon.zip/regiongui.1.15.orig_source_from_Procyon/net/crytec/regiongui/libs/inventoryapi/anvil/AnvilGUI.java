// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi.anvil;

import org.bukkit.plugin.Plugin;
import org.bukkit.event.Listener;
import net.crytec.regiongui.libs.inventoryapi.InventoryAPI;
import org.bukkit.Bukkit;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import java.util.function.BiFunction;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Player;

public class AnvilGUI
{
    private static final AnvilImplementation WRAPPER;
    private static final AnvilListener listener;
    private final Player holder;
    private final ItemStack insert;
    private final BiFunction<Player, String, String> biFunction;
    private final int containerId;
    private final Inventory inventory;
    private boolean open;
    
    public AnvilGUI(final Player holder, final String insert, final BiFunction<Player, String, String> biFunction) {
        this.holder = holder;
        this.biFunction = biFunction;
        final ItemStack insert2 = new ItemStack(Material.PAPER);
        final ItemMeta itemMeta = insert2.getItemMeta();
        itemMeta.setDisplayName(insert);
        insert2.setItemMeta(itemMeta);
        this.insert = insert2;
        AnvilGUI.WRAPPER.handleInventoryCloseEvent(holder);
        AnvilGUI.WRAPPER.setActiveContainerDefault(holder);
        final Object containerAnvil = AnvilGUI.WRAPPER.newContainerAnvil(holder);
        (this.inventory = AnvilGUI.WRAPPER.toBukkitInventory(containerAnvil)).setItem(0, this.insert);
        this.containerId = AnvilGUI.WRAPPER.getNextContainerId(holder);
        AnvilGUI.WRAPPER.sendPacketOpenWindow(holder, this.containerId);
        AnvilGUI.WRAPPER.setActiveContainer(holder, containerAnvil);
        AnvilGUI.WRAPPER.setActiveContainerId(containerAnvil, this.containerId);
        AnvilGUI.WRAPPER.addActiveContainerSlotListener(containerAnvil, holder);
        this.open = true;
        AnvilGUI.listener.add(holder, this);
    }
    
    public void closeInventory() {
        if (!this.open) {
            AnvilGUI.listener.remove(this.holder);
            return;
        }
        this.open = false;
        AnvilGUI.WRAPPER.handleInventoryCloseEvent(this.holder);
        AnvilGUI.WRAPPER.setActiveContainerDefault(this.holder);
        AnvilGUI.WRAPPER.sendPacketCloseWindow(this.holder, this.containerId);
    }
    
    public Player getHolder() {
        return this.holder;
    }
    
    public ItemStack getInsert() {
        return this.insert;
    }
    
    public BiFunction<Player, String, String> getBiFunction() {
        return this.biFunction;
    }
    
    public Inventory getInventory() {
        return this.inventory;
    }
    
    public boolean isOpen() {
        return this.open;
    }
    
    public int getContainerId() {
        return this.containerId;
    }
    
    static {
        WRAPPER = new AnvilImplementation();
        listener = new AnvilListener();
        Bukkit.getPluginManager().registerEvents((Listener)AnvilGUI.listener, (Plugin)InventoryAPI.get().getHost());
        System.out.println("Initialized Listeners" + (AnvilGUI.listener == null));
    }
    
    public static class Slot
    {
        public static final int INPUT_LEFT = 0;
        public static final int INPUT_RIGHT = 1;
        public static final int OUTPUT = 2;
    }
}

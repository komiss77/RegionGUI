// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi.anvil;

import org.bukkit.inventory.InventoryView;
import net.minecraft.server.v1_15_R1.ChatComponentText;
import org.bukkit.ChatColor;
import org.bukkit.craftbukkit.v1_15_R1.inventory.CraftItemStack;
import org.bukkit.Material;
import net.minecraft.server.v1_15_R1.ContainerAccess;
import net.minecraft.server.v1_15_R1.BlockPosition;
import net.minecraft.server.v1_15_R1.ItemStack;
import net.minecraft.server.v1_15_R1.ContainerAnvil;
import org.bukkit.craftbukkit.v1_15_R1.entity.CraftPlayer;
import net.minecraft.server.v1_15_R1.EntityPlayer;
import org.bukkit.inventory.Inventory;
import net.minecraft.server.v1_15_R1.ICrafting;
import java.lang.reflect.Field;
import net.minecraft.server.v1_15_R1.Container;
import net.minecraft.server.v1_15_R1.PacketPlayOutCloseWindow;
import net.minecraft.server.v1_15_R1.Packet;
import net.minecraft.server.v1_15_R1.IChatBaseComponent;
import net.minecraft.server.v1_15_R1.PacketPlayOutOpenWindow;
import net.minecraft.server.v1_15_R1.ChatMessage;
import net.minecraft.server.v1_15_R1.Containers;
import net.minecraft.server.v1_15_R1.EntityHuman;
import org.bukkit.craftbukkit.v1_15_R1.event.CraftEventFactory;
import org.bukkit.entity.Player;

public class AnvilImplementation
{
    protected AnvilImplementation() {
    }
    
    public int getNextContainerId(final Player player) {
        return this.toNMS(player).nextContainerCounter();
    }
    
    public void handleInventoryCloseEvent(final Player player) {
        CraftEventFactory.handleInventoryCloseEvent((EntityHuman)this.toNMS(player));
    }
    
    public void sendPacketOpenWindow(final Player player, final int containerId) {
        this.toNMS(player).playerConnection.sendPacket((Packet)new PacketPlayOutOpenWindow(containerId, Containers.ANVIL, (IChatBaseComponent)new ChatMessage("Anvil", new Object[0])));
    }
    
    public void sendPacketCloseWindow(final Player player, final int containerId) {
        this.toNMS(player).playerConnection.sendPacket((Packet)new PacketPlayOutCloseWindow(containerId));
    }
    
    public void setActiveContainerDefault(final Player player) {
        this.toNMS(player).activeContainer = (Container)this.toNMS(player).defaultContainer;
    }
    
    public void setActiveContainer(final Player player, final Object container) {
        this.toNMS(player).activeContainer = (Container)container;
    }
    
    public void setActiveContainerId(final Object container, final int containerId) {
        try {
            final Field field = Container.class.getField("windowId");
            field.setAccessible(true);
            field.setInt(container, containerId);
        }
        catch (SecurityException | NoSuchFieldException | IllegalAccessException ex) {
            final Throwable t;
            t.printStackTrace();
        }
    }
    
    public void addActiveContainerSlotListener(final Object container, final Player player) {
        ((Container)container).addSlotListener((ICrafting)this.toNMS(player));
    }
    
    public Inventory toBukkitInventory(final Object container) {
        return ((Container)container).getBukkitView().getTopInventory();
    }
    
    public Object newContainerAnvil(final Player player) {
        return new AnvilContainer((EntityHuman)this.toNMS(player));
    }
    
    private EntityPlayer toNMS(final Player player) {
        return ((CraftPlayer)player).getHandle();
    }
    
    private class AnvilContainer extends ContainerAnvil
    {
        private final ItemStack output;
        
        public AnvilContainer(final EntityHuman entityhuman) {
            super(AnvilImplementation.this.getNextContainerId((Player)entityhuman.getBukkitEntity()), entityhuman.inventory, ContainerAccess.at(entityhuman.world, new BlockPosition(0, 0, 0)));
            this.checkReachable = false;
            this.setTitle((IChatBaseComponent)new ChatMessage("Repair & Name", new Object[0]));
            final org.bukkit.inventory.ItemStack itemStack = new org.bukkit.inventory.ItemStack(Material.COAL);
            this.output = CraftItemStack.asNMSCopy(itemStack);
            this.getSlot(1).set(CraftItemStack.asNMSCopy(itemStack));
        }
        
        public void e() {
            this.levelCost.set(0);
            if (this.renameText != null && !this.renameText.isEmpty()) {
                this.output.a((IChatBaseComponent)new ChatComponentText(ChatColor.translateAlternateColorCodes('&', this.renameText)));
                this.getSlot(2).set(this.output);
                CraftEventFactory.callPrepareAnvilEvent((InventoryView)this.getBukkitView(), this.output);
                this.c();
            }
        }
    }
}

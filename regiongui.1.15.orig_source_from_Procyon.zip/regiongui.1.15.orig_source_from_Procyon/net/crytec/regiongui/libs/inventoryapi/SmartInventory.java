// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi;

import java.util.Optional;
import net.crytec.regiongui.libs.inventoryapi.api.opener.InventoryOpener;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.inventory.Inventory;
import org.bukkit.entity.Player;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;
import org.bukkit.event.inventory.InventoryType;

public class SmartInventory
{
    private String id;
    private String title;
    private InventoryType type;
    private int rows;
    private int columns;
    private SmartInventory parent;
    private InventoryProvider provider;
    
    private SmartInventory() {
    }
    
    public Inventory open(final Player player) {
        return this.open(player, 0);
    }
    
    public Inventory open(final Player player, final int page) {
        final InventoryManager value = InventoryManager.get();
        value.getInventory(player).ifPresent(p2 -> value.setInventory(player, null));
        this.provider.preInit(player);
        final InventoryContent inventoryContent = new InventoryContent(this, player);
        inventoryContent.pagination().page(page);
        value.setContents(player, inventoryContent);
        this.provider.init(player, inventoryContent);
        final Object o;
        final Inventory open = value.findOpener(this.type).orElseThrow(() -> {
            new IllegalStateException("No opener found for inventory type " + this.type.name());
            return o;
        }).open(this, player);
        value.setInventory(player, this);
        return open;
    }
    
    public void close(final Player player) {
        final InventoryManager value = InventoryManager.get();
        value.setInventory(player, null);
        player.closeInventory();
        value.setContents(player, null);
    }
    
    public String getId() {
        return this.id;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public InventoryType getType() {
        return this.type;
    }
    
    public int getRows() {
        return this.rows;
    }
    
    public int getColumns() {
        return this.columns;
    }
    
    public InventoryProvider getProvider() {
        return this.provider;
    }
    
    public Optional<SmartInventory> getParent() {
        return Optional.ofNullable(this.parent);
    }
    
    public static Builder builder() {
        return new Builder();
    }
    
    public static final class Builder
    {
        private String id;
        private String title;
        private InventoryType type;
        private int rows;
        private int columns;
        private InventoryProvider provider;
        private SmartInventory parent;
        
        private Builder() {
            this.id = "unknown";
            this.title = "unknown";
            this.type = InventoryType.CHEST;
            this.rows = 6;
            this.columns = 9;
        }
        
        public Builder id(final String id) {
            this.id = id;
            return this;
        }
        
        public Builder title(final String title) {
            this.title = title;
            return this;
        }
        
        public Builder type(final InventoryType type) {
            this.type = type;
            return this;
        }
        
        public Builder size(final int rows) {
            this.rows = rows;
            this.columns = 9;
            return this;
        }
        
        public Builder size(final int rows, final int columns) {
            this.rows = rows;
            this.columns = columns;
            return this;
        }
        
        public Builder provider(final InventoryProvider provider) {
            this.provider = provider;
            return this;
        }
        
        public Builder parent(final SmartInventory parent) {
            this.parent = parent;
            return this;
        }
        
        public SmartInventory build() {
            if (this.provider == null) {
                throw new IllegalStateException("The provider of the SmartInventory.Builder must be set.");
            }
            final SmartInventory smartInventory = new SmartInventory(null);
            smartInventory.id = this.id;
            smartInventory.title = this.title;
            smartInventory.type = this.type;
            smartInventory.rows = this.rows;
            smartInventory.columns = this.columns;
            smartInventory.provider = this.provider;
            smartInventory.parent = this.parent;
            return smartInventory;
        }
    }
}

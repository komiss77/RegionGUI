// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.inventoryapi;

import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import org.bukkit.event.server.PluginDisableEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import java.util.Iterator;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.event.Listener;

public class InventoryAPIListener implements Listener
{
    private InventoryManager manager;
    private JavaPlugin host;
    
    protected InventoryAPIListener() {
    }
    
    protected InventoryAPIListener(final InventoryManager manager, final JavaPlugin host) {
        this.manager = manager;
        this.host = host;
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public void onInventoryClick(final InventoryClickEvent e) {
        final Player player = (Player)e.getWhoClicked();
        if (!this.manager.getInventories().containsKey(player)) {
            return;
        }
        if (e.getAction() == InventoryAction.NOTHING || e.getClickedInventory() == null) {
            e.setCancelled(true);
            return;
        }
        if (e.getClickedInventory().equals(player.getOpenInventory().getBottomInventory()) && (e.getAction() == InventoryAction.COLLECT_TO_CURSOR || e.getAction() == InventoryAction.MOVE_TO_OTHER_INVENTORY)) {
            e.setCancelled(true);
            return;
        }
        if (e.getClickedInventory() == player.getOpenInventory().getTopInventory()) {
            e.setCancelled(true);
            final int row = e.getSlot() / 9;
            final int column = e.getSlot() % 9;
            if (row < 0 || column < 0) {
                return;
            }
            final SmartInventory smartInventory = this.manager.getInventories().get(player);
            if (row >= smartInventory.getRows() || column >= smartInventory.getColumns()) {
                return;
            }
            this.manager.getContents().get(player).get(row, column).ifPresent(clickableItem -> clickableItem.run(e));
            player.updateInventory();
        }
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public void onInventoryDrag(final InventoryDragEvent e) {
        final Player player = (Player)e.getWhoClicked();
        if (!this.manager.getInventories().containsKey(player)) {
            return;
        }
        final Iterator<Integer> iterator = e.getRawSlots().iterator();
        while (iterator.hasNext()) {
            if (iterator.next() >= player.getOpenInventory().getTopInventory().getSize()) {
                continue;
            }
            e.setCancelled(true);
            break;
        }
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public void onInventoryClose(final InventoryCloseEvent e) {
        final Player player = (Player)e.getPlayer();
        if (!this.manager.getInventories().containsKey(player)) {
            return;
        }
        this.manager.getInventories().get(player).getProvider().onClose(player, this.manager.getContents().get(player));
        this.manager.getInventories().remove(player);
        this.manager.getContents().remove(player);
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public void onPlayerQuit(final PlayerQuitEvent e) {
        final Player player = e.getPlayer();
        if (!this.manager.getInventories().containsKey(player)) {
            return;
        }
        this.manager.getInventories().get(player).getProvider().onClose(player, this.manager.getContents().get(player));
        this.manager.getInventories().remove(player);
        this.manager.getContents().remove(player);
    }
    
    @EventHandler(priority = EventPriority.LOW)
    public void onPluginDisable(final PluginDisableEvent e) {
        if (!e.getPlugin().getName().equals(this.host.getName())) {
            return;
        }
        this.manager.getInventories().clear();
        this.manager.getContents().clear();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.io.InputStream;
import org.bukkit.util.io.BukkitObjectInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.bukkit.Bukkit;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;
import java.io.OutputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import java.io.ByteArrayOutputStream;
import org.jetbrains.annotations.Nullable;
import java.util.Iterator;
import java.util.HashSet;
import org.bukkit.entity.Item;
import org.bukkit.World;
import org.bukkit.Material;
import java.util.Arrays;
import java.util.stream.IntStream;
import org.bukkit.Location;
import org.bukkit.inventory.Inventory;
import java.util.HashMap;
import org.bukkit.Sound;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Player;

public class UtilInv
{
    public static void insert(final Player player, final ItemStack stack) {
        insert(player, stack, false);
    }
    
    public static void insert(final Player player, final ItemStack stack, final boolean drop) {
        insert(player, stack, drop, true);
    }
    
    public static void insert(final Player player, final ItemStack stack, final boolean drop, final boolean playsound) {
        final HashMap addItem = player.getInventory().addItem(new ItemStack[] { stack });
        if (addItem.size() == 0 && playsound) {
            UtilPlayer.playSound(player, Sound.ENTITY_ITEM_PICKUP);
        }
        else {
            addItem.values().forEach(itemStack -> player.getWorld().dropItemNaturally(player.getLocation(), itemStack));
            if (playsound) {
                player.getWorld().playSound(player.getLocation(), Sound.ENTITY_CHICKEN_EGG, 0.8f, 1.0f);
            }
        }
    }
    
    public static void insert(final Inventory inventory, final ItemStack stack, final boolean drop, final Location dropLocation) {
        inventory.addItem(new ItemStack[] { stack }).values().forEach(itemStack -> {
            if (drop) {
                dropLocation.getWorld().dropItemNaturally(dropLocation, itemStack);
            }
        });
    }
    
    public static void insertAmount(final Inventory inventory, final ItemStack item, final int amount, final boolean dropExcess, final Location dropLocation) {
        final int amount2 = item.getAmount();
        final int maxStackSize = item.getMaxStackSize();
        final int endExclusive = (int)(amount * amount2 / (double)maxStackSize);
        final int amount3 = (int)(amount * amount2 % (double)maxStackSize);
        final ItemStack clone = item.clone();
        clone.setAmount(1);
        if (endExclusive != 0) {
            clone.setAmount(maxStackSize);
            IntStream.range(0, endExclusive).forEach(p4 -> insert(inventory, clone.clone(), dropExcess, dropLocation));
        }
        if (amount3 != 0) {
            clone.setAmount(amount3);
            insert(inventory, clone.clone(), dropExcess, dropLocation);
        }
    }
    
    public static boolean isEmpty(final Inventory inv) {
        return Arrays.stream(inv.getContents()).anyMatch(itemStack -> itemStack != null);
    }
    
    @Deprecated
    public static boolean contains(final Player player, final Material item, final int required) {
        return player.getInventory().contains(item, required);
    }
    
    public static boolean has(final Inventory inv, final ItemStack item, final int amount) {
        return amount * item.getAmount() <= IntStream.range(0, 36).mapToObj(n -> inv.getItem(n)).filter(itemStack2 -> itemStack2 != null && itemStack2.isSimilar(item)).mapToInt(itemStack -> itemStack.getAmount()).sum();
    }
    
    public static int remove(final Inventory inv, final ItemStack item, final int amount) {
        int n = amount * item.getAmount();
        for (int i = 0; i < inv.getSize(); ++i) {
            final ItemStack item2 = inv.getItem(i);
            if (item2 != null) {
                if (item2.isSimilar(item)) {
                    final int amount2 = item2.getAmount();
                    if (amount2 >= n) {
                        item2.setAmount(item2.getAmount() - n);
                        return 0;
                    }
                    n -= amount2;
                    inv.clear(i);
                }
            }
        }
        return n;
    }
    
    public static void drop(final Location dropLocation, final ItemStack[] content) {
        drop(dropLocation, content, 0);
    }
    
    public static void drop(final Location dropLocation, final ItemStack[] content, final int pickupDelay) {
        final World world = dropLocation.getWorld();
        for (final ItemStack itemStack : content) {
            if (itemStack != null) {
                if (itemStack.getType() != Material.AIR) {
                    final Item dropItemNaturally = world.dropItemNaturally(dropLocation, itemStack);
                    if (pickupDelay > 0) {
                        dropItemNaturally.setPickupDelay(pickupDelay);
                    }
                }
            }
        }
    }
    
    public static int removeAll(final Player player, final Material type) {
        final HashSet<ItemStack> set = new HashSet<ItemStack>();
        int n = 0;
        for (final ItemStack e : player.getInventory().getContents()) {
            if (e != null && e.getType() == type) {
                n += e.getAmount();
                set.add(e);
            }
        }
        final Iterator<ItemStack> iterator = set.iterator();
        while (iterator.hasNext()) {
            player.getInventory().remove((ItemStack)iterator.next());
        }
        return n;
    }
    
    public static void clear(final Player player, final boolean clearArmor) {
        for (int i = 0; i < player.getInventory().getSize(); ++i) {
            player.getInventory().clear(i);
        }
        if (clearArmor) {
            player.getInventory().setArmorContents(new ItemStack[0]);
        }
        player.updateInventory();
    }
    
    public static boolean hasSpot(final Player player) {
        return player.getInventory().firstEmpty() != -1;
    }
    
    public static boolean hasSpot(final Inventory inventory) {
        return inventory.firstEmpty() != -1;
    }
    
    public static boolean hasItems(final Inventory inventory, final ItemStack item, final int amount) {
        return amount * item.getAmount() <= IntStream.range(0, inventory.getSize()).mapToObj(n -> inventory.getItem(n)).filter(itemStack2 -> itemStack2 != null && itemStack2.isSimilar(item)).mapToInt(itemStack -> itemStack.getAmount()).sum();
    }
    
    public static int removeItem(final Inventory inventory, final Material mat, final int quantity) {
        int n = quantity;
        for (int i = 0; i < inventory.getSize(); ++i) {
            final ItemStack item = inventory.getItem(i);
            if (item != null) {
                if (item.getType().equals((Object)mat)) {
                    final int amount = item.getAmount();
                    if (amount >= n) {
                        item.setAmount(item.getAmount() - n);
                        return 0;
                    }
                    n -= amount;
                    inventory.clear(i);
                }
            }
        }
        return n;
    }
    
    public static int removeItem(final Inventory inventory, final ItemStack item, final int amount) {
        int n = amount * item.getAmount();
        for (int i = 0; i < inventory.getSize(); ++i) {
            final ItemStack item2 = inventory.getItem(i);
            if (item2 != null) {
                if (item2.isSimilar(item)) {
                    final int amount2 = item2.getAmount();
                    if (amount2 >= n) {
                        item2.setAmount(item2.getAmount() - n);
                        return 0;
                    }
                    n -= amount2;
                    inventory.clear(i);
                }
            }
        }
        return n;
    }
    
    public static boolean isNull(@Nullable final ItemStack item) {
        return item == null || item.getType() == Material.AIR || item.getType().toString().endsWith("_AIR");
    }
    
    public static boolean isNull(@Nullable final Material material) {
        return material == null || material == Material.AIR || material.toString().endsWith("_AIR");
    }
    
    public static boolean compare(@Nullable final ItemStack a, @Nullable final ItemStack b) {
        if (isNull(a)) {
            return isNull(b);
        }
        if (isNull(b)) {
            return isNull(a);
        }
        return a.equals((Object)b);
    }
    
    public static boolean compare(@Nullable final ItemStack[] a, @Nullable final ItemStack[] b) {
        if (a == null && b == null) {
            return true;
        }
        if (a == null || b == null) {
            return false;
        }
        if (a.length != b.length) {
            return false;
        }
        for (int i = 0; i < a.length; ++i) {
            if (!compare(a[i], b[i])) {
                return false;
            }
        }
        return true;
    }
    
    public static String itemStackArrayToBase64(final ItemStack[] items) {
        try {
            final ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            try {
                final BukkitObjectOutputStream bukkitObjectOutputStream = new BukkitObjectOutputStream((OutputStream)byteArrayOutputStream);
                try {
                    bukkitObjectOutputStream.writeInt(items.length);
                    for (int i = 0; i < items.length; ++i) {
                        bukkitObjectOutputStream.writeObject((Object)items[i]);
                    }
                    final String encodeLines = Base64Coder.encodeLines(byteArrayOutputStream.toByteArray());
                    bukkitObjectOutputStream.close();
                    byteArrayOutputStream.close();
                    return encodeLines;
                }
                catch (Throwable t) {
                    try {
                        bukkitObjectOutputStream.close();
                    }
                    catch (Throwable exception) {
                        t.addSuppressed(exception);
                    }
                    throw t;
                }
            }
            catch (Throwable t2) {
                try {
                    byteArrayOutputStream.close();
                }
                catch (Throwable exception2) {
                    t2.addSuppressed(exception2);
                }
                throw t2;
            }
        }
        catch (IOException ex) {
            Bukkit.getLogger().severe("Failed to serialize ItemStack array to Base64");
            ex.printStackTrace();
            return null;
        }
    }
    
    public static ItemStack[] itemStackArrayFromBase64(final String data) {
        try {
            final BukkitObjectInputStream bukkitObjectInputStream = new BukkitObjectInputStream((InputStream)new ByteArrayInputStream(Base64Coder.decodeLines(data)));
            try {
                final ItemStack[] array = new ItemStack[bukkitObjectInputStream.readInt()];
                for (int i = 0; i < array.length; ++i) {
                    array[i] = (ItemStack)bukkitObjectInputStream.readObject();
                }
                final ItemStack[] array2 = array;
                bukkitObjectInputStream.close();
                return array2;
            }
            catch (Throwable t) {
                try {
                    bukkitObjectInputStream.close();
                }
                catch (Throwable exception) {
                    t.addSuppressed(exception);
                }
                throw t;
            }
        }
        catch (IOException | ClassNotFoundException ex) {
            final Object o2;
            final Object o = o2;
            Bukkit.getLogger().severe("Failed to deserialize Base64");
            ((Throwable)o).printStackTrace();
            return null;
        }
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import org.bukkit.entity.Entity;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import org.bukkit.block.Block;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.Nullable;
import org.bukkit.World;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.block.BlockFace;

public class UtilLoc
{
    private static final BlockFace[] axis;
    private static final BlockFace[] radial;
    
    public static String locToString(final Location location) {
        final StringBuilder sb = new StringBuilder();
        sb.append(location.getWorld().getUID().toString()).append("@").append(location.getX()).append("@").append(location.getY()).append("@").append(location.getZ()).append("@").append(location.getYaw()).append("@").append(location.getPitch());
        return sb.toString();
    }
    
    @Nullable
    public static Location locFromString(final String locationString) {
        if (locationString.contains(";")) {
            if (importOldFormat(locationString) != null) {
                Bukkit.getLogger().info("- Imported old location format - ");
            }
            return importOldFormat(locationString);
        }
        final String[] split = locationString.split("@");
        final World world = Bukkit.getWorld(UUID.fromString(split[0]));
        if (world == null) {
            return null;
        }
        return new Location(world, Double.parseDouble(split[1]), Double.parseDouble(split[2]), Double.parseDouble(split[3]), Float.parseFloat(split[4]), Float.parseFloat(split[5]));
    }
    
    private static Location importOldFormat(final String input) {
        if (input == null || input.equals("null")) {
            return Bukkit.getWorlds().get(0).getSpawnLocation();
        }
        final String[] split = input.replace("_", ".").split(";");
        final String s = split[0];
        final double double1 = Double.parseDouble(split[1]);
        final double double2 = Double.parseDouble(split[2]);
        final double double3 = Double.parseDouble(split[3]);
        final float float1 = Float.parseFloat(split[4]);
        final float float2 = Float.parseFloat(split[5]);
        if (Bukkit.getWorld(s) == null) {
            return null;
        }
        return new Location(Bukkit.getWorld(s), double1, double2, double3, float2, float1);
    }
    
    public static BlockFace yawToFace(final float yaw, final boolean useSubCardinalDirections) {
        if (useSubCardinalDirections) {
            return UtilLoc.radial[Math.round(yaw / 45.0f) & 0x7].getOppositeFace();
        }
        return UtilLoc.axis[Math.round(yaw / 90.0f) & 0x3].getOppositeFace();
    }
    
    public static boolean isChunkLoaded(final Location location) {
        return location.getWorld().isChunkLoaded(location.getBlockX() >> 4, location.getBlockZ() >> 4);
    }
    
    public static boolean isInRadius(final Player player, final Location loc, final double radius) {
        return Math.sqrt(Math.pow(loc.getX() - player.getLocation().getX(), 2.0) + Math.pow(loc.getZ() - player.getLocation().getZ(), 2.0)) <= radius;
    }
    
    public static boolean isInRadius3D(final Player player, final Location loc, final double radius) {
        return Math.sqrt(Math.pow(loc.getX() - player.getLocation().getX(), 2.0) + Math.pow(loc.getY() - player.getLocation().getY(), 2.0) + Math.pow(loc.getZ() - player.getLocation().getZ(), 2.0)) <= radius;
    }
    
    public static boolean isInRadius3D(final Location midpoint, final Location loc, final double radius) {
        return Math.sqrt(Math.pow(loc.getX() - midpoint.getX(), 2.0) + Math.pow(loc.getY() - midpoint.getY(), 2.0) + Math.pow(loc.getZ() - midpoint.getZ(), 2.0)) <= radius;
    }
    
    public static Location getRandomLocationArroundPlayer(final Player player, final int XmaxDistance, final int ZmaxDistance) {
        return new Location(player.getWorld(), player.getLocation().getX() + (1 + (int)(Math.random() * (XmaxDistance - 1 + 1))), player.getLocation().clone().add(0.0, 1.0, 0.0).getY(), player.getLocation().getZ() + (1 + (int)(Math.random() * (ZmaxDistance - 1 + 1))));
    }
    
    public static boolean isSafe(final Location loc) {
        final World world = loc.getWorld();
        final Block relative = world.getHighestBlockAt(loc).getRelative(BlockFace.DOWN);
        final Block block = world.getBlockAt(loc.add(0.0, 1.0, 0.0));
        final Block block2 = world.getBlockAt(loc.add(0.0, 2.0, 0.0));
        return !block.isLiquid() && !block2.isLiquid() && !relative.isLiquid() && (relative.getType().isSolid() || block.getType() != Material.AIR || block2.getType() != Material.AIR);
    }
    
    public static Location getRandomLoc(final World w) {
        final int n = (int)w.getWorldBorder().getCenter().getX();
        final int n2 = (int)w.getWorldBorder().getCenter().getZ();
        return new Location(w, (double)UtilMath.getRandom(n - (int)w.getWorldBorder().getSize() / 2, n + (int)w.getWorldBorder().getSize() / 2), 0.0, (double)UtilMath.getRandom(n2 - (int)w.getWorldBorder().getSize() / 2, n2 + (int)w.getWorldBorder().getSize() / 2));
    }
    
    public static String getLogString(final Location loc) {
        return "(" + loc.getWorld().getName() + ") X: " + UtilMath.trim(1, loc.getX()) + " Y: " + UtilMath.trim(1, loc.getY()) + " Z: " + UtilMath.trim(1, loc.getZ());
    }
    
    public static List<Player> getClosestPlayersFromLocation(final Location location, final double distance) {
        final ArrayList<Player> list = new ArrayList<Player>();
        final double n = distance * distance;
        for (final Player player : location.getWorld().getPlayers()) {
            if (player.getLocation().add(0.0, 0.85, 0.0).distanceSquared(location) <= n) {
                list.add(player);
            }
        }
        return list;
    }
    
    public static List<Entity> getClosestEntitiesFromLocation(final Location location, final double radius) {
        final double n = (radius < 16.0) ? 1.0 : ((radius - radius % 16.0) / 16.0);
        final ArrayList<Entity> list = new ArrayList<Entity>();
        for (double n2 = 0.0 - n; n2 <= n; ++n2) {
            for (double n3 = 0.0 - n; n3 <= n; ++n3) {
                for (final Entity entity : new Location(location.getWorld(), (int)location.getX() + n2 * 16.0, (double)(int)location.getY(), (int)location.getZ() + n3 * 16.0).getChunk().getEntities()) {
                    if (entity.getLocation().distance(location) <= radius && entity.getLocation().getBlock() != location.getBlock() && entity instanceof Entity) {
                        list.add(entity);
                    }
                }
            }
        }
        return list;
    }
    
    public static Location getCenter(final Location loc) {
        return loc.clone().add(0.5, 0.0, 0.5);
    }
    
    public static ArrayList<Location> getCircle(final Location center, final double radius, final int amount) {
        final World world = center.getWorld();
        final double n = 6.283185307179586 / amount;
        final ArrayList<Location> list = new ArrayList<Location>();
        for (int i = 0; i < amount; ++i) {
            final double n2 = i * n;
            list.add(new Location(world, center.getX() + radius * Math.cos(n2), center.getY(), center.getZ() + radius * Math.sin(n2)));
        }
        return list;
    }
    
    public static Location lookAt(Location from, final Location to, final float aiming) {
        from = from.clone();
        final double a = to.getX() - from.getX();
        final double n = to.getY() - from.getY();
        final double a2 = to.getZ() - from.getZ();
        if (a != 0.0) {
            if (a < 0.0) {
                from.setYaw(4.712389f);
            }
            else {
                from.setYaw(1.5707964f);
            }
            from.setYaw(from.getYaw() - (float)Math.atan(a2 / a));
        }
        else if (a2 < 0.0) {
            from.setYaw(3.1415927f);
        }
        from.setPitch((float)(-Math.atan(n / Math.sqrt(Math.pow(a, 2.0) + Math.pow(a2, 2.0)))));
        float n2 = 360.0f - aiming * 360.0f / 100.0f;
        if (n2 > 0.0f) {
            n2 = (float)UtilMath.getRandom((int)n2, (int)(-n2));
        }
        float n3 = 180.0f - aiming * 180.0f / 100.0f;
        if (n3 > 0.0f) {
            n3 = (float)UtilMath.getRandom((int)n3, (int)(-n3));
        }
        from.setYaw(-from.getYaw() * 180.0f / 3.1415927f + n2);
        from.setPitch(from.getPitch() * 180.0f / 3.1415927f + n3);
        return from;
    }
    
    static {
        axis = new BlockFace[] { BlockFace.NORTH, BlockFace.EAST, BlockFace.SOUTH, BlockFace.WEST };
        radial = new BlockFace[] { BlockFace.NORTH, BlockFace.NORTH_EAST, BlockFace.EAST, BlockFace.SOUTH_EAST, BlockFace.SOUTH, BlockFace.SOUTH_WEST, BlockFace.WEST, BlockFace.NORTH_WEST };
    }
}

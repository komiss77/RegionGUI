// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;
import java.util.NavigableMap;

public class RomanNumsUtil
{
    private static final NavigableMap<Integer, String> reversed;
    private static final TreeMap<Integer, String> romanNums;
    
    public static int fromRoman(String roman) {
        roman = roman.toUpperCase();
        int n = 0;
        for (final Map.Entry<Object, Object> entry : RomanNumsUtil.reversed.entrySet()) {
            final String prefix = entry.getValue();
            final int intValue = entry.getKey();
            while (roman.startsWith(prefix)) {
                n += intValue;
                roman = roman.substring(prefix.length());
            }
        }
        return n;
    }
    
    public static String toRoman(int num) {
        final StringBuilder sb = new StringBuilder();
        while (num > 0) {
            final Map.Entry<Integer, String> floorEntry = RomanNumsUtil.romanNums.floorEntry(num);
            num -= floorEntry.getKey();
            sb.append(floorEntry.getValue());
        }
        return sb.toString();
    }
    
    static {
        (romanNums = new TreeMap<Integer, String>()).put(1, "I");
        RomanNumsUtil.romanNums.put(4, "IV");
        RomanNumsUtil.romanNums.put(5, "V");
        RomanNumsUtil.romanNums.put(9, "IX");
        RomanNumsUtil.romanNums.put(10, "X");
        RomanNumsUtil.romanNums.put(40, "XL");
        RomanNumsUtil.romanNums.put(50, "L");
        RomanNumsUtil.romanNums.put(90, "XC");
        RomanNumsUtil.romanNums.put(100, "C");
        RomanNumsUtil.romanNums.put(400, "CD");
        RomanNumsUtil.romanNums.put(500, "D");
        RomanNumsUtil.romanNums.put(900, "CM");
        RomanNumsUtil.romanNums.put(1000, "M");
        RomanNumsUtil.romanNums.put(4000, "MV\u00cc\u2026");
        RomanNumsUtil.romanNums.put(5000, "V\u00cc\u2026");
        RomanNumsUtil.romanNums.put(9000, "MX\u00cc\u2026");
        RomanNumsUtil.romanNums.put(10000, "X\u00cc\u2026");
        RomanNumsUtil.romanNums.put(40000, "X\u00cc\u2026L\u00cc\u2026");
        RomanNumsUtil.romanNums.put(50000, "L\u00cc\u2026");
        RomanNumsUtil.romanNums.put(90000, "X\u00cc\u2026C\u00cc\u2026");
        RomanNumsUtil.romanNums.put(100000, "C\u00cc\u2026");
        RomanNumsUtil.romanNums.put(400000, "C\u00cc\u2026D\u00cc\u2026");
        RomanNumsUtil.romanNums.put(500000, "D\u00cc\u2026");
        RomanNumsUtil.romanNums.put(900000, "C\u00cc\u2026M\u00cc\u2026");
        RomanNumsUtil.romanNums.put(1000000, "M\u00cc\u2026");
        reversed = RomanNumsUtil.romanNums.descendingMap();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import org.bukkit.Keyed;
import org.bukkit.inventory.ItemStack;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.data.BlockData;
import com.google.common.collect.Sets;
import com.google.common.collect.Lists;
import java.util.Collection;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.List;
import java.util.function.Predicate;
import java.util.Set;
import org.bukkit.NamespacedKey;
import org.bukkit.Material;
import org.bukkit.Tag;

public class MaterialSet implements Tag<Material>
{
    private final NamespacedKey key;
    private final Set<Material> materials;
    
    public MaterialSet(final NamespacedKey key, final Predicate<Material> filter) {
        this(key, (Collection<Material>)Stream.of(Material.values()).filter(filter).collect((Collector<? super Material, ?, List<? super Material>>)Collectors.toList()));
    }
    
    public MaterialSet(final NamespacedKey key, final Material... materials) {
        this(key, Lists.newArrayList((Object[])materials));
    }
    
    public MaterialSet(final NamespacedKey key, final Collection<Material> materials) {
        this.key = key;
        this.materials = (Set<Material>)Sets.newEnumSet((Iterable)materials, (Class)Material.class);
    }
    
    public NamespacedKey getKey() {
        return this.key;
    }
    
    public MaterialSet add(final Tag<Material>... tags) {
        for (int length = tags.length, i = 0; i < length; ++i) {
            this.add(tags[i].getValues());
        }
        return this;
    }
    
    public MaterialSet add(final MaterialSet... tags) {
        for (int length = tags.length, i = 0; i < length; ++i) {
            this.add(((Tag)tags[i]).getValues());
        }
        return this;
    }
    
    public MaterialSet add(final Material... material) {
        this.materials.addAll(Lists.newArrayList((Object[])material));
        return this;
    }
    
    public MaterialSet add(final Collection<Material> materials) {
        this.materials.addAll(materials);
        return this;
    }
    
    public MaterialSet contains(final String with) {
        return this.add(material -> material.name().contains(with));
    }
    
    public MaterialSet endsWith(final String with) {
        return this.add(material -> material.name().endsWith(with));
    }
    
    public MaterialSet startsWith(final String with) {
        return this.add(material -> material.name().startsWith(with));
    }
    
    public MaterialSet add(final Predicate<Material> filter) {
        this.add((Collection<Material>)Stream.of(Material.values()).filter(((Predicate<? super Material>)Material::isLegacy).negate()).filter(filter).collect((Collector<? super Material, ?, List<? super Material>>)Collectors.toList()));
        return this;
    }
    
    public MaterialSet not(final MaterialSet tags) {
        this.not(tags.getValues());
        return this;
    }
    
    public MaterialSet not(final Material... material) {
        this.materials.removeAll(Lists.newArrayList((Object[])material));
        return this;
    }
    
    public MaterialSet not(final Collection<Material> materials) {
        this.materials.removeAll(materials);
        return this;
    }
    
    public MaterialSet not(final Predicate<Material> filter) {
        this.not((Collection<Material>)Stream.of(Material.values()).filter(((Predicate<? super Material>)Material::isLegacy).negate()).filter(filter).collect((Collector<? super Material, ?, List<? super Material>>)Collectors.toList()));
        return this;
    }
    
    public MaterialSet notEndsWith(final String with) {
        return this.not(material -> material.name().endsWith(with));
    }
    
    public MaterialSet notStartsWith(final String with) {
        return this.not(material -> material.name().startsWith(with));
    }
    
    public Set<Material> getValues() {
        return this.materials;
    }
    
    public boolean isTagged(final BlockData block) {
        return this.isTagged(block.getMaterial());
    }
    
    public boolean isTagged(final BlockState block) {
        return this.isTagged(block.getType());
    }
    
    public boolean isTagged(final Block block) {
        return this.isTagged(block.getType());
    }
    
    public boolean isTagged(final ItemStack item) {
        return this.isTagged(item.getType());
    }
    
    public boolean isTagged(final Material material) {
        return this.materials.contains(material);
    }
}

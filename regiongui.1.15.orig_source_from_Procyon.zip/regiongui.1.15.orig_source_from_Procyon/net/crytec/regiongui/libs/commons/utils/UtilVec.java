// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.util.ArrayList;
import java.util.List;
import org.bukkit.entity.Player;
import org.bukkit.Location;
import org.bukkit.util.Vector;
import org.bukkit.entity.Entity;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Set;

public class UtilVec
{
    public static TreeSet<String> sortKey(final Set<String> toSort) {
        final TreeSet<String> set = new TreeSet<String>();
        final Iterator<String> iterator = toSort.iterator();
        while (iterator.hasNext()) {
            set.add(iterator.next());
        }
        return set;
    }
    
    public static Vector getTrajectory(final Entity from, final Entity to) {
        return getTrajectory(from.getLocation().toVector(), to.getLocation().toVector());
    }
    
    public static Vector getTrajectory(final Location from, final Location to) {
        return getTrajectory(from.toVector(), to.toVector());
    }
    
    public static Vector getTrajectory(final Vector from, final Vector to) {
        return to.subtract(from).normalize();
    }
    
    public static Vector getTrajectory2d(final Entity from, final Entity to) {
        return getTrajectory2d(from.getLocation().toVector(), to.getLocation().toVector());
    }
    
    public static Vector getTrajectory2d(final Location from, final Location to) {
        return getTrajectory2d(from.toVector(), to.toVector());
    }
    
    public static Vector getTrajectory2d(final Vector from, final Vector to) {
        return to.subtract(from).setY(0).normalize();
    }
    
    public static boolean HasSight(final Location from, final Player to) {
        return HasSight(from, to.getLocation()) || HasSight(from, to.getEyeLocation());
    }
    
    public static boolean HasSight(final Location from, final Location to) {
        final Location a = new Location(from.getWorld(), from.getX(), from.getY(), from.getZ());
        final Vector multiply = getTrajectory(from, to).multiply(0.1);
        while (UtilMath.offset(a, to) > 0.1) {
            a.add(multiply);
            if (a.getBlock().getType().isSolid()) {
                return false;
            }
        }
        return true;
    }
    
    public static Vector cross(final Vector a, final Vector b) {
        return new Vector(a.getY() * b.getZ() - a.getZ() * b.getY(), a.getZ() * b.getX() - a.getX() * b.getZ(), a.getX() * b.getY() - a.getY() * b.getX()).normalize();
    }
    
    public static Vector getRight(final Vector vec) {
        return cross(vec.clone().normalize(), new Vector(0, 1, 0));
    }
    
    public static Vector getLeft(final Vector vec) {
        return getRight(vec).multiply(-1);
    }
    
    public static Vector getBehind(final Vector vec) {
        return vec.clone().multiply(-1);
    }
    
    public static Vector getUp(final Vector vec) {
        return getDown(vec).multiply(-1);
    }
    
    public static Vector getDown(final Vector vec) {
        return cross(vec, getRight(vec));
    }
    
    public static float GetPitch(final Vector vec) {
        final double x = vec.getX();
        final double y = vec.getY();
        final double z = vec.getZ();
        final double degrees = Math.toDegrees(Math.atan(Math.sqrt(x * x + z * z) / y));
        double n;
        if (y <= 0.0) {
            n = degrees + 90.0;
        }
        else {
            n = degrees - 90.0;
        }
        return (float)n;
    }
    
    public static float GetYaw(final Vector vec) {
        final double x = vec.getX();
        final double z = vec.getZ();
        double degrees = Math.toDegrees(Math.atan(-x / z));
        if (z < 0.0) {
            degrees += 180.0;
        }
        return (float)degrees;
    }
    
    public static Vector Normalize(final Vector vec) {
        if (vec.length() > 0.0) {
            vec.normalize();
        }
        return vec;
    }
    
    public static Vector Clone(final Vector vec) {
        return new Vector(vec.getX(), vec.getY(), vec.getZ());
    }
    
    public static <T> T Random(final List<T> list) {
        return list.get(UtilMath.r(list.size()));
    }
    
    public static Vector bumpEntity(final Entity entity, final double power) {
        final Vector add = entity.getLocation().toVector().add(new Vector(0.0, 1.0, 0.0));
        add.multiply(power);
        return add;
    }
    
    public static Vector getPushVector(final Entity entity, final Location from, final double power) {
        final Vector normalize = entity.getLocation().toVector().subtract(from.toVector()).normalize();
        normalize.multiply(power);
        return normalize;
    }
    
    public static Vector getPullVector(final Entity entity, final Location to, final double power) {
        final Vector normalize = to.toVector().subtract(entity.getLocation().toVector()).normalize();
        normalize.multiply(power);
        return normalize;
    }
    
    public static void pushEntity(final Entity entity, final Location from, final double power) {
        entity.setVelocity(getPushVector(entity, from, power));
    }
    
    public static void pushEntity(final Entity entity, final Location from, final double power, final double fixedY) {
        final Vector pushVector = getPushVector(entity, from, power);
        pushVector.setY(fixedY);
        entity.setVelocity(pushVector);
    }
    
    public static void pullEntity(final Entity entity, final Location to, final double power) {
        entity.setVelocity(getPullVector(entity, to, power));
    }
    
    public static void pullEntity(final Entity entity, final Location from, final double power, final double fixedY) {
        final Vector pullVector = getPullVector(entity, from, power);
        pullVector.setY(fixedY);
        entity.setVelocity(pullVector);
    }
    
    public static void velocity(final Entity ent, final double str, final double yAdd, final double yMax, final boolean groundBoost) {
        velocity(ent, ent.getLocation().getDirection(), str, false, 0.0, yAdd, yMax, groundBoost);
    }
    
    public static void velocity(final Entity ent, final Vector vec, final double str, final boolean ySet, final double yBase, final double yAdd, final double yMax, final boolean groundBoost) {
        if (Double.isNaN(vec.getX()) || Double.isNaN(vec.getY()) || Double.isNaN(vec.getZ()) || vec.length() == 0.0) {
            return;
        }
        if (ySet) {
            vec.setY(yBase);
        }
        vec.normalize();
        vec.multiply(str);
        vec.setY(vec.getY() + yAdd);
        if (vec.getY() > yMax) {
            vec.setY(yMax);
        }
        if (groundBoost && ent.isOnGround()) {
            vec.setY(vec.getY() + 0.2);
        }
        ent.setFallDistance(0.0f);
        ent.setVelocity(vec);
    }
    
    public static Location getLocationAwayFromPlayers(final ArrayList<Location> locs, final ArrayList<Player> players) {
        Location location = null;
        double n = 0.0;
        for (final Location b : locs) {
            double n2 = -1.0;
            for (final Player player : players) {
                if (!player.getWorld().equals(b.getWorld())) {
                    continue;
                }
                final double offsetSquared = UtilMath.offsetSquared(player.getLocation(), b);
                if (n2 != -1.0 && offsetSquared >= n2) {
                    continue;
                }
                n2 = offsetSquared;
            }
            if (n2 == -1.0) {
                continue;
            }
            if (location != null && n2 <= n) {
                continue;
            }
            location = b;
            n = n2;
        }
        return location;
    }
    
    public static Location getLocationNearPlayers(final ArrayList<Location> locs, final ArrayList<Player> players, final ArrayList<Player> dontOverlap) {
        Location location = null;
        double n = 0.0;
        for (final Location location2 : locs) {
            double n2 = -1.0;
            boolean b = true;
            for (final Player player : dontOverlap) {
                if (!player.getWorld().equals(location2.getWorld())) {
                    continue;
                }
                if (UtilMath.offsetSquared(player.getLocation(), location2) < 0.8) {
                    b = false;
                    break;
                }
            }
            if (!b) {
                continue;
            }
            for (final Player player2 : players) {
                if (!player2.getWorld().equals(location2.getWorld())) {
                    continue;
                }
                final double offsetSquared = UtilMath.offsetSquared(player2.getLocation(), location2);
                if (n2 != -1.0 && offsetSquared >= n2) {
                    continue;
                }
                n2 = offsetSquared;
            }
            if (n2 == -1.0) {
                continue;
            }
            if (location != null && n2 >= n) {
                continue;
            }
            location = location2;
            n = n2;
        }
        return location;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils.item;

import org.bukkit.attribute.AttributeModifier;
import java.util.UUID;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.attribute.Attribute;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.meta.SkullMeta;
import net.crytec.regiongui.libs.apache.commons.Validate;
import org.bukkit.OfflinePlayer;
import java.util.Iterator;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.meta.Damageable;
import java.util.Collection;
import java.util.List;
import com.google.common.collect.Lists;
import org.bukkit.Material;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.ItemStack;

public class ItemBuilder
{
    private final ItemStack item;
    private final ItemMeta meta;
    
    public ItemBuilder(final Material material) {
        this.item = new ItemStack(material);
        this.meta = this.item.getItemMeta();
    }
    
    public ItemBuilder(final ItemStack item) {
        this.item = item;
        this.meta = item.getItemMeta();
    }
    
    public ItemStack build() {
        this.item.setItemMeta(this.meta);
        return this.item;
    }
    
    public ItemBuilder amount(final int amount) {
        this.item.setAmount(amount);
        return this;
    }
    
    public ItemBuilder name(final String name) {
        this.meta.setDisplayName(name);
        return this;
    }
    
    public ItemBuilder lore(final String string) {
        final List lore = this.meta.hasLore() ? this.meta.getLore() : Lists.newArrayList();
        lore.add(string);
        this.meta.setLore(lore);
        return this;
    }
    
    public ItemBuilder lore(final String string, final int index) {
        final List lore = this.meta.hasLore() ? this.meta.getLore() : Lists.newArrayList();
        lore.set(index, string);
        this.meta.setLore(lore);
        return this;
    }
    
    public ItemBuilder lore(final List<String> lore) {
        final List lore2 = this.meta.hasLore() ? this.meta.getLore() : Lists.newArrayList();
        lore2.addAll(lore);
        this.meta.setLore(lore2);
        return this;
    }
    
    public ItemBuilder setUnbreakable(final boolean unbreakable) {
        this.meta.setUnbreakable(unbreakable);
        return this;
    }
    
    public ItemBuilder setDurability(final int durability) {
        ((Damageable)this.meta).setDamage(durability);
        return this;
    }
    
    public ItemBuilder enchantment(final Enchantment enchantment, final int level) {
        if (level <= 0) {
            this.meta.removeEnchant(enchantment);
        }
        else {
            this.meta.addEnchant(enchantment, level, true);
        }
        return this;
    }
    
    public ItemBuilder enchantment(final Enchantment enchantment) {
        this.meta.addEnchant(enchantment, 1, true);
        return this;
    }
    
    public ItemBuilder type(final Material material) {
        this.item.setType(material);
        return this;
    }
    
    public ItemBuilder clearLore() {
        this.meta.setLore((List)Lists.newArrayList());
        return this;
    }
    
    public ItemBuilder clearEnchantment() {
        final Iterator<Enchantment> iterator = this.item.getEnchantments().keySet().iterator();
        while (iterator.hasNext()) {
            this.item.removeEnchantment((Enchantment)iterator.next());
        }
        return this;
    }
    
    public ItemBuilder setSkullOwner(final OfflinePlayer player) {
        Validate.isTrue(this.item.getType() == Material.PLAYER_HEAD, "skullOwner() only applicable for skulls!", new Object[0]);
        final SkullMeta itemMeta = (SkullMeta)this.meta;
        itemMeta.setOwningPlayer(player);
        this.item.setItemMeta((ItemMeta)itemMeta);
        return this;
    }
    
    public ItemBuilder setItemFlag(final ItemFlag flag) {
        this.meta.addItemFlags(new ItemFlag[] { flag });
        return this;
    }
    
    public ItemBuilder setAttribute(final Attribute attribute, final double amount, final EquipmentSlot slot) {
        this.meta.addAttributeModifier(attribute, new AttributeModifier(UUID.randomUUID(), "itembuilder", amount, AttributeModifier.Operation.ADD_NUMBER, slot));
        return this;
    }
    
    public ItemBuilder removeAttribute(final Attribute attribute) {
        this.meta.removeAttributeModifier(attribute);
        return this;
    }
    
    public ItemBuilder setModelData(final int data) {
        this.meta.setCustomModelData(Integer.valueOf(data));
        return this;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.util.Iterator;
import java.util.ArrayList;
import org.bukkit.block.BlockFace;
import org.bukkit.Material;
import java.util.HashSet;
import org.bukkit.World;
import org.bukkit.block.Block;
import java.util.HashMap;
import org.bukkit.Location;

public class UtilBlock
{
    public static HashMap<Block, Double> getInRadius(final Location loc, final double dR) {
        return getInRadius(loc, dR, 999.0);
    }
    
    public static HashMap<Block, Double> getInRadius(final Location loc, final double dR, final double heightLimit) {
        final HashMap<Block, Double> hashMap = new HashMap<Block, Double>();
        for (int n = (int)dR + 1, i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    if (Math.abs(k) <= heightLimit) {
                        final Block block = loc.getWorld().getBlockAt((int)(loc.getX() + i), (int)(loc.getY() + k), (int)(loc.getZ() + j));
                        final double offset = UtilMath.offset(loc, block.getLocation().add(0.5, 0.5, 0.5));
                        if (offset <= dR) {
                            hashMap.put(block, 1.0 - offset / dR);
                        }
                    }
                }
            }
        }
        return hashMap;
    }
    
    public static HashMap<Block, Double> getInRadius(final Block block, final double dR) {
        final HashMap<Block, Double> hashMap = new HashMap<Block, Double>();
        for (int n = (int)dR + 1, i = -n; i <= n; ++i) {
            for (int j = -n; j <= n; ++j) {
                for (int k = -n; k <= n; ++k) {
                    final Block relative = block.getRelative(i, k, j);
                    final double offset = UtilMath.offset(block.getLocation(), relative.getLocation());
                    if (offset <= dR) {
                        hashMap.put(relative, 1.0 - offset / dR);
                    }
                }
            }
        }
        return hashMap;
    }
    
    public static Block getHighest(final World world, final int x, final int z) {
        return getHighest(world, x, z, null);
    }
    
    public static Block getHighest(final World world, final int x, final int z, final HashSet<Material> ignore) {
        Block block;
        for (block = world.getHighestBlockAt(x, z); block.getType().isSolid() || block.getType().toString().contains("LEAVES") || (ignore != null && ignore.contains(block.getType())); block = block.getRelative(BlockFace.DOWN)) {}
        return block.getRelative(BlockFace.UP);
    }
    
    public static ArrayList<Block> getSurrounding(final Block block, final boolean diagonals) {
        final ArrayList<Block> list = new ArrayList<Block>();
        if (diagonals) {
            for (int i = -1; i <= 1; ++i) {
                for (int j = -1; j <= 1; ++j) {
                    for (int k = -1; k <= 1; ++k) {
                        if (i != 0 || j != 0 || k != 0) {
                            list.add(block.getRelative(i, j, k));
                        }
                    }
                }
            }
        }
        else {
            list.add(block.getRelative(BlockFace.UP));
            list.add(block.getRelative(BlockFace.DOWN));
            list.add(block.getRelative(BlockFace.NORTH));
            list.add(block.getRelative(BlockFace.SOUTH));
            list.add(block.getRelative(BlockFace.EAST));
            list.add(block.getRelative(BlockFace.WEST));
        }
        return list;
    }
    
    public static boolean isVisible(final Block block) {
        final Iterator<Block> iterator = getSurrounding(block, false).iterator();
        while (iterator.hasNext()) {
            if (!iterator.next().getType().isOccluding()) {
                return true;
            }
        }
        return false;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.util.stream.StreamSupport;
import java.util.Iterator;
import java.util.Spliterators;
import java.util.stream.Stream;
import java.util.function.ToDoubleFunction;
import com.google.common.base.Preconditions;
import java.util.Collection;
import java.util.Random;
import java.util.function.ToIntFunction;

public final class RandomSelector<T>
{
    private final T[] elements;
    private final ToIntFunction<Random> selection;
    
    public static <T> RandomSelector<T> uniform(final Collection<T> elements) {
        Preconditions.checkNotNull((Object)elements, (Object)"collection must not be null");
        Preconditions.checkArgument(!elements.isEmpty(), (Object)"collection must not be empty");
        final int bound;
        return new RandomSelector<T>(elements.toArray(new Object[elements.size()]), random -> random.nextInt(bound));
    }
    
    public static <T> RandomSelector<T> weighted(final Collection<T> elements, final ToDoubleFunction<? super T> weighter) {
        Preconditions.checkNotNull((Object)elements, (Object)"elements must not be null");
        Preconditions.checkNotNull((Object)weighter, (Object)"weighter must not be null");
        Preconditions.checkArgument(!elements.isEmpty(), (Object)"elements must not be empty");
        final int size = elements.size();
        final T[] array = elements.toArray(new Object[size]);
        double n = 0.0;
        final double[] probabilities = new double[size];
        for (int i = 0; i < size; ++i) {
            final double applyAsDouble = weighter.applyAsDouble(array[i]);
            Preconditions.checkArgument(applyAsDouble > 0.0, (Object)"weighter returned a negative number");
            probabilities[i] = applyAsDouble;
            n += applyAsDouble;
        }
        for (int j = 0; j < size; ++j) {
            final double[] array2 = probabilities;
            final int n2 = j;
            array2[n2] /= n;
        }
        return new RandomSelector<T>(array, new RandomWeightedSelection(probabilities));
    }
    
    RandomSelector(final T[] elements, final ToIntFunction<Random> selection) {
        this.elements = elements;
        this.selection = selection;
    }
    
    public T next(final Random random) {
        return this.elements[this.selection.applyAsInt(random)];
    }
    
    public Stream<T> stream(final Random random) {
        Preconditions.checkNotNull((Object)random, (Object)"random must not be null");
        return StreamSupport.stream(Spliterators.spliteratorUnknownSize((Iterator<? extends T>)new BaseIterator(random), 1040), false);
    }
    
    private class BaseIterator implements Iterator<T>
    {
        private final Random random;
        
        BaseIterator(final Random random) {
            this.random = random;
        }
        
        @Override
        public boolean hasNext() {
            return true;
        }
        
        @Override
        public T next() {
            return RandomSelector.this.next(this.random);
        }
    }
    
    private static class RandomWeightedSelection implements ToIntFunction<Random>
    {
        private final double[] probabilities;
        private final int[] alias;
        
        RandomWeightedSelection(final double[] probabilities) {
            final int length = probabilities.length;
            final double n = 1.0 / length;
            final int[] array = new int[length];
            int i = 0;
            final int[] array2 = new int[length];
            int j = 0;
            for (int k = 0; k < length; ++k) {
                if (probabilities[k] < n) {
                    array[i++] = k;
                }
                else {
                    array2[j++] = k;
                }
            }
            final double[] probabilities2 = new double[length];
            final int[] alias = new int[length];
            this.probabilities = probabilities2;
            this.alias = alias;
            while (j != 0 && i != 0) {
                final int n2 = array[--i];
                final int n3 = array2[--j];
                probabilities2[n2] = probabilities[n2] * length;
                alias[n2] = n3;
                final int n4 = n3;
                probabilities[n4] += probabilities[n2] - n;
                if (probabilities[n3] < n) {
                    array[i++] = n3;
                }
                else {
                    array2[j++] = n3;
                }
            }
            while (i != 0) {
                probabilities2[array[--i]] = 1.0;
            }
            while (j != 0) {
                probabilities2[array2[--j]] = 1.0;
            }
        }
        
        @Override
        public int applyAsInt(final Random random) {
            final int nextInt = random.nextInt(this.probabilities.length);
            return (random.nextDouble() < this.probabilities[nextInt]) ? nextInt : this.alias[nextInt];
        }
    }
}

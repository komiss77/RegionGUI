// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import org.bukkit.ChunkSnapshot;
import org.bukkit.Location;
import com.google.common.base.Preconditions;
import org.bukkit.World;
import org.bukkit.Chunk;

public class UtilChunk
{
    public static long getChunkKey(final int x, final int z) {
        return ((long)x & 0xFFFFFFFFL) | ((long)z & 0xFFFFFFFFL) << 32;
    }
    
    public static long getChunkKey(final Chunk chunk) {
        return ((long)chunk.getX() & 0xFFFFFFFFL) | ((long)chunk.getZ() & 0xFFFFFFFFL) << 32;
    }
    
    public static Chunk keyToChunk(final World world, final long chunkID) {
        Preconditions.checkArgument(world != null, (Object)"World cannot be null");
        return world.getChunkAt((int)chunkID, (int)(chunkID >> 32));
    }
    
    public static boolean isChunkLoaded(final Location loc) {
        return loc.getWorld().isChunkLoaded(loc.getBlockX() >> 4, loc.getBlockZ() >> 4);
    }
    
    public static long getChunkKey(final Location loc) {
        return getChunkKey(loc.getBlockX() >> 4, loc.getBlockZ() >> 4);
    }
    
    public static long getChunkKey(final ChunkSnapshot chunk) {
        return ((long)chunk.getX() & 0xFFFFFFFFL) | ((long)chunk.getZ() & 0xFFFFFFFFL) << 32;
    }
}

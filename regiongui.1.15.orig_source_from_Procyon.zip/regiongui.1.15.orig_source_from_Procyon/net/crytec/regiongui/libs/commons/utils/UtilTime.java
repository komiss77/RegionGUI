// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import net.crytec.regiongui.libs.apache.commons.time.DurationFormatUtils;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.time.chrono.ChronoLocalDateTime;
import java.time.LocalDateTime;
import java.time.temporal.Temporal;
import java.time.Duration;
import java.time.Instant;

public class UtilTime
{
    public static String getElapsedTime(final long timestamp) {
        return getElapsedTime(millisToLocalDate(timestamp));
    }
    
    public static int getElapsedTimeInSeconds(final long start) {
        return (int)Duration.between(millisToInstant(start), Instant.now()).toMillis() / 1000;
    }
    
    public static String getElapsedTime(final LocalDateTime startdate) {
        final Duration between = Duration.between(localDateToInstant(startdate), localDateToInstant(LocalDateTime.now()));
        final StringBuilder sb = new StringBuilder();
        if (between.toDays() > 0L) {
            sb.append(between.toDays() + ((between.toDays() > 1L) ? " Tage " : " Tag "));
        }
        if (between.toHours() % 24L > 0L) {
            sb.append(between.toHours() % 24L + ((between.toHours() % 24L > 1L) ? " Stunden " : " Stunde "));
        }
        if (between.toMinutes() % 60L > 0L) {
            sb.append(between.toMinutes() % 60L + ((between.toMinutes() % 60L > 1L) ? " Minuten " : " Minute "));
        }
        if (between.getSeconds() % 60L > 0L) {
            sb.append(between.getSeconds() % 60L + ((between.getSeconds() % 60L > 1L) ? " Sekunden" : " Sekunde"));
        }
        return sb.toString();
    }
    
    public static String between(final LocalDateTime startdate, final LocalDateTime endDate) {
        final Duration between = Duration.between(localDateToInstant(startdate), localDateToInstant(endDate));
        final StringBuilder sb = new StringBuilder();
        if (between.toDays() > 0L) {
            sb.append(between.toDays() + ((between.toDays() > 1L) ? " Tage " : " Tag "));
        }
        if (between.toHours() % 24L > 0L) {
            sb.append(between.toHours() % 24L + ((between.toHours() % 24L > 1L) ? " Stunden " : " Stunde "));
        }
        if (between.toMinutes() % 60L > 0L) {
            sb.append(between.toMinutes() % 60L + ((between.toMinutes() % 60L > 1L) ? " Minuten " : " Minute "));
        }
        if (between.getSeconds() % 60L > 0L) {
            sb.append(between.getSeconds() % 60L + ((between.getSeconds() % 60L > 1L) ? " Sekunden" : " Sekunde"));
        }
        return sb.toString();
    }
    
    public static String getTimeUntil(final long timestamp, final String expired) {
        return getTimeUntil(millisToLocalDate(timestamp), expired);
    }
    
    public static String getTimeUntil(final long timestamp) {
        return getTimeUntil(timestamp, null);
    }
    
    public static String getTimeUntil(final LocalDateTime endDate) {
        return getTimeUntil(endDate, null);
    }
    
    public static String getTimeUntil(final LocalDateTime endDate, final String expired) {
        if (isElapsed(endDate)) {
            return (expired != null) ? expired : "Expired";
        }
        final Duration between = Duration.between(localDateToInstant(LocalDateTime.now()), localDateToInstant(endDate));
        final StringBuilder sb = new StringBuilder();
        if (between.toDays() > 0L) {
            sb.append(between.toDays() + ((between.toDays() > 1L) ? " Tage " : " Tag "));
        }
        if (between.toHours() % 24L > 0L) {
            sb.append(between.toHours() % 24L + ((between.toHours() % 24L > 1L) ? " Stunden " : " Stunde "));
        }
        if (between.toMinutes() % 60L > 0L) {
            sb.append(between.toMinutes() % 60L + ((between.toMinutes() % 60L > 1L) ? " Minuten " : " Minute "));
        }
        if (between.getSeconds() % 60L > 0L) {
            sb.append(between.getSeconds() % 60L + ((between.getSeconds() % 60L > 1L) ? " Sekunden" : " Sekunde"));
        }
        return sb.toString();
    }
    
    public static boolean isElapsed(final LocalDateTime endDate) {
        return LocalDateTime.now().isAfter(endDate);
    }
    
    public static boolean isElapsed(final long timestamp) {
        return isElapsed(millisToLocalDate(timestamp));
    }
    
    public static LocalDateTime millisToLocalDate(final long timestamp) {
        return Instant.ofEpochMilli(timestamp).atZone(ZoneId.systemDefault()).toLocalDateTime();
    }
    
    public static long LocalDateToMillis(final LocalDateTime timestamp) {
        return timestamp.toInstant(OffsetDateTime.now().getOffset()).toEpochMilli();
    }
    
    public static Instant millisToInstant(final long timestamp) {
        return Instant.ofEpochMilli(timestamp);
    }
    
    public static Instant localDateToInstant(final LocalDateTime timestamp) {
        return timestamp.toInstant(OffsetDateTime.now().getOffset());
    }
    
    public static LocalDateTime instantToLocalDate(final Instant instant) {
        return instant.atZone(ZoneId.systemDefault()).toLocalDateTime();
    }
    
    public static String now() {
        return DurationFormatUtils.formatDuration(LocalDateToMillis(LocalDateTime.now()), "HH:mm:ss", false);
    }
    
    public static String when(final LocalDateTime destinationDate) {
        return destinationDate.format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss"));
    }
    
    public static String when(final long destinationTime) {
        return millisToLocalDate(destinationTime).format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm:ss"));
    }
    
    public static String date() {
        return LocalDate.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy"));
    }
}

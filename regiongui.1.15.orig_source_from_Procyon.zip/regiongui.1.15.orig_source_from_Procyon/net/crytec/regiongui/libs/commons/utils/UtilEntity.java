// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.util.Optional;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import net.crytec.regiongui.libs.apache.commons.EnumUtils;
import org.bukkit.Material;
import org.bukkit.entity.EntityType;

public class UtilEntity
{
    public static Material getSpawnEgg(final EntityType type) {
        if (!EnumUtils.isValidEnum((Class<Enum>)Material.class, type.toString() + "_SPAWN_EGG")) {
            return Material.BARRIER;
        }
        return Material.valueOf(type.toString() + "_SPAWN_EGG");
    }
    
    public static boolean isInRadius(final Entity entity, final Location loc, final double radius) {
        return Math.sqrt(Math.pow(loc.getX() - entity.getLocation().getX(), 2.0) + Math.pow(loc.getY() - entity.getLocation().getY(), 2.0) + Math.pow(loc.getZ() - entity.getLocation().getZ(), 2.0)) <= radius;
    }
    
    public static CreatureSpawnEvent.SpawnReason getSpawnReason(final Entity entity) {
        final Optional first = entity.getScoreboardTags().stream().filter(s -> s.startsWith("ct:corespawnreason;")).findFirst();
        return first.isPresent() ? CreatureSpawnEvent.SpawnReason.valueOf(first.get().replace("ctcore:spawnreason;", "")) : CreatureSpawnEvent.SpawnReason.CUSTOM;
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.commons.utils;

import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.Date;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Set;
import java.util.Map;

public final class DateTickFormat
{
    public static final Map<String, Integer> nameToTicks;
    public static final Set<String> resetAliases;
    public static final int ticksAtMidnight = 18000;
    public static final int ticksPerDay = 24000;
    public static final int ticksPerHour = 1000;
    public static final double ticksPerMinute = 16.666666666666668;
    public static final double ticksPerSecond = 0.2777777777777778;
    private static final SimpleDateFormat SDFTwentyFour;
    
    public static long parse(String desc) {
        desc = desc.toLowerCase(Locale.ENGLISH).replaceAll("[^A-Za-z0-9:]", "");
        try {
            return parseTicks(desc);
        }
        catch (NumberFormatException ex) {
            try {
                return parse24(desc);
            }
            catch (NumberFormatException ex2) {
                try {
                    return parseAlias(desc);
                }
                catch (NumberFormatException ex3) {
                    throw new NumberFormatException();
                }
            }
        }
    }
    
    public static long parseTicks(String desc) {
        if (!desc.matches("^[0-9]+ti?c?k?s?$")) {
            throw new NumberFormatException();
        }
        desc = desc.replaceAll("[^0-9]", "");
        return Long.parseLong(desc) % 24000L;
    }
    
    public static long parse24(String desc) {
        if (!desc.matches("^[0-9]{2}[^0-9]?[0-9]{2}$")) {
            throw new NumberFormatException();
        }
        desc = desc.toLowerCase(Locale.ENGLISH).replaceAll("[^0-9]", "");
        if (desc.length() != 4) {
            throw new NumberFormatException();
        }
        return hoursMinutesToTicks(Integer.parseInt(desc.substring(0, 2)), Integer.parseInt(desc.substring(2, 4)));
    }
    
    public static long hoursMinutesToTicks(final int hours, final int minutes) {
        return (long)(18000L + hours * 1000 + minutes / 60.0 * 1000.0) % 24000L;
    }
    
    public static long parseAlias(final String desc) {
        final Integer n = DateTickFormat.nameToTicks.get(desc);
        if (n == null) {
            throw new NumberFormatException();
        }
        return n;
    }
    
    public static boolean meansReset(final String desc) {
        return DateTickFormat.resetAliases.contains(desc);
    }
    
    public static String format(final long ticks) {
        return format24(ticks);
    }
    
    public static String formatTicks(final long ticks) {
        return ticks % 24000L + "ticks";
    }
    
    public static String format24(final long ticks) {
        synchronized (DateTickFormat.SDFTwentyFour) {
            return formatDateFormat(ticks, DateTickFormat.SDFTwentyFour);
        }
    }
    
    public static String formatDateFormat(final long ticks, final SimpleDateFormat format) {
        return format.format(ticksToDate(ticks));
    }
    
    public static Date ticksToDate(long ticks) {
        ticks = ticks - 18000L + 24000L;
        final long n = ticks / 24000L;
        ticks -= n * 24000L;
        final long n2 = ticks / 1000L;
        ticks -= n2 * 1000L;
        final long n3 = (long)Math.floor(ticks / 16.666666666666668);
        final long n4 = (long)Math.floor((ticks - n3 * 16.666666666666668) / 0.2777777777777778);
        final Calendar instance = Calendar.getInstance(TimeZone.getTimeZone("GMT"), Locale.ENGLISH);
        instance.setLenient(true);
        instance.set(0, 0, 1, 0, 0, 0);
        instance.add(6, (int)n);
        instance.add(11, (int)n2);
        instance.add(12, (int)n3);
        instance.add(13, (int)n4 + 1);
        return instance.getTime();
    }
    
    static {
        nameToTicks = new LinkedHashMap<String, Integer>();
        resetAliases = new HashSet<String>();
        (SDFTwentyFour = new SimpleDateFormat("HH:mm", Locale.ENGLISH)).setTimeZone(TimeZone.getTimeZone("GMT"));
        DateTickFormat.nameToTicks.put("sunrise", 23000);
        DateTickFormat.nameToTicks.put("dawn", 23000);
        DateTickFormat.nameToTicks.put("daystart", 0);
        DateTickFormat.nameToTicks.put("day", 0);
        DateTickFormat.nameToTicks.put("morning", 1000);
        DateTickFormat.nameToTicks.put("midday", 6000);
        DateTickFormat.nameToTicks.put("noon", 6000);
        DateTickFormat.nameToTicks.put("afternoon", 9000);
        DateTickFormat.nameToTicks.put("sunset", 12000);
        DateTickFormat.nameToTicks.put("dusk", 12000);
        DateTickFormat.nameToTicks.put("sundown", 12000);
        DateTickFormat.nameToTicks.put("nightfall", 12000);
        DateTickFormat.nameToTicks.put("nightstart", 14000);
        DateTickFormat.nameToTicks.put("night", 14000);
        DateTickFormat.nameToTicks.put("midnight", 18000);
        DateTickFormat.resetAliases.add("reset");
        DateTickFormat.resetAliases.add("normal");
        DateTickFormat.resetAliases.add("default");
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.timings.lib;

import co.aikar.timings.Timings;
import org.bukkit.plugin.Plugin;
import co.aikar.timings.Timing;

class MinecraftTiming extends MCTiming
{
    private final Timing timing;
    
    MinecraftTiming(final Plugin plugin, final String name, final MCTiming parent) {
        this.timing = Timings.of(plugin, name, (parent instanceof MinecraftTiming) ? ((MinecraftTiming)parent).timing : null);
    }
    
    @Override
    public MCTiming startTiming() {
        this.timing.startTimingIfSync();
        return this;
    }
    
    @Override
    public void stopTiming() {
        this.timing.stopTimingIfSync();
    }
}

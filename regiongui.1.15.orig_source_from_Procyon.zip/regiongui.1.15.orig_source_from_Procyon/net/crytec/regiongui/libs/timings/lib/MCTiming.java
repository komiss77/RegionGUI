// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.timings.lib;

public abstract class MCTiming implements AutoCloseable
{
    public abstract MCTiming startTiming();
    
    public abstract void stopTiming();
    
    @Override
    public void close() {
        this.stopTiming();
    }
}

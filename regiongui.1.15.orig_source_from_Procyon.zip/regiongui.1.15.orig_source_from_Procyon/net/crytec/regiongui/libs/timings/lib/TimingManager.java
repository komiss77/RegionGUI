// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.timings.lib;

import java.util.HashMap;
import java.util.Map;
import org.bukkit.plugin.Plugin;

public class TimingManager
{
    private static TimingType timingProvider;
    private static final Object LOCK;
    private final Plugin plugin;
    private final Map<String, MCTiming> timingCache;
    
    private TimingManager(final Plugin plugin) {
        this.timingCache = new HashMap<String, MCTiming>(0);
        this.plugin = plugin;
    }
    
    public static TimingManager of(final Plugin plugin) {
        return new TimingManager(plugin);
    }
    
    public MCTiming ofStart(final String name) {
        return this.ofStart(name, null);
    }
    
    public MCTiming ofStart(final String name, final MCTiming parent) {
        return this.of(name, parent).startTiming();
    }
    
    public MCTiming of(final String name) {
        return this.of(name, null);
    }
    
    public MCTiming of(final String name, final MCTiming parent) {
        if (TimingManager.timingProvider == null) {
            synchronized (TimingManager.LOCK) {
                if (TimingManager.timingProvider == null) {
                    try {
                        final Class<?> forName = Class.forName("co.aikar.timings.Timing");
                        if (forName.getMethod("startTiming", (Class<?>[])new Class[0]).getReturnType() != forName) {
                            TimingManager.timingProvider = TimingType.MINECRAFT_18;
                        }
                        else {
                            TimingManager.timingProvider = TimingType.MINECRAFT;
                        }
                    }
                    catch (ClassNotFoundException | NoSuchMethodException ex) {
                        try {
                            Class.forName("org.spigotmc.CustomTimingsHandler");
                            TimingManager.timingProvider = TimingType.SPIGOT;
                        }
                        catch (ClassNotFoundException ex2) {
                            TimingManager.timingProvider = TimingType.EMPTY;
                        }
                    }
                }
            }
        }
        if (TimingManager.timingProvider.useCache()) {
            MCTiming timing;
            synchronized (this.timingCache) {
                final String lowerCase = name.toLowerCase();
                timing = this.timingCache.get(lowerCase);
                if (timing == null) {
                    timing = TimingManager.timingProvider.newTiming(this.plugin, name, parent);
                    this.timingCache.put(lowerCase, timing);
                }
            }
            return timing;
        }
        return TimingManager.timingProvider.newTiming(this.plugin, name, parent);
    }
    
    static {
        LOCK = new Object();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.timings.lib;

import java.lang.reflect.InvocationTargetException;
import org.bukkit.plugin.Plugin;

enum TimingType
{
    SPIGOT(true) {
        @Override
        MCTiming newTiming(final Plugin plugin, final String command, final MCTiming parent) {
            return new SpigotTiming(command);
        }
    }, 
    MINECRAFT {
        @Override
        MCTiming newTiming(final Plugin plugin, final String command, final MCTiming parent) {
            return new MinecraftTiming(plugin, command, parent);
        }
    }, 
    MINECRAFT_18 {
        @Override
        MCTiming newTiming(final Plugin plugin, final String command, final MCTiming parent) {
            try {
                return new Minecraft18Timing(plugin, command, parent);
            }
            catch (InvocationTargetException | IllegalAccessException ex) {
                return new EmptyTiming();
            }
        }
    }, 
    EMPTY;
    
    private final boolean useCache;
    
    public boolean useCache() {
        return this.useCache;
    }
    
    private TimingType() {
        this(false);
    }
    
    private TimingType(final boolean useCache) {
        this.useCache = useCache;
    }
    
    MCTiming newTiming(final Plugin plugin, final String command, final MCTiming parent) {
        return new EmptyTiming();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.timings.lib;

class EmptyTiming extends MCTiming
{
    @Override
    public final MCTiming startTiming() {
        return this;
    }
    
    @Override
    public final void stopTiming() {
    }
}

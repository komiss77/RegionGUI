// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.libs.timings.lib;

import org.bukkit.Bukkit;
import java.lang.reflect.InvocationTargetException;
import org.bukkit.plugin.Plugin;
import java.lang.reflect.Method;

class Minecraft18Timing extends MCTiming
{
    private final Object timing;
    private static Method startTiming;
    private static Method stopTiming;
    private static Method of;
    
    Minecraft18Timing(final Plugin plugin, final String name, final MCTiming parent) {
        this.timing = Minecraft18Timing.of.invoke(null, plugin, name, (parent instanceof Minecraft18Timing) ? ((Minecraft18Timing)parent).timing : null);
    }
    
    @Override
    public MCTiming startTiming() {
        try {
            if (Minecraft18Timing.startTiming != null) {
                Minecraft18Timing.startTiming.invoke(this.timing, new Object[0]);
            }
        }
        catch (IllegalAccessException ex) {}
        catch (InvocationTargetException ex2) {}
        return this;
    }
    
    @Override
    public void stopTiming() {
        try {
            if (Minecraft18Timing.stopTiming != null) {
                Minecraft18Timing.stopTiming.invoke(this.timing, new Object[0]);
            }
        }
        catch (IllegalAccessException ex) {}
        catch (InvocationTargetException ex2) {}
    }
    
    static {
        try {
            final Class<?> forName = Class.forName("co.aikar.timings.Timing");
            final Class<?> forName2 = Class.forName("co.aikar.timings.Timings");
            Minecraft18Timing.startTiming = forName.getDeclaredMethod("startTimingIfSync", (Class<?>[])new Class[0]);
            Minecraft18Timing.stopTiming = forName.getDeclaredMethod("stopTimingIfSync", (Class<?>[])new Class[0]);
            Minecraft18Timing.of = forName2.getDeclaredMethod("of", Plugin.class, String.class, forName);
        }
        catch (ClassNotFoundException | NoSuchMethodException ex) {
            final Throwable t;
            t.printStackTrace();
            Bukkit.getLogger().severe("Timings18 failed to initialize correctly. Stuff's going to be broken.");
        }
    }
}

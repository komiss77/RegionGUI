// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.events;

import org.bukkit.entity.Player;
import net.crytec.regiongui.data.RegionClaim;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Cancellable;
import org.bukkit.event.player.PlayerEvent;

public class RegionPrePurchaseEvent extends PlayerEvent implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private boolean generateBorder;
    private final RegionClaim claim;
    private int price;
    
    public RegionPrePurchaseEvent(final Player who, final int price, final RegionClaim claim, final boolean generateBorder) {
        super(who);
        this.cancelled = false;
        this.generateBorder = generateBorder;
        this.claim = claim;
        this.price = price;
    }
    
    public boolean getGenerateBorder() {
        return this.generateBorder;
    }
    
    public RegionClaim getRegionClaim() {
        return this.claim;
    }
    
    public int getPrice() {
        return this.price;
    }
    
    public void setPrice(final int price) {
        this.price = price;
    }
    
    public void setGenerateBorder(final boolean value) {
        this.generateBorder = value;
    }
    
    public HandlerList getHandlers() {
        return RegionPrePurchaseEvent.handlers;
    }
    
    public static HandlerList getHandlerList() {
        return RegionPrePurchaseEvent.handlers;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
    
    static {
        handlers = new HandlerList();
    }
}

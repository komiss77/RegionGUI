// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.events;

import org.bukkit.entity.Player;
import java.util.UUID;
import net.crytec.regiongui.data.RegionClaim;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Cancellable;
import org.bukkit.event.player.PlayerEvent;

public class RegionRemoveMemberEvent extends PlayerEvent implements Cancellable
{
    private static final HandlerList handlers;
    private boolean cancelled;
    private final RegionClaim claim;
    private final UUID member;
    
    public RegionRemoveMemberEvent(final Player who, final RegionClaim claim, final UUID target) {
        super(who);
        this.cancelled = false;
        this.claim = claim;
        this.member = target;
    }
    
    public RegionClaim getRegionClaim() {
        return this.claim;
    }
    
    public UUID getMember() {
        return this.member;
    }
    
    public HandlerList getHandlers() {
        return RegionRemoveMemberEvent.handlers;
    }
    
    public static HandlerList getHandlerList() {
        return RegionRemoveMemberEvent.handlers;
    }
    
    public boolean isCancelled() {
        return this.cancelled;
    }
    
    public void setCancelled(final boolean cancelled) {
        this.cancelled = cancelled;
    }
    
    static {
        handlers = new HandlerList();
    }
}

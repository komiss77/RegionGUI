// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.commands;

import net.crytec.regiongui.libs.acf.BaseCommand;

public class LandPurge extends BaseCommand
{
}

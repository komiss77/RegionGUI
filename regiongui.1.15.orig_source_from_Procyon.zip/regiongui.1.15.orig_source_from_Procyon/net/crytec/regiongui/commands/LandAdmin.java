// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.commands;

import net.crytec.regiongui.libs.acf.CommandHelp;
import net.crytec.regiongui.libs.acf.CommandIssuer;
import net.crytec.regiongui.data.RegionClaim;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import org.bukkit.OfflinePlayer;
import net.crytec.regiongui.libs.acf.annotation.Description;
import net.crytec.regiongui.libs.acf.annotation.Subcommand;
import net.crytec.regiongui.libs.acf.annotation.Default;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;
import net.crytec.regiongui.menus.admin.AdminTemplateList;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import org.bukkit.entity.Player;
import net.crytec.regiongui.RegionGUI;
import net.crytec.regiongui.libs.acf.annotation.CommandPermission;
import net.crytec.regiongui.libs.acf.annotation.CommandAlias;
import net.crytec.regiongui.libs.acf.BaseCommand;

@CommandAlias("landadmin")
@CommandPermission("region.admin")
public class LandAdmin extends BaseCommand
{
    private final RegionGUI plugin;
    
    public LandAdmin(final RegionGUI plugin) {
        this.plugin = plugin;
    }
    
    @Default
    public void openEditor(final Player player) {
        SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("Template Editor [" + player.getWorld().getName() + "]").build().open(player);
    }
    
    @Subcommand("editor")
    @Description("Opens the land template editor")
    public void landAdminCommand(final Player player) {
        SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("Template Editor [" + player.getWorld().getName() + "]").build().open(player);
    }
    
    @Subcommand("addregion")
    @Description("Adds a defined worldguard region to a player with a given template, regardless of size or checks. This is a forced action.")
    public void forceAdd(final Player player, final OfflinePlayer owner, final ProtectedRegion region, final RegionClaim claim) {
        this.plugin.getPlayerManager().addClaimToPlayer(owner.getUniqueId(), region, claim);
        player.sendMessage("\ufffd7Assigned region to player. Please note this is a forced action and no size/permission check apply.");
    }
    
    @Subcommand("help")
    public void sendCommandHelp(final CommandIssuer issuer, final CommandHelp help) {
        help.showHelp(issuer);
    }
}

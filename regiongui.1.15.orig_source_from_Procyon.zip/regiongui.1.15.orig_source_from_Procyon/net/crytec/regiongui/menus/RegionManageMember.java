// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import com.sk89q.worldguard.domains.PlayerDomain;
import com.sk89q.worldguard.domains.DefaultDomain;
import org.bukkit.OfflinePlayer;
import java.util.Iterator;
import net.crytec.regiongui.libs.inventoryapi.api.Pagination;
import net.crytec.regiongui.libs.inventoryapi.api.SlotIterator;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import net.crytec.regiongui.util.PlayerChatInput;
import com.sk89q.worldguard.util.profile.Profile;
import com.sk89q.worldguard.WorldGuard;
import net.crytec.regiongui.events.RegionAddMemberEvent;
import net.crytec.regiongui.libs.inventoryapi.api.SlotPos;
import net.crytec.regiongui.libs.commons.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.event.Event;
import net.crytec.regiongui.events.RegionRemoveMemberEvent;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import net.crytec.regiongui.Language;
import net.crytec.regiongui.libs.commons.utils.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.Bukkit;
import java.util.UUID;
import java.util.ArrayList;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.entity.Player;
import net.crytec.regiongui.data.ClaimEntry;
import org.bukkit.inventory.ItemStack;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;

public class RegionManageMember implements InventoryProvider
{
    private static final ItemStack fill;
    private final ClaimEntry claim;
    
    public RegionManageMember(final ClaimEntry claim) {
        this.claim = claim;
    }
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        contents.fillBorders(ClickableItem.empty(RegionManageMember.fill));
        final ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> list = new ArrayList<ClickableItem>();
        final Iterator iterator = protectedRegion.getMembers().getUniqueIds().iterator();
        while (iterator.hasNext()) {
            final OfflinePlayer offlinePlayer = Bukkit.getOfflinePlayer((UUID)iterator.next());
            final String s2 = offlinePlayer.hasPlayedBefore() ? offlinePlayer.getName() : "Unknown Name";
            final ItemStack build = new ItemBuilder(Material.PLAYER_HEAD).name("\ufffdf" + s2).lore(Language.INTERFACE_REMOVE_DESC.toString().replaceAll("%name%", s2)).build();
            if (offlinePlayer.hasPlayedBefore()) {
                final ItemStack itemStack = build;
                final SkullMeta itemMeta = (SkullMeta)itemStack.getItemMeta();
                itemMeta.hasOwner();
                itemMeta.setOwningPlayer(offlinePlayer);
                itemStack.setItemMeta((ItemMeta)itemMeta);
            }
            final UUID target;
            final RegionRemoveMemberEvent regionRemoveMemberEvent;
            final ProtectedRegion protectedRegion2;
            final Pagination pagination2;
            final String replacement;
            list.add(ClickableItem.of(build, p6 -> {
                regionRemoveMemberEvent = new RegionRemoveMemberEvent(player, this.claim.getTemplate(), target);
                Bukkit.getPluginManager().callEvent((Event)regionRemoveMemberEvent);
                if (regionRemoveMemberEvent.isCancelled()) {
                    contents.getHost().open(player);
                    return;
                }
                else {
                    protectedRegion2.getMembers().removePlayer(target);
                    contents.getHost().open(player, pagination2.getPage());
                    UtilPlayer.playSound(player, Sound.BLOCK_LEVER_CLICK);
                    player.sendMessage(Language.INTERFACE_REMOVE_SUCESSFULL.toChatString().replaceAll("%name%", replacement));
                    return;
                }
            }));
        }
        pagination.setItems((ClickableItem[])list.toArray(new ClickableItem[list.size()]));
        pagination.setItemsPerPage(18);
        final OfflinePlayer offlinePlayer2;
        RegionAddMemberEvent regionAddMemberEvent;
        final ProtectedRegion protectedRegion3;
        final DefaultDomain members;
        final PlayerDomain playerDomain;
        contents.set(SlotPos.of(0, 4), ClickableItem.of(new ItemBuilder(Material.WRITABLE_BOOK).name(Language.INTERFACE_MANAGE_BUTTON_ADDMEMBER.toString()).build(), p3 -> {
            player.closeInventory();
            player.sendMessage(Language.REGION_MESSAGE_CHATADDMEMBER.toChatString());
            PlayerChatInput.get(player, s -> {
                Bukkit.getOfflinePlayer(s);
                if (!offlinePlayer2.hasPlayedBefore()) {
                    player.sendMessage(Language.ERROR_INVALID_OFFLINEPLAYER.toChatString());
                }
                else {
                    regionAddMemberEvent = new RegionAddMemberEvent(player, this.claim.getTemplate(), offlinePlayer2.getUniqueId());
                    Bukkit.getPluginManager().callEvent((Event)regionAddMemberEvent);
                    if (regionAddMemberEvent.isCancelled()) {
                        this.reopen(player, contents);
                    }
                    else {
                        protectedRegion3.getMembers();
                        members.getPlayerDomain();
                        playerDomain.addPlayer(offlinePlayer2.getUniqueId());
                        members.setPlayerDomain(playerDomain);
                        protectedRegion3.setMembers(members);
                        protectedRegion3.setDirty(true);
                        WorldGuard.getInstance().getProfileCache().put(new Profile(offlinePlayer2.getUniqueId(), offlinePlayer2.getName()));
                        members.toUserFriendlyComponent(WorldGuard.getInstance().getProfileCache());
                        this.reopen(player, contents);
                    }
                }
            });
            return;
        }));
        contents.set(4, 4, ClickableItem.of(new ItemBuilder(Material.RED_WOOL).name(Language.INTERFACE_BACK.toString()).build(), p1 -> SmartInventory.builder().provider(new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        contents.set(4, 6, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), p3 -> contents.getHost().open(player, pagination.next().getPage())));
        contents.set(4, 2, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), p3 -> contents.getHost().open(player, pagination.previous().getPage())));
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, SlotPos.of(1, 1)).allowOverride(false));
    }
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
}

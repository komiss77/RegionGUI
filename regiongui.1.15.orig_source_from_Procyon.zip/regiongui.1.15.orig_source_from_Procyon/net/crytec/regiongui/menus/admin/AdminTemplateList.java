// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.menus.admin;

import org.bukkit.event.inventory.InventoryClickEvent;
import java.util.Iterator;
import net.crytec.regiongui.util.PlayerChatInput;
import net.crytec.regiongui.libs.inventoryapi.api.SlotPos;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import net.crytec.regiongui.libs.commons.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.ChatColor;
import net.crytec.regiongui.libs.commons.utils.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.regiongui.data.RegionClaim;
import java.util.List;
import java.util.Collections;
import java.util.Collection;
import java.util.ArrayList;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.entity.Player;
import net.crytec.regiongui.RegionGUI;
import net.crytec.regiongui.manager.ClaimManager;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;

public class AdminTemplateList implements InventoryProvider
{
    private final ClaimManager claimManager;
    
    public AdminTemplateList() {
        this.claimManager = RegionGUI.getInstance().getClaimManager();
    }
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        final ArrayList<Comparable> list = new ArrayList<Comparable>(this.claimManager.getTemplates(player.getWorld()));
        Collections.sort(list);
        for (final RegionClaim regionClaim : list) {
            final ItemBuilder itemBuilder = new ItemBuilder((regionClaim.getIcon() == null) ? Material.BARRIER : regionClaim.getIcon().getType());
            itemBuilder.name(ChatColor.translateAlternateColorCodes('&', regionClaim.getDisplayname()));
            final ArrayList lore = new ArrayList<String>(regionClaim.getDescription());
            lore.replaceAll(s -> ChatColor.translateAlternateColorCodes('&', s));
            itemBuilder.lore((List<String>)lore);
            final RegionClaim claim;
            contents.add(ClickableItem.of(itemBuilder.build(), p2 -> {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                SmartInventory.builder().provider(new TemplateEditor(claim)).size(5).title("Editing " + claim.getDisplayname()).build().open(player);
                return;
            }));
        }
        contents.set(SlotPos.of(5, 4), new ClickableItem(new ItemBuilder(Material.EMERALD).name(ChatColor.GREEN + "Create new template").build(), p2 -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            player.closeInventory();
            player.sendMessage(ChatColor.GRAY + "Please enter the name for this template:");
            PlayerChatInput.get(player, p2 -> {
                this.claimManager.registerTemplate(new RegionClaim(player.getWorld()));
                this.claimManager.save();
                this.reopen(player, contents);
            });
        }));
    }
}

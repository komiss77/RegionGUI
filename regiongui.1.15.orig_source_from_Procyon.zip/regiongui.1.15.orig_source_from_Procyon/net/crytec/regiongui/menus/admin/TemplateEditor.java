// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.menus.admin;

import org.bukkit.event.inventory.InventoryClickEvent;
import net.crytec.regiongui.libs.commons.utils.UtilMath;
import net.crytec.regiongui.util.PlayerChatInput;
import com.google.common.collect.Lists;
import org.bukkit.plugin.Plugin;
import net.crytec.regiongui.RegionGUI;
import org.bukkit.Bukkit;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.List;
import net.crytec.regiongui.libs.inventoryapi.api.buttons.InputButton;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import net.crytec.regiongui.libs.commons.utils.UtilPlayer;
import org.bukkit.Sound;
import org.bukkit.Material;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.ChatColor;
import net.crytec.regiongui.libs.commons.utils.item.ItemBuilder;
import net.crytec.regiongui.libs.inventoryapi.api.SlotPos;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.entity.Player;
import net.crytec.regiongui.data.RegionClaim;
import org.bukkit.inventory.ItemStack;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;

public class TemplateEditor implements InventoryProvider
{
    private static final ItemStack filler;
    private final RegionClaim claim;
    
    public TemplateEditor(final RegionClaim claim) {
        this.claim = claim;
    }
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        contents.fillRow(0, ClickableItem.empty(TemplateEditor.filler));
        contents.fillRow(4, ClickableItem.empty(TemplateEditor.filler));
        contents.set(SlotPos.of(0, 4), ClickableItem.of(new ItemBuilder(this.claim.getIcon()).name(ChatColor.GRAY + "Set list icon").lore(ChatColor.GRAY + "Click with an Item on your").lore(ChatColor.GRAY + "curser to set the list icon").build(), inventoryClickEvent -> {
            if (inventoryClickEvent.getClick() == ClickType.LEFT && inventoryClickEvent.getCursor() != null && inventoryClickEvent.getCursor().getType() != Material.AIR) {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setIcon(inventoryClickEvent.getCursor().getType());
                inventoryClickEvent.getView().getBottomInventory().addItem(new ItemStack[] { inventoryClickEvent.getCursor() });
                inventoryClickEvent.getView().setCursor(new ItemStack(Material.AIR));
                this.reopen(player, contents);
            }
            return;
        }));
        contents.set(SlotPos.of(1, 0), new InputButton(new ItemBuilder(Material.NAME_TAG).name(ChatColor.GRAY + "Template").lore(ChatColor.GRAY + "Current name: " + ChatColor.GOLD + this.claim.getDisplayname()).build(), "Name..", displayname -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            this.claim.setDisplayname(displayname);
            SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("\ufffd8Template Editor [" + player.getWorld().getName() + "]").build().open(player);
            return;
        }));
        final List<String> description;
        List<String> description2;
        contents.set(SlotPos.of(2, 0), ClickableItem.of(new ItemBuilder(Material.BOOK).name(ChatColor.GRAY + "Description").lore(ChatColor.GRAY + "Current description:").lore((List<String>)this.claim.getDescription().stream().map(s -> ChatColor.translateAlternateColorCodes('&', s)).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList())).lore("").lore(ChatColor.GREEN + "Left click " + ChatColor.GRAY + "to add a new line").lore(ChatColor.GREEN + "Right click " + ChatColor.GRAY + "to delete the last line.").build(), inventoryClickEvent2 -> {
            if (inventoryClickEvent2.getClick() == ClickType.RIGHT) {
                if (this.claim.getDescription().size() <= 0) {
                    return;
                }
                else {
                    this.claim.getDescription();
                    description.remove(description.size() - 1);
                    this.claim.setDescription(description);
                    this.reopen(player, contents);
                    return;
                }
            }
            else {
                player.closeInventory();
                player.sendMessage(ChatColor.GRAY + "Enter a new line. Type 'exit' to abort");
                PlayerChatInput.get(player, s2 -> {
                    if (s2.equals("exit")) {
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reopen(player, contents));
                    }
                    else {
                        description2 = ((this.claim.getDescription() == null) ? Lists.newArrayList() : this.claim.getDescription());
                        description2.add(s2);
                        this.claim.setDescription(description2);
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reopen(player, contents));
                    }
                });
                return;
            }
        }));
        contents.set(SlotPos.of(1, 1), new InputButton(new ItemBuilder(Material.BLAZE_POWDER).name(ChatColor.GRAY + "Set Permission").lore(ChatColor.GRAY + "Current Permission: " + ChatColor.GOLD + this.claim.getPermission()).build(), "permission..", permission -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            this.claim.setPermission(permission);
            this.reopen(player, contents);
            return;
        }));
        contents.set(SlotPos.of(2, 1), ClickableItem.of(new ItemBuilder(Material.REDSTONE_TORCH).name(ChatColor.GRAY + "Set 'No Permission' description").lore(ChatColor.YELLOW + "This lines will be added below").lore(ChatColor.YELLOW + "the claim description in /land").lore("").lore(ChatColor.GRAY + "Current:").lore(this.claim.getNoPermDescription()).lore(ChatColor.GRAY + "Left click to add a new line").lore(ChatColor.GRAY + "Right click to delete the last line.").build(), inventoryClickEvent3 -> {
            if (inventoryClickEvent3.getClick() == ClickType.RIGHT) {
                if (this.claim.getDescription().size() <= 0) {
                    return;
                }
                else {
                    this.claim.getNoPermDescription().remove(this.claim.getNoPermDescription().size() - 1);
                    this.reopen(player, contents);
                    return;
                }
            }
            else {
                player.closeInventory();
                player.sendMessage(ChatColor.GRAY + "Enter a new line. Type 'exit' to abort");
                PlayerChatInput.get(player, s3 -> {
                    if (s3.equals("exit")) {
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reopen(player, contents));
                    }
                    else {
                        this.claim.getNoPermDescription().add(ChatColor.translateAlternateColorCodes('&', s3));
                        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> this.reopen(player, contents));
                    }
                });
                return;
            }
        }));
        contents.set(SlotPos.of(1, 2), new InputButton(new ItemBuilder(Material.GOLD_NUGGET).name(ChatColor.GRAY + "Price").lore(ChatColor.GRAY + "Current Price: " + ChatColor.GOLD + this.claim.getPrice()).build(), String.valueOf(this.claim.getPrice()), s4 -> {
            if (!UtilMath.isInt(s4)) {
                player.sendMessage(ChatColor.DARK_RED + "Error: The given input is not a valid integer!");
                this.reopen(player, contents);
                return;
            }
            else {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setPrice(Integer.parseInt(s4));
                this.reopen(player, contents);
                return;
            }
        }));
        contents.set(SlotPos.of(2, 2), new InputButton(new ItemBuilder(Material.GOLD_NUGGET).name(ChatColor.GRAY + "Refund").lore(ChatColor.GRAY + "This amount will be \ufffdaadded\ufffd7 to").lore(ChatColor.GRAY + "the players balance on deletion").lore(ChatColor.GRAY + "Current Refund: " + ChatColor.GOLD + this.claim.getRefund()).build(), String.valueOf(this.claim.getRefund()), s5 -> {
            if (!UtilMath.isInt(s5)) {
                player.sendMessage("\ufffdcError: \ufffd7The given input is not a valid integer!");
                this.reopen(player, contents);
                return;
            }
            else {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setRefund(Integer.parseInt(s5));
                this.reopen(player, contents);
                return;
            }
        }));
        contents.set(SlotPos.of(1, 3), new InputButton(new ItemBuilder(Material.BEACON).name(ChatColor.GRAY + "Set Size").lore(ChatColor.GRAY + "Current Size: " + ChatColor.GOLD + this.claim.getSize()).lore(ChatColor.GRAY + "Increasing the size will not update").lore(ChatColor.GRAY + "already claimed/existing regions.").lore(ChatColor.GRAY + "This does only affect new regions").build(), String.valueOf(this.claim.getSize()), s6 -> {
            if (!UtilMath.isInt(s6)) {
                player.sendMessage(ChatColor.RED + "Error: The given input is not a valid integer!");
                this.reopen(player, contents);
                return;
            }
            else {
                UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                this.claim.setSize(Integer.parseInt(s6));
                this.reopen(player, contents);
                return;
            }
        }));
        contents.set(SlotPos.of(1, 5), new ClickableItem(new ItemBuilder(Material.COMMAND_BLOCK).name(ChatColor.GRAY + "Commands").lore(ChatColor.GRAY + "This is a set of commands that will be").lore(ChatColor.GRAY + "executed by the 'player' after").lore(ChatColor.GRAY + "a successfull purchase.").lore(ChatColor.GRAY + "You may use this to set default flags or").lore(ChatColor.GRAY + "whatever you want.").lore(ChatColor.GRAY + "Valid placeholders:").lore(ChatColor.YELLOW + "%player%" + ChatColor.GRAY + " - The players name").lore(ChatColor.YELLOW + "%region%" + ChatColor.GRAY + " - The purchased region").lore(ChatColor.YELLOW + "%world%" + ChatColor.GRAY + " - The worldname").lore("").lore(ChatColor.GRAY + "To run a command from the console,").lore(ChatColor.GRAY + "simply put" + ChatColor.YELLOW + "<server>" + ChatColor.GRAY + " in front").lore("").lore(ChatColor.GRAY + "Right click to " + ChatColor.RED + "delete" + ChatColor.GRAY + " the last command in the list.").lore(ChatColor.GRAY + "Current Commands:").lore(this.claim.getRunCommands()).build(), inventoryClickEvent4 -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            if (inventoryClickEvent4.isRightClick()) {
                if (this.claim.getRunCommands().size() == 0) {
                    return;
                }
                else {
                    this.claim.getRunCommands().remove(this.claim.getRunCommands().size() - 1);
                    this.reopen(player, contents);
                    return;
                }
            }
            else {
                player.closeInventory();
                player.sendMessage(ChatColor.GRAY + "Please enter the command you want to add (without the first slash (/)): ");
                PlayerChatInput.get(player, s7 -> {
                    this.claim.getRunCommands().add(s7);
                    this.reopen(player, contents);
                });
                return;
            }
        }));
        contents.set(SlotPos.of(1, 4), ClickableItem.of(new ItemBuilder(Material.OAK_FENCE).name(ChatColor.GRAY + "Enable Border").lore(ChatColor.GRAY + "Currently enabled: " + (this.claim.isGenerateBorder() ? "yes" : "no")).build(), p2 -> {
            UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
            this.claim.setGenerateBorder(!this.claim.isGenerateBorder());
            this.reopen(player, contents);
            return;
        }));
        contents.set(SlotPos.of(2, 4), ClickableItem.of(new ItemBuilder(this.claim.getBorderMaterial()).name(ChatColor.GRAY + "Set Border Material").lore(ChatColor.GRAY + "Click with an Item on your").lore(ChatColor.GRAY + "curser to set the border material").build(), inventoryClickEvent5 -> {
            if (inventoryClickEvent5.getClick() == ClickType.LEFT && inventoryClickEvent5.getCursor() != null && inventoryClickEvent5.getCursor().getType() != Material.AIR) {
                if (!inventoryClickEvent5.getCursor().getType().isBlock()) {
                    player.sendMessage(ChatColor.DARK_RED + "ERROR: The given material is not a placeable block.");
                    this.reopen(player, contents);
                }
                else {
                    UtilPlayer.playSound(player, Sound.UI_BUTTON_CLICK, 0.5f, 1.0f);
                    this.claim.setBorderMaterial(inventoryClickEvent5.getCursor().getType());
                    inventoryClickEvent5.getView().getBottomInventory().addItem(new ItemStack[] { inventoryClickEvent5.getCursor() });
                    inventoryClickEvent5.getView().setCursor(new ItemStack(Material.AIR));
                    this.reopen(player, contents);
                }
            }
            return;
        }));
        contents.set(SlotPos.of(4, 8), ClickableItem.of(new ItemBuilder(Material.TNT).name(ChatColor.DARK_RED + "Delete template").lore(ChatColor.GRAY + "Deleting this template will remove it").lore(ChatColor.GRAY + "from all players that have already").lore(ChatColor.GRAY + " it.").build(), p2 -> {
            player.closeInventory();
            player.sendMessage(ChatColor.DARK_RED + "Type 'confirm' to confirm the deletion of the selected template:");
            PlayerChatInput.get(player, s8 -> {
                if (s8.equals("confirm")) {
                    UtilPlayer.playSound(player, Sound.ENTITY_GENERIC_EXPLODE, 0.5f, 1.15f);
                    RegionGUI.getInstance().getClaimManager().deleteTemplate(this.claim);
                    this.reopen(player, contents);
                }
                else {
                    this.reopen(player, contents);
                    UtilPlayer.playSound(player, Sound.ENTITY_LEASH_KNOT_PLACE, 1.0f, 0.85f);
                }
            });
            return;
        }));
        contents.set(SlotPos.of(4, 4), ClickableItem.of(new ItemBuilder(Material.EMERALD).name(ChatColor.DARK_GREEN + "Save template").build(), p1 -> {
            RegionGUI.getInstance().getClaimManager().save();
            SmartInventory.builder().provider(new AdminTemplateList()).size(6).title("Template Editor [" + player.getWorld().getName() + "]").build().open(player);
        }));
    }
    
    static {
        filler = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
}

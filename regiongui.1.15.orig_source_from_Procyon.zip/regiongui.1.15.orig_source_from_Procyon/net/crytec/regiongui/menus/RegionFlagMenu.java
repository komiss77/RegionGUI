// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.menus;

import net.crytec.regiongui.data.flags.FlagSetting;
import org.bukkit.event.inventory.InventoryClickEvent;
import net.crytec.regiongui.libs.inventoryapi.api.Pagination;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import net.crytec.regiongui.Language;
import net.crytec.regiongui.libs.commons.utils.item.ItemBuilder;
import org.bukkit.Material;
import net.crytec.regiongui.libs.inventoryapi.api.SlotPos;
import net.crytec.regiongui.libs.inventoryapi.api.SlotIterator;
import java.util.LinkedList;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.entity.Player;
import net.crytec.regiongui.RegionGUI;
import net.crytec.regiongui.data.ClaimEntry;
import net.crytec.regiongui.manager.FlagManager;
import org.bukkit.inventory.ItemStack;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;

public class RegionFlagMenu implements InventoryProvider
{
    private static final ItemStack fill;
    private final FlagManager flagManager;
    private final ClaimEntry claim;
    
    public RegionFlagMenu(final ClaimEntry claim) {
        this.claim = claim;
        this.flagManager = RegionGUI.getInstance().getFlagManager();
    }
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        contents.fillRow(0, ClickableItem.empty(RegionFlagMenu.fill));
        contents.fillRow(4, ClickableItem.empty(RegionFlagMenu.fill));
        final ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        final Pagination pagination = contents.pagination();
        final LinkedList list = new LinkedList();
        final LinkedList<ClickableItem> list2;
        final ProtectedRegion region;
        this.flagManager.getFlagMap().forEach(flagSetting -> {
            if (player.hasPermission(flagSetting.getPermission()) || player.hasPermission("region.flagmenu.all")) {
                list2.add(flagSetting.getButton(player, region, contents));
            }
            return;
        });
        final ClickableItem[] items = list.toArray(new ClickableItem[list.size()]);
        final SlotIterator allowOverride = contents.newIterator(SlotIterator.Type.HORIZONTAL, SlotPos.of(0, 1)).allowOverride(false);
        pagination.setItems(items);
        pagination.setItemsPerPage(27);
        pagination.addToIterator(allowOverride);
        contents.set(4, 4, ClickableItem.of(new ItemBuilder(Material.RED_WOOL).name(Language.INTERFACE_BACK.toString()).build(), p1 -> SmartInventory.builder().provider(new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        if (!pagination.isLast()) {
            contents.set(4, 6, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_NEXT_PAGE.toString()).build(), p3 -> contents.getHost().open(player, pagination.next().getPage())));
        }
        if (!pagination.isFirst()) {
            contents.set(4, 2, ClickableItem.of(new ItemBuilder(Material.MAP).name(Language.INTERFACE_PREVIOUS_PAGE.toString()).build(), p3 -> contents.getHost().open(player, pagination.previous().getPage())));
        }
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, SlotPos.of(0, 1)));
    }
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
}

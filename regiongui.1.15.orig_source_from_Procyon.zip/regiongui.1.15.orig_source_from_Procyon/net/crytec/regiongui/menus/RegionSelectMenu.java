// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import java.util.Iterator;
import net.crytec.regiongui.libs.inventoryapi.api.Pagination;
import net.crytec.regiongui.libs.inventoryapi.api.SlotPos;
import net.crytec.regiongui.libs.inventoryapi.api.SlotIterator;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import net.crytec.regiongui.Language;
import net.crytec.regiongui.libs.commons.utils.item.ItemBuilder;
import org.bukkit.Material;
import org.bukkit.ChatColor;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import java.util.ArrayList;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.entity.Player;
import net.crytec.regiongui.data.ClaimEntry;
import java.util.Set;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;

public class RegionSelectMenu implements InventoryProvider
{
    private final Set<ClaimEntry> claims;
    
    public RegionSelectMenu(final Set<ClaimEntry> claims) {
        this.claims = claims;
    }
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        final Pagination pagination = contents.pagination();
        final ArrayList<ClickableItem> list = new ArrayList<ClickableItem>();
        final Iterator<ClaimEntry> iterator = this.claims.iterator();
        while (iterator.hasNext()) {
            final String string = ChatColor.GREEN + iterator.next().getRegionID();
            final ClaimEntry claim;
            list.add(ClickableItem.of(new ItemBuilder(Material.BOOK).name(string).lore(Language.INTERFACE_SELECT_DESCRIPTION.toString().replace("%region%", string)).build(), p2 -> SmartInventory.builder().provider(new RegionManageInterface(claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        }
        pagination.setItems((ClickableItem[])list.toArray(new ClickableItem[list.size()]));
        pagination.setItemsPerPage(18);
        pagination.addToIterator(contents.newIterator(SlotIterator.Type.HORIZONTAL, SlotPos.of(0, 1)));
    }
}

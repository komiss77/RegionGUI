// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.menus;

import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.OfflinePlayer;
import net.crytec.regiongui.util.RegionUtils;
import net.crytec.regiongui.RegionGUI;
import net.crytec.regiongui.libs.inventoryapi.SmartInventory;
import net.crytec.regiongui.Language;
import net.crytec.regiongui.libs.commons.utils.item.ItemBuilder;
import org.bukkit.Material;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import net.crytec.regiongui.libs.inventoryapi.api.ClickableItem;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryContent;
import org.bukkit.entity.Player;
import net.crytec.regiongui.data.ClaimEntry;
import org.bukkit.inventory.ItemStack;
import net.crytec.regiongui.libs.inventoryapi.api.InventoryProvider;

public class RegionDeleteConfirm implements InventoryProvider
{
    private static final ItemStack fill;
    private final ClaimEntry claim;
    
    public RegionDeleteConfirm(final ClaimEntry claim) {
        this.claim = claim;
    }
    
    @Override
    public void init(final Player player, final InventoryContent contents) {
        contents.fill(ClickableItem.empty(RegionDeleteConfirm.fill));
        if (!this.claim.getProtectedRegion().isPresent()) {
            System.out.println("Claim not present");
            player.closeInventory();
            return;
        }
        final ProtectedRegion protectedRegion = this.claim.getProtectedRegion().get();
        contents.set(0, 2, ClickableItem.of(new ItemBuilder(Material.REDSTONE).name(Language.INTERFACE_DELETE_ABORT_BUTTON.toString()).build(), p1 -> SmartInventory.builder().provider(new RegionManageInterface(this.claim)).size(3).title(Language.INTERFACE_MANAGE_TITLE.toString()).build().open(player)));
        final ProtectedRegion region;
        contents.set(0, 6, ClickableItem.of(new ItemBuilder(Material.EMERALD).name(Language.INTERFACE_DELETE_CONFIRM_BUTTON.toString()).build(), p2 -> {
            player.closeInventory();
            RegionGUI.getInstance().getPlayerManager().deleteClaim(player.getUniqueId(), region);
            RegionUtils.getRegionManager(player.getWorld()).removeRegion(region.getId());
            RegionUtils.saveRegions(player.getWorld());
            if (this.claim.getTemplate().hasRefund()) {
                RegionGUI.getInstance().getEconomy().depositPlayer((OfflinePlayer)player, (double)this.claim.getTemplate().getRefund());
                player.sendMessage(Language.REGION_REMOVED_REFUNDED.toString().replaceAll("%refund%", String.valueOf(this.claim.getTemplate().getRefund())));
            }
            player.sendMessage(Language.REGION_REMOVED.toChatString());
        }));
    }
    
    static {
        fill = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
    }
}

// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.util;

import com.sk89q.worldguard.domains.PlayerDomain;
import com.sk89q.worldguard.domains.DefaultDomain;
import org.bukkit.plugin.Plugin;
import org.bukkit.event.Event;
import net.crytec.regiongui.events.RegionPurchasedEvent;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.util.profile.Profile;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import com.sk89q.worldedit.math.BlockVector3;
import org.bukkit.util.Vector;
import net.crytec.regiongui.Language;
import com.sk89q.worldguard.bukkit.WorldGuardPlugin;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldguard.WorldGuard;
import org.bukkit.plugin.java.JavaPlugin;
import com.sk89q.worldguard.LocalPlayer;
import com.sk89q.worldguard.protection.managers.RegionManager;
import org.bukkit.Location;
import net.crytec.regiongui.data.RegionClaim;
import org.bukkit.entity.Player;
import net.crytec.regiongui.RegionGUI;

public class PlotBuilder
{
    private final RegionGUI plugin;
    private final Player player;
    private final String displayname;
    private final RegionClaim claim;
    private final Location loc;
    private final RegionManager manager;
    private final LocalPlayer localPlayer;
    
    public PlotBuilder(final Player player, final String displayname, final RegionClaim claim) {
        this.plugin = (RegionGUI)JavaPlugin.getPlugin((Class)RegionGUI.class);
        this.player = player;
        this.displayname = displayname;
        this.claim = claim;
        this.loc = player.getLocation();
        this.manager = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(player.getWorld()));
        this.localPlayer = WorldGuardPlugin.inst().wrapPlayer(player);
    }
    
    public void build() {
        final int blockX = this.loc.getBlockX();
        final int blockZ = this.loc.getBlockZ();
        final int blockY = this.loc.getBlockY();
        final int size = this.claim.getSize();
        if (this.claim.getPermission() != null && !this.claim.getPermission().isEmpty() && !this.player.hasPermission(this.claim.getPermission())) {
            this.player.sendMessage(Language.ERROR_NO_PERMISSION.toChatString().replaceAll("%permission%", this.claim.getPermission()));
            return;
        }
        final int n = (int)Math.round(size / 2.0);
        final Vector vector = new Vector(blockX + n, blockY + this.claim.getHeight(), blockZ + n);
        final Vector vector2 = new Vector(blockX - n, blockY - this.claim.getDepth(), blockZ - n);
        final ProtectedCuboidRegion region = new ProtectedCuboidRegion(this.plugin.getConfig().getString("region-identifier").replace("%player%", this.player.getName()).replace("%displayname%", this.displayname), BlockVector3.at(vector.getBlockX(), vector.getBlockY(), vector.getBlockZ()), BlockVector3.at(vector2.getBlockX(), vector2.getBlockY(), vector2.getBlockZ()));
        if (this.manager.overlapsUnownedRegion((ProtectedRegion)region, this.localPlayer) && this.plugin.getConfig().getBoolean("preventRegionOverlap", true)) {
            this.player.sendMessage(Language.ERROR_OVERLAP.toString());
            return;
        }
        final int price = this.claim.getPrice();
        final DefaultDomain owners = ((ProtectedRegion)region).getOwners();
        final PlayerDomain playerDomain = owners.getPlayerDomain();
        WorldGuard.getInstance().getProfileCache().put(new Profile(this.player.getUniqueId(), this.player.getName()));
        playerDomain.addPlayer(this.player.getUniqueId());
        owners.setPlayerDomain(playerDomain);
        ((ProtectedRegion)region).setOwners(owners);
        ((ProtectedRegion)region).setFlag((Flag)Flags.TELE_LOC, (Object)BukkitAdapter.adapt(this.player.getLocation()));
        if (!RegionGUI.getInstance().getEconomy().withdrawPlayer((OfflinePlayer)this.player.getPlayer(), (double)price).transactionSuccess()) {
            this.player.sendMessage(Language.ERROR_NO_MONEY.toChatString());
            return;
        }
        this.player.sendMessage(Language.REGION_CREATE_MONEY.toChatString().replace("%money%", "" + price).replace("%currencyname%", RegionGUI.getInstance().getEconomy().currencyNameSingular()));
        ((ProtectedRegion)region).setDirty(true);
        if (this.claim.isGenerateBorder()) {
            new Walls(this.claim, (ProtectedRegion)region);
        }
        this.manager.addRegion((ProtectedRegion)region);
        this.player.sendMessage(Language.REGION_CREATE_SUCCESS.toChatString());
        RegionGUI.getInstance().getPlayerManager().addClaimToPlayer(this.player.getUniqueId(), (ProtectedRegion)region, this.claim);
        Bukkit.getScheduler().runTask((Plugin)RegionGUI.getInstance(), () -> Bukkit.getPluginManager().callEvent((Event)new RegionPurchasedEvent(this.player, price, this.claim, (ProtectedRegion)region)));
    }
}

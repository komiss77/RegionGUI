// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.util;

import com.google.common.collect.Maps;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.EventPriority;
import org.bukkit.event.EventHandler;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.entity.Player;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import net.crytec.regiongui.RegionGUI;
import java.util.function.Consumer;
import java.util.UUID;
import java.util.HashMap;
import org.bukkit.event.Listener;

public class PlayerChatInput implements Listener
{
    private static final HashMap<UUID, Consumer<String>> players;
    private final RegionGUI plugin;
    
    public PlayerChatInput(final RegionGUI core) {
        this.plugin = core;
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)core);
    }
    
    public static void get(final Player player, final Consumer<String> result) {
        PlayerChatInput.players.put(player.getUniqueId(), result);
    }
    
    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(final AsyncPlayerChatEvent event) {
        if (PlayerChatInput.players.containsKey(event.getPlayer().getUniqueId())) {
            final Consumer<String> consumer = PlayerChatInput.players.get(event.getPlayer().getUniqueId());
            PlayerChatInput.players.remove(event.getPlayer().getUniqueId());
            Bukkit.getScheduler().runTask((Plugin)this.plugin, () -> consumer.accept(event.getMessage()));
            event.setCancelled(true);
        }
    }
    
    @EventHandler
    public void onQuit(final PlayerQuitEvent e) {
        PlayerChatInput.players.remove(e.getPlayer().getUniqueId());
    }
    
    static {
        players = Maps.newHashMap();
    }
}

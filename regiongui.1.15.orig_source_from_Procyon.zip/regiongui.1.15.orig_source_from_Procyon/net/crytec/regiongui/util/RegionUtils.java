// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.util;

import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldedit.math.BlockVector3;
import java.util.Collection;
import java.util.ArrayList;
import org.bukkit.util.Vector;
import java.util.List;
import com.sk89q.worldguard.protection.regions.ProtectedRegion;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.managers.storage.StorageException;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import org.bukkit.World;
import net.crytec.regiongui.libs.apache.commons.EnumUtils;
import org.bukkit.Material;
import com.sk89q.worldguard.internal.platform.WorldGuardPlatform;

public class RegionUtils
{
    private static final WorldGuardPlatform platform;
    
    public static boolean validateMaterial(final String material) {
        return EnumUtils.isValidEnum(Material.class, material);
    }
    
    public static boolean saveRegions(final World world) {
        try {
            RegionUtils.platform.getRegionContainer().get(BukkitAdapter.adapt(world)).saveChanges();
            return true;
        }
        catch (StorageException ex) {
            ex.printStackTrace();
            return false;
        }
    }
    
    public static RegionManager getRegionManager(final World world) {
        return RegionUtils.platform.getRegionContainer().get(BukkitAdapter.adapt(world));
    }
    
    public static List<Vector> getLocationsFromRegion(final ProtectedRegion region) {
        final BlockVector3 minimumPoint = region.getMinimumPoint();
        final BlockVector3 maximumPoint = region.getMaximumPoint();
        final int n = region.getMaximumPoint().getY() - region.getMinimumPoint().getY();
        final ArrayList<Object> list = new ArrayList<Object>();
        final ArrayList<Vector> list2 = new ArrayList<Vector>();
        list2.add(new Vector(minimumPoint.getX(), minimumPoint.getY(), minimumPoint.getZ()));
        list2.add(new Vector(maximumPoint.getX(), minimumPoint.getY(), minimumPoint.getZ()));
        list2.add(new Vector(maximumPoint.getX(), minimumPoint.getY(), maximumPoint.getZ()));
        list2.add(new Vector(minimumPoint.getX(), minimumPoint.getY(), maximumPoint.getZ()));
        for (int i = 0; i < list2.size(); ++i) {
            final Vector vector = list2.get(i);
            Vector p2;
            if (i + 1 < list2.size()) {
                p2 = list2.get(i + 1);
            }
            else {
                p2 = list2.get(0);
            }
            final Vector add = vector.add(new Vector(0, n, 0));
            final Vector add2 = p2.add(new Vector(0, n, 0));
            list.addAll(regionLine(vector, p2));
            list.addAll(regionLine(add, add2));
            list.addAll(regionLine(vector, add));
            for (double n2 = 2.0; n2 < n; n2 += 2.0) {
                list.addAll(regionLine(vector.add(new Vector(0.0, n2, 0.0)), p2.add(new Vector(0.0, n2, 0.0))));
            }
        }
        return (List<Vector>)list;
    }
    
    public static List<Vector> regionLine(final Vector p1, final Vector p2) {
        final ArrayList<Vector> list = new ArrayList<Vector>();
        final int n = (int)(p1.distance(p2) / 1.0) + 1;
        final Vector multiply = p2.subtract(p1).normalize().multiply(p1.distance(p2) / (n - 1));
        for (int i = 0; i < n; ++i) {
            list.add(p1.add(multiply.multiply(i)));
        }
        return list;
    }
    
    static {
        platform = WorldGuard.getInstance().getPlatform();
    }
}

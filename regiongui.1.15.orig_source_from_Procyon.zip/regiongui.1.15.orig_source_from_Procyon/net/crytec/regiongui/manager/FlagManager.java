// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.manager;

import java.util.Iterator;
import org.bukkit.permissions.Permission;
import org.bukkit.permissions.PermissionDefault;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.List;
import java.util.function.Function;
import java.util.Comparator;
import java.io.IOException;
import org.bukkit.ChatColor;
import net.crytec.regiongui.libs.apache.commons.EnumUtils;
import org.bukkit.Material;
import com.sk89q.worldguard.protection.flags.LocationFlag;
import com.sk89q.worldguard.protection.flags.Flag;
import com.sk89q.worldguard.WorldGuard;
import java.io.File;
import com.google.common.collect.Lists;
import net.crytec.regiongui.RegionGUI;
import java.util.ArrayList;
import org.bukkit.configuration.file.YamlConfiguration;
import net.crytec.regiongui.data.flags.FlagSetting;
import java.util.LinkedList;

public class FlagManager
{
    private final LinkedList<FlagSetting> settings;
    private final LinkedList<FlagSetting> flags;
    private final YamlConfiguration flagConfig;
    private final ArrayList<String> forbiddenFlags;
    
    public FlagManager(final RegionGUI plugin) {
        this.settings = (LinkedList<FlagSetting>)Lists.newLinkedList();
        this.flags = (LinkedList<FlagSetting>)Lists.newLinkedList();
        (this.forbiddenFlags = (ArrayList<String>)Lists.newArrayList()).add("receive-chat");
        this.forbiddenFlags.add("allowed-cmds");
        this.forbiddenFlags.add("blocked-cmds");
        this.forbiddenFlags.add("send-chat");
        this.forbiddenFlags.add("invincible");
        this.forbiddenFlags.add("command-on-entry");
        this.forbiddenFlags.add("command-on-exit");
        this.forbiddenFlags.add("console-command-on-entry");
        this.forbiddenFlags.add("console-command-on-exit");
        this.forbiddenFlags.add("godmode");
        this.forbiddenFlags.add("worldedit");
        this.forbiddenFlags.add("chunk-unload");
        this.forbiddenFlags.add("passthrough");
        this.forbiddenFlags.add("price");
        this.flagConfig = YamlConfiguration.loadConfiguration(new File(plugin.getDataFolder(), "flags.yml"));
        boolean b = false;
        for (final Flag flag : WorldGuard.getInstance().getFlagRegistry().getAll()) {
            if (!this.forbiddenFlags.contains(flag.getName())) {
                if (flag instanceof LocationFlag) {
                    continue;
                }
                final String string = "flags." + flag.getName() + ".";
                if (!this.flagConfig.isSet("flags." + flag.getName() + ".name")) {
                    this.flagConfig.set(string + "name", (Object)("&7" + flag.getName()));
                    this.flagConfig.set(string + "enabled", (Object)true);
                    this.flagConfig.set(string + "icon", (Object)Material.LIGHT_GRAY_DYE.toString());
                    b = true;
                }
                Material icon = Material.BARRIER;
                if (EnumUtils.isValidEnum((Class<Enum>)Material.class, this.flagConfig.getString(string + "icon"))) {
                    icon = Material.valueOf(this.flagConfig.getString(string + "icon"));
                }
                if (!this.flagConfig.getBoolean(string + "enabled")) {
                    continue;
                }
                this.addFlags(flag.getName(), (Flag<?>)flag, icon, ChatColor.translateAlternateColorCodes('&', this.flagConfig.getString(string + "name")));
            }
        }
        if (b) {
            try {
                this.flagConfig.save(new File(plugin.getDataFolder(), "flags.yml"));
            }
            catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        this.settings.sort(Comparator.comparing((Function<? super Object, ? extends Comparable>)FlagSetting::getId));
        this.getFlagMap().stream().map((Function<? super Object, ?>)FlagSetting::getPermission).collect((Collector<? super Object, ?, List<? super Object>>)Collectors.toList()).forEach(permission -> new Permission("region.flagmenu.all", "Allow the useage of all flags", PermissionDefault.FALSE).getChildren().put(permission.getName(), permission.getDefault().getValue(false)));
    }
    
    public void addFlags(final String idenfifier, final Flag<?> flag, final Material icon, final String displayname) {
        this.flags.add(new FlagSetting(idenfifier, flag, icon, displayname));
    }
    
    public LinkedList<FlagSetting> getFlagMap() {
        return this.flags;
    }
}

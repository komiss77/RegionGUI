// 
// Decompiled by Procyon v0.5.36
// 

package net.crytec.regiongui.manager;

import net.crytec.regiongui.data.ClaimEntry;
import java.io.IOException;
import java.util.Iterator;
import org.bukkit.configuration.file.YamlConfiguration;
import com.google.common.io.Files;
import java.util.Optional;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import java.util.Set;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.Bukkit;
import com.google.common.collect.Maps;
import net.crytec.regiongui.RegionGUI;
import java.io.File;
import net.crytec.regiongui.data.RegionClaim;
import java.util.UUID;
import java.util.LinkedHashMap;
import org.bukkit.event.Listener;

public class ClaimManager implements Listener
{
    private final LinkedHashMap<UUID, RegionClaim> templates;
    private final File templateFolder;
    
    public ClaimManager(final RegionGUI plugin) {
        this.templates = (LinkedHashMap<UUID, RegionClaim>)Maps.newLinkedHashMap();
        Bukkit.getPluginManager().registerEvents((Listener)this, (Plugin)plugin);
        this.templateFolder = new File(plugin.getDataFolder(), "templates");
        if (!this.templateFolder.exists()) {
            this.templateFolder.mkdir();
        }
        this.loadTemplates();
    }
    
    public void registerTemplate(final RegionClaim claim) {
        this.templates.put(claim.getId(), claim);
    }
    
    public Set<RegionClaim> getTemplates(final World world) {
        return this.templates.values().stream().filter(regionClaim -> regionClaim.getWorld().isPresent()).filter(regionClaim2 -> regionClaim2.getWorld().get().equals(world)).collect((Collector<? super RegionClaim, ?, Set<RegionClaim>>)Collectors.toSet());
    }
    
    public Optional<RegionClaim> getByName(final World world, final String name) {
        return this.templates.values().stream().filter(regionClaim -> regionClaim.getWorld().isPresent()).filter(regionClaim2 -> regionClaim2.getWorld().get().equals(world) && regionClaim2.getDisplayname().equals(name)).findFirst();
    }
    
    public RegionClaim getClaimByID(final UUID uuid) {
        return this.templates.get(uuid);
    }
    
    public void deleteTemplate(final RegionClaim claim) {
        this.templates.remove(claim.getId());
        final File file = new File(this.templateFolder, claim.getId().toString() + ".claim");
        if (file.exists()) {
            file.delete();
        }
        RegionGUI.getInstance().getPlayerManager().getPlayerdata().values().forEach(set -> set.removeIf(claimEntry -> claimEntry.getTemplate().equals(claim)));
    }
    
    public void loadTemplates() {
        for (final File file : Files.fileTreeTraverser().breadthFirstTraversal((Object)this.templateFolder).filter(file -> file.getName().endsWith(".claim"))) {
            try {
                final RegionClaim value = (RegionClaim)YamlConfiguration.loadConfiguration(file).getSerializable("data", (Class)RegionClaim.class);
                this.templates.put(value.getId(), value);
            }
            catch (Exception ex) {
                RegionGUI.getInstance().getLogger().severe("Failed to load template from file " + file.getName());
                ex.printStackTrace();
            }
        }
    }
    
    public void save() {
        for (final RegionClaim regionClaim : this.templates.values()) {
            try {
                final File file = new File(this.templateFolder, regionClaim.getId().toString() + ".claim");
                if (!file.exists()) {
                    file.createNewFile();
                }
                final YamlConfiguration loadConfiguration = YamlConfiguration.loadConfiguration(file);
                loadConfiguration.set("data", (Object)regionClaim);
                loadConfiguration.save(file);
            }
            catch (IOException ex) {
                RegionGUI.getInstance().getLogger().severe("Failed to save template to disk!");
            }
        }
    }
}
